/*!
 *  \file      gpaVaporator.h
 *  \brief     Класс, описывающий аппарат воздушного охлаждения
 *  \author    Фролов Алексей
 *  \date      2024
 */
#ifndef GPA_VAPORATOR_H
#define GPA_VAPORATOR_H

#include "gpaBlinds.h"
#include "gpaBoundaryCondition.h"
#include "gpaDryAir.h"
#include "gpaExportSystem.h"
#include "gpaFan.h"
#include "gpaFixedGeometry.h"
#include "gpaFrictionExponential.h"
#include "gpaInclude.h"
#include "gpaInstantTransfer.h"
#include "gpaOuterFlow.h"
#include "gpaPowerHeatCoef.h"
#include "gpaTemperatureCondition.h"
#include "gpaTemperatureMixStream.h"
#include "gpaUPipesGeometry.h"
#include "gpaVaporatorPipe.h"
#include "gpaVolumeRateCondition.h"

/*!
 * \class gpaVaporator
 * \brief Класс, реализующий аппарат воздушного охлаждения
 */
class gpaVaporator : public gpaExportSystem {
public:
  /*!
   * Конструктор с параметрами
   * \param interfaces интерфейсы интегратора
   * \param importRef ссылка на парный аппарат в интеграторе
   */
  gpaVaporator(const gpaCoreInterfaces *interfaces, gpaCoreReference importRef);
  /*!
   * Конструктор копирования
   * \param cooler ссылка на аппарат воздушного охлаждения
   */
  gpaVaporator(const gpaVaporator &cooler) = delete;
  /*!
   * Деструктор
   */
  virtual ~gpaVaporator() override = default;
  /*!
   * Функция копирования аппарата воздушного охлаждения
   * \return скопированный аппарат воздушного охлаждения
   */
  virtual gpaVaporator *copy() const override { return NULL; }
  /*!
   * Получить имя типа аппарата
   * \return имя типа аппарата
   */
  virtual const gpaString &getTypeName() const override {
    return getDeviceTypeName();
  }
  /*!
   * Получить описание аппарата
   * \return описание аппарата
   */
  virtual const gpaString &getDescription() const override {
    return getDeviceDescription();
  }
  /*!
   * Функция получения количества материальных контуров элемента
   * \return количество материальных контуров элемента
   */
  virtual gpaUInt getNumMixCircuits() const override {
    return getDeviceNumMixCircuits();
  }
  /*!
   * Функция получения минимального количества портов в материальном контуре
   * элемента
   * \param index индекс контура
   * \return минимальное количество портов
   */
  virtual gpaUInt getMinNumMixPorts(gpaUInt index) const override {
    return getDeviceMinNumMixPorts(index);
  }
  /*!
   * Функция получения максимального количества портов в материальном контуре
   * элемента
   * \param index индекс контура
   * \return максимальное количество портов
   */
  virtual gpaUInt getMaxNumMixPorts(gpaUInt index) const override {
    return getDeviceMaxNumMixPorts(index);
  }
  /*!
   * Инициализировать аппарат
   * \return код операции
   */
  virtual gpaResult initialize() override;
  /*!
   * Установить значения сигналов
   * \param [out] signals значения сигналов
   * \return код операции
   */
  virtual gpaResult setSignals(const gpaConstVector &signals) override;
  /*!
   * Рассчитать значения сенсоров
   * \param [out] sensors вектор сенсоров
   * \return код операции
   */
  virtual gpaResult calcSensors(gpaVector &sensors) const override;

protected:
  /*!
   * Функция получения вектора с описаниями параметров аппарата
   * \return вектор с описаниями параметров аппарата
   */
  virtual const gpaParameterInfoVector *getParamsInfo() const override {
    return getParametersInfo();
  }
  /*!
   * Функция получения вектора с описаниями сенсоров модели аппарата
   * \return вектор с описаниями сенсоров модели аппарата
   */
  virtual const gpaSensorInfoVector *getSensesInfo() const override {
    return getSensorsInfo();
  }
  /*!
   * Функция проверки значений параметров модели аппарата
   * \param values вектор параметров модели аппарата
   * \return код операции
   */
  virtual gpaResult
  checkParamValues(const gpaExtParameter *values) const override;
  /*!
   * Функция назначения параметров модели аппарата
   * \param values вектор параметров модели аппарата
   * \param checkNeeded флаг о необходимости проверить параметры
   * \return код операции
   */
  virtual gpaResult setParamValues(const gpaExtParameter *values,
                                   bool checkNeeded = true) override;

private:
  //! Охлаждающий воздух
  gpaDryAir m_air;
  //! Трубы в АВО
  gpaVaporatorPipe m_heatPipes;
  //! Модель геометрии труб
  gpaUPipesGeometry *m_pipesGeom;
  //! Модель сопротивления труб
  gpaFrictionExponential *m_frictionModel;
  //! Модель расчета коэффициента теплопередачи труб
  gpaPowerHeatCoef *m_heatCoef;
  //! Поток воздуха по трубам
  gpaOuterFlow m_airFlow;
  //! Теплообмен конвекцией с оребрением
  gpaInstantTransfer m_convection;
  //! Составляющая граничного условия на входе воздуха на его расход
  gpaVolumeRateCondition *m_inletRate;
  //! Составляющая граничного условия на входе воздуха на его температуру
  gpaTemperatureCondition *m_inletTemp;
  //! Граничные условия на входе воздуха
  gpaBoundaryCondition m_airInlet;
  //! Граничные условия на выходе воздуха
  gpaBoundaryCondition m_airOutlet;
  //! Точка входа воздуха
  gpaTemperatureMixStream m_airInletStr;
  //! Точка выхода воздуха
  gpaTemperatureMixStream m_airOutletStr;
  //! Вентилятор
  gpaFan m_fan;
  //! Жалюзи
  gpaBlinds m_blinds;
  /*!
   * Назначить имена аппаратам и потокам
   */
  void setNames();
  /*!
   * Инициализировать поток смеси
   * \param values вектор параметров модели аппарата
   * \return результат операции
   */
  gpaResult initMixtureFlow(const gpaExtParameter *values);
  /*!
   * Инициализировать поток воздуха
   * \param values вектор параметров модели аппарата
   * \return результат операции
   */
  gpaResult initAirFlow(const gpaExtParameter *values);
  /*!
   * Инициализировать теплопередачу
   * \param values вектор параметров модели аппарата
   * \return результат операции
   */
  gpaResult initHeatTransfer(const gpaExtParameter *values);
  /*!
   * Обновить поток жалюзи
   * \param values вектор параметров модели аппарата
   * \return результат операции
   */
  gpaResult initAirDevices(const gpaExtParameter *values);
  /*!
   * Соединить аппараты и потоки в аппарате
   */
  gpaResult buildDevice();
  /*!
   * Обновить граничные условия для потока воздуха
   * \param values вектор параметров модели аппарата
   * \return результат операции
   */
  gpaResult updateAirInlet();

public:
  /*!
   * Получить название типа аппарата
   * \return название типа аппарата
   */
  static const gpaString &getDeviceTypeName() { return m_typeName; }
  /*!
   * Получить описание аппарата
   * \return описание аппарата
   */
  static const gpaString &getDeviceDescription() { return m_description; }
  /*!
   * Получить количество материальных контуров элемента
   * \return количество материальных контуров элемента
   */
  static gpaUInt getDeviceNumMixCircuits();
  /*!
   * Получить минимальное количество подключенных материальных потоков
   * \param index индекс материального контура
   * \return минимальное количество подключенных материальных потоков
   */
  static gpaUInt getDeviceMinNumMixPorts(gpaUInt index);
  /*!
   * Получить максимальное количество подключенных материальных потоков
   * \param index индекс материального контура
   * \return максимальное количество подключенных материальных потоков
   */
  static gpaUInt getDeviceMaxNumMixPorts(gpaUInt index);
  /*!
   * Получить вектор описаний параметров аппарата
   * \return вектор описаний параметров аппарата
   */
  static const gpaParameterInfoVector *getParametersInfo() {
    return &m_parameters;
  }
  /*!
   * Получить вектор описаний сенсоров модели
   * \return вектор описаний сенсоров модели
   */
  static const gpaSensorInfoVector *getSensorsInfo() { return &m_sensors; }
  /*!
   * Функция получения названия материального контура элемента
   * \param index индекс контура
   * \return название материального контура элемента
   */
  virtual const gpaString *getMixCircuitName(gpaUInt index) const override {
    return getDeviceMixCircuitName(index);
  }
  /*!
   * Функция получения названия порта в материальном контуре элемента
   * \param circIdx индекс контура
   * \param portIdx индекс порта
   * \return название порта
   */
  virtual const gpaString *getMixPortName(gpaUInt circIdx,
                                          gpaUInt portIdx) const override {
    return getDeviceMixPortName(circIdx, portIdx);
  }
  /*!
   * Получить название материального порта элемента
   * \param index индекс контура
   * \return название материального порта элемента
   */
  static const gpaString *getDeviceMixCircuitName(gpaUInt index);

  /*!
   * Получить название материального порта элемента
   * \param index индекс контура
   * \return название материального порта элемента
   */
  static const gpaString *getDeviceMixPortName(gpaUInt circIdx,
                                               gpaUInt portIdx);

private:
  //! Название аппарата
  static const gpaString m_typeName;
  //! Описание аппарата
  static const gpaString m_description;
  //! Вектор описаний параметров аппарата
  static const gpaParameterInfoVector m_parameters;
  //! Вектор описаний сенсоров модели
  static const gpaSensorInfoVector m_sensors;

  //! Массив названий портов элемента
  static const gpaStringVector m_portNames;

  //! Массив названий контуров элемента
  static const gpaStringVector m_circuitNames;
};

#endif
