#include "gpaNitrogenTank.h"
#include "gpaEllipseVerticalCylinder.h"
#include "gpaLogMeanTempDifference.h"
#include "gpaThinWall.h"
#include "gpaZeroRadiation.h"

constexpr gpaUInt ID_CIRCUIT = 0;
constexpr gpaUInt NUM_CIRCUITS = 1;

constexpr gpaUInt GPA_N01_INLET = 0;
constexpr gpaUInt GPA_N03_ANY = 1;
constexpr gpaUInt GPA_N04_OUTLET = 2;
constexpr gpaUInt GPA_N12_INLET = 3;
constexpr gpaUInt GPA_N15_OUTLET = 4;
constexpr gpaUInt GPA_N18_INLET = 5;
constexpr gpaUInt NUM_PORTS = 6;

constexpr gpaUInt ID_PARAM_PRES0 = 0x00;
constexpr gpaUInt ID_PARAM_TEMP0 = 0x01;
constexpr gpaUInt ID_PARAM_D = 0x02;
constexpr gpaUInt ID_PARAM_Y = 0x03;
constexpr gpaUInt ID_PARAM_H = 0x04;
constexpr gpaUInt ID_PARAM_FRACTIONS = 0x05;
constexpr gpaUInt ID_PARAM_OUT_TEMPERATURE = 0x06;
constexpr gpaUInt ID_PARAM_OUT_CONDUCTIVITY = 0x07;
constexpr gpaUInt ID_PARAM_WALL_THICKNESS = 0x08;
constexpr gpaUInt ID_PARAM_WALL_CONDUCTIVITY = 0x09;

constexpr gpaUInt ID_SENSOR_PRESSURE = 0x00;
constexpr gpaUInt ID_SENSOR_TEMPERATURE = 0x01;
constexpr gpaUInt ID_SENSOR_INLET_PRES = 0x02;
constexpr gpaUInt ID_SENSOR_OUT_GAS_PRES = 0x03;
constexpr gpaUInt ID_SENSOR_OUT_LIQ_PRES = 0x04;
constexpr gpaUInt ID_SENSOR_LIQUID_LEVEL = 0x05;
constexpr gpaUInt ID_SENSOR_LEV_FULLNESS = 0x06;
constexpr gpaUInt ID_SENSOR_VOL_FULLNESS = 0x07;
constexpr gpaUInt ID_SENSOR_GAS_DELTA_PRES = 0x08;
constexpr gpaUInt ID_SENSOR_LIQ_DELTA_PRES = 0x09;
constexpr gpaUInt ID_SENSOR_FRACTION0 = 0x0A;
constexpr gpaUInt ID_SENSOR_FRACTION1 = 0x0B;
constexpr gpaUInt ID_SENSOR_FRACTION2 = 0x0C;
constexpr gpaUInt ID_SENSOR_FRACTION3 = 0x0D;
constexpr gpaUInt ID_SENSOR_FRACTION4 = 0x0E;
constexpr gpaUInt ID_SENSOR_FRACTION5 = 0x0F;

const gpaString gpaNitrogenTank::m_typeName = "nitrogen-tank";
const gpaString gpaNitrogenTank::m_description = "Блок хранения азота";

const gpaParameterInfoVector gpaNitrogenTank::m_parameters = {
    realParam("initial-pressure", "Начальное давление", GPA_PRESSURE_UNIT,
              false, 1e+3),
    realParam("initial-temp", "Начальная температура", GPA_TEMPERATURE_UNIT,
              false, 0.0),
    realParam("d", "Рабочий внутренний диаметр аппарата", GPA_LENGTH_UNIT,
              false, 1.2),
    realParam("y", "Высота подъема шаровой части аппарата", GPA_LENGTH_UNIT,
              false, 0.6),
    realParam("H", "Высота цилиндрической рабочей части аппарата",
              GPA_LENGTH_UNIT, false, 2.3),
    realVecFracsParam("fractions", "Начальные мольные доли компонентов",
                      GPA_DIMLESS_UNIT, false, 0),
    realParam("out-temperature", "Температура окружающей среды",
              GPA_TEMPERATURE_UNIT, false, 20),
    realParam("out-conductivity", "Коэффициент внешней теплоотдачи",
              GPA_HEAT_RATE_UNIT, false, 0.1),
    realParam("wall-thickness", "Толщина стенки", GPA_LENGTH_UNIT, false,
              0.001),
    realParam("wall-conductivity", "Коэффициент теплопроводности стенки",
              GPA_HEAT_RATE_UNIT, false, 0.1),
};

const gpaSensorInfoVector gpaNitrogenTank::m_sensors = {
    scalarSensor("pressure", "Давление в сепараторе", GPA_PRESSURE_UNIT),
    scalarSensor("temperature", "Температура в сепараторе",
                 GPA_TEMPERATURE_UNIT),
    scalarSensor("mix-pressure", "Давление на входе в сепаратор",
                 GPA_PRESSURE_UNIT),
    scalarSensor("gas-pressure", "Давление газа на выходе из сепаратора",
                 GPA_PRESSURE_UNIT),
    scalarSensor("liq-pressure", "Давление жидкости на выходе из сепаратора",
                 GPA_PRESSURE_UNIT),
    scalarSensor("liquid-level", "Уровень жидкости в сепараторе",
                 GPA_LENGTH_UNIT),
    scalarSensor("lev-fullness", "Заполненность по уровню жидкости",
                 GPA_DIMLESS_UNIT),
    scalarSensor("vol-fullness", "Заполненность по объему", GPA_DIMLESS_UNIT),
    scalarSensor("gas-delta-pres", "Перепад давлений по газу",
                 GPA_PRESSURE_UNIT),
    scalarSensor("liq-delta-pres", "Перепад давлений по жидкости",
                 GPA_PRESSURE_UNIT),
    scalarSensor("fraction0", "Доля компонента 1", GPA_DIMLESS_UNIT),
    scalarSensor("fraction1", "Доля компонента 2", GPA_DIMLESS_UNIT),
    scalarSensor("fraction2", "Доля компонента 3", GPA_DIMLESS_UNIT),
    scalarSensor("fraction3", "Доля компонента 4", GPA_DIMLESS_UNIT),
    scalarSensor("fraction4", "Доля компонента 5", GPA_DIMLESS_UNIT),
    scalarSensor("fraction5", "Доля компонента 6", GPA_DIMLESS_UNIT)};

gpaNitrogenTank::gpaNitrogenTank(const gpaCoreInterfaces *interfaces,
                                 gpaCoreReference importRef)
    : gpaExportSystem(interfaces, importRef), m_volume(asParent()),
      m_environment(asParent()), m_heatTransfers(GPA_VOLUME_NUM_FACES, NULL) {
  for (gpaUInt i = 0; i < GPA_VOLUME_NUM_FACES; i++)
    m_heatTransfers[i] = new gpaInstantTransfer(asParent());
}

const gpaStringVector gpaNitrogenTank::m_circuitNames = {"Контур"};

const gpaStringVector gpaNitrogenTank::m_portNames = {"N01", "N03", "N04",
                                                      "N12", "N15", "N18"};

gpaNitrogenTank::~gpaNitrogenTank() {
  for (gpaUInt i = 0; i < GPA_VOLUME_NUM_FACES; i++)
    if (m_heatTransfers[i])
      delete m_heatTransfers[i];
  m_heatTransfers.clear();
}

gpaUInt gpaNitrogenTank::getDeviceNumMixCircuits() { return NUM_CIRCUITS; }

gpaUInt gpaNitrogenTank::getDeviceMinNumMixPorts(gpaUInt index) {
  return index < NUM_CIRCUITS ? NUM_PORTS : 0;
}

gpaUInt gpaNitrogenTank::getDeviceMaxNumMixPorts(gpaUInt index) {
  return index < NUM_CIRCUITS ? NUM_PORTS : 0;
}

const gpaString *gpaNitrogenTank::getDeviceMixCircuitName(gpaUInt index) {
  return index < NUM_CIRCUITS ? &m_circuitNames[index] : NULL;
}

const gpaString *gpaNitrogenTank::getDeviceMixPortName(gpaUInt circIdx,
                                                       gpaUInt portIdx) {
  if (circIdx == ID_CIRCUIT)
    return portIdx < NUM_PORTS ? &m_portNames[portIdx] : NULL;
  return NULL;
}

gpaResult
gpaNitrogenTank::checkParamValues(const gpaExtParameter *values) const {
  (void)values;
  return GPA_RESULT_OK;
}

void gpaNitrogenTank::setNames() {
  m_volume.setName("Vol");
  m_environment.setName("Env");
  m_heatTransfers[GPA_VOLUME_FACE_BOTTOM]->setName("VB-HT");
  m_heatTransfers[GPA_VOLUME_FACE_LIQ_WALL]->setName("VLq-HT");
  m_heatTransfers[GPA_VOLUME_FACE_GAS_WALL]->setName("VGs-HT");
  m_heatTransfers[GPA_VOLUME_FACE_TOP]->setName("VT-HT");
}

gpaResult gpaNitrogenTank::initVolumes(const gpaExtParameter *values) {
  // Назначаем параметры сепрационной секции
  bool good = true;
  gpaReal h = values[ID_PARAM_H].value.realValue;
  gpaReal y = values[ID_PARAM_Y].value.realValue;
  gpaReal d = values[ID_PARAM_D].value.realValue;
  gpaEllipseVerticalCylinder *shape =
      new gpaEllipseVerticalCylinder(&m_volume, d, h, y);
  if (!good)
    return GPA_ERROR_WRONG_ARGS;
  m_volume.setShape(shape);
  gpaDataVector fractions(values[ID_PARAM_FRACTIONS].value.realVector,
                          values[ID_PARAM_FRACTIONS].size);
  good &= m_volume.setInitFractions(fractions);
  good &= m_volume.setInitPressure(values[ID_PARAM_PRES0].value.realValue);
  good &= m_volume.setInitTemperature(
      values[ID_PARAM_TEMP0].value.realValue + GPA_CELCIUS_TO_KELVIN);
  good &= m_volume.setGasHeatTransCoef(.65);
  good &= m_volume.setLiqHeatTransCoef(4.34);
  if (!good)
    return GPA_ERROR_WRONG_ARGS;
  return GPA_RESULT_OK;
}

gpaResult gpaNitrogenTank::initPortParameters(const gpaExtParameter *values) {
  bool good = true;
  gpaReal h = values[ID_PARAM_H].value.realValue;
  gpaReal y = values[ID_PARAM_Y].value.realValue;
  // Создаем отверсие для входа смеси и назначаем его характеристики
  gpaVolumeFittingData *port = NULL;
  port = new gpaVolumeFittingData(&m_volume);
  good &= port->setVolumeBottom(.04);
  good &= m_volume.setFittingPortData(GPA_N01_INLET, port);
  // Создаем отверсие для выхода газа и назначаем его характеристики
  port = new gpaVolumeFittingData(&m_volume);
  good &= port->setParameters(h + 2 * y, .04);
  good &= m_volume.setFittingPortData(GPA_N03_ANY, port);
  // Создаем отверсие для выхода газа и назначаем его характеристики
  port = new gpaVolumeFittingData(&m_volume);
  good &= port->setVolumeBottom(3.);
  good &= m_volume.setFittingPortData(GPA_N04_OUTLET, port);
  // Создаем отверсие для выхода газа и назначаем его характеристики
  port = new gpaVolumeFittingData(&m_volume);
  good &= port->setVolumeBottom(3.);
  good &= m_volume.setFittingPortData(GPA_N12_INLET, port);
  // Создаем отверсие для выхода газа и назначаем его характеристики
  port = new gpaVolumeFittingData(&m_volume);
  good &= port->setParameters(h + 2 * y, 3.);
  good &= m_volume.setFittingPortData(GPA_N15_OUTLET, port);
  // Создаем отверсие для выхода газа и назначаем его характеристики
  port = new gpaVolumeFittingData(&m_volume);
  good &= port->setParameters(h + 2 * y, 3.);
  good &= m_volume.setFittingPortData(GPA_N18_INLET, port);
  if (!good)
    return GPA_ERROR_WRONG_ARGS;
  return GPA_RESULT_OK;
}

gpaResult gpaNitrogenTank::initHeatTransfers(const gpaExtParameter *values) {
  // Назначаем параметры теплообменов через стенки
  gpaReal conductivity = values[ID_PARAM_WALL_CONDUCTIVITY].value.realValue;
  gpaReal thickness = values[ID_PARAM_WALL_THICKNESS].value.realValue;
  bool good = true;
  for (gpaUInt i = 0; i < 4; i++) {
    good &= m_heatTransfers[i]->setCounterFlow(false);
    m_heatTransfers[i]->setConvTempDiff(new gpaLogMeanTempDifference());
    m_heatTransfers[i]->setRadiation(new gpaZeroRadiation());
    gpaThinWall *wall = new gpaThinWall();
    good &= wall->calcPipeHeatCoef(conductivity, thickness);
    m_heatTransfers[i]->setWallModel(wall);
    if (!good)
      return GPA_ERROR_WRONG_ARGS;
  }
  m_environment.setTemperature(
      values[ID_PARAM_OUT_TEMPERATURE].value.realValue +
      GPA_CELCIUS_TO_KELVIN);
  m_environment.setHeatTransferCoef(
      values[ID_PARAM_OUT_CONDUCTIVITY].value.realValue);
  if (!good)
    return GPA_ERROR_WRONG_ARGS;
  return GPA_RESULT_OK;
}

gpaResult gpaNitrogenTank::setParamValues(const gpaExtParameter *values,
                                          bool checkNeeded) {
  // Проверка параметров, если требуется
  if (checkNeeded) {
    gpaResult res = checkParamValues(values);
    if (res != GPA_RESULT_OK)
      return res;
  }
  // Даем названия элементам и потокам
  setNames();
  // Инициализируем сепарационную камеру
  gpaResult res = initVolumes(values);
  if (res != GPA_RESULT_OK)
    return res;
  // Назначаем параметры портов
  res = initPortParameters(values);
  if (res != GPA_RESULT_OK)
    return res;
  // Инициализируем потоки теплообмена через стенки
  res = initHeatTransfers(values);
  if (res != GPA_RESULT_OK)
    return res;
  // Инициализируем внешнюю среду
  return res;
}

gpaResult gpaNitrogenTank::buildDevice() {
  bool good = true;
  // Соединяем сепарационную камеру с граничными потоками смеси системы
  good = good &&
         m_volume.connectMixStream(GPA_ELEM_CIRCUIT_0, GPA_N01_INLET,
                                   getEdgeMixStream(ID_CIRCUIT, GPA_N01_INLET),
                                   GPA_STREAM_INLET);
  good = good &&
         m_volume.connectMixStream(GPA_ELEM_CIRCUIT_0, GPA_N12_INLET,
                                   getEdgeMixStream(ID_CIRCUIT, GPA_N12_INLET),
                                   GPA_STREAM_INLET);
  good = good &&
         m_volume.connectMixStream(GPA_ELEM_CIRCUIT_0, GPA_N18_INLET,
                                   getEdgeMixStream(ID_CIRCUIT, GPA_N18_INLET),
                                   GPA_STREAM_INLET);
  // outlet section
  good = good &&
         m_volume.connectMixStream(GPA_ELEM_CIRCUIT_0, GPA_N03_ANY,
                                   getEdgeMixStream(ID_CIRCUIT, GPA_N03_ANY),
                                   GPA_STREAM_OUTLET);
  good = good &&
         m_volume.connectMixStream(GPA_ELEM_CIRCUIT_0, GPA_N04_OUTLET,
                                   getEdgeMixStream(ID_CIRCUIT, GPA_N04_OUTLET),
                                   GPA_STREAM_OUTLET);
  good = good &&
         m_volume.connectMixStream(GPA_ELEM_CIRCUIT_0, GPA_N15_OUTLET,
                                   getEdgeMixStream(ID_CIRCUIT, GPA_N15_OUTLET),
                                   GPA_STREAM_OUTLET);
  // Соединяем сепарационную камеру с тепловыми потоками
  good = good && m_volume.connectHeatStream(
                     GPA_VOLUME_FACE_BOTTOM,
                     m_heatTransfers[GPA_VOLUME_FACE_BOTTOM], GPA_STREAM_INLET);
  good = good &&
         m_volume.connectHeatStream(GPA_VOLUME_FACE_LIQ_WALL,
                                    m_heatTransfers[GPA_VOLUME_FACE_LIQ_WALL],
                                    GPA_STREAM_INLET);
  good = good &&
         m_volume.connectHeatStream(GPA_VOLUME_FACE_GAS_WALL,
                                    m_heatTransfers[GPA_VOLUME_FACE_GAS_WALL],
                                    GPA_STREAM_INLET);
  good = good && m_volume.connectHeatStream(
                     GPA_VOLUME_FACE_TOP, m_heatTransfers[GPA_VOLUME_FACE_TOP],
                     GPA_STREAM_INLET);
  // Соединяем окружающую среду с тепловыми потоками
  good =
      good && m_environment.connectHeatStream(
                  GPA_VOLUME_FACE_BOTTOM,
                  m_heatTransfers[GPA_VOLUME_FACE_BOTTOM], GPA_STREAM_OUTLET);
  good =
      good && m_environment.connectHeatStream(
                  GPA_VOLUME_FACE_LIQ_WALL,
                  m_heatTransfers[GPA_VOLUME_FACE_LIQ_WALL], GPA_STREAM_OUTLET);
  good =
      good && m_environment.connectHeatStream(
                  GPA_VOLUME_FACE_GAS_WALL,
                  m_heatTransfers[GPA_VOLUME_FACE_GAS_WALL], GPA_STREAM_OUTLET);
  good = good && m_environment.connectHeatStream(
                     GPA_VOLUME_FACE_TOP, m_heatTransfers[GPA_VOLUME_FACE_TOP],
                     GPA_STREAM_OUTLET);
  if (!good)
    return GPA_ERROR_WRONG_ARGS;
  // Добавляем в систему все элементы и потоки
  setElements({&m_volume, &m_environment});
  setStreams({m_heatTransfers[GPA_VOLUME_FACE_BOTTOM],
              m_heatTransfers[GPA_VOLUME_FACE_LIQ_WALL],
              m_heatTransfers[GPA_VOLUME_FACE_GAS_WALL],
              m_heatTransfers[GPA_VOLUME_FACE_TOP]});
  return GPA_RESULT_OK;
}

gpaResult gpaNitrogenTank::initialize() {
  // Подключить экспортируемый элемент к потокам в интеграторе
  gpaResult res = linkToCoreStreams();
  if (res != GPA_RESULT_OK)
    return res;
  // Соединяем все элементы друг с другом
  res = buildDevice();
  if (res != GPA_RESULT_OK)
    return res;
  // Создаем схемы течений (нужны соединенные элементы)
  if (!createSimStructures({},
                           {
                               {getOuterEntrance(ID_CIRCUIT, GPA_N01_INLET)},
                           }))
    return GPA_ERROR_WRONG_ARGS;
  // Инициализируем систему
  return gpaExportSystem::initialize();
}

gpaResult gpaNitrogenTank::setSignals(const gpaConstVector &signals) {
  // gpaReal value;
  // bool good = true;
  // if (getSignalValue(signals, ID_PARAM_EXT_TEMP, value))
  //     good &= m_environment.setTemperature(value + GPA_CELCIUS_TO_KELVIN);
  // if (!good)
  //     return GPA_ERROR_WRONG_ARGS;
  return GPA_RESULT_OK;
}

gpaResult gpaNitrogenTank::calcSensors(gpaVector &sensors) const {
  setSensorValue(sensors, ID_SENSOR_PRESSURE,
                 m_volume.getLiquidLevelPressure());
  setSensorValue(sensors, ID_SENSOR_TEMPERATURE,
                 m_volume.getTemperatureAt(m_volume.getLiquidLevel()) -
                     GPA_CELCIUS_TO_KELVIN);
  setSensorValue(sensors, ID_SENSOR_INLET_PRES,
                 m_volume.getFittingData(GPA_N01_INLET)->getPressure());
  setSensorValue(sensors, ID_SENSOR_OUT_GAS_PRES,
                 m_volume.getFittingData(GPA_N01_INLET)->getPressure());
  setSensorValue(sensors, ID_SENSOR_OUT_LIQ_PRES,
                 m_volume.getFittingData(GPA_N01_INLET)->getPressure());
  setSensorValue(sensors, ID_SENSOR_LIQUID_LEVEL, m_volume.getLiquidLevel());
  setSensorValue(sensors, ID_SENSOR_LEV_FULLNESS,
                 m_volume.getLiquidLevel() / m_volume.getShape()->getHeight());
  setSensorValue(sensors, ID_SENSOR_VOL_FULLNESS,
                 m_volume.getLiquidVolume() / m_volume.getShape()->getVolume());
  setSensorValue(sensors, ID_SENSOR_GAS_DELTA_PRES,
                 m_volume.getFittingData(GPA_N01_INLET)->getPressure() -
                     m_volume.getFittingData(GPA_N01_INLET)->getPressure());
  setSensorValue(sensors, ID_SENSOR_LIQ_DELTA_PRES,
                 m_volume.getFittingData(GPA_N01_INLET)->getPressure() -
                     m_volume.getFittingData(GPA_N01_INLET)->getPressure());
  gpaConstVector fractions = m_volume.getMedium()->getFractions();
  for (gpaUInt i = 0; i < fractions.size(); ++i)
    setSensorValue(sensors, i + ID_SENSOR_FRACTION0, fractions[i]);
  return GPA_RESULT_OK;
}
