#ifndef GPA_OIL_FIREHEATER_H
#define GPA_OIL_FIREHEATER_H
#include "gpaFlowElement.h"
#include "gpaHeatLayer.h"
#include "gpaInclude.h"
#include <fstream>
#include <iostream>
#include <numbers>
using namespace std;

#include <stdexcept>
#include <vector>

#include <algorithm>
#include <cstdlib>
#include <filesystem>
#include <iomanip>
#include <sstream>
#include <string>

namespace fs = std::filesystem;

const gpaUInt GPA_ELEM_CIRCUIT_Oil = 1;

class simpleBurner_FOH {

  // Перечень стехиометрических коэффициентов
  vector<gpaReal> sCoef = {0, 0, 0, 0, 0, 2};
  // Вектор удельных энергий горения компонент, Дж/моль
  vector<gpaReal> gpCoef = {0, 0, 0, 0, 0, 802.3e3};
  // Матриц коэффициентов пропорциональности продуктов реакции компонентов
  vector<vector<gpaReal>> kTilda = {{0, 1, 0}, {0, 0, 0}, {1, 0, 0},
                                    {0, 0, 0}, {0, 0, 0}, {0, 1, 2}};

  // isReactComp   = {0, 0, 0, 0, 0, 1};
  vector<gpaReal> isReactComp = {0, 0, 0, 0, 0, 1};
  // isntReactComp = {1, 1, 1, 0, 1, 0};
  vector<gpaReal> isntReactComp = {1, 1, 1, 0, 1, 0};
  vector<gpaReal> mol_FR_Products = {0, 0, 0, 0, 0, 0};

  // fr_FG = {CO2, CO, N2, O2, H2O, CH4}
  vector<gpaReal> fr_FG = {0, 0, 0, 0, 0, 0};

  // Молярный поток, кмоль/с
  gpaReal mol_FR;
  // Молярный поток требуемый для полного сгорания смеси, кмоль/с
  gpaReal mol_FR_TildaO2;
  // Молярный поток кислорода в смеси, кмоль/с
  gpaReal mol_FR_O2;
  // Степень полноты сгорания 0...1
  gpaReal rO2;

  vector<gpaReal> mol_FR_React_list;
  vector<gpaReal> mol_FR_NotReact_list;

  vector<gpaReal> mol_FR_Products_N2CO2H20;
  vector<gpaReal> mol_FR_StarComp_list;

  gpaReal mol_FR_Star;
  // fr_EG = {CO2, CO, N2, O2, H2O, CH4}
  vector<gpaReal> fr_EG = {0, 0, 0, 0, 0, 0};

  // Молярные компоненты, подаваемой на горение смеси
  gpaDataVector fr_FG_in = {0, 0, 0, 0, 0};

  // Перечень компонентов входящей топливной смеси
  vector<string> compNamesList = {"0", "0", "0", "0", "0"};

public:
  // fr_EG_Out = {CH4 , CO2, H2O, N2, O2}
  gpaDataVector fr_EG_Out = {0, 0, 0, 0, 0};

  gpaReal Q_Burn;

  // dQ/dot_m/mu, kJ/kmol
  gpaReal q_burn_unit_flow = 0;

  gpaReal concMin = 0.05;
  gpaReal concCH4;
  gpaMedium *medium;
  gpaReal T_Burned_gas = 300;

  const gpaMixPort *flueGasPort;

  gpaReal getScalarPr(vector<gpaReal> x, vector<gpaReal> y) {
    gpaReal total = 0;
    for (size_t i = 0; i < x.size(); i++) {
      total += x[i] * y[i];
    }
    return total;
  }

  vector<gpaReal> getVecDotVecByElem(vector<gpaReal> x, vector<gpaReal> y) {
    vector<gpaReal> res = x;
    for (size_t i = 0; i < res.size(); i++) {
      res[i] = x[i] * y[i];
    }
    return res;
  }

  vector<gpaReal> getVectDotScalar(vector<gpaReal> vec, gpaReal scal) {
    vector<gpaReal> res = vec;
    for (size_t i = 0; i < res.size(); i++) {
      res[i] = vec[i] * scal;
    }
    return res;
  }

  vector<gpaReal> getMatrAndDotProd(vector<vector<gpaReal>> m,
                                    vector<gpaReal> x) {
    vector<gpaReal> res = m[0];
    for (size_t i = 0; i < m[0].size(); i++) {
      res[i] = 0;
      for (size_t j = 0; j < m.size(); j++) {
        res[i] += x[j] * m[j][i];
        // cout<< res[i] << endl;
      }

      cout << " " << endl;
    }
    return res;
  }

  vector<gpaReal> sumVectByElem(vector<gpaReal> x, vector<gpaReal> y) {
    vector<gpaReal> res = x;
    for (size_t i = 0; i < x.size(); i++) {
      res[i] = x[i] + y[i];
    }
    return res;
  }

  gpaReal totalVecEl(vector<gpaReal> x) {
    gpaReal res = 0;
    for (size_t i = 0; i < x.size(); i++) {
      res += x[i];
    }
    return res;
  }

  gpaReal myMin(gpaReal a, gpaReal b) {

    if (a < b) {
      return a;
    } else {
      return b;
    }
  }

  void calcQBurn(gpaInt isShow) {
    mol_FR_TildaO2 = mol_FR * getScalarPr(fr_FG, sCoef);

    mol_FR_O2 = mol_FR * fr_FG[3];

    rO2 = myMin(mol_FR_O2, mol_FR_TildaO2) / mol_FR_TildaO2;

    mol_FR_React_list =
        getVectDotScalar(getVecDotVecByElem(isReactComp, fr_FG), rO2 * mol_FR);

    Q_Burn = getScalarPr(mol_FR_React_list, gpCoef); // kW = kJ/kmol * kmol/s

    q_burn_unit_flow = Q_Burn / mol_FR; // kw / (kmol/s) =  kJ/kmol

    // show q_burn_unit_flow
    if (isShow == 1) {
      cout << endl << " -------------------------------------- " << endl;
      cout << " <-- calcQBurn --> " << endl;
      cout << "mol_FR_TildaO2 --> " << mol_FR_TildaO2 << endl;
      cout << "mol_FR_O2 --> " << mol_FR_O2 << endl;
      cout << "rO2 --> " << rO2 << endl;
      cout << "q_burn_unit_flow --> " << q_burn_unit_flow << endl;
      cout << endl;
    }
  }

  void calcEGFract(gpaInt isShow) {

    if (isShow == 1) {
      cout << endl << " -------------------------------------- " << endl;
      cout << " <-- calcEGFract --> " << endl;
    }

    mol_FR_NotReact_list = sumVectByElem(
        getVectDotScalar(getVecDotVecByElem(isntReactComp, fr_FG), mol_FR),
        getVectDotScalar(getVecDotVecByElem(isReactComp, fr_FG),
                         (1 - rO2) * mol_FR));
    mol_FR_NotReact_list[3] = mol_FR_O2 - rO2 * mol_FR_TildaO2;

    if (isShow == 1) {
      cout << " mol_FR_NotReact_list -> ";
      for (size_t i = 0; i < mol_FR_NotReact_list.size(); i++) {
        cout << mol_FR_NotReact_list[i] << " ";
      }
      cout << " " << endl;
    }

    // "CO2","CO","N2","O2", "H2O", "CH4"
    vector<gpaReal> mol_FR_StarComp_list = {0, 0, 0, 0, 0, 0};

    vector<gpaReal> mol_FR_Products_N2CO2H20 =
        getMatrAndDotProd(kTilda, mol_FR_React_list);

    if (isShow == 1) {
      cout << " mol_FR_Products_N2CO2H20 -> ";
      for (size_t i = 0; i < mol_FR_Products_N2CO2H20.size(); i++) {
        cout << mol_FR_Products_N2CO2H20[i] << " ";
      }
      cout << " " << endl;
    }

    mol_FR_StarComp_list[2] = mol_FR_Products_N2CO2H20[0];
    mol_FR_StarComp_list[0] = mol_FR_Products_N2CO2H20[1];
    mol_FR_StarComp_list[4] = mol_FR_Products_N2CO2H20[2];

    if (isShow == 1) {
      cout << " mol_FR_StarComp_list -> ";
      for (size_t i = 0; i < mol_FR_StarComp_list.size(); i++) {
        cout << mol_FR_StarComp_list[i] << " ";
      }
      cout << " " << endl;
    }

    mol_FR_StarComp_list =
        sumVectByElem(mol_FR_StarComp_list, mol_FR_NotReact_list);
    gpaReal mol_FR_Star = totalVecEl(mol_FR_StarComp_list);

    fr_EG = getVectDotScalar(mol_FR_StarComp_list, 1 / mol_FR_Star);

    vector<string> outFrCompNames = {"CO2", "CO", "N2", "O2", "H2O", "CH4"};

    // Словарь название продукта горения - мольная доля
    std::map<std::string, gpaReal> frComponentsOut;

    for (size_t i = 0; i < outFrCompNames.size(); i++) {
      frComponentsOut[outFrCompNames[i]] = fr_EG[i];
    }

    // show fr_EG
    if (isShow == 1) {
      cout << endl << " fr_EG: " << endl;

      cout << "names -> ";
      for (size_t i = 0; i < fr_EG.size(); i++) {
        cout << outFrCompNames[i] << " | ";
      }
      cout << " " << endl;

      cout << "fract -> ";
      for (size_t i = 0; i < fr_EG.size(); i++) {
        cout << fr_EG[i] << " | ";
      }
      cout << " " << endl;
    }

    for (size_t i = 0; i < compNamesList.size(); i++) {
      fr_EG_Out[i] = frComponentsOut[compNamesList[i]];
    }

    // show fr_EG_Out
    if (isShow == 1) {
      cout << endl << " fr_EG_Out: " << endl;

      cout << "names -> ";
      for (size_t i = 0; i < fr_EG_Out.size(); i++) {
        cout << compNamesList[i] << " | ";
      }
      cout << " " << endl;

      cout << "fract -> ";
      for (size_t i = 0; i < fr_EG_Out.size(); i++) {
        cout << fr_EG_Out[i] << " | ";
      }
      cout << " " << endl;
    }
  }

  void calcTempEGinlet(gpaInt isShow) {
    // сверка с табличными значениями. присутсвует отличие по энтальпии
    // m_medium_ExchGas ->calcFlashPT(P_in_gas, 50+273,
    // m_medium_ExchGas->getFractions()); cout << "hin "<<
    // m_medium_ExchGas->getEnthalpy() <<endl; m_medium_ExchGas
    // ->calcFlashPT(P_in_gas, 1765.63, m_medium_ExchGas->getFractions()); cout
    // << "hburn "<< m_medium_ExchGas->getEnthalpy() <<endl; T_Burned_gas =
    // 1765.63;

    gpaReal h_in = flueGasPort->getStreamEnthalpy();
    gpaReal delta_h_Burn = q_burn_unit_flow;
    gpaReal h_Burn = h_in + delta_h_Burn;
    gpaReal P_in_gas = flueGasPort->getStreamPressure();

    // cout  << " Export props VS T " << endl;

    medium->calcFlashPH(P_in_gas, h_Burn, flueGasPort->getStreamFractions());
    // Cp_M_Burned_gas = medium->getHeatCapacity()/medium->getMolarMass();
    T_Burned_gas = medium->getTemperature(); // mdotCond

    if (isShow == 1) {
      cout << endl << " -------------------------------------- " << endl;
      cout << " <-- calcTempEGinlet --> " << endl;
      cout << "h_in " << h_in << endl;
      cout << "delta_h_Burn " << delta_h_Burn << endl;
      cout << "h_Burn " << h_Burn << endl;
      cout << "T_Burned_gas " << T_Burned_gas << endl;
    }
  }

  // Расчет тепла от горения и температуры ДГ в области входа в КР
  // (T_Burned_gas)
  void calcBurning(gpaInt isShow) {

    if (isShow == 1) {
      cout << endl << " -------------------------------------- " << endl;
      cout << " <-- calcBurning --> " << endl;
    }

    mol_FR = flueGasPort->getIncomingFlowRate();
    mol_FR = mol_FR > 0.001 ? mol_FR : 0.001;

    fr_FG_in = flueGasPort->getStreamFractions();

    for (size_t i = 0; i < fr_FG_in.size(); i++) {
      compNamesList[i] = flueGasPort->getStreamMedium()->getComponentName(i);
    }

    std::map<std::string, gpaReal> frComponents;
    // установка значений
    for (size_t i = 0; i < fr_FG_in.size(); i++) {
      frComponents[compNamesList[i]] = fr_FG_in[i];
    }

    // Названия компонент, участвующих в горении
    vector<string> rule = {"CO2", "N2", "O2", "H2O", "CH4"};
    // Номера компонент, участвующих в горении 1 - CO нет в потоке
    vector<gpaInt> ruleComp = {0, 2, 3, 4, 5};

    // show fr_FG_in
    if (isShow == 1) {
      cout << " fr_FG_in: ";
      cout << "names -> ";

      for (size_t i = 0; i < rule.size(); i++) {
        cout << rule[i] << " | ";
      }
      cout << endl;

      cout << "fract -> ";

      for (size_t i = 0; i < rule.size(); i++) {
        cout << frComponents[rule[i]] << " | ";
      }
      cout << endl;
    }

    for (size_t i = 0; i < ruleComp.size(); i++) {
      fr_FG[ruleComp[i]] = frComponents[rule[i]];
    }

    concCH4 = fr_FG[5];

    // show concCH4
    if (isShow == 1) {
      cout << "mol_FR  = " << mol_FR << endl;
      cout << "concCH4 = " << concCH4 << endl;
      cout << "concMin = " << concMin << endl;
    }

    if (concCH4 > concMin) {
      calcQBurn(isShow);
      calcEGFract(isShow);
      calcTempEGinlet(isShow);
    } else {
      q_burn_unit_flow = 0;
      fr_EG_Out = fr_FG_in;
      T_Burned_gas = flueGasPort->getStreamTemperature();

      // show no fire
      if (isShow == 1) {
        cout << "no fire --> " << endl;
      }
    }

    if (isShow == 1) {
      cout << "   ----  " << endl;
    }
  }

  // Удельный поток излучения RC
  gpaReal getqRadRC(bool isShow, gpaReal gasMeanTemp, gpaReal oilMeanTemp) {

    gpaReal qRad = 0;

    if (concCH4 > concMin) {
      gpaReal epsilonC = 0.9;
      gpaReal epsilonEff = 0.5 * (epsilonC + 1.0);
      gpaReal c0 = 5.67;
      gpaReal epsilonGas = 0.29 - gasMeanTemp / 8100.0;
      gpaReal aGas =
          (0.23 - gasMeanTemp / 8000.0) * pow(gasMeanTemp / oilMeanTemp, 0.65) +
          0.12 + gasMeanTemp / 53000.0;

      qRad = gasMeanTemp > 500 ? epsilonEff * c0 *
                                     (epsilonGas * pow(gasMeanTemp / 100, 4.0) -
                                      aGas * pow(oilMeanTemp / 100, 4.0))
                               : 0;

      qRad = qRad < 0 ? 0 : qRad;

      // gpaReal x=gasPipeRC.meanTemp;
      // qRadRC = (3754.58 - 19.0469*x + 0.0238199*pow(x,2))*(1 -
      // sigmoid(0.2*(-1500 + x))) + (-253552. + 313.105*x -
      // 0.0839541*pow(x,2))*sigmoid(0.2*(-1500 + x));

      if (isShow == 1) {
        std::cout << " --> gas burned  -->  qRad, kW / m^2  " << qRad / 1000
                  << "\n";
      }
    } else {
      if (isShow == 1) {
        std::cout << " --> no fire  " << "\n";
      }
    }
    return qRad;
  }
};

class myPipe_FOH {

public:
  gpaString pipe_Name;
  gpaString fluid;
  gpaMedium *medium;

  gpaReal flag = 0.0;
  gpaReal meanTemp = 300.0;
  gpaReal meanPressure = 101.0;

  gpaReal n_ch = 1.0;
  gpaReal epsilon = 1.0;
  gpaReal d_char = 1.0;
  gpaReal l_ch = 1.0;
  gpaReal deltaH = 1.0;

  gpaReal density = 1.0;
  gpaReal viscosity = 1.0;
  gpaReal mu = 1.0;
  gpaReal cp = 1.0;
  gpaReal lambda = 1.0;

  gpaReal v = 1.0;
  gpaReal Re = 1.0;

  gpaReal coefFrick = 1.0;
  gpaReal DP_Frick = 1.0;
  gpaReal DP_DH = 1.0;
  gpaReal DP = 1.0;

  gpaReal F1 = 1.0;
  gpaReal F2 = 1.0;
  gpaReal F3 = 1.0;
  gpaReal X1 = 1.0;
  gpaReal X2 = 1.0;

  gpaReal ReJoin1 = 2300.0;
  gpaReal ReJoin2 = 4000.0;
  gpaReal deltaRe = 30.0;

  gpaReal sigm = 0.2;
  gpaReal crossArea = 0.2;
  gpaReal volume = 0;

  gpaReal Pr = 1.0;
  gpaReal Nu = 1.0;
  gpaReal alpha_conv = 0.1;

  // Запись матрицы в CSV файл
  bool writeMatrixToCSV(const vector<vector<double>> &matrix,
                        const string &filename, char delimiter = ',',
                        int precision = 3, bool includeHeaders = false,
                        const vector<string> &rowHeaders = {},
                        const vector<string> &colHeaders = {}) {

    ofstream file(filename);

    if (!file.is_open()) {
      cerr << "Ошибка: не удалось открыть файл " << filename << " для записи"
           << endl;
      return false;
    }

    // Устанавливаем точность вывода
    file << scientific << setprecision(precision);

    int rows = matrix.size();
    if (rows == 0) {
      cerr << "Ошибка: пустая матрица" << endl;
      file.close();
      return false;
    }

    int cols = matrix[0].size();

    // Проверка корректности матрицы (все строки одинаковой длины)
    for (int i = 1; i < rows; i++) {
      if (matrix[i].size() != static_cast<size_t>(cols)) {
        cerr << "Ошибка: строки матрицы имеют разную длину" << endl;
        file.close();
        return false;
      }
    }

    // Записываем заголовки столбцов (если нужно)
    if (includeHeaders && !colHeaders.empty()) {
      // Если есть заголовки строк, первая ячейка пустая
      if (!rowHeaders.empty()) {
        file << delimiter;
      }

      // Записываем заголовки столбцов
      for (int j = 0; j < cols; j++) {
        if (j < static_cast<int>(colHeaders.size())) {
          // Если в заголовках есть запятые, заключаем в кавычки
          if (colHeaders[j].find(delimiter) != string::npos) {
            file << "\"" << colHeaders[j] << "\"";
          } else {
            file << colHeaders[j];
          }
        } else {
          file << "Column_" << (j + 1);
        }

        if (j < cols - 1) {
          file << delimiter;
        }
      }
      file << endl;
    }

    // Записываем данные матрицы
    for (int i = 0; i < rows; i++) {
      // Заголовок строки (если есть)
      if (includeHeaders && !rowHeaders.empty()) {
        if (i < static_cast<int>(rowHeaders.size())) {
          // Если в заголовках есть запятые, заключаем в кавычки
          if (rowHeaders[i].find(delimiter) != string::npos) {
            file << "\"" << rowHeaders[i] << "\"";
          } else {
            file << rowHeaders[i];
          }
        } else {
          file << "Row_" << (i + 1);
        }
        file << delimiter;
      }

      // Элементы строки матрицы
      for (int j = 0; j < cols; j++) {
        file << matrix[i][j];
        if (j < cols - 1) {
          file << delimiter;
        }
      }
      file << endl;
    }

    file.close();

    if (file.fail()) {
      cerr << "Ошибка при записи в файл" << endl;
      return false;
    }

    return true;
  }

  // Проверка существования директории (кросс-платформенная)
  bool directoryExists(const string &path) {
    return fs::exists(path) && fs::is_directory(path);
  }

  // Создание директории (кросс-платформенная)
  bool createDirectory(const string &path) {
    try {
      return fs::create_directory(path);
    } catch (const fs::filesystem_error &e) {
      cerr << "Ошибка при создании директории: " << e.what() << endl;
      return false;
    }
  }

  void exportCurrentBiblProps(string way, gpaReal tempStart, gpaReal tempEnd,
                              gpaReal deltaTemp, gpaDataVector fractions) {

    cout << "  cp_gas = f(T)   " << " | " << "\n";

    vector<vector<gpaReal>> parsVST;
    vector<gpaReal> pars = {0, 0, 0, 0, 0, 0};
    for (gpaReal temp = tempStart; temp < tempEnd; temp = temp + deltaTemp) {
      // cout<<temp <<endl;
      medium->calcFlashPT(meanPressure, temp, fractions);

      pars[0] = temp;
      pars[1] = medium->getConductivity();
      pars[2] = medium->getDensity();
      pars[3] = medium->getViscosity();
      pars[4] = medium->getHeatCapacity() / medium->getMolarMass();
      pars[5] = medium->getMolarMass();

      parsVST.push_back(pars);
    }

    gpaString nameExport_CM =
        pipe_Name + " " + fluid + " " + to_string(meanPressure) + " .csv";
    cout << "--> export " << " | " << nameExport_CM << " "
         << writeMatrixToCSV(parsVST, way + nameExport_CM) << endl;

    std::cout << "  ---------   " << "\n";
  }

  void calcVolume() { volume = 8 * crossArea * l_ch; }

  // Функция, выдающая свойства ГМ. Функции получены интерполяцией табличных
  // зависимостей терминола 66
  gpaReal getOilProp(gpaString par, gpaReal T) {
    if (par == "rho") {
      return 1236.69 - 0.745665 * T; // kg/m^3
    }
    if (par == "cp") {
      return (0.5211052170945513 + 0.0035340139549585384 * T); // kJ/kg/K
    }
    if (par == "lambda") {
      return (0.15395 - 0.000103468 * T) / 1000; // kW/K/m
    }
    if (par == "eta") {
      return 21.834 / pow(T - 273, 1.912); // Pa*s
    }
    if (par == "mu") {
      return 252.0; // kg/kmol
    }
  }

  // Функция, выдающая свойства ГС и ДГ. Для простоты взяты табличные
  // зависимости воздуха при 1 атм
  gpaReal getGasProp(gpaString par, gpaReal T) {
    if (par == "rho") {
      return 365.863 / T;
    }
    if (par == "cp") {
      return (-229.668 + 463.18 * pow(T, 0.168614)) / 1000.0;
    }
    if (par == "lambda") {
      return (0.00396343 + 0.0000706675 * T) / 1000.0;
    }
    if (par == "eta") {
      return -2.96295 * pow(10.0, -6.0) +
             3.65048 * pow(10.0, -7.0) * pow(T, 0.696601);
    }
    if (par == "mu") {
      return 29.0;
    }
  }

  // Получить теплопроводность, плотность, динамическую вязкость,теплоемкость,
  // молярную массу
  void getStandartPackProp(gpaDataVector fractions) {
    if (flag == 0) {

      density = fluid == "gas" ? getGasProp("rho", meanTemp)
                               : getOilProp("rho", meanTemp);
      viscosity = fluid == "gas" ? getGasProp("eta", meanTemp)
                                 : getOilProp("eta", meanTemp);
      mu = fluid == "gas" ? getGasProp("mu", meanTemp)
                          : getOilProp("mu", meanTemp);
      cp = fluid == "gas" ? getGasProp("cp", meanTemp)
                          : getOilProp("cp", meanTemp);
      lambda = fluid == "gas" ? getGasProp("lambda", meanTemp)
                              : getOilProp("lambda", meanTemp);

    } else {

      medium->calcFlashPT(meanPressure, meanTemp,
                          fractions); // !!! без изменения состава b P_in_gas
      // std::cout << " gas | is good calcFlash | "<< res<< "\n";
      lambda = medium->getConductivity();
      density = medium->getDensity();
      viscosity = medium->getViscosity();
      cp = medium->getHeatCapacity() / medium->getMolarMass();
      mu = medium->getMolarMass();
    }
  }

  // Функция сигмойда
  gpaReal sigmoid(gpaReal x) { return 1.0 / (1.0 + std::exp(-x)); }

  // Выдает сглаженное значение кусочно-заданной функции по числу Рейнолдса
  gpaReal smFun(gpaReal fL, gpaReal fR, gpaReal ReStar, gpaReal ReDelta) {
    gpaReal ReDim = (Re - ReStar) / ReDelta;
    return fL * (1.0 - sigmoid(ReDim)) + fR * sigmoid(ReDim);
  }

  // Выдвет Nu для турбулетного режима согласно закону Диттуса-Болтера
  gpaReal getNuByDBLaw(gpaReal Re, gpaReal Pr) {
    return 0.023 * pow(Re, 0.8) * pow(Pr, 0.3);
  }

  // Выдает значение линейной функции, сшивающей два закона в переходной зоне
  gpaReal getLineTransFunByRe(gpaReal reS, gpaReal reE, gpaReal yS,
                              gpaReal yE) {
    return yS + (yE - yS) * (Re - reS) / (reE - reS);
  }

  gpaReal getNu(bool imShow) {

    gpaReal ReTrZSt = 2300;
    gpaReal ReTrZEnd = 105000;
    gpaReal deltaReForNuLaw = 100;
    gpaReal nuLam = 3.657;
    gpaReal nuTrZEnd = getNuByDBLaw(ReTrZEnd, Pr);
    gpaReal nuTurb = getNuByDBLaw(Re, Pr);
    gpaReal nuTr = getLineTransFunByRe(ReTrZSt, ReTrZEnd, nuLam, nuTrZEnd);
    gpaReal NuSM = smFun(nuLam, nuTr, ReTrZSt, deltaReForNuLaw);
    Nu = smFun(NuSM, nuTurb, ReTrZEnd, deltaReForNuLaw);
    return Nu;

    if (imShow == 1) {
      std::cout << "  nuTrZEnd | nuTurb  | nuTr " << "\n";
      std::cout << " | " << nuTrZEnd << " | " << nuTurb << " | " << nuTr
                << " | " << "\n";
      std::cout << "  Re | NuSM1 | NuSM2 " << "\n";
      std::cout << Re << " | " << NuSM << Nu << " | " << "\n";
    }

    // trustNuFun()
  }

  // Выводит зависимость Nu = f(Re)
  void trustNuFun() {

    // test nu fun
    for (size_t ReTest = 0; ReTest < 30000; ReTest = ReTest + 1000) {
      Re = ReTest;
      std::cout << " | " << ReTest << " | " << getNu(0) << " | " << "\n";
    }
  }

  void calcMyPipeHeatTransherProp(bool imshow) {
    Pr = viscosity * cp / lambda;
    Nu = getNu(imshow);
    alpha_conv = Nu * lambda / d_char;
  }

  void calcMyPipeMeanFlowProp1(bool isShow, gpaReal G) {
    // G  = (G * mu > 3 ? G: 3 / mu );//flowCond

    v = G * mu / n_ch / density / crossArea;
    Re = v * density * d_char / viscosity;

    F1 = 64.0 * Re;

    gpaReal corrFactor = 1.0934692026804917 - 0.0017678048379265673 * G * mu;
    F3 = corrFactor * 1 / pow(1.8, 2.0) * pow(Re, 2.0) /
         pow(log10(6.9 / (Re + 1e-9) + pow(epsilon / 3.7 / d_char, 1.11)), 2.0);

    F2 = F1 + (Re - ReJoin1) / (ReJoin2 - ReJoin1) * (F3 - F1);

    X1 = (Re - ReJoin1) / deltaRe;
    X2 = (Re - ReJoin2) / deltaRe;

    sigm = 1.0 / (1.0 + exp(-1.0 * X1));
    coefFrick = F1 * (1.0 - sigm) + F2 * sigm;

    sigm = 1.0 / (1.0 + exp(-1.0 * X2));
    coefFrick = coefFrick * (1.0 - sigm) + F3 * sigm;

    DP_Frick = coefFrick * pow(viscosity, 2.0) * l_ch / 2.0 / density /
               pow(d_char, 3.0) / 1000; // flowCond

    DP_DH = density * 9.8 * deltaH / 1000;

    DP = DP_Frick + DP_DH;
  }
};

class myPipeRib_FOH {

public:
  gpaString pipe_Name;
  gpaString fluid;
  gpaMedium *medium;

  gpaReal flag = 0.0;
  gpaReal meanPressure = 101.0;
  gpaReal meanTemp = 300.0;

  gpaReal n_ch = 1.0;

  // gpaReal l_ch    = 1.0;
  gpaReal deltaH = 1.0;

  gpaReal density = 1.0;
  gpaReal viscosity = 1.0;
  gpaReal mu = 1.0;
  gpaReal cp = 1.0;
  gpaReal lambda = 1.0;

  gpaReal v = 1.0;
  gpaReal Re = 1.0;
  gpaReal volume = 0.0;

  gpaReal DP = 1.0;

  gpaReal crossArea = 0.2;

  gpaReal Pr = 1.0;
  gpaReal Nu = 1.0;
  gpaReal alpha_conv = 0.1;

  gpaReal c;
  gpaReal n;
  gpaReal m;

  // Перечень входных геометрических параметров КК (СC - convection chamber)
  gpaReal deltaRib = 0.0012;
  gpaReal hRib = 0.015;
  gpaReal sRib = 1;
  gpaReal psiRib = 4;
  gpaReal lambdaRib = 0.1; // kWt/m/k

  gpaReal d_equal;
  gpaReal l_char;
  gpaReal nRow;
  gpaReal zeta_0_R;

  // Запись матрицы в CSV файл
  bool writeMatrixToCSV(const vector<vector<double>> &matrix,
                        const string &filename, char delimiter = ',',
                        int precision = 3, bool includeHeaders = false,
                        const vector<string> &rowHeaders = {},
                        const vector<string> &colHeaders = {}) {

    ofstream file(filename);

    if (!file.is_open()) {
      cerr << "Ошибка: не удалось открыть файл " << filename << " для записи"
           << endl;
      return false;
    }

    // Устанавливаем точность вывода
    file << scientific << setprecision(precision);

    int rows = matrix.size();
    if (rows == 0) {
      cerr << "Ошибка: пустая матрица" << endl;
      file.close();
      return false;
    }

    int cols = matrix[0].size();

    // Проверка корректности матрицы (все строки одинаковой длины)
    for (int i = 1; i < rows; i++) {
      if (matrix[i].size() != static_cast<size_t>(cols)) {
        cerr << "Ошибка: строки матрицы имеют разную длину" << endl;
        file.close();
        return false;
      }
    }

    // Записываем заголовки столбцов (если нужно)
    if (includeHeaders && !colHeaders.empty()) {
      // Если есть заголовки строк, первая ячейка пустая
      if (!rowHeaders.empty()) {
        file << delimiter;
      }

      // Записываем заголовки столбцов
      for (int j = 0; j < cols; j++) {
        if (j < static_cast<int>(colHeaders.size())) {
          // Если в заголовках есть запятые, заключаем в кавычки
          if (colHeaders[j].find(delimiter) != string::npos) {
            file << "\"" << colHeaders[j] << "\"";
          } else {
            file << colHeaders[j];
          }
        } else {
          file << "Column_" << (j + 1);
        }

        if (j < cols - 1) {
          file << delimiter;
        }
      }
      file << endl;
    }

    // Записываем данные матрицы
    for (int i = 0; i < rows; i++) {
      // Заголовок строки (если есть)
      if (includeHeaders && !rowHeaders.empty()) {
        if (i < static_cast<int>(rowHeaders.size())) {
          // Если в заголовках есть запятые, заключаем в кавычки
          if (rowHeaders[i].find(delimiter) != string::npos) {
            file << "\"" << rowHeaders[i] << "\"";
          } else {
            file << rowHeaders[i];
          }
        } else {
          file << "Row_" << (i + 1);
        }
        file << delimiter;
      }

      // Элементы строки матрицы
      for (int j = 0; j < cols; j++) {
        file << matrix[i][j];
        if (j < cols - 1) {
          file << delimiter;
        }
      }
      file << endl;
    }

    file.close();

    if (file.fail()) {
      cerr << "Ошибка при записи в файл" << endl;
      return false;
    }

    return true;
  }

  // Проверка существования директории (кросс-платформенная)
  bool directoryExists(const string &path) {
    return fs::exists(path) && fs::is_directory(path);
  }

  // Создание директории (кросс-платформенная)
  bool createDirectory(const string &path) {
    try {
      return fs::create_directory(path);
    } catch (const fs::filesystem_error &e) {
      cerr << "Ошибка при создании директории: " << e.what() << endl;
      return false;
    }
  }

  void exportCurrentBiblProps(string way, gpaReal tempStart, gpaReal tempEnd,
                              gpaReal deltaTemp, gpaDataVector fractions) {

    cout << "  cp_gas = f(T)   " << " | " << "\n";

    vector<vector<gpaReal>> parsVST;
    vector<gpaReal> pars = {0, 0, 0, 0, 0, 0};
    for (gpaReal temp = tempStart; temp < tempEnd; temp = temp + deltaTemp) {
      // cout<<temp <<endl;
      medium->calcFlashPT(meanPressure, temp, fractions);

      pars[0] = temp;
      pars[1] = medium->getConductivity();
      pars[2] = medium->getDensity();
      pars[3] = medium->getViscosity();
      pars[4] = medium->getHeatCapacity() / medium->getMolarMass();
      pars[5] = medium->getMolarMass();

      parsVST.push_back(pars);
    }

    gpaString nameExport_CM =
        pipe_Name + " " + fluid + " " + to_string(meanPressure) + " .csv";
    cout << "--> export " << " | " << nameExport_CM << " "
         << writeMatrixToCSV(parsVST, way + nameExport_CM) << endl;

    std::cout << "  ---------   " << "\n";
  }

  // Функция, выдающая свойства ГМ. Функции получены интерполяцией табличных
  // зависимостей терминола 66
  gpaReal getOilProp(gpaString par, gpaReal T) {
    if (par == "rho") {
      return 1236.69 - 0.745665 * T; // kg/m^3
    }
    if (par == "cp") {
      return (0.5211052170945513 + 0.0035340139549585384 * T); // kJ/kg/K
    }
    if (par == "lambda") {
      return (0.15395 - 0.000103468 * T) / 1000; // kW/K/m
    }
    if (par == "eta") {
      return 21.834 / pow(T - 273, 1.912); // Pa*s
    }
    if (par == "mu") {
      return 252.0; // kg/kmol
    }
  }

  // Функция, выдающая свойства ГС и ДГ. Для простоты взяты табличные
  // зависимости воздуха при 1 атм
  gpaReal getGasProp(gpaString par, gpaReal T) {
    if (par == "rho") {
      return 365.863 / T;
    }
    if (par == "cp") {
      return (-229.668 + 463.18 * pow(T, 0.168614)) / 1000.0;
    }
    if (par == "lambda") {
      return (0.00396343 + 0.0000706675 * T) / 1000.0;
    }
    if (par == "eta") {
      return -2.96295 * pow(10.0, -6.0) +
             3.65048 * pow(10.0, -7.0) * pow(T, 0.696601);
    }
    if (par == "mu") {
      return 29.0;
    }
  }

  // Получить теплопроводность, плотность, динамическую вязкость,теплоемкость,
  // молярную массу
  void getStandartPackProp(gpaDataVector fractions) {
    if (flag == 0) {

      density = fluid == "gas" ? getGasProp("rho", meanTemp)
                               : getOilProp("rho", meanTemp);
      viscosity = fluid == "gas" ? getGasProp("eta", meanTemp)
                                 : getOilProp("eta", meanTemp);
      mu = fluid == "gas" ? getGasProp("mu", meanTemp)
                          : getOilProp("mu", meanTemp);
      cp = fluid == "gas" ? getGasProp("cp", meanTemp)
                          : getOilProp("cp", meanTemp);
      lambda = fluid == "gas" ? getGasProp("lambda", meanTemp)
                              : getOilProp("lambda", meanTemp);

    } else {

      medium->calcFlashPT(meanPressure, meanTemp, fractions);
      // std::cout << " gas | is good calcFlash | "<< res<< "\n";
      lambda = medium->getConductivity();
      density = medium->getDensity();
      viscosity = medium->getViscosity();
      cp = medium->getHeatCapacity() / medium->getMolarMass();
      mu = medium->getMolarMass();
    }
  }

  // Функция сигмойда
  gpaReal sigmoid(gpaReal x) { return 1.0 / (1.0 + std::exp(-x)); }

  // Выдает сглаженное значение кусочно-заданной функции по числу Рейнолдса
  gpaReal smFun(gpaReal fL, gpaReal fR, gpaReal ReStar, gpaReal ReDelta) {
    gpaReal ReDim = (Re - ReStar) / ReDelta;
    return fL * (1.0 - sigmoid(ReDim)) + fR * sigmoid(ReDim);
  }

  void calcMyPipeHeatTransherProp(bool imShow) {
    Pr = viscosity * cp / lambda;
    Nu = smFun(1, c * pow(Re, n) * pow(Pr, m), 100, 10);

    if (imShow == 1) {
      std::cout << "  Re | NuSM1 | NuSM2 " << "\n";
      std::cout << Re << " | " << Nu << " | " << "\n";
      std::cout << c << " | " << n << " | " << m << "\n";
    }

    gpaReal alphaEG = Nu * lambda / l_char;
    gpaReal mRib = pow(2 * alphaEG * lambdaRib / deltaRib, 0.5);
    gpaReal eff =
        tanh(mRib * (hRib + deltaRib / 2.0)) / (mRib * (hRib + deltaRib / 2.0));
    gpaReal psiE = 1.0 - 0.058 * mRib * hRib;
    gpaReal eta = 1.0 - (1.0 - psiE * eff) *
                            (1.0 - 1.0 / psiRib * (1.0 - deltaRib / sRib));
    alpha_conv = alphaEG * psiRib * eta;
  }

  void getZeta0R() { zeta_0_R = 0.26 * pow(l_char / d_equal, 0.3); }

  void calcMyPipeMeanFlowProp2(bool isShow, gpaReal G, gpaReal Tin,
                               gpaReal Tout) {
    v = (G)*mu / n_ch / density / crossArea;
    Re = v * density * l_char / viscosity;

    gpaReal zeta, zeta_t, zeta_0, zeta_0_L;

    zeta_t = 2 * (Tin - Tout) / meanTemp;
    zeta_0_L = (5.4 * l_char) / d_equal * pow(Re, -0.25);
    zeta_0 = smFun(zeta_0_L, zeta_0_R, 1.5e5, 100);
    zeta = zeta_0_L * nRow + zeta_t;

    DP = zeta * density * v * abs(v) / 2 / 1000; // kPa

    if (isShow == 1) {
      std::cout << "   Re  " << Re << "\n";
      std::cout << "  zeta_0 | zeta | DP " << "\n";
      std::cout << zeta_0 << " | " << zeta << " | " << DP << "\n";
    }
  }
};

class gpaFireOilHeaterElement : public gpaFlowElement {
public:
  // не убирать
  gpaFireOilHeaterElement(const gpaParentLink *link)
      : m_gasEnthalpy(0), m_liquidEnthalpy(0), m_liquidFlowRate(0),
        m_temperature(0) {

    setMixCircuit(new gpaElementMixCircuit(this, GPA_ELEM_CIRCUIT_Oil));
    m_d = 0.5;
    m_l = 2.0;
    m_dh = 0.3;
    m_nBends = 2;
    m_eps = 0.0001;
    m_Tenv = 293.15;
    m_heatLayers.push_back(gpaHeatLayer{0.02, 7800, 16.0, 460});
    m_alpha_in_pipe = m_alpha_out_pipe = m_alpha_in_gas = m_alpha_out_gas =
        100.0;
    calcThermalParams();
  }
  gpaFireOilHeaterElement(const gpaFireOilHeaterElement &m_heatPipes) {
    m_gasEnthalpy = m_heatPipes.m_gasEnthalpy;
    m_liquidEnthalpy = m_heatPipes.m_liquidEnthalpy;
    m_liquidFlowRate = m_heatPipes.m_liquidFlowRate;
    m_temperature = m_heatPipes.m_temperature;
    m_d = m_heatPipes.m_d;
    m_l = m_heatPipes.m_l;
    m_dh = m_heatPipes.m_dh;
    m_nBends = m_heatPipes.m_nBends;
    m_eps = m_heatPipes.m_eps;
    m_Tenv = m_heatPipes.m_Tenv;
    m_heatLayers = m_heatPipes.m_heatLayers;

    m_alpha_in_pipe = m_heatPipes.m_alpha_in_pipe;
    m_alpha_out_pipe = m_heatPipes.m_alpha_out_pipe;
    m_alpha_in_gas = m_heatPipes.m_alpha_in_gas;
    m_alpha_out_gas = m_heatPipes.m_alpha_out_gas;
    calcThermalParams();
  }
  virtual gpaFireOilHeaterElement *copy() const override {
    return new gpaFireOilHeaterElement(*this);
  }
  // не убирать

  virtual gpaUInt getMinNumMixPorts(gpaUInt index) const override {
    return getDeviceMinNumMixPorts(index);
  }
  static gpaUInt getDeviceMinNumMixPorts(gpaUInt index) {
    if (index == GPA_ELEM_CIRCUIT_0) {
      return 2;
    }
    if (index == GPA_ELEM_CIRCUIT_Oil) {
      return 2;
    }
    return 0;
  }
  static gpaUInt getDeviceNumMixCircuits() { return 2; }
  virtual gpaUInt getNumMixCircuits() const { return 2; }
  virtual gpaUInt getMaxNumMixPorts(gpaUInt index) const override {
    return getDeviceMaxNumMixPorts(index);
  }
  static gpaUInt getDeviceMaxNumMixPorts(gpaUInt index) {
    if (index == GPA_ELEM_CIRCUIT_0) {
      return 2;
    }
    if (index == GPA_ELEM_CIRCUIT_Oil) {
      return 2;
    }
    return 0;
  }

  //+++++++++++ Инициализация переменных

  // Кол-во переменных
  gpaUInt getNumVariables() const override { return 2; }

  // Нумирация переменных
  enum {
    TEMP_GAS_STAR = 0,
    TEMP_OIL_STAR = 1,
    // VOL_OIL = 2,
  };

  void fillVarNames(gpaStringVector &varNames) const override {}

  // Задаем начальные условия для переменнных
  gpaResult initVariables(gpaVector &variables) const override {
    variables[TEMP_GAS_STAR] = temp_gas_star_zero; // 872+273;
    variables[TEMP_OIL_STAR] = temp_gas_oil_zero;  // 459+273;
    // variables[VOL_OIL] = 0;//459+273;
    return GPA_RESULT_OK;
  }

  //++++++++++++ Инициализация переменных

  //+++++++++++++ Инициализация остального
  // Главная функция инициалзации
  gpaResult initialize() override {

    initFlows();

    initMedium();

    calcOutSurfArea();
    calcGeomPars();
    calcGeomParsGasPipeline();
    calcGeomParsHotOilPipeline();

    return GPA_RESULT_OK;
  }

  // параметры для расчета тепломассопереноса в межтрубном пространстве СС
  void calcGeomPars() {

    nPipeСС = nPipeCorСС + nPipeSmСС;
    DPipeCC = dPipeCC + deltaPipeCC;
    DpCC = DPipeCC + hRib;
  }

  // для расчета тепломассопереноса в межтрубном пространстве RС
  void calcGeomParsGasPipeline() {
    // CC
    sRibStar = nPipeСС / (nPipeCorСС) * (1 / kRib);
    gasPipeCC.sRib = sRibStar;

    psiRib = 1 / (2 * DPipeCC * sRibStar) *
                 (DpCC * DpCC - dPipeCC * dPipeCC + 2 * DpCC * deltaRib) +
             1 - deltaRib / sRibStar;

    gasPipeCC.d_equal = 2 * (sRibStar * (s1 - DPipeCC) - 2 * deltaRib * hRib) /
                        (2 * hRib + sRibStar);
    sStar = std::min(s1, s3);
    gasPipeCC.crossArea = ((sStar - DPipeCC) * sRibStar - deltaRib * hRib) *
                          (aCC * bCC) / (s1 * sRibStar);
    gasPipeCC.n_ch = 4.0;
    gasPipeCC.l_char =
        (sRibStar - deltaRib) * DPipeCC / (sRibStar * psiRib) +
        (DpCC * DpCC - dPipeCC * dPipeCC + 2 * DpCC * deltaRib) /
            (1 * sRibStar * DPipeCC * psiRib) *
            sqrt(std::numbers::pi / 4 * (DpCC * DpCC - dPipeCC * dPipeCC));

    gasPipeCC.psiRib = psiRib;

    gasPipeCC.m = 0.33;
    cConst = 0.36;
    nConst = 0.6;
    gasPipeCC.c =
        cConst * pow((s1 - DPipeCC) / (s3 - DPipeCC), 0.1) * pow(psiRib, -0.5);
    gasPipeCC.n = nConst * pow(psiRib, 0.07);
    gasPipeCC.nRow = (nPipeСС - 1) / 2 + 1;

    gasPipeCC.getZeta0R();
    // CC

    // RC
    DPipeRC = dPipeRC + deltaPipeRC;
    sLSRC = aRC * bRC - 8 * nPipeRC * (std::numbers::pi * pow(DPipeRC, 2)) /
                            4; //(s_"жс")_"КР"
    pWetRC = std::numbers::pi * DPipeRC * 8 * nPipeRC + 2 * (aRC + bRC);
    dGasRC = 4 * sLSRC / pWetRC;

    gasPipeRC.n_ch = 1.0;
    gasPipeRC.d_char = dGasRC;
    gasPipeRC.crossArea = sLSRC;
    gasPipeRC.l_ch = lPipeRC;
    gasPipeRC.epsilon = epsilonRC;
    gasPipeRC.deltaH = lPipeRC;
    // RC
  }

  // Расчет площади внешней поверхности, с которой тепло уходит в окр среду, с
  // учетом слоя утеплителя
  void calcOutSurfArea() {
    sAtmSideCC =
        8.0 * (aCC + bCC + 4.0 * dIsoCC) * hCC1 +
        2.0 * (10.0 * aCC + bCC + 2.0 * dIsoCC) * (hCC2 + 2.0 * dIsoCC) +
        14.0 * (aCC + 2.0 * dIsoCC) * (bCC + 2.0 * dIsoCC);
    sAtmSideRC = 2.0 * (aRC + bRC + 4.0 * dIsoRC) * lPipeRC;
  }

  // параметры геометрии трубопровода с ГМ
  void calcGeomParsHotOilPipeline() {
    oilPipeCC.n_ch = 8.0;
    oilPipeCC.d_char = dPipeCC;
    oilPipeCC.crossArea = std::numbers::pi * pow(dPipeCC, 2.0) / 4.0;
    oilPipeCC.l_ch = nPipeСС * lPipeCC;
    oilPipeCC.epsilon = epsilonСС;
    oilPipeCC.deltaH = -2.0 * s2 * ((nPipeСС - 1.0) / 2.0 + 1.0);
    oilPipeCC.calcVolume();

    oilPipeRC.n_ch = 8.0;
    oilPipeRC.d_char = dPipeRC;
    oilPipeRC.crossArea = std::numbers::pi * pow(dPipeRC, 2.0) / 4.0;
    oilPipeRC.l_ch = nPipeRC * lPipeRC;
    oilPipeRC.epsilon = epsilonRC;
    oilPipeRC.deltaH = -lPipeCC;
    oilPipeRC.calcVolume();

    total_volume_oil = oilPipeCC.volume + oilPipeRC.volume;
  }

  // Инициализация среды
  void initMedium() {

    m_medium_Gas = gasInlet->getStreamMedium()->copyTo(asOwner());
    m_medium_ExchGas = gasOut->getStreamMedium()->copyTo(asOwner());
    m_medium_Oil = oilInlet->getStreamMedium()->copyTo(asOwner());

    oilPipeCC.flag = oilPipeRC.flag = gasPipeCC.flag = gasPipeRC.flag =
        flagMixBibl;

    oilPipeCC.pipe_Name = oilPipeRC.pipe_Name = "terminol";
    oilPipeCC.fluid = oilPipeRC.fluid = "oil";
    oilPipeCC.medium = oilPipeRC.medium = m_medium_Oil;

    gasPipeCC.pipe_Name = gasPipeRC.pipe_Name = "exhaustGas";
    gasPipeCC.fluid = gasPipeRC.fluid = "gas";
    gasPipeCC.medium = gasPipeRC.medium = m_medium_Gas;

    // exportBiblProps("C:\\Users\\workstation777\\Desktop\\Matvey\\0
    // Saturn\\db\\");

    burner.concMin = 0.05;
    burner.flueGasPort = gasInlet;
    burner.medium = m_medium_Gas;

    burner.calcBurning(0);

    updateAllPipeProperties();
  }

  void exportBiblProps(string way) {
    cout << " Export props VS T " << endl;
    gpaDataVector frFuelGas = gasInlet->getStreamFractions();
    gpaDataVector frOil = oilInlet->getStreamFractions();
    gpaDataVector frExhaustGas = {0, 0, 0, 0, 0};

    cout << endl;

    oilPipeCC.exportCurrentBiblProps(way, 293.0, 600.0, 10.0, frOil);

    cout << " FuelGas --> ";
    for (size_t i = 0; i < frExhaustGas.size(); i++) {
      cout << frFuelGas[i] << " ";
    }

    cout << endl;

    gasPipeCC.pipe_Name = "fuelGas";
    gasPipeCC.exportCurrentBiblProps(way, 293.0, 2273.0, 10.0, frFuelGas);

    cout << " ExhaustGas --> ";
    gpaReal total = 0.0;
    frExhaustGas = {0, 0, 0, 0, 0};

    for (int i = 0; i < frExhaustGas.size(); i++) {
      frExhaustGas[i] = frFuelGas[i] + delta_gas_fraction[i];
      total += frExhaustGas[i];
      cout << frExhaustGas[i] << " " << delta_gas_fraction[i] << " | ";
    }

    gasPipeCC.pipe_Name = "exhaustGas c_CH4 = " + to_string(frExhaustGas[2]);
    gasPipeCC.exportCurrentBiblProps(way, 293.0, 2273.0, 10.0, frExhaustGas);

    for (size_t j = 0; j <= 10; j++) {
      cout << " ExhaustGas --> ";
      gpaReal total = 0.0;
      frExhaustGas = {0, 0, 0, 0, 0};

      for (int i = 0; i < frExhaustGas.size(); i++) {
        frExhaustGas[i] = frFuelGas[i] + j / 10.0 * delta_gas_fraction[i];
        total += frExhaustGas[i];
        cout << frExhaustGas[i] << " " << j / 10.0 * delta_gas_fraction[i]
             << " | ";
      }

      gasPipeCC.pipe_Name = "exhaustGas c_CH4 = " + to_string(frExhaustGas[2]);
      gasPipeCC.exportCurrentBiblProps(way, 293.0, 2273.0, 10.0, frExhaustGas);
    }

    cout << " ------- " << endl;

    // while (1>0)
    // {

    // }
  }

  void updateAllPipeProperties() {

    oilPipeCC.getStandartPackProp({1});
    oilPipeRC.getStandartPackProp({1});

    // gpaDataVector fr = gasInlet->getStreamFractions();

    gasPipeCC.getStandartPackProp(burner.fr_EG_Out);
    gasPipeRC.getStandartPackProp(burner.fr_EG_Out);
  }

  // Инициализация потоков
  void initFlows() {
    circuit_Gas = getMixCircuit(GPA_ELEM_CIRCUIT_0);
    circuit_Oil = getMixCircuit(GPA_ELEM_CIRCUIT_Oil);

    gasInlet = circuit_Gas->getPort(0);
    gasOut = circuit_Gas->getPort(1);
    oilInlet = circuit_Oil->getPort(0);
    oilOut = circuit_Oil->getPort(1);

    G_in_gas = 1; // flowCond
    G_in_oil = 1; // flowCond
  }

  //+++++++++++++++++ Инициализация остального

  //+++++++++++++++++ Библиотека смесей для тестирования

  // Функция, выдающая свойства ГМ. Функции получены интерполяцией табличных
  // зависимостей терминола 66
  gpaReal getOilProp(gpaString par, gpaReal T) {
    if (par == "rho") {
      return 1236.69 - 0.745665 * T; // kg/m^3
    }
    if (par == "cp") {
      return (0.5211052170945513 + 0.0035340139549585384 * T); // kJ/kg/K
    }
    if (par == "lambda") {
      return (0.15395 - 0.000103468 * T) / 1000; // kW/K/m
    }
    if (par == "eta") {
      return 21.834 / pow(T - 273, 1.912); // Pa*s
    }
    if (par == "mu") {
      return 252.0; // kg/kmol
    }
  }

  // Функция, выдающая свойства ГС и ДГ. Для простоты взяты табличные
  // зависимости воздуха при 1 атм
  gpaReal getGasProp(gpaString par, gpaReal T) {
    if (par == "rho") {
      return 365.863 / T;
    }
    if (par == "cp") {
      return (-229.668 + 463.18 * pow(T, 0.168614)) / 1000.0;
    }
    if (par == "lambda") {
      return (0.00396343 + 0.0000706675 * T) / 1000.0;
    }
    if (par == "eta") {
      return -2.96295 * pow(10.0, -6.0) +
             3.65048 * pow(10.0, -7.0) * pow(T, 0.696601);
    }
    if (par == "mu") {
      return 29.0;
    }
  }

  //+++++++++++++++++ Библиотека смесей для тестирования

  //+++++++++++++++++ Функции, которые будут использоваться на каждой итерации

  //+++ Расчет перепадов давлений
  void calcDeltaP(bool isShow) {
    // m_medium_RC_oil->calcFlashPT(P_in_oil, TMeanRCOil,
    // m_medium_RC_oil->getFractions());

    // prop
    updateAllPipeProperties();
    // std::cout << " my | gasPipeRC " << " | " <<
    // myRound(gasPipeRC.viscosity*pow(10,6),1) << " | " <<
    // myRound(gasPipeRC.lambda*pow(10,6),1) << " | "<<
    // myRound(gasPipeRC.density,2)<<  " | " << myRound(gasPipeRC.cp,2) << " | "
    // << gasPipeRC.mu<< "\n"; std::cout << " my | oilPipeRC " << " | " <<
    // myRound(oilPipeRC.viscosity*pow(10,6),0)  << " | " <<
    // myRound(oilPipeRC.lambda*pow(10,6),0) << " | "<<
    // myRound(oilPipeRC.density,0)<<  " | " << myRound(oilPipeRC.cp,2) << " | "
    // << oilPipeRC.mu<< "\n";

    // oil
    oilPipeCC.calcMyPipeMeanFlowProp1(isShow, G_in_oil);
    oilPipeRC.calcMyPipeMeanFlowProp1(isShow, G_in_oil);

    P_star_oil = P_in_oil + oilPipeCC.DP_Frick;
    deltaP_oil = oilPipeRC.DP_Frick;

    // gas

    gasPipeRC.calcMyPipeMeanFlowProp1(isShow, G_in_gas);
    gasPipeCC.calcMyPipeMeanFlowProp2(isShow, G_in_gas, T_star_gas, T_out_gas);

    P_star_gas = P_in_gas + gasPipeRC.DP; // ??? Problem with add gasPipeRC.DP

    if (isShow == 1) {
      std::cout << "  gasPipeRC " << " | " << gasPipeRC.DP << " | " << "\n";
    }

    deltaP_gas = gasPipeRC.DP;
  }
  //+++ Расчет перепадов давлений

  //+++ Расчет свойств потоков
  void calcFlowProperties() {

    T_in_gas = gasInlet->getStreamTemperature();
    T_in_oil = oilInlet->getStreamTemperature();

    T_out_gas = gasOut->getStreamTemperature();
    T_out_oil = oilOut->getStreamTemperature();

    // Get G&P
    G_in_gas = gasInlet->getIncomingFlowRate();
    P_in_gas = gasInlet->getStreamPressure();
    G_in_oil = oilInlet->getIncomingFlowRate();
    P_in_oil = oilInlet->getStreamPressure();

    G_out_gas = gasOut->getIncomingFlowRate();
    G_out_oil = oilOut->getIncomingFlowRate();
    P_out_gas = gasOut->getStreamPressure();
    P_out_oil = oilOut->getStreamPressure();

    m_dot_gas = gasInlet->getIncomingMassRate();
    m_dot_oil = oilInlet->getIncomingMassRate();
  }
  //+++ Расчет свойств потоков

  //+++ Расчет теплообмена

  // Расчет кол-ва тепла, которое уходит в окр среду с внешней поеврхности
  // установки
  void calcQInAtm(bool isShow) {

    QAtmCC = alphaAtmCC / 1000.0 * sAtmSideCC * (gasPipeCC.meanTemp - TAirAtm) /
             (1 + (alphaAtmCC * dIsoCC) / lambdaAtmCC);
    QAtmRC = alphaAtmRC / 1000.0 * sAtmSideRC * (gasPipeRC.meanTemp - TAirAtm) /
             (1 + (alphaAtmRC * dIsoRC) / lambdaAtmRC);

    if (isShow == 1) {
      cout << "   -- Atm --  " << endl;

      cout << "QAtmCC = " << QAtmCC << "| QAtmCC/Q = " << 100 * QAtmCC / Q
           << endl;
      cout << "QAtmRC = " << QAtmRC << "| QAtmRC/Q = " << 100 * QAtmRC / Q
           << endl;

      cout << "   -- Atm --  " << endl;
    }
  }

  // Расчет средних температур в каналах
  void calcMeanTemp(bool isShow) {

    if (isShow == 1) {
      cout << " calcMeanTemp " << endl;
    }

    gasPipeRC.meanTemp = (burner.T_Burned_gas + T_star_gas) / 2;
    gasPipeCC.meanTemp = (T_out_gas + T_star_gas) / 2;
    oilPipeCC.meanTemp = (T_in_oil + T_star_oil) / 2;
    oilPipeRC.meanTemp = (T_out_oil + T_star_oil) / 2;
    if (isShow == 1) {
      cout << " calcMeanTemp " << endl;
    }
  }

  // Расчет средних значений давлений в каналах
  void calcMeanPressure() {
    gasPipeRC.meanPressure = (P_in_gas + P_star_gas) / 2;
    gasPipeCC.meanPressure = (P_out_gas + P_star_gas) / 2;
    oilPipeCC.meanPressure = (P_in_oil + P_star_oil) / 2;
    oilPipeRC.meanPressure = (P_out_oil + P_star_oil) / 2;
  }

  gpaReal myRound(gpaReal x, gpaReal n) {
    return round(x * pow(10, n)) / pow(10, n);
  }

  gpaReal build_polinom(vector<gpaReal> coef_List, gpaReal x) {
    gpaReal res = 0;
    for (size_t i = 0; i < coef_List.size(); i++) {
      res += coef_List[i] * pow(x, i);
    }
    return res;
  }

  // Функция сигмойда
  gpaReal sigmoid(gpaReal x) { return 1.0 / (1.0 + std::exp(-x)); }

  // Получить средне-логарифмический перепад температур 0 -  соноправленное
  // течение, 1 - противонаправленное течение
  gpaResult getLMTD(gpaReal T_in_1, gpaReal T_out_1, gpaReal T_in_2,
                    gpaReal T_out_2, gpaUInt i_Flow_Scheme) {
    gpaReal bigDelta;
    gpaReal smallDelta;
    gpaReal sign;

    if (i_Flow_Scheme = 0) {
      bigDelta = abs(T_in_1 - T_in_2);
      smallDelta = abs(T_out_1 - T_out_2);

      sign = (T_in_1 > T_in_2) ? 1 : -1;

    } else {
      bigDelta = abs(T_in_1 - T_out_2);
      smallDelta = abs(T_out_1 - T_in_2);

      sign = (T_in_1 > T_in_2)    ? (T_out_1 > T_in_2) ? 1 : 0
             : (T_in_2 > T_out_1) ? -1
                                  : 0;
    }

    gpaReal LMTD_True =
        (bigDelta - smallDelta) / (log(bigDelta / (smallDelta + 0.00001)));
    gpaReal LMTD_Simple = (bigDelta + smallDelta) / 2;
    gpaReal diffDelta = bigDelta - smallDelta;

    gpaReal sigm = sigmoid(1 * (diffDelta - 1));

    gpaReal LMTD = LMTD_Simple * (1 - sigm) + sigm * LMTD_True;

    return sign * LMTD;
  }

  // Расчитывает поправочные коэффициенты
  void setCurrentHTPars(bool isShow) {

    vector<gpaReal> coef_List_kQCC = {0.871725, -0.258519, 0.0353535,
                                      -0.00116684};
    vector<gpaReal> coef_List_kQRC = {0.167331, -0.0371499, 0.0139911,
                                      -0.00052326};

    if (m_dot_gas < 3) {
      kQCC = 0.4;
      kQRC = 0.12;
    } else {
      if (m_dot_gas > 16.712) {
        kQCC = 1;
        kQRC = 1;
      } else {
        kQCC = build_polinom(coef_List_kQCC, m_dot_gas);
        kQRC = build_polinom(coef_List_kQRC, m_dot_gas);
      }
    }

    if (isShow == 1) {
      cout << endl << " <--- current HT correction --->" << endl;
      cout << "m_dot_gas" << " | " << "kQCC" << " | " << "kQRC" << " | "
           << endl;
      cout << m_dot_gas << " | " << kQCC << " | " << kQRC << " | " << endl;
      cout << "<--- set pars --->" << endl << endl;
    }
  }

  // Расчет теплообмена
  void calcHeatEchange(bool isShow) {

    if (isShow == 1) {
      std::cout << "  <--  calcHeatEchange --> " << "\n";
    }

    qRadRC = sigmoid(m_dot_gas - 2) *
             burner.getqRadRC(isShow, gasPipeRC.meanTemp, oilPipeRC.meanTemp) /
             1000; // m_dot_gas> ... нужно, чтобы не выпадала ошибка с якобианом

    LMTDRC = getLMTD(burner.T_Burned_gas, T_star_gas, T_star_oil, T_out_oil,
                     1);                                              // 817.727
    LMTDCC = getLMTD(T_star_gas, T_out_gas, T_in_oil, T_star_oil, 1); // 180.015

    alphaRC = gasPipeRC.alpha_conv; // 47/1000
    alphaCC = gasPipeCC.alpha_conv; // 94/1000

    sSideRC =
        8.0 * std::numbers::pi * dPipeRC * lPipeRC * nPipeRC; /// 2.0;//512.708
    sSideCC = 8.0 * std::numbers::pi * dPipeCC * lPipeCC * nPipeСС; // 395.041

    if (m_dot_gas > 1.3) // flow limits
    {
      if (setParsMethodFlag == 1) {
        setCurrentHTPars(isShow);
      }
    }

    QRC = kQRC * (alphaRC * LMTDRC + qRadRC) * sSideRC;
    QCC = kQCC * alphaCC * LMTDCC * sSideCC;

    // vol_Switcher = 0.1 + sigmoid((vol_oil - total_volume_oil)/deltaVolume);
    // Q   = vol_Switcher*(QCC + QRC);

    Q = 1 * (QCC + QRC);
    // Разница энтальпии между входом и выходом

    Delta_H_Gas_Fixed =
        burner.q_burn_unit_flow -
        (Q + QAtmRC + QAtmCC) /
            (G_in_gas + 0.01); // dQ/dot_m/mu КДж/КМоль // mdotCond
    Delta_H_Oil_Fixed =
        Q / (G_in_oil + 0.01); // dQ/dot_m/mu КДж/КМоль // mdotCond

    if (isShow == 1) {
      std::cout << "  LMTD  " << LMTDRC << " | " << LMTDCC << "\n";
      std::cout << "  alpha  " << alphaRC << " | " << alphaCC << "\n";
      std::cout << "  S  " << sSideRC << " | " << sSideCC << "\n";
      std::cout << "  QPart  " << QRC << " | " << QCC << "| Q ->  " << " | "
                << Q << "\n";
      std::cout << "  calcDeltaH  " << Delta_H_Gas_Fixed << " | "
                << Delta_H_Oil_Fixed << "\n";
    }
  }

  //+++ Расчет теплообмена

  // gpaResult fillMassMatrix(gpaUInt refRow, gpaUInt refCol) const
  // {
  //     gpaResult res;

  //     res = setMassMatrCoef(refRow + 6, refCol + 2, 1.0);

  //     if (res != GPA_RESULT_OK)
  //         return res;
  //     return GPA_RESULT_OK;
  // }

  // Главная функция: полный набор уравнений для "стрелок" и фазового равновесия
  gpaResult calcFuncValues(const gpaConstVector &,
                           const gpaConstVector &variables, gpaVector &values,
                           const gpaSetOfEquations &eqIds) override {
    calcFlowProperties();

    // Переименовал для удобства неизвестые перемеые. Можно потом убрать для
    // ускорения
    T_star_gas = variables[0];
    T_star_oil = variables[1];
    // vol_oil = variables[2];

    //++ Пересчет различных переменных
    calcQInAtm(1);
    burner.calcBurning(1);
    calcMeanTemp(1);

    gasPipeRC.calcMyPipeHeatTransherProp(1);
    gasPipeCC.calcMyPipeHeatTransherProp(1);

    calcHeatEchange(1);

    calcDeltaP(1);

    // if(abs(G_in_gas) > 1e-6)
    // {
    //     calcMeanPressure();
    // }

    calcMeanPressure();

    //++ Пересчет различных переменных

    getProps(1); // Вывод различных переменных

    //++ Формирование уравнений для невязок

    values[0] = P_in_gas - P_out_gas - deltaP_gas;
    values[1] = G_in_gas + G_out_gas;
    values[2] = P_in_oil - P_out_oil - deltaP_oil;
    values[3] = G_in_oil + G_out_oil;

    // Уравнения баланса  для газа в RC
    values[4] =
        (m_dot_gas + 0.01) * (burner.T_Burned_gas - T_star_gas) * gasPipeRC.cp -
        (QRC + QAtmRC); // flowCond
    // Уравнения баланса  для масла в СС
    values[5] = (m_dot_oil + 0.01) * (T_star_oil - T_in_oil) * oilPipeCC.cp -
                QCC; // flowCond

    // gpaReal volRate = oilInlet->getIncomingVolRate();

    // values[6] =  volRate * (1 - vol_Switcher);

    // cout << " volRate "   << " | "  <<  volRate  << endl;
    // cout << " vol_oil "   << " | "  <<  vol_oil  << endl;
    // cout << " v_oil_CC "   << " | "  <<  oilPipeCC.volume  << " v_oil_RC " <<
    // " | "  <<  oilPipeRC.volume  << " total_volume_oil "   << " | "  <<
    // total_volume_oil  << endl;
    //++ Формирование уравнений для невязок

    return GPA_RESULT_OK;
  }

  void getProps(bool imShow) {

    getCpOnPorts();

    if (imShow == 1) {
      cout << endl << "  <-- Props --> " << endl;

      cout << " Cp_M_in_gas " << " | " << "gasPipeRC.cp " << " | "
           << "Cp_M_star_gas " << endl;
      cout << Cp_M_in_gas << " | " << gasPipeRC.cp << " | " << Cp_M_star_gas
           << endl;

      cout << " oilPipeCC.cp " << endl;
      cout << oilPipeCC.cp << endl;

      cout << "T_in_gas" << " | " << "T_burn" << " | " << "T_star_gas" << " | "
           << "T_out_gas" << endl;
      cout << T_in_gas - 273 << " | " << burner.T_Burned_gas - 273 << " | "
           << T_star_gas - 273 << " | " << T_out_gas - 273 << endl;
      cout << "        " << " | " << "T_out_oil" << " | " << "T_star_oil"
           << " | " << "T_in_oil" << endl;
      cout << "        " << " | " << T_out_oil - 273 << " | "
           << T_star_oil - 273 << " | " << T_in_oil - 273 << endl;

      cout << "-- m_dot_gas -> " << m_dot_gas << " | -- m_dot_oil -> "
           << m_dot_oil << endl;
      cout << "-- concCH4 -> " << concCH4 << " | " << "-- concCH4/concMin -> "
           << 100 * concCH4 / concMin << " %" << endl;
    }
  }

  // Расчет свойств промежуточных точек трактов (г* и м*)
  void getCpOnPorts() {

    if (flagMixBibl == 0.0) {
      // Расчет теплоемкости входщих потоков ТС и ГМ
      Cp_M_in_gas = getGasProp("cp", T_in_gas);
      Cp_M_in_oil = getOilProp("cp", T_in_oil);

      // Расчет теплоемкости выходящих потоков ДГ и ГМ для сравнения с ИД
      Cp_M_out_gas = getGasProp("cp", T_out_gas);
      Cp_M_out_oil = getOilProp("cp", T_out_oil);

      // Расчет свойств промежуточных точек трактов (г* и м*)
      Cp_M_star_gas = getGasProp("cp", T_star_gas);
      Cp_M_star_oil = getOilProp("cp", T_star_oil);

      // trustCpAndQBalance(0);
    } else {

      // Расчет теплоемкости входщих потоков ТС и ГМ
      Cp_M_in_gas = gasInlet->getStreamMedium()->getHeatCapacity() /
                    gasInlet->getStreamMedium()->getMolarMass();
      Cp_M_in_oil = oilInlet->getStreamMedium()->getHeatCapacity() /
                    oilInlet->getStreamMedium()->getMolarMass();

      // Расчет свойств промежуточных точек трактов (г* и м*)
      m_medium_ExchGas->calcFlashPT(P_in_gas, T_star_gas,
                                    m_medium_ExchGas->getFractions());
      Cp_M_star_gas = m_medium_ExchGas->getHeatCapacity() /
                      m_medium_ExchGas->getMolarMass();

      m_medium_Oil->calcFlashPT(P_in_oil, T_star_oil,
                                m_medium_Oil->getFractions());
      Cp_M_star_oil =
          m_medium_Oil->getHeatCapacity() / m_medium_Oil->getMolarMass();

      // Расчет теплоемкости выходящих потоков ТС и ГМ
      Cp_M_out_gas = gasOut->getStreamMedium()->getHeatCapacity() /
                     gasOut->getStreamMedium()->getMolarMass();
      Cp_M_out_oil = oilOut->getStreamMedium()->getHeatCapacity() /
                     oilOut->getStreamMedium()->getMolarMass();
    }
  }

  void trustCpAndQBalance(bool isNeedShowCpVST) {

    // trust cp
    std::cout << "  -port-   " << " | " << "P_in_gas" << " | " << "T" << " | "
              << "bibl" << " | " << "table" << " | " << "delta, %" << "\n";

    m_medium_Gas->calcFlashPT(P_in_gas, T_in_gas, m_medium_Gas->getFractions());
    gpaReal current_cp_1 =
        m_medium_Gas->getHeatCapacity() / m_medium_Gas->getMolarMass();
    std::cout << "  in_gas   " << " | " << P_in_gas << " | "
              << myRound(T_in_gas - 273, 1) << " | " << myRound(current_cp_1, 2)
              << " | " << myRound(Cp_M_in_gas, 2) << " | "
              << myRound(100 * (current_cp_1 - Cp_M_in_gas) / Cp_M_in_gas, 1)
              << "\n";

    m_medium_Gas->calcFlashPT(P_out_gas, T_out_gas,
                              m_medium_Gas->getFractions());
    gpaReal current_cp_2 =
        m_medium_Gas->getHeatCapacity() / m_medium_Gas->getMolarMass();
    std::cout << "  out_gas  " << " | " << P_out_gas << " | "
              << myRound(T_out_gas - 273, 1) << " | "
              << myRound(current_cp_2, 2) << " | " << myRound(Cp_M_out_gas, 2)
              << " | "
              << myRound(100 * (current_cp_2 - Cp_M_out_gas) / Cp_M_out_gas, 1)
              << "\n";

    m_medium_Oil->calcFlashPT(P_in_oil, T_in_oil, m_medium_Oil->getFractions());
    gpaReal current_cp_3 =
        m_medium_Oil->getHeatCapacity() / m_medium_Oil->getMolarMass();
    std::cout << "  in_oil   " << " | " << P_in_oil << " | "
              << myRound(T_in_oil - 273, 1) << " | " << myRound(current_cp_3, 2)
              << " | " << myRound(Cp_M_in_oil, 2) << " | "
              << myRound(100 * (current_cp_3 - Cp_M_in_oil) / Cp_M_in_oil, 1)
              << "\n";

    m_medium_Oil->calcFlashPT(P_out_oil, T_out_oil,
                              m_medium_Oil->getFractions());
    gpaReal current_cp_4 =
        m_medium_Oil->getHeatCapacity() / m_medium_Oil->getMolarMass();
    std::cout << "  out_oil  " << " | " << P_out_oil << " | "
              << myRound(T_out_oil - 273, 1) << " | "
              << myRound(current_cp_4, 2) << " | " << myRound(Cp_M_out_oil, 2)
              << " | "
              << myRound(100 * (current_cp_4 - Cp_M_out_oil) / Cp_M_out_oil, 1)
              << "\n";

    // trust cp
    gpaReal Q1 =
        (current_cp_1 + current_cp_2) / 2 * m_dot_gas * (T_out_gas - T_in_gas);
    gpaReal Q2 =
        (Cp_M_in_gas + Cp_M_out_gas) / 2 * m_dot_gas * (T_out_gas - T_in_gas);
    gpaReal Q3 =
        (current_cp_3 + current_cp_4) / 2 * m_dot_oil * (T_out_oil - T_in_oil);
    gpaReal Q4 =
        (Cp_M_in_oil + Cp_M_out_oil) / 2 * m_dot_oil * (T_out_oil - T_in_oil);

    std::cout << " " << "\n";
    std::cout << " <-- Q balance --> " << "\n";
    std::cout << " Q_gas  " << " | " << myRound(Q1, 1) << " | "
              << myRound(Q2, 1) << " | " << myRound((Q1 - Q2) / Q2 * 100, 1)
              << "\n";
    std::cout << " Q_oil  " << " | " << myRound(Q3, 1) << " | "
              << myRound(Q4, 1) << " | " << myRound((Q3 - Q4) / Q4 * 100, 1)
              << "\n";
    std::cout << " Q_total " << " | " << myRound(Q3 + Q1, 1) << " | "
              << myRound(Q4 + Q2, 1) << " | "
              << myRound((Q1 + Q3 - Q4 - Q2) / (Q4 + Q2) * 100, 1) << "\n";

    std::cout << " <-- Q balance --> " << "\n";
    std::cout << " " << "\n";
  }

  // Невязка по энтальпии
  gpaResult calcEnthalpyFuncValueAt(gpaUInt circIdx, gpaUInt portIdx,
                                    gpaReal enthalpy,
                                    gpaReal &funcValue) const override {
    if (circIdx == GPA_ELEM_CIRCUIT_0) {
      const gpaMixPort *oppPort = getMixPort(GPA_ELEM_CIRCUIT_0, 1 - portIdx);
      if (!oppPort)
        return GPA_ERROR_WRONG_ARGS;
      funcValue = enthalpy - oppPort->getStreamMedium()->getEnthalpy() -
                  Delta_H_Gas_Fixed;
      // printf("Gas enthalpy %d: %f\n", portIdx, funcValue);
      return GPA_RESULT_OK;
    }
    if (circIdx == GPA_ELEM_CIRCUIT_Oil) {
      const gpaMixPort *oppPort2 =
          getMixPort(GPA_ELEM_CIRCUIT_Oil, 1 - portIdx);
      if (!oppPort2)
        return GPA_ERROR_WRONG_ARGS;
      funcValue = enthalpy - oppPort2->getStreamMedium()->getEnthalpy() -
                  Delta_H_Oil_Fixed;
      // printf("Oil enthalpy %d: %f\n", portIdx, funcValue);
      return GPA_RESULT_OK;
    }
    return GPA_ERROR_WRONG_ARGS;
  }

  // Невязка по компонентам — для выходных портов сравниваем с переменными
  // разделителя
  gpaResult calcFractionsFuncValuesAt(gpaUInt circIdx, gpaUInt portIdx,
                                      const gpaConstVector &fractions,
                                      gpaVector &funcValues) const override {
    if (circIdx == GPA_ELEM_CIRCUIT_0) {

      const gpaMixPort *oppPort = getMixCircuit(circIdx)->getPort(1 - portIdx);
      if (!oppPort)
        return GPA_ERROR_WRONG_ARGS;
      const gpaConstVector calcFractions =
          oppPort->getStreamMedium()->getFractions();

      for (gpaUInt i = 0; i < funcValues.size(); ++i)
        funcValues[i] = fractions[i] - burner.fr_EG_Out[i];

      // printf("Gas fractions %d\n", portIdx);
      //  for (gpaUInt i = 0; i < funcValues.size(); ++i)
      //      printf("%f | ", funcValues[i]);
      //  printf("\n");
      return GPA_RESULT_OK;
    }

    if (circIdx == GPA_ELEM_CIRCUIT_Oil) {

      const gpaMixPort *oppPort2 = getMixCircuit(circIdx)->getPort(1 - portIdx);
      ;
      if (!oppPort2)
        return GPA_ERROR_WRONG_ARGS;
      const gpaConstVector calcFractions2 =
          oppPort2->getStreamMedium()->getFractions();
      for (gpaUInt i = 0; i < funcValues.size(); ++i)
        funcValues[i] = fractions[i] - calcFractions2[i];
      // printf("Oil fractions %d\n", portIdx);
      //  for (gpaUInt i = 0; i < funcValues.size(); ++i)
      //      printf("%f | ", funcValues[i]);
      //  printf("\n");
      return GPA_RESULT_OK;
    }

    return GPA_ERROR_WRONG_ARGS;
  }

  virtual const gpaString &getTypeName() const override {
    return getDeviceTypeName();
  }
  virtual const gpaString &getDescription() const override {
    return getDeviceDescription();
  }

private:
  gpaElementMixCircuit *circuit_Gas;
  gpaElementMixCircuit *circuit_Oil;

  void calcThermalParams() {
    gpaReal d = m_d;
    gpaReal l = m_l;
    // PIPE (основная труба)
    m_R_pipe = 0;
    m_A_in_pipe = std::numbers::pi * d * l;
    gpaReal radius_inner = d / 2.0;
    for (const auto &layer : m_heatLayers) {
      gpaReal r1 = radius_inner;
      gpaReal r2 = r1 + layer.thickness;
      m_R_pipe += std::log(r2 / r1) /
                  (2 * std::numbers::pi * layer.heatConductivity * l);
      radius_inner = r2;
    }
    m_A_out_pipe = std::numbers::pi * (2 * radius_inner) * l;

    // GAS (газовая сторона, пусть конструкция аналогична)
    m_R_gas = m_R_pipe;
    m_A_in_gas = m_A_in_pipe;
    m_A_out_gas = m_A_out_pipe;
  }

public:
  // Переключатель библиотек
  gpaReal flagMixBibl = 1.0;
  gpaReal setParsMethodFlag = 1.0;

  // Параметры геометрии:
  gpaReal m_d = 0.0;       // внутренний диаметр (м)
  gpaReal m_l = 0.0;       // длина аппарата (м)
  gpaReal m_dh = 0.0;      // гидростат. напор (м)
  gpaReal m_nBends = 0.0;  // число колен
  gpaReal m_eps = 0.0;     // шероховатость (м)
  gpaReal m_Tenv = 298.15; // температура окружающей среды (К)

  gpaHeatLayerVector m_heatLayers;

  // PIPE (общая труба)
  gpaReal m_R_pipe = 1.0;
  gpaReal m_A_in = 0.0;
  gpaReal m_A_out = 0.0;
  gpaReal m_A_in_pipe = 0.0;
  gpaReal m_A_out_pipe = 0.0;
  gpaReal m_alpha_in_pipe = 0.0;
  gpaReal m_alpha_out_pipe = 0.0;

  // GAS (газовая)
  gpaReal m_R_gas = 1.0;
  gpaReal m_A_in_gas = 0.0;
  gpaReal m_A_out_gas = 0.0;
  gpaReal m_alpha_in_gas = 0.0;
  gpaReal m_alpha_out_gas = 0.0;
  gpaReal m_wall_diamet1;
  gpaReal m_wall_diamet2;
  gpaReal m_wall_diamet3;
  gpaReal m_hydro_coeff;
  gpaReal m_diametr;
  gpaReal m_wall_conductive1;
  gpaReal m_wall_conductive2;

  // gpaHeatCoeffPrm m_hydro_coeff;

  // Проcтые трубы
  myPipe_FOH oilPipeCC;
  myPipe_FOH oilPipeRC;
  myPipe_FOH gasPipeRC;

  simpleBurner_FOH burner;

  // Для межтрубного пространства CC используется модель трубы с оребрением
  myPipeRib_FOH gasPipeCC;

  const gpaMixPort *gasInlet;
  const gpaMixPort *gasOut;
  const gpaMixPort *oilInlet;
  const gpaMixPort *oilOut;

  gpaReal vol_oil;
  gpaReal deltaVolume = 10;
  gpaReal total_volume_oil;
  gpaReal vol_Switcher = -10;
  gpaReal timeCalc;
  gpaReal volumeOilChannel;

  // Расчет параметров геометрии и течения в межтрубном пучке оребренных труб КК
  gpaReal qRadRC = 0;
  gpaReal concCH4 = 0;
  gpaReal concMin = 0.05;

  gpaReal m;
  gpaReal cConst;
  gpaReal nConst;
  gpaReal c;
  gpaReal n;

  gpaReal sLSRC;
  gpaReal dGasRC;
  gpaReal DPipeRC;
  gpaReal pWetRC;

  //

  gpaReal mGasCC;
  gpaReal sStar;
  gpaReal sMS;
  gpaReal velGasCC;
  gpaReal reEG;

  gpaReal P_star_gas;
  gpaReal P_star_oil;

  gpaReal sRib;
  gpaReal sRibStar;
  gpaReal nPipeСС;
  gpaReal DPipeCC;
  gpaReal DpCC;
  gpaReal lChar;
  gpaReal dEqual;
  gpaReal rhoGasCC;
  gpaReal etaGasCC;

  // Перечень входных геометрических параметров КР (RC - radiation chamber)
  gpaReal aRC = 6.0;
  gpaReal bRC = 4.2;
  gpaReal lPipeRC = 10.0;
  gpaReal dPipeRC = 0.102;
  gpaReal nPipeRC = 40.0;
  gpaReal deltaPipeRC = 0.006;
  gpaReal epsilonRC = 0.0001;

  // Перечень входных геометрических параметров КК (СC - convection chamber)
  gpaReal lPipeCC = 6.7;
  gpaReal dPipeCC = 0.102;
  gpaReal aCC = 1.0;
  gpaReal bCC = 6.0;
  gpaReal hCC1 = 5.0;
  gpaReal hCC2 = 1.7;
  gpaReal nPipeSmСС = 5.0;
  gpaReal nPipeCorСС = 18.0;
  gpaReal deltaPipeCC = 0.006;
  gpaReal epsilonСС = 0.0001;
  gpaReal kRib = 167.0;
  gpaReal deltaRib = 0.0012;
  gpaReal hRib = 0.015;
  gpaReal s1 = 0.2;
  gpaReal s2 = 0.086;
  gpaReal s3 = 0.2;

  // Перечень параметров окружающей установку среды+

  // Коэффициент теплоотдачи от поверхности стенки КР
  gpaReal alphaAtmRC = 10.0;
  // Коэффициент теплоотдачи от поверхности стенки КК
  gpaReal alphaAtmCC = 10.0;
  // Коэффициент теплопроводности стенки изоляции КР
  gpaReal lambdaAtmRC = 0.15;
  // Коэффициент теплопроводности стенки изоляции КК
  gpaReal lambdaAtmCC = 0.15;
  // Толщина изоляции КК
  gpaReal dIsoRC = 0.200;
  // Толщина изоляции КР
  gpaReal dIsoCC = 0.150;
  // Температура окружающей среды
  gpaReal TAirAtm = 300.0;

  // Площадь контакта СС с окружающей средой
  gpaReal sAtmSideCC;
  // Площадь контакта КС с окружающей средой
  gpaReal sAtmSideRC;
  // Тепло от CC в  окружающую среду
  gpaReal QAtmCC;
  // Тепло от RC в  окружающую среду
  gpaReal QAtmRC;

  // Теплообмен
  gpaReal temp_gas_star_zero;
  gpaReal temp_gas_oil_zero;

  gpaReal re_RC_gas;
  gpaReal Pr_RC_gas;
  gpaReal Nu_RC_gas;

  gpaReal pr_CC_gas;
  gpaReal nu_CC_gas;
  gpaReal alphaEG;
  gpaReal mRib;
  gpaReal eta;
  gpaReal psiRib;
  gpaReal kQCC;
  gpaReal kQRC;
  gpaReal alphaRC;
  gpaReal alphaCC;
  gpaReal sSideCC;
  gpaReal sSideRC;
  gpaReal LMTDRC;
  gpaReal LMTDCC;

  // Теплопроводность ребра
  gpaReal lambdaRib;

  gpaReal Delta_H_Gas_Fixed; //
  gpaReal Delta_H_Oil_Fixed; //

  // Перешедшее от газа к маслу тепло в КК
  gpaReal QCC;
  // Перешедшее от газа к маслу тепло в РК
  gpaReal QRC;
  // Перешедшее от газа к маслу тепло
  gpaReal Q;
  // Выделевшееся в ходе сгорания метана тепло
  gpaReal QBurn;
  // Изменение энтальпии ТС
  gpaReal Delta_H_Gas;
  // Изменение энтальпии ГМ
  gpaReal Delta_H_Oil;

  gpaReal P_in_gas;
  gpaReal P_out_gas;
  gpaReal P_in_oil;
  gpaReal P_out_oil;

  // Перепад давлений по маслу
  gpaReal deltaP_oil;
  // Перепад давлений по газу
  gpaReal deltaP_gas;

  // Массовый расход входящей ТС
  gpaReal m_dot_gas;
  // Массовый расход входящего ГМ
  gpaReal m_dot_oil;

  // Мольные расходы
  gpaReal G_in_gas;
  gpaReal G_star_gas;
  gpaReal G_out_gas;
  gpaReal G_in_oil;
  gpaReal G_star_oil;
  gpaReal G_out_oil;

  // Массовые теплоемкости
  gpaReal Cp_M_star_oil;
  gpaReal Cp_M_out_oil;
  gpaReal Cp_M_in_gas;
  gpaReal Cp_M_star_gas;
  gpaReal Cp_M_out_gas;
  gpaReal Cp_M_in_oil;
  gpaReal Cp_M_Burned_gas;

  // Temperature
  gpaReal T_in_gas;
  gpaReal T_star_gas;
  gpaReal T_out_gas;

  gpaReal T_in_oil;
  gpaReal T_star_oil;
  gpaReal T_out_oil;

  // Medium
  gpaMedium *m_medium_Gas;
  gpaMedium *m_medium_Oil;
  gpaMedium *m_medium_mixGas;

  gpaMedium *m_medium_ExchGas;

  // Old
  gpaReal m_temperature = 0.0;
  gpaReal m_gasEnthalpy = 0.0;
  gpaReal m_liquidEnthalpy = 0.0;
  gpaReal m_liquidFlowRate = 0.0;

  // Показывает разницу консентраций компонент смеси на выходе и на входе
  //  gpaDataVector delta_gas_fraction = {0.000740068, 0.164894, -0.0745216,
  //  0.0804703, -0.171582};
  //  // ("-" - сожгли метан и кислород, "+" - появилась вода и угл газ, доля
  //  озота поти неизменна)

  gpaDataVector delta_gas_fraction = {-0.0745216, 0.0804703, 0.164894,
                                      0.000740068, -0.171582};
  // ("-" - сожгли метан и кислород, "+" - появилась вода и угл газ, доля озота
  // поти неизменна)

public:
  static const gpaString &getDeviceTypeName() { return m_typeName; }
  static const gpaString &getDeviceDescription() { return m_description; }

private:
  static const gpaString m_typeName;
  static const gpaString m_description;
  static const gpaSensorInfoVector m_sensors;
};
#endif
