#include "gpaFlareSystemInfo.h"
#include "gpaFlareSystem.h"

gpaFlareSystemInfo::gpaFlareSystemInfo() : gpaDeviceInfo(gpaFlareSystem::getDeviceTypeName(),
                                               gpaFlareSystem::getDeviceDescription())
{
    setParameters(gpaFlareSystem::getParametersInfo());
    setSensors(gpaFlareSystem::getSensorsInfo());
}

gpaUInt gpaFlareSystemInfo::getNumMixCircuits() const
{
    return gpaFlareSystem::getDeviceNumMixCircuits();
}

gpaUInt gpaFlareSystemInfo::getMinNumMixPorts(gpaUInt index) const
{
    return gpaFlareSystem::getDeviceMinNumMixPorts(index);
}

gpaUInt gpaFlareSystemInfo::getMaxNumMixPorts(gpaUInt index) const
{
    return gpaFlareSystem::getDeviceMaxNumMixPorts(index);
}
const gpaString *gpaFlareSystemInfo::getMixPortName(gpaUInt circIdx, gpaUInt portIdx) const
{
    return gpaFlareSystem::getDeviceMixPortName(circIdx, portIdx);
}

const gpaString *gpaFlareSystemInfo::getMixCircuitName(gpaUInt index) const
{
    return gpaFlareSystem::getDeviceMixCircuitName(index);
}

gpaElement *gpaFlareSystemInfo::createDevice(const gpaCoreInterfaces *interfaces, gpaCoreReference pairDevice,
                                        const gpaExtObjectModel *model) const
{
    gpaFlareSystem *cooler = new gpaFlareSystem(interfaces, pairDevice);
    gpaResult res = cooler->specifyModel(model);
    if (res == GPA_RESULT_OK)
        return cooler;
    delete cooler;
    return NULL;
}
