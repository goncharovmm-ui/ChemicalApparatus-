#include "gpaLiquidWasteIncinerator.h"
#include "gpaLogMeanTempDifference.h"
#include "gpaZeroRadiation.h"
#include "gpaThinWall.h"
#include <iostream>

constexpr gpaUInt ID_CIRCUIT_INNER      = 0;
constexpr gpaUInt NUM_CIRCUITS          = 1;

constexpr gpaUInt ID_PORT_INLET         = 0;
constexpr gpaUInt ID_PORT_OUTLET        = 1;
constexpr gpaUInt NUM_PORTS             = 2;

constexpr gpaUInt ID_PARAM_HEAT_LOSS_RATIO           = 0x00;
constexpr gpaUInt ID_PARAM_HEAT_TRANSFER_COEF        = 0x01;
constexpr gpaUInt ID_PARAM_IN_THERMAL_EXPANSION      = 0x02;
constexpr gpaUInt ID_PARAM_OUT_THERMAL_EXPANSION     = 0x03;
constexpr gpaUInt ID_PARAM_IN_DENSITY                = 0x04;
constexpr gpaUInt ID_PARAM_OUT_DENSITY               = 0x05;
constexpr gpaUInt ID_PARAM_IN_VISCOSITY              = 0x06;
constexpr gpaUInt ID_PARAM_OUT_VISCOSITY             = 0x07;
constexpr gpaUInt ID_PARAM_IN_HEAT_CAPACITY          = 0x08;
constexpr gpaUInt ID_PARAM_OUT_HEAT_CAPACITY         = 0x09;
constexpr gpaUInt ID_PARAM_IN_CONDUCTIVITY           = 0x0A;
constexpr gpaUInt ID_PARAM_OUT_THERMAL_CONDUCTIVITY  = 0x0B;
constexpr gpaUInt ID_PARAM_FLOW_VELOCITY             = 0x0C;
constexpr gpaUInt ID_PARAM_IN_TEMPERATURE            = 0x0D;
constexpr gpaUInt ID_PARAM_OUT_TEMPERATURE           = 0x0E;

constexpr gpaUInt ID_SENSOR_PRESSURE_DROP           =  0x00;
constexpr gpaUInt ID_SENSOR_IN_MOLAR_CONSUMPTION    =  0x01;
constexpr gpaUInt ID_SENSOR_OUT_MOLAR_CONSUMPTION   =  0x02;
constexpr gpaUInt ID_SENSOR_TEMPERATURE_DIFFERENCE  =  0x03;
constexpr gpaUInt ID_SENSOR_MOLAR_CONCENTRATIONS    =  0x04;
constexpr gpaUInt ID_SENSOR_MOLAR_FLOW              =  0x05;
constexpr gpaUInt ID_SENSOR_OXYGEN                  =  0x06;

const gpaString gpaLiquidWasteIncinerator::m_typeName      = "simple";
const gpaString gpaLiquidWasteIncinerator::m_description   = "Самый простой аппрат";

const gpaParameterInfoVector gpaLiquidWasteIncinerator::m_parameters =
{
    realParam("heat-loss-ratio",            "Доля тепловых потерь в виде излучения, %",                   GPA_DIMLESS_UNIT,         false, 0.0),
    realParam("heat-transfer-coef",         "Коэффициент внешней теплоотдачи, Вт/(м²·К)",                 GPA_HEATTRANS_COEF_UNIT,  false, 0.0),
    realParam("in-thermal-expansion",       "Коэффициент теплового расширения техсреды, 1/К",             NAN,                      false, 0.0),
    realParam("out-thermal-expansion",      "Коэффициент теплового расширения среды, 1/К",                NAN,                      false, 0.0),
    realParam("in-density",                 "Плотность технологической среды, кг/м^3",                    NAN,                      false, 0.0),
    realParam("out-density",                "Плотность окружающей среды, кг/м^3",                         NAN,                      false, 0.0),
    realParam("in-viscosity",               "Динамическая вязкость техсреды, Па·с",                       NAN,                      false, 0.0),
    realParam("out-viscosity",              "Динамическая вязкость среды, Па·с",                          NAN,                      false, 0.0),
    realParam("in-heat-capacity",           "Теплоемкость техсреды, Дж/(кг·К)",                           NAN,                      false, 0.0),
    realParam("out-heat-capacity",          "Теплоемкость среды, Дж/(кг·К)",                              NAN,                      false, 0.0),
    realParam("in-conductivity",            "Теплопроводность техсреды, Вт/(м·К)",                        GPA_CONDUCTIVITY_UNIT,    false, 0.0),
    realParam("out-thermal-conductivity",   "Теплопроводность среды, Вт/(м·К)",                           GPA_CONDUCTIVITY_UNIT,    false, 0.0),
    realParam("flow-velocity",              "Скорость движения среды, м/с",                               GPA_VELOCITY_UNIT,        false, 0.0),
    realParam("in-temperature",             "Температура техсреды внутри аппарата, К",                    GPA_TEMPERATURE_UNIT,     false, 0.0),
    realParam("out-temperature",            "Температура окружающей среды, К",                            GPA_TEMPERATURE_UNIT,     false, 0.0)
};

const gpaSensorInfoVector gpaLiquidWasteIncinerator::m_sensors =
{
    scalarSensor("pressure-drop",               "Перепад давления, Па",                                                                                    GPA_PRES_DIFFER_UNIT),
    scalarSensor("in-molar-consumption",        "Молярный расход, моль/с",                                                                                 GPA_MOLAR_RATE_UNIT),
    scalarSensor("out-molar-consumption",       "Молярный расход, моль/с",                                                                                 GPA_MOLAR_RATE_UNIT),
    scalarSensor("temperature-difference",      "Перепад температур, K",                                                                                   GPA_TEMP_DIFFER_UNIT),
    scalarSensor("molar-concentrations",        "Мольные концентрации компонентов выходящих дымовых газов с дымовой трубы в атмосферу, моль.д.ед.",        GPA_AMOUNT_UNIT),
    scalarSensor("molar-flow",                  "Молярный расход несгоревшего потока, моль/с",                                                             GPA_MOLAR_RATE_UNIT),
    scalarSensor("oxygen",                      "Избыток кислорода в реакции горения, %",                                                                  GPA_DIMLESS_UNIT)
};

gpaLiquidWasteIncinerator::gpaLiquidWasteIncinerator(const gpaCoreInterfaces* interfaces, gpaCoreReference importRef) :
    gpaExportSystem (interfaces, importRef),
    m_pipes         (asParent())
{
}

gpaUInt gpaLiquidWasteIncinerator::getDeviceNumMixCircuits()
{
    return NUM_CIRCUITS;
}

gpaUInt gpaLiquidWasteIncinerator::getDeviceMinNumMixPorts(gpaUInt index)
{
    return index < NUM_CIRCUITS ? NUM_PORTS : 0;
}

gpaUInt gpaLiquidWasteIncinerator::getDeviceMaxNumMixPorts(gpaUInt index)
{
    return index < NUM_CIRCUITS ? NUM_PORTS : 0;
}

gpaResult gpaLiquidWasteIncinerator::checkParamValues(const gpaExtParameter*) const
{
    return GPA_RESULT_OK;
}

void gpaLiquidWasteIncinerator::setNames()
{
    m_pipes.setName("pipes");
}

gpaResult gpaLiquidWasteIncinerator::setParamValues(const gpaExtParameter* values, bool checkNeeded)
{
    return GPA_RESULT_OK;
}

gpaResult gpaLiquidWasteIncinerator::buildDevice()
{
    bool good = true;

    good = good && m_pipes.connectMixStream(GPA_ELEM_CIRCUIT_0, GPA_FLOW_INLET, getEdgeMixStream(ID_CIRCUIT_INNER, ID_PORT_INLET), GPA_STREAM_OUTLET);
    good = good && m_pipes.connectMixStream(GPA_ELEM_CIRCUIT_0, GPA_FLOW_OUTLET, getEdgeMixStream(ID_CIRCUIT_INNER, ID_PORT_OUTLET), GPA_STREAM_INLET);
    // Добавляем в систему все элементы и потоки
    //setElements({ &m_pipes });
    //setStreams({ });
    return GPA_RESULT_OK;
}

gpaResult gpaLiquidWasteIncinerator::initialize()
{
    // Подключить экспортируемый элемент к потокам в интеграторе
    gpaResult res = linkToCoreStreams();
    if (res != GPA_RESULT_OK)
        return res;
    // Соединяем все элементы друг с другом
    res = buildDevice();
    if (res != GPA_RESULT_OK)
        return res;
    // Создаем схемы течений (нужны соединенные элементы)
    auto oe1 = getOuterEntrance(ID_CIRCUIT_INNER, ID_PORT_INLET);
    auto oe2 = getOuterEntrance(ID_CIRCUIT_INNER, ID_PORT_OUTLET);
    auto ret = createSimStructures({}, {oe1});
    if (!ret)
        return GPA_ERROR_WRONG_ARGS;
    // Инициализируем систему
    return gpaExportSystem::initialize();
}

gpaResult gpaLiquidWasteIncinerator::calcSensors(gpaVector& sensors) const
{
    setSensorValue(sensors, ID_SENSOR_PRESSURE_DROP,            );
    setSensorValue(sensors, ID_SENSOR_IN_MOLAR_CONSUMPTION,     );
    setSensorValue(sensors, ID_SENSOR_OUT_MOLAR_CONSUMPTION,    );
    setSensorValue(sensors, ID_SENSOR_TEMPERATURE_DIFFERENCE,   );
    setSensorValue(sensors, ID_SENSOR_MOLAR_CONCENTRATIONS,     );
    setSensorValue(sensors, ID_SENSOR_MOLAR_FLOW,               );
    setSensorValue(sensors, ID_SENSOR_OXYGEN,                   );

    return GPA_RESULT_OK;
}

gpaResult gpaLiquidWasteIncinerator::calcFuncValues(const gpaConstVector& states, const gpaConstVector& variables, gpaVector& values)
{
    std::cout<< "test" <<"\n";
    std::cout<<" variables : " << variables[0] ;
    std::cout<<" value : " << values[0] <<" " << values[1] <<" " << values[2] <<" "<<"\n";

    gpaReal inletRate = m_pipes.getInletPort()->getIncomingFlowRate();
    gpaReal outletRate = m_pipes.getOutletPort()->getIncomingFlowRate();
    
    gpaReal inletPres = m_pipes.getInletPort()->getStreamPressure();
    gpaReal outletPres = m_pipes.getOutletPort()->getStreamPressure();

    values[0] = inletRate + outletRate;
    values[1]= variables[0]-inletRate;
    values[2]= variables[0] -(inletPres-outletPres);
    return GPA_RESULT_OK;
}
