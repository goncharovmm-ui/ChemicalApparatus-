#include "gpaLogMeanTempDifference.h"
#include "gpaZeroRadiation.h"
#include "gpaThinWall.h"
#include "gpaFurnaceHeatExchanger.h"
#include <iostream>

constexpr gpaUInt ID_CIRCUIT_INNER      = 0;
constexpr gpaUInt NUM_CIRCUITS          = 2;

constexpr gpaUInt ID_CIRCUIT = 0;
constexpr gpaUInt ID_CIRCUIT_2 = 1;

constexpr gpaUInt ID_PORT_GAS_INLET  = 0;
constexpr gpaUInt ID_PORT_GAS_OUTLET = 1;
constexpr gpaUInt ID_PORT_OIL_INLET  = 0;
constexpr gpaUInt ID_PORT_OIL_OUTLET = 1;

constexpr gpaUInt NUM_PORTS          = 2;


enum id_Param: gpaUInt {
    //Перечень входных геометрических параметров КР (RC - radiation chamber) 7
    ID_PARAM_burnerModel               =0,
    ID_PARAM_aRC                ,
    ID_PARAM_bRC                ,
    ID_PARAM_dRC               ,
    ID_PARAM_lPipeRC            ,
    ID_PARAM_dPipeRC            ,
    ID_PARAM_nPipeRC            ,
    ID_PARAM_deltaPipeRC        ,
    ID_PARAM_epsilonRC          ,
    //ID_PARAM_setParsMethodFlag ,


    ID_PARAM_alphaAtmRC          ,
    ID_PARAM_lambdaAtmRC         ,
    ID_PARAM_dIsoRC              ,
    ID_PARAM_TAirAtm             ,
    ID_PARAM_total_local_frick_coef_RC,

};



// sensors
constexpr gpaUInt ID_SENSOR_GAS_IN_TEMP         = 0;
constexpr gpaUInt ID_SENSOR_GAS_OUT_TEMP        = 1;
constexpr gpaUInt ID_SENSOR_OIL_IN_TEMP         = 2;
constexpr gpaUInt ID_SENSOR_OIL_OUT_TEMP        = 3;

constexpr gpaUInt ID_SENSOR_alphaRC      = 4;
constexpr gpaUInt ID_SENSOR_sSideRC      = 5;
constexpr gpaUInt ID_SENSOR_LMTDRC       = 6;

constexpr gpaUInt ID_SENSOR_GAS_IN_MHC      = 7;
constexpr gpaUInt ID_SENSOR_GAS_OUT_MHC     = 8;
constexpr gpaUInt ID_SENSOR_OIL_IN_MHC      = 9;
constexpr gpaUInt ID_SENSOR_OIL_OUT_MHC     = 10;

constexpr gpaUInt ID_SENSOR_Delta_H_Gas     = 11;
constexpr gpaUInt ID_SENSOR_Delta_H_Oil     = 12;

constexpr gpaUInt ID_SENSOR_Q               = 13;

constexpr gpaUInt ID_SENSOR_QAtmRC          = 14;

constexpr gpaUInt ID_SENSOR_deltaP_oil      = 15;
constexpr gpaUInt ID_SENSOR_deltaP_gas      = 16;

constexpr gpaUInt ID_SENSOR_oilPipeRC_density        = 17;
constexpr gpaUInt ID_SENSOR_oilPipeRC_viscosity      = 18;
constexpr gpaUInt ID_SENSOR_oilPipeRC_mu             = 19;
constexpr gpaUInt ID_SENSOR_oilPipeRC_v              = 20;
constexpr gpaUInt ID_SENSOR_oilPipeRC_Re             = 21;
constexpr gpaUInt ID_SENSOR_oilPipeRC_deltaH         = 22;
constexpr gpaUInt ID_SENSOR_oilPipeRC_coefFrick      = 23;
constexpr gpaUInt ID_SENSOR_oilPipeRC_DP_Frick       = 24;
constexpr gpaUInt ID_SENSOR_oilPipeRC_DP_DH          = 25;
constexpr gpaUInt ID_SENSOR_oilPipeRC_DP             = 26;


const gpaString gpaFurnaceHeatExchanger::m_typeName      = "FHE";
const gpaString gpaFurnaceHeatExchanger::m_description   = "Радиационная камера ОПГМ";

const gpaStringVector gpaFurnaceHeatExchanger::m_circuitNames =
{
    "Контур ДГ",
    "Контур ГМ",
};

const gpaStringVector gpaFurnaceHeatExchanger::m_portNames =
{
    "Вход ТС",
    "Выход ДГ",
    "Вход ГМ",
    "Выход ГМ",
};



const gpaParameterInfoVector gpaFurnaceHeatExchanger::m_parameters =
{
    //Перечень входных геометрических параметров КР (RC - radiation chamber)
    realParam("burnerModel",              "Модель ОПГМ (1 - G1-87Y0, 2- L03-87Y01)",                              GPA_LENGTH_UNIT, false, 1),
    realParam("aRC",                      "Длина газового канала",                                                GPA_LENGTH_UNIT, false, 6),
    realParam("bRC",                      "Ширина газового канала",                                               GPA_LENGTH_UNIT, false, 4.2),
    realParam("dRC",                      "Диаметр газовго канала",                                               GPA_LENGTH_UNIT, false, 15),

    realParam("lPipeRC",                  "Длина труб масляного канала внутри",                                   GPA_LENGTH_UNIT, false, 10),
    realParam("dPipeRC",                  "Внутренний диаметр труб масляного канала внутри",                      GPA_LENGTH_UNIT, false, 0.102),
    realParam("nPipeRC",                  "Количество труб масляного канала внутри одного змеевика",                          NAN, false, 40),
    realParam("deltaPipeRC",              "Толщина труб с маслом канала",                                         GPA_LENGTH_UNIT, false, 0.006),
    realParam("epsilonRC",                "Шероховатость трубопровода",                                              GPA_LENGTH_UNIT, false, 0.001),


    realParam("alphaAtmRC",                   "Коэффициент теплоотдачи от поверхности теплоизоляции, Вт/м^2/К",        GPA_LENGTH_UNIT, false, 10),
    realParam("lambdaAtmRC",                  "Коэффициент теплопроводности стенки изоляции, Вт/м/К",                              NAN, false, 0.15),
    realParam("dIsoRC",                       "Толщина изоляции",                                                        GPA_LENGTH_UNIT, false, 0.150),
    realParam("TAirAtm",                      "Температура окружающей среды, К",                                           NAN, false, 300),

    realParam("total_local_frick_coef_RC",                      "Общий коэффицент прочих местных потерь ГМ",                                           NAN, false, 1),

};


const gpaSensorInfoVector gpaFurnaceHeatExchanger::m_sensors =
{
    //6
    scalarSensor("GAS_IN_TEMP",      "T1 Температура газа на входе",                 GPA_TEMPERATURE_UNIT),
    scalarSensor("GAS_OUT_TEMP",     "T2 Температура газа на выходе",               GPA_TEMPERATURE_UNIT),
    scalarSensor("OIL_IN_TEMP",      "T3 Температура масла на входе",               GPA_TEMPERATURE_UNIT),
    scalarSensor("OIL_OUT_TEMP",     "T4 Температура масла на выходе",              GPA_TEMPERATURE_UNIT),
    //6
    scalarSensor("ID_SENSOR_alphaCC",     "Коэффициент теплоотдачи с поверхности змеевиков, КВт/м^2/K",             NAN),
    scalarSensor("ID_SENSOR_sSideCC",     "Площадь поверхности теплоотдачи змеевиков, м^2",             GPA_AREA_UNIT),
    scalarSensor("ID_SENSOR_LMTDCC",      "Средне-логарифмический перепад температур, K",              GPA_TEMPERATURE_UNIT),
    //6
    scalarSensor("GAS_IN_MHC",      "1    Теплоемкость  газа на входе, КДж/кмоль/К",            NAN),
    scalarSensor("GAS_OUT_MHC",     "2    Теплоемкость газа на выходе, КДж/кмоль/К",           NAN),
    scalarSensor("OIL_IN_MHC",      "3    Теплоемкость масла на входе, КДж/кмоль/К",           NAN),
    scalarSensor("OIL_OUT_MHC",     "4    Теплоемкость масла на выходе, КДж/кмоль/К",          NAN),
    //4
    scalarSensor("Delta_H_Gas",     "Изменение этальпии газа, кДж/кмоль",   NAN),
    scalarSensor("Delta_H_Oil",     "Изменение энтальпии масла, кДж/кмоль", NAN),
    scalarSensor("Q",               "Тепло от газа к маслу, кДж",           NAN),
    scalarSensor("QAtmRC",          "Тепло от РК в атм, кДж",               NAN),

    scalarSensor("deltaP_oil",      "Перепад давлений по маслу",            GPA_PRESSURE_UNIT),
    scalarSensor("deltaP_gas",      "Перепад давлений по газу",             GPA_PRESSURE_UNIT),


    scalarSensor("oilPipeCC_density",      "Плотность ГМ, кг/(м^3)",                 GPA_DENSITY_UNIT),
    scalarSensor("oilPipeCC_viscosity",    "Вязкость ГМ, мкПа*с",                      GPA_DIMLESS_UNIT),
    scalarSensor("oilPipeCC_mu",           "Молярная масса ГМ, КГ/КМоль",            GPA_DIMLESS_UNIT),
    scalarSensor("oilPipeCC_v",            "Скорость ГМ в КК_v, м/c",                     GPA_VELOCITY_UNIT),
    scalarSensor("oilPipeCC_Re",           "Число Рейнольдса ГМ",                    GPA_DIMLESS_UNIT),
    scalarSensor("oilPipeCC_deltaH",       "Перепад высот канала ГМ",                GPA_LENGTH_UNIT),
    scalarSensor("oilPipeCC_coefFrick",    "Коэффициент трения ГМ",                  GPA_DIMLESS_UNIT),
    scalarSensor("oilPipeCC_DP_Frick",     "Гидравлические потери давления ГМ",  GPA_PRESSURE_UNIT),
    scalarSensor("oilPipeCC_DP_DH",        "Гидростатический напор ГМ",         GPA_PRESSURE_UNIT),
    scalarSensor("oilPipeCC_DP",           "Суммарные потери давления ГМ",      GPA_PRESSURE_UNIT),

};

gpaFurnaceHeatExchanger::gpaFurnaceHeatExchanger(const gpaCoreInterfaces* interfaces, gpaCoreReference importRef) :
    gpaExportSystem (interfaces, importRef),
    m_heatPipes      (asParent())
{
}

gpaResult gpaFurnaceHeatExchanger::calcSensors(gpaVector& sensors) const
{

    // (QBurn-Q)/abs(G_in_gas)
    setSensorValue(sensors, ID_SENSOR_GAS_IN_TEMP,      m_heatPipes.T_in_gas   - 273.15); // m_heatPipes.T_in_gas   - 273.15
    setSensorValue(sensors, ID_SENSOR_GAS_OUT_TEMP,     m_heatPipes.T_out_gas  - 273.15);//
    setSensorValue(sensors, ID_SENSOR_OIL_IN_TEMP,      m_heatPipes.T_in_oil   - 273.15);//T_in_oil - 273.15
    setSensorValue(sensors, ID_SENSOR_OIL_OUT_TEMP,     m_heatPipes.T_out_oil  - 273.15);//T_out_oil - 273.15

    setSensorValue(sensors, ID_SENSOR_alphaRC,     m_heatPipes.alphaRC);//m_heatPipes.alphaCC
    setSensorValue(sensors, ID_SENSOR_sSideRC,     m_heatPipes.sSideRC);
    setSensorValue(sensors, ID_SENSOR_LMTDRC,      m_heatPipes.LMTDRC);

    setSensorValue(sensors, ID_SENSOR_GAS_IN_MHC,     m_heatPipes.Cp_M_in_gas);
    setSensorValue(sensors, ID_SENSOR_GAS_OUT_MHC,    m_heatPipes.Cp_M_out_gas);
    setSensorValue(sensors, ID_SENSOR_OIL_IN_MHC,     m_heatPipes.Cp_M_in_oil);
    setSensorValue(sensors, ID_SENSOR_OIL_OUT_MHC,    m_heatPipes.Cp_M_out_oil);

    setSensorValue(sensors, ID_SENSOR_Delta_H_Gas,    m_heatPipes.Delta_H_Gas_Fixed);
    setSensorValue(sensors, ID_SENSOR_Delta_H_Oil,    m_heatPipes.Delta_H_Oil_Fixed);
    setSensorValue(sensors, ID_SENSOR_Q,              m_heatPipes.Q);
    setSensorValue(sensors, ID_SENSOR_QAtmRC,         m_heatPipes.QAtmRC);//

    setSensorValue(sensors, ID_SENSOR_deltaP_oil,         m_heatPipes.deltaP_oil);//
    setSensorValue(sensors, ID_SENSOR_deltaP_gas,         m_heatPipes.deltaP_gas);//


    setSensorValue(sensors, ID_SENSOR_oilPipeRC_density,       m_heatPipes.oilPipeRC.density);//
    setSensorValue(sensors, ID_SENSOR_oilPipeRC_viscosity,     1000000*m_heatPipes.oilPipeRC.viscosity);//
    setSensorValue(sensors, ID_SENSOR_oilPipeRC_mu,            m_heatPipes.oilPipeRC.mu);//
    setSensorValue(sensors, ID_SENSOR_oilPipeRC_v,             m_heatPipes.oilPipeRC.v);//
    setSensorValue(sensors, ID_SENSOR_oilPipeRC_Re,            m_heatPipes.oilPipeRC.Re);//
    setSensorValue(sensors, ID_SENSOR_oilPipeRC_deltaH,        m_heatPipes.oilPipeRC.deltaH);//
    setSensorValue(sensors, ID_SENSOR_oilPipeRC_coefFrick,     m_heatPipes.oilPipeRC.coefFrick/pow(m_heatPipes.oilPipeRC.Re, 2));//
    setSensorValue(sensors, ID_SENSOR_oilPipeRC_DP_Frick,      m_heatPipes.oilPipeRC.DP_Frick);//
    setSensorValue(sensors, ID_SENSOR_oilPipeRC_DP_DH,         m_heatPipes.oilPipeRC.DP_DH);//
    setSensorValue(sensors, ID_SENSOR_oilPipeRC_DP,            m_heatPipes.oilPipeRC.DP);//

    return GPA_RESULT_OK;
}
gpaResult gpaFurnaceHeatExchanger::checkParamValues(const gpaExtParameter *values) const
{
    (void)values;
    return GPA_RESULT_OK;
}

void gpaFurnaceHeatExchanger::setNames()
{
    m_heatPipes.setName("pipes");
}

gpaResult gpaFurnaceHeatExchanger::initMixtureFlow(const gpaExtParameter *values)
{
    // Назначаем параметры проточных элементов
    bool good = true;
    return GPA_RESULT_OK;
}

gpaResult gpaFurnaceHeatExchanger::setParamValues(const gpaExtParameter *values, bool checkNeeded)
{

    //набор параметров модели
    //m_heatPipes.LHV_Fuel             = values[ID_PARAM_LHV_Fuel].value.realValue;
    // m_heatPipes.kQCC                = values[ID_PARAM_kQCC].value.realValue;
    // m_heatPipes.kQRC                = values[ID_PARAM_kQRC].value.realValue;
    // m_heatPipes.k_LMTDRC            = values[ID_PARAM_k_LMTDRC].value.realValue;

    // набор значений еременных для их инициализации
    // m_heatPipes.temp_gas_star_zero    = values[ID_PARAM_temp_gas_star_zero].value.realValue + 273;
    // m_heatPipes.temp_gas_oil_zero     = values[ID_PARAM_temp_gas_oil_zero] .value.realValue + 273;
    // переключение между библ
    //m_heatPipes.flagMixBibl         = values[ID_PARAM_flagMixBibl].value.realValue;


    //Параметры геометрии

    //Перечень входных геометрических параметров КР (RC - radiation chamber) 7

    m_heatPipes.burnerModel =values[ID_PARAM_burnerModel].value.realValue;
    m_heatPipes.aRC         =values[ID_PARAM_aRC].value.realValue;
    m_heatPipes.bRC         =values[ID_PARAM_bRC].value.realValue;
    m_heatPipes.dRC         =values[ID_PARAM_dRC].value.realValue;

    m_heatPipes.lPipeRC     =values[ID_PARAM_lPipeRC].value.realValue;
    m_heatPipes.dPipeRC     =values[ID_PARAM_dPipeRC].value.realValue;
    m_heatPipes.nPipeRC     =values[ID_PARAM_nPipeRC].value.realValue;
    m_heatPipes.deltaPipeRC =values[ID_PARAM_deltaPipeRC].value.realValue;
    m_heatPipes.epsilonRC   =values[ID_PARAM_epsilonRC].value.realValue;

    //Параметры геометрии
    //m_heatPipes.setParsMethodFlag=values[ID_PARAM_setParsMethodFlag].value.realValue;


    m_heatPipes.alphaAtmRC=         values[ID_PARAM_alphaAtmRC].value.realValue;
    m_heatPipes.lambdaAtmRC=         values[ID_PARAM_lambdaAtmRC].value.realValue;
    m_heatPipes.dIsoRC=         values[ID_PARAM_dIsoRC].value.realValue;
    m_heatPipes.TAirAtm=         values[ID_PARAM_TAirAtm].value.realValue;

    m_heatPipes.total_local_frick_coef_RC   = values[ID_PARAM_total_local_frick_coef_RC].value.realValue;

    // Проверка параметров, если требуется
    if (checkNeeded)
    {
        gpaResult res = checkParamValues(values);
        if (res != GPA_RESULT_OK)
            return res;
    }
    // Даем названия элементам и потокам
    setNames();
    // Инициализируются элементы с потоком смеси
    gpaResult res = initMixtureFlow(values);
    if (res != GPA_RESULT_OK)
        return res;
    // Обновляем параметры воздуха на входе
    return res;
}

gpaResult gpaFurnaceHeatExchanger::buildDevice()
{
    bool good = true;
    // Соединяем поток смеси по трубам с граничными потоками смеси системы
    good = good && m_heatPipes.connectMixStream(GPA_ELEM_CIRCUIT_0, ID_PORT_GAS_INLET,  getEdgeMixStream(ID_CIRCUIT,   ID_PORT_GAS_INLET),  GPA_STREAM_INLET);
    good = good && m_heatPipes.connectMixStream(GPA_ELEM_CIRCUIT_0, ID_PORT_GAS_OUTLET, getEdgeMixStream(ID_CIRCUIT,   ID_PORT_GAS_OUTLET), GPA_STREAM_OUTLET);
    good = good && m_heatPipes.connectMixStream(GPA_ELEM_CIRCUIT_1, ID_PORT_OIL_INLET,  getEdgeMixStream(ID_CIRCUIT_2, ID_PORT_OIL_INLET),  GPA_STREAM_INLET);
    good = good && m_heatPipes.connectMixStream(GPA_ELEM_CIRCUIT_1, ID_PORT_OIL_OUTLET, getEdgeMixStream(ID_CIRCUIT_2, ID_PORT_OIL_OUTLET), GPA_STREAM_OUTLET);
    if (!good)
        return GPA_ERROR_WRONG_ARGS;
    // Добавляем в систему все элементы и потоки
    setElements({&m_heatPipes});
    setStreams({});
    return GPA_RESULT_OK;
}

gpaResult gpaFurnaceHeatExchanger::initialize()
{
    // Подключить экспортируемый элемент к потокам в интеграторе
    gpaResult res = linkToCoreStreams();
    if (res != GPA_RESULT_OK)
        return res;
    // Соединяем все элементы друг с другом
    res = buildDevice();
    if (res != GPA_RESULT_OK)
        return res;
    // Создаем схемы течений (нужны соединенные элементы)
    if (!createSimStructures({}, {getOuterEntrance(ID_CIRCUIT, ID_PORT_GAS_INLET),
                                  getOuterEntrance(ID_CIRCUIT_2, ID_PORT_OIL_INLET)}))
        return GPA_ERROR_WRONG_ARGS;
    // Инициализируем систему
    return gpaExportSystem::initialize();
}

gpaResult gpaFurnaceHeatExchanger::setSignals(const gpaConstVector &signals)
{

    gpaReal value;
    bool good = true;

    // if (getSignalValue(signals, ID_PARAM_kQCC, value))
    // m_heatPipes.kQCC               = value;
    // if (getSignalValue(signals, ID_PARAM_kQRC, value))
    // m_heatPipes.kQRC               = value;


    return GPA_RESULT_OK;
}
const gpaString* gpaFurnaceHeatExchanger::getDeviceMixCircuitName(gpaUInt index)
{
    return index < NUM_CIRCUITS ? &m_circuitNames[index] : NULL;
}
const gpaString* gpaFurnaceHeatExchanger::getDeviceMixPortName(gpaUInt circIdx, gpaUInt portIdx)
{
    return portIdx + circIdx*2 < 4 ? &m_portNames[portIdx + circIdx*2] : NULL;
}





