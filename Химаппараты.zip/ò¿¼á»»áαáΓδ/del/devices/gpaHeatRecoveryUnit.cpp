#include "gpaLogMeanTempDifference.h"
#include "gpaZeroRadiation.h"
#include "gpaThinWall.h"
#include "gpaHeatRecoveryUnit.h"
#include <iostream>


constexpr gpaUInt NUM_CIRCUITS          = 2;

constexpr gpaUInt ID_CIRCUIT = 0;
constexpr gpaUInt ID_CIRCUIT_2 = 1;

constexpr gpaUInt ID_PORT_GAS_INLET  = 0;
constexpr gpaUInt ID_PORT_GAS_OUTLET = 1;
constexpr gpaUInt ID_PORT_OIL_INLET  = 0;
constexpr gpaUInt ID_PORT_OIL_OUTLET = 1;

constexpr gpaUInt NUM_PORTS          = 2;


enum id_Param: gpaUInt {
    //Перечень входных геометрических параметров КК (СC - convection chamber) 16
    ID_PARAM_c_fix_cp_EG   = 0        ,
    ID_PARAM_c_fix_HE         ,
    ID_PARAM_c_fix_temp_mix          ,

    ID_PARAM_part_flow_for_HE          ,

    ID_PARAM_nChannelsCC           ,
    ID_PARAM_h_dist_BW_oil_ports           ,
    ID_PARAM_lPipeCC            ,
    ID_PARAM_dPipeCC            ,
    ID_PARAM_l_out_CC                ,
    ID_PARAM_aCC                ,
    ID_PARAM_bCC               ,
    ID_PARAM_nPipeSmСС         ,
    ID_PARAM_nPipeCorСС        ,
    ID_PARAM_deltaPipeCC        ,
    ID_PARAM_epsilonСС         ,
    ID_PARAM_kRib               ,
    ID_PARAM_deltaRib          ,
    ID_PARAM_hRib             ,
    ID_PARAM_s1                ,
    ID_PARAM_s2                 ,
    ID_PARAM_s3                 ,
    //ID_PARAM_setParsMethodFlag ,

    ID_PARAM_alphaAtmCC          ,
    ID_PARAM_lambdaAtmCC         ,
    ID_PARAM_dIsoCC              ,
    ID_PARAM_TAirAtm             ,
    ID_PARAM_sAtmSideCC          ,
    ID_PARAM_total_local_frick_coef_CC          ,
    

};


// sensors

constexpr gpaUInt ID_SENSOR_GAS_MF_FULL       = 0;
constexpr gpaUInt ID_SENSOR_GAS_MF_HRU        = 1;
constexpr gpaUInt ID_SENSOR_GAS_MF_BP         = 2;
constexpr gpaUInt ID_SENSOR_GAS_IN_TEMP         = 3;
constexpr gpaUInt ID_SENSOR_T_EG_after_HE       = 4;
constexpr gpaUInt ID_SENSOR_GAS_OUT_TEMP        = 5;
constexpr gpaUInt ID_SENSOR_DELTA_P_GAS          = 6;

constexpr gpaUInt ID_SENSOR_OIL_IN_TEMP         = 7;
constexpr gpaUInt ID_SENSOR_OIL_OUT_TEMP        = 8;
constexpr gpaUInt ID_SENSOR_OIL_MF              = 9;
constexpr gpaUInt ID_SENSOR_DELTA_P_OIL      = 10;

constexpr gpaUInt ID_SENSOR_alphaCC      = 11;
constexpr gpaUInt ID_SENSOR_sSideCC      = 12;
constexpr gpaUInt ID_SENSOR_LMTDCC       = 13;

constexpr gpaUInt ID_SENSOR_Q            = 14;
constexpr gpaUInt ID_SENSOR_QAtmCC       = 15;

//Legacy
// constexpr gpaUInt ID_SENSOR_GAS_IN_MHC      = 7;
// constexpr gpaUInt ID_SENSOR_GAS_OUT_MHC     = 8;
// constexpr gpaUInt ID_SENSOR_OIL_IN_MHC      = 9;
// constexpr gpaUInt ID_SENSOR_OIL_OUT_MHC     = 10;
// constexpr gpaUInt ID_SENSOR_Delta_H_Gas     = 11;
// constexpr gpaUInt ID_SENSOR_Delta_H_Oil     = 12;
// constexpr gpaUInt ID_SENSOR_oilPipeCC_density        = 17;
// constexpr gpaUInt ID_SENSOR_oilPipeCC_viscosity      = 18;
// constexpr gpaUInt ID_SENSOR_oilPipeCC_mu             = 19;
// constexpr gpaUInt ID_SENSOR_oilPipeCC_v              = 20;
// constexpr gpaUInt ID_SENSOR_oilPipeCC_Re             = 21;
// constexpr gpaUInt ID_SENSOR_oilPipeCC_deltaH         = 22;
// constexpr gpaUInt ID_SENSOR_oilPipeCC_coefFrick      = 23;
// constexpr gpaUInt ID_SENSOR_oilPipeCC_DP_Frick       = 24;
// constexpr gpaUInt ID_SENSOR_oilPipeCC_DP_DH          = 25;
// constexpr gpaUInt ID_SENSOR_oilPipeCC_DP             = 26;



const gpaString gpaHeatRecoveryUnit::m_typeName      = "HRU";
const gpaString gpaHeatRecoveryUnit::m_description   = "Утилизатор тепла (УТ)";

const gpaStringVector gpaHeatRecoveryUnit::m_circuitNames =
{
    "Контур ДГ",
    "Контур ГМ",
};

const gpaStringVector gpaHeatRecoveryUnit::m_portNames =
{
    "Вход ТС",
    "Выход ДГ",
    "Вход ГМ",
    "Выход ГМ",
};



const gpaParameterInfoVector gpaHeatRecoveryUnit::m_parameters =
{
    //Перечень входных геометрических параметров КК (СC - convection chamber)
    realParam("c_fix_cp_EG",                  "Коэффициент для теплоемкости ДГ",                                    NAN, false,1),
    realParam("c_fix_HE",                  "Коэффициент для теплоотдачи",                                    NAN, false,1),
    realParam("c_fix_temp_mix",                  "Коэффициент для вычисления температуры ДГ после УТ",                                    NAN, false,1),
  
    realParam("part_flow_for_HE",                   "Доля ДГ, отобранных для нагрева масла",                                    NAN, true, 1),
   

    realParam("nChannelsCC",                  "Количество каналов",                                    NAN, false,8),
    realParam("h_dist_BW_oil_ports",      "Разница высот выхода - входа масла",                                    GPA_LENGTH_UNIT, false,1),
    realParam("lPipeCC",                  "Длина труб масляного канала внутри",                                    GPA_LENGTH_UNIT, false, 6.7),
    realParam("dPipeCC",                  "Внутренний диаметр труб масляного канала внутри",                       GPA_LENGTH_UNIT, false, 0.102),
    realParam("l_out_CC",                 "Длина корпуса",                                                 GPA_LENGTH_UNIT, false, 1),
    realParam("aCC",                      "Высота корпуса",                                                 GPA_LENGTH_UNIT, false, 1),
    realParam("bCC",                      "Ширина сечения газового канала",                                                GPA_LENGTH_UNIT, false, 6),
    realParam("nPipeSmСС",                "Количество гладких труб масляного канала внутри одного змеевика",       NAN,             false, 5),
    realParam("nPipeCorСС",               "Количество оребренных труб масляного канала внутри одного змеевика",    NAN,             false, 18),
    realParam("deltaPipeCC",              "Толщина труб с маслом канала",                                          GPA_LENGTH_UNIT, false, 0.006),
    realParam("epsilonСС",                "Шероховатость трубопровода",                                               GPA_LENGTH_UNIT, false, 0.0002),
    realParam("kRib",                     "Шаг ребр, шт/м",                                                           NAN,             false, 167),
    realParam("deltaRib",                 "Толщина ребра",                                                            GPA_LENGTH_UNIT, false, 0.0012),
    realParam("hRib",                     "Высота ребра",                                                             GPA_LENGTH_UNIT, false, 0.015),
    realParam("s1",                       "Горизонтальный шаг",                                                       GPA_LENGTH_UNIT, false, 0.2),
    realParam("s2",                       "Вертикальный шаг",                                                         GPA_LENGTH_UNIT, false, 0.0865),
    realParam("s3",                       "Диагональный шаг",                                                         GPA_LENGTH_UNIT, false, 0.200),
    //realParam("setParsMethodFlag",                       "Переключатель метода расчета параметров регулировки",       NAN, false, 0),

    realParam("alphaAtmCC",                   "Коэффициент теплоотдачи от поверхности теплоизоляции, Вт/м^2/К",        GPA_LENGTH_UNIT, false, 10),
    realParam("lambdaAtmCC",                  "Коэффициент теплопроводности стенки изоляции, Вт/м/К",                              NAN, false, 0.15),
    realParam("dIsoCC",                       "Толщина изоляции",                                                        GPA_LENGTH_UNIT, false, 0.150),
    realParam("TAirAtm",                      "Температура окружающей среды, К",                                           NAN, false, 300),
    realParam("sAtmSideCC",                   "Площадь контакта с окружающей средой",                                    GPA_AREA_UNIT, false, 1),
    realParam("total_local_frick_coef_CC",    "Общий коэффицент  прочих местных потерь масла",                                    NAN, false, 1),

 
};





const gpaSensorInfoVector gpaHeatRecoveryUnit::m_sensors =
{
    scalarSensor("GAS_MF_FULL",      "Расход ДГ на входе",                 GPA_TEMPERATURE_UNIT),
    scalarSensor("GAS_MF_HRU",       "Расход ДГ на УТ",                    GPA_TEMPERATURE_UNIT),
    scalarSensor("GAS_MF_BP",        "Расход ДГ на байпас",                GPA_TEMPERATURE_UNIT),
    scalarSensor("GAS_IN_TEMP",      "T1 Температура ДГ на входе",                 GPA_TEMPERATURE_UNIT),
    scalarSensor("T_EG_after_HE",    "Температура после УТ, отобранной части ДГ для нагрева масла",      GPA_TEMPERATURE_UNIT),
    scalarSensor("GAS_OUT_TEMP",     "T2 Температура ДГ на выходе",               GPA_TEMPERATURE_UNIT),
    scalarSensor("DELTA_P_GAS",      "Перепад давлений по ДГ",                    GPA_PRESSURE_UNIT),

    
    scalarSensor("OIL_IN_TEMP",      "T3 Температура масла на входе",               GPA_TEMPERATURE_UNIT),
    scalarSensor("OIL_OUT_TEMP",     "T4 Температура масла на выходе",              GPA_TEMPERATURE_UNIT),
    scalarSensor("OIL_MF",           "Расход масла",                                GPA_TEMPERATURE_UNIT),
    scalarSensor("DELTA_P_OIL",      "Перепад давлений по маслу",                   GPA_PRESSURE_UNIT),

    scalarSensor("ID_SENSOR_alphaCC",     "Коэффициент теплоотдачи с поверхности змеевиков",       GPA_HEATTRANS_COEF_UNIT),
    scalarSensor("ID_SENSOR_sSideCC",     "Площадь поверхности теплоотдачи змеевиков",             GPA_AREA_UNIT),
    scalarSensor("ID_SENSOR_LMTDCC",      "Средне-логарифмический перепад температур",             GPA_TEMPERATURE_UNIT),
    
    scalarSensor("Q",               "Переданное маслу тепло",           GPA_ENERGY_UNIT),
    scalarSensor("QAtmCC",          "Ушедшее в атмосферу тепло",        GPA_ENERGY_UNIT),

    //Legacy
    // scalarSensor("GAS_IN_MHC",      "1    Теплоемкость  газа на входе в КР",            GPA_MOLAR_ENTROPY_UNIT),
    // scalarSensor("GAS_OUT_MHC",     "2    Теплоемкость газа на выходе из КК",           GPA_MOLAR_ENTROPY_UNIT),
    // scalarSensor("OIL_IN_MHC",      "3    Теплоемкость масла на входе  в КК",           GPA_MOLAR_ENTROPY_UNIT),
    // scalarSensor("OIL_OUT_MHC",     "4    Теплоемкость масла на выходе из КР",          GPA_MOLAR_ENTROPY_UNIT),
    //4
    // scalarSensor("Delta_H_Gas",     "Изменение этальпии газа, кДж/кмоль",   GPA_DIMLESS_UNIT),
    // scalarSensor("Delta_H_Oil",     "Изменение энтальпии масла, кДж/кмоль", GPA_DIMLESS_UNIT),
    // scalarSensor("oilPipeCC_density",      "Плотность ГМ в КК, кг/(м^3)",                 GPA_DENSITY_UNIT),
    // scalarSensor("oilPipeCC_viscosity",    "Вязкость ГМ в КК, мкПа*с",                      GPA_DIMLESS_UNIT),
    // scalarSensor("oilPipeCC_mu",           "Молярная масса ГМ в КК, КГ/КМоль",            GPA_DIMLESS_UNIT),
    // scalarSensor("oilPipeCC_v",            "Скорость ГМ в КК_v, м/c",                     GPA_VELOCITY_UNIT),
    // scalarSensor("oilPipeCC_Re",           "Число Рейнольдса ГМ в КК",                    GPA_DIMLESS_UNIT),
    // scalarSensor("oilPipeCC_deltaH",       "Перепад высот канала ГМ в КК",                GPA_LENGTH_UNIT),
    // scalarSensor("oilPipeCC_coefFrick",    "Коэффициент трения ГМ в КК",                  GPA_DIMLESS_UNIT),
    // scalarSensor("oilPipeCC_DP_Frick",     "Гидравлические потери давления ГМ в КК",  GPA_PRESSURE_UNIT),
    // scalarSensor("oilPipeCC_DP_DH",        "Гидростатический напор ГМ в КК",         GPA_PRESSURE_UNIT),
    // scalarSensor("oilPipeCC_DP",           "Суммарные потери давления ГМ в КК",      GPA_PRESSURE_UNIT),

  

};

gpaHeatRecoveryUnit::gpaHeatRecoveryUnit(const gpaCoreInterfaces* interfaces, gpaCoreReference importRef) :
    gpaExportSystem (interfaces, importRef),
    m_heatPipes      (asParent())
{
}

gpaResult gpaHeatRecoveryUnit::calcSensors(gpaVector& sensors) const
{

    // (QBurn-Q)/abs(G_in_gas)

    setSensorValue(sensors, ID_SENSOR_GAS_MF_FULL,      m_heatPipes.m_dot_gas); 
    setSensorValue(sensors, ID_SENSOR_GAS_MF_HRU,       m_heatPipes.m_dot_gas *      m_heatPipes.part_flow_for_HE );
    setSensorValue(sensors, ID_SENSOR_GAS_MF_BP,        m_heatPipes.m_dot_gas * (1 - m_heatPipes.part_flow_for_HE));
    setSensorValue(sensors, ID_SENSOR_GAS_IN_TEMP,      m_heatPipes.T_in_gas      - 273.15);//
    setSensorValue(sensors, ID_SENSOR_T_EG_after_HE,    m_heatPipes.T_EG_after_HE - 273.15);//
    setSensorValue(sensors, ID_SENSOR_GAS_OUT_TEMP,     m_heatPipes.T_out_gas     - 273.15);//
    setSensorValue(sensors, ID_SENSOR_DELTA_P_GAS,      m_heatPipes.deltaP_gas);//

    setSensorValue(sensors, ID_SENSOR_OIL_IN_TEMP,      m_heatPipes.T_in_oil   - 273.15);//T_in_oil - 273.15
    setSensorValue(sensors, ID_SENSOR_OIL_OUT_TEMP,     m_heatPipes.T_out_oil  - 273.15);//T_out_oil - 273.15
    setSensorValue(sensors, ID_SENSOR_OIL_MF,           m_heatPipes.m_dot_oil);
    setSensorValue(sensors, ID_SENSOR_DELTA_P_OIL,      m_heatPipes.deltaP_oil);//

    setSensorValue(sensors, ID_SENSOR_alphaCC,     m_heatPipes.alphaCC);//m_heatPipes.alphaCC
    setSensorValue(sensors, ID_SENSOR_sSideCC,     m_heatPipes.sSideCC);
    setSensorValue(sensors, ID_SENSOR_LMTDCC,      m_heatPipes.LMTDCC);


    setSensorValue(sensors, ID_SENSOR_Q,              m_heatPipes.Q-m_heatPipes.QAtmCC);
    setSensorValue(sensors, ID_SENSOR_QAtmCC,         m_heatPipes.QAtmCC);//

    
    


    // Legacy
    // setSensorValue(sensors, ID_SENSOR_GAS_IN_MHC,     m_heatPipes.Cp_M_in_gas);
    // setSensorValue(sensors, ID_SENSOR_GAS_OUT_MHC,    m_heatPipes.Cp_M_out_gas);
    // setSensorValue(sensors, ID_SENSOR_OIL_IN_MHC,     m_heatPipes.Cp_M_in_oil);
    // setSensorValue(sensors, ID_SENSOR_OIL_OUT_MHC,    m_heatPipes.Cp_M_out_oil);
    // setSensorValue(sensors, ID_SENSOR_Delta_H_Gas,    m_heatPipes.Delta_H_Gas_Fixed);
    // setSensorValue(sensors, ID_SENSOR_Delta_H_Oil,    m_heatPipes.Delta_H_Oil_Fixed);
    // setSensorValue(sensors, ID_SENSOR_oilPipeCC_density,       m_heatPipes.oilPipeCC.density);//
    // setSensorValue(sensors, ID_SENSOR_oilPipeCC_viscosity,     1000000*m_heatPipes.oilPipeCC.viscosity);//
    // setSensorValue(sensors, ID_SENSOR_oilPipeCC_mu,            m_heatPipes.oilPipeCC.mu);//
    // setSensorValue(sensors, ID_SENSOR_oilPipeCC_v,             m_heatPipes.oilPipeCC.v);//
    // setSensorValue(sensors, ID_SENSOR_oilPipeCC_Re,            m_heatPipes.oilPipeCC.Re);//
    // setSensorValue(sensors, ID_SENSOR_oilPipeCC_deltaH,        m_heatPipes.oilPipeCC.deltaH);//
    // setSensorValue(sensors, ID_SENSOR_oilPipeCC_coefFrick,     m_heatPipes.oilPipeCC.coefFrick/pow(m_heatPipes.oilPipeCC.Re, 2));//
    // setSensorValue(sensors, ID_SENSOR_oilPipeCC_DP_Frick,      m_heatPipes.oilPipeCC.DP_Frick);//
    // setSensorValue(sensors, ID_SENSOR_oilPipeCC_DP_DH,         m_heatPipes.oilPipeCC.DP_DH);//
    // setSensorValue(sensors, ID_SENSOR_oilPipeCC_DP,            m_heatPipes.oilPipeCC.DP);//

    
    
    return GPA_RESULT_OK;
}
gpaResult gpaHeatRecoveryUnit::checkParamValues(const gpaExtParameter *values) const
{
    (void)values;
    return GPA_RESULT_OK;
}

void gpaHeatRecoveryUnit::setNames()
{
    m_heatPipes.setName("pipes");
}

gpaResult gpaHeatRecoveryUnit::initMixtureFlow(const gpaExtParameter *values)
{
    // Назначаем параметры проточных элементов
    bool good = true;
    return GPA_RESULT_OK;
}

gpaResult gpaHeatRecoveryUnit::setParamValues(const gpaExtParameter *values, bool checkNeeded)
{

    //Параметры геометрии

    //Перечень входных геометрических параметров КК (СC - convection chamber) 16

    m_heatPipes.c_fix_cp_EG     =   values[ID_PARAM_c_fix_cp_EG].value.realValue;
    m_heatPipes.c_fix_HE        =   values[ID_PARAM_c_fix_HE].value.realValue;
    m_heatPipes.c_fix_temp_mix  =   values[ID_PARAM_c_fix_temp_mix].value.realValue;

    m_heatPipes.nChannelsCC =   values[ID_PARAM_nChannelsCC].value.realValue;

    m_heatPipes.h_dist_BW_oil_ports =   values[ID_PARAM_h_dist_BW_oil_ports].value.realValue;
    m_heatPipes.lPipeCC =   values[ID_PARAM_lPipeCC].value.realValue;
    m_heatPipes.dPipeCC =   values[ID_PARAM_dPipeCC].value.realValue;

    m_heatPipes.l_out_CC =       values[ID_PARAM_l_out_CC].value.realValue;
    m_heatPipes.aCC =       values[ID_PARAM_aCC].value.realValue;
    m_heatPipes.bCC =       values[ID_PARAM_bCC].value.realValue;



    m_heatPipes.nPipeSmСС=  values[ID_PARAM_nPipeSmСС].value.realValue;
    m_heatPipes.nPipeCorСС= values[ID_PARAM_nPipeCorСС].value.realValue;
    m_heatPipes.deltaPipeCC=values[ID_PARAM_deltaPipeCC].value.realValue;
    m_heatPipes.epsilonСС=  values[ID_PARAM_epsilonСС].value.realValue;

    m_heatPipes.kRib=       values[ID_PARAM_kRib].value.realValue;
    m_heatPipes.deltaRib=   values[ID_PARAM_deltaRib].value.realValue;
    m_heatPipes.hRib=       values[ID_PARAM_hRib].value.realValue;

    m_heatPipes.s1=         values[ID_PARAM_s1].value.realValue;
    m_heatPipes.s2=         values[ID_PARAM_s2].value.realValue;
    m_heatPipes.s3=         values[ID_PARAM_s3].value.realValue;

    m_heatPipes.alphaAtmCC=         values[ID_PARAM_alphaAtmCC].value.realValue;
    m_heatPipes.lambdaAtmCC=         values[ID_PARAM_lambdaAtmCC].value.realValue;
    m_heatPipes.dIsoCC=         values[ID_PARAM_dIsoCC].value.realValue;
    m_heatPipes.TAirAtm=         values[ID_PARAM_TAirAtm].value.realValue;
    m_heatPipes.sAtmSideCC=         values[ID_PARAM_sAtmSideCC].value.realValue;

    m_heatPipes.total_local_frick_coef_CC=         values[ID_PARAM_total_local_frick_coef_CC].value.realValue;

    m_heatPipes.part_flow_for_HE=         values[ID_PARAM_part_flow_for_HE].value.realValue;


    //Параметры геометрии
    //m_heatPipes.setParsMethodFlag=values[ID_PARAM_setParsMethodFlag].value.realValue;


    // Проверка параметров, если требуется
    if (checkNeeded)
    {
        gpaResult res = checkParamValues(values);
        if (res != GPA_RESULT_OK)
            return res;
    }
    // Даем названия элементам и потокам
    setNames();
    // Инициализируются элементы с потоком смеси
    gpaResult res = initMixtureFlow(values);
    if (res != GPA_RESULT_OK)
        return res;
    // Обновляем параметры воздуха на входе
    return res;
}

gpaResult gpaHeatRecoveryUnit::buildDevice()
{
    bool good = true;
    // Соединяем поток смеси по трубам с граничными потоками смеси системы
    good = good && m_heatPipes.connectMixStream(GPA_ELEM_CIRCUIT_0, ID_PORT_GAS_INLET,  getEdgeMixStream(ID_CIRCUIT,   ID_PORT_GAS_INLET),  GPA_STREAM_INLET);
    good = good && m_heatPipes.connectMixStream(GPA_ELEM_CIRCUIT_0, ID_PORT_GAS_OUTLET, getEdgeMixStream(ID_CIRCUIT,   ID_PORT_GAS_OUTLET), GPA_STREAM_OUTLET);
    good = good && m_heatPipes.connectMixStream(GPA_ELEM_CIRCUIT_Oil, ID_PORT_OIL_INLET,  getEdgeMixStream(ID_CIRCUIT_2, ID_PORT_OIL_INLET),  GPA_STREAM_INLET);
    good = good && m_heatPipes.connectMixStream(GPA_ELEM_CIRCUIT_Oil, ID_PORT_OIL_OUTLET, getEdgeMixStream(ID_CIRCUIT_2, ID_PORT_OIL_OUTLET), GPA_STREAM_OUTLET);
    if (!good)
        return GPA_ERROR_WRONG_ARGS;
    // Добавляем в систему все элементы и потоки
    setElements({&m_heatPipes});
    setStreams({});
    return GPA_RESULT_OK;
}

gpaResult gpaHeatRecoveryUnit::initialize()
{
    // Подключить экспортируемый элемент к потокам в интеграторе
    gpaResult res = linkToCoreStreams();
    if (res != GPA_RESULT_OK)
        return res;
    // Соединяем все элементы друг с другом
    res = buildDevice();
    if (res != GPA_RESULT_OK)
        return res;
    // Создаем схемы течений (нужны соединенные элементы)
    if (!createSimStructures({}, {getOuterEntrance(ID_CIRCUIT, ID_PORT_GAS_INLET),
                                  getOuterEntrance(ID_CIRCUIT_2, ID_PORT_OIL_INLET)}))
        return GPA_ERROR_WRONG_ARGS;
    // Инициализируем систему
    return gpaExportSystem::initialize();
}

gpaResult gpaHeatRecoveryUnit::setSignals(const gpaConstVector &signals)
{
    gpaReal value;
    bool good = true;

    if (getSignalValue(signals, ID_PARAM_part_flow_for_HE, value))
    m_heatPipes.part_flow_for_HE               = value;
    // if (getSignalValue(signals, ID_PARAM_kQRC, value))
    // m_heatPipes.kQRC               = value;

    return GPA_RESULT_OK;
}
const gpaString* gpaHeatRecoveryUnit::getDeviceMixCircuitName(gpaUInt index)
{
    return index < NUM_CIRCUITS ? &m_circuitNames[index] : NULL;
}
const gpaString* gpaHeatRecoveryUnit::getDeviceMixPortName(gpaUInt circIdx, gpaUInt portIdx)
{
    return portIdx + circIdx*2 < 4 ? &m_portNames[portIdx + circIdx*2] : NULL;
}





