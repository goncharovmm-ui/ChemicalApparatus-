#include "gpaNitrogenTankInfo.h"
#include "gpaNitrogenTank.h"

gpaNitrogenTankInfo::gpaNitrogenTankInfo() : gpaDeviceInfo(gpaNitrogenTank::getDeviceTypeName(),
                                                           gpaNitrogenTank::getDeviceDescription())
{
    setParameters(gpaNitrogenTank::getParametersInfo());
    setSensors(gpaNitrogenTank::getSensorsInfo());
}

gpaUInt gpaNitrogenTankInfo::getNumMixCircuits() const
{
    return gpaNitrogenTank::getDeviceNumMixCircuits();
}

gpaUInt gpaNitrogenTankInfo::getMinNumMixPorts(gpaUInt index) const
{
    return gpaNitrogenTank::getDeviceMinNumMixPorts(index);
}

gpaUInt gpaNitrogenTankInfo::getMaxNumMixPorts(gpaUInt index) const
{
    return gpaNitrogenTank::getDeviceMaxNumMixPorts(index);
}

const gpaString *gpaNitrogenTankInfo::getMixPortName(gpaUInt circIdx, gpaUInt portIdx) const
{
    return gpaNitrogenTank::getDeviceMixPortName(circIdx, portIdx);
}

const gpaString *gpaNitrogenTankInfo::getMixCircuitName(gpaUInt index) const
{
    return gpaNitrogenTank::getDeviceMixCircuitName(index);
}

gpaElement *gpaNitrogenTankInfo::createDevice(const gpaCoreInterfaces *interfaces, gpaCoreReference pairDevice,
                                              const gpaExtObjectModel *model) const
{
    gpaNitrogenTank *separator = new gpaNitrogenTank(interfaces, pairDevice);
    gpaResult res = separator->specifyModel(model);
    if (res == GPA_RESULT_OK)
        return separator;
    delete separator;
    return NULL;
}
