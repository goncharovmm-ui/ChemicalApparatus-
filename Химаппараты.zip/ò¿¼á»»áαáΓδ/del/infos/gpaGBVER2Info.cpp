#include "gpaGBVER2Info.h"
#include "gpaGBVER2.h"



gpaGBVER2Info::gpaGBVER2Info() :
    gpaDeviceInfo  (gpaGBVER2::getDeviceTypeName(),
                    gpaGBVER2::getDeviceDescription())
{
    setParameters(gpaGBVER2::getParametersInfo());
    setSensors(gpaGBVER2::getSensorsInfo());
}

gpaUInt gpaGBVER2Info::getNumMixCircuits() const
{
    return gpaGBVER2::getDeviceNumMixCircuits();
}

gpaUInt gpaGBVER2Info::getMinNumMixPorts(gpaUInt index) const
{
    return gpaGBVER2::getDeviceMinNumMixPorts(index);
}

gpaUInt gpaGBVER2Info::getMaxNumMixPorts(gpaUInt index) const
{
    return gpaGBVER2::getDeviceMaxNumMixPorts(index);
}
const gpaString *gpaGBVER2Info::getMixPortName(gpaUInt circIdx, gpaUInt portIdx) const
{
    return gpaGBVER2::getDeviceMixPortName(circIdx, portIdx);
}

const gpaString *gpaGBVER2Info::getMixCircuitName(gpaUInt index) const
{
    return gpaGBVER2::getDeviceMixCircuitName(index);
}



gpaElement* gpaGBVER2Info::createDevice(const gpaCoreInterfaces* interfaces, gpaCoreReference pairDevice,
                                             const gpaExtObjectModel* model) const
{
    gpaGBVER2* cooler = new gpaGBVER2(interfaces, pairDevice);
    gpaResult res = cooler->specifyModel(model);
    if (res == GPA_RESULT_OK)
        return cooler;
    delete cooler;
    return NULL;
}
