#include "gpaInclude.h"
#include <gpaMedium.h>
#include <numbers>

#ifndef PRESSURE_GRADIENT_MODEL_H
#define PRESSURE_GRADIENT_MODEL_H

class PressureGradientModel {
public:
  // Конструктор с развернутыми параметрами трубы
  PressureGradientModel(gpaReal eps, gpaReal length, gpaReal D, gpaReal dh,
                        gpaUInt numBends)
      : m_eps(eps), m_length(length), m_diameter(D), m_dHeight(dh),
        m_numBends(numBends) {}

  // Метод вычисления dp (давление)
  gpaReal calcDeltaPressure(gpaReal G, gpaMedium *medium) const {
    gpaReal density = medium->getDensity();
    gpaReal viscosity = medium->getViscosity();
    gpaReal V = G / (std::numbers::pi * m_diameter * m_diameter / 4.0);
    gpaReal Re = density * std::abs(V) * m_diameter / viscosity;

    gpaReal F1 = 16.0 * Re;
    gpaReal F3 = 0.07716 * Re * Re /
                 vmPower(std::log10(6.9 / (Re + 1e-9) +
                                    vmPower(m_eps / 3.7 / m_diameter, 1.11)),
                         2.0);
    gpaReal F2 = F1 + (Re - 2300.0) / 1700.0 * (F3 - F1);

    gpaReal X1 = (Re - 2300.0) / 300.0;
    gpaReal X2 = (Re - 4000.0) / 300.0;

    gpaReal sigmoidX1 = sigmoid(X1);
    gpaReal sigmoidX2 = sigmoid(X2);

    gpaReal f = (F1 * (1 - sigmoidX1) + F2 * sigmoidX1) * (1 - sigmoidX2) +
                F3 * sigmoidX2;
    gpaReal friction_dp = f * std::pow(viscosity, 2.0) * m_length / 2.0 /
                          density / std::pow(m_diameter, 3.0);

    gpaReal dp = GPA_GRAVITY_ACCELERATION * m_dHeight * density +
                 friction_dp * ((V > 0) ? 1.0 : ((V < 0) ? -1.0 : 0.0));
    gpaReal dp_bends = m_numBends * 0.04 * density * vmPower(V, 2) / 2;
    return (dp + dp_bends) / GPA_KILOPASCAL_TO_PASCAL;
  }

private:
  static gpaReal sigmoid(gpaReal x) { return 1.0 / (1.0 + std::exp(-x)); }

  gpaReal m_eps, m_length, m_diameter, m_dHeight;
  gpaUInt m_numBends;
};

#endif
