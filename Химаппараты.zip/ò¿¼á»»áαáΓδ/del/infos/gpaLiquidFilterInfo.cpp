#include "gpaLiquidFilterInfo.h"
#include "gpaLiquidFilter.h"

gpaLiquidFilterInfo::gpaLiquidFilterInfo() : gpaDeviceInfo(gpaLiquidFilter::getDeviceTypeName(),
                                               gpaLiquidFilter::getDeviceDescription())
{
    setParameters(gpaLiquidFilter::getParametersInfo());
    setSensors(gpaLiquidFilter::getSensorsInfo());
}

gpaUInt gpaLiquidFilterInfo::getNumMixCircuits() const
{
    return gpaLiquidFilter::getDeviceNumMixCircuits();
}

gpaUInt gpaLiquidFilterInfo::getMinNumMixPorts(gpaUInt index) const
{
    return gpaLiquidFilter::getDeviceMinNumMixPorts(index);
}

gpaUInt gpaLiquidFilterInfo::getMaxNumMixPorts(gpaUInt index) const
{
    return gpaLiquidFilter::getDeviceMaxNumMixPorts(index);
}
const gpaString *gpaLiquidFilterInfo::getMixPortName(gpaUInt circIdx, gpaUInt portIdx) const
{
    return gpaLiquidFilter::getDeviceMixPortName(circIdx, portIdx);
}

const gpaString *gpaLiquidFilterInfo::getMixCircuitName(gpaUInt index) const
{
    return gpaLiquidFilter::getDeviceMixCircuitName(index);
}

gpaElement *gpaLiquidFilterInfo::createDevice(const gpaCoreInterfaces *interfaces, gpaCoreReference pairDevice,
                                        const gpaExtObjectModel *model) const
{
    gpaLiquidFilter *cooler = new gpaLiquidFilter(interfaces, pairDevice);
    gpaResult res = cooler->specifyModel(model);
    if (res == GPA_RESULT_OK)
        return cooler;
    delete cooler;
    return NULL;
}
