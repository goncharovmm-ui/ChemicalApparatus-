#include "gpaInclude.h"
#include "gpaGBVER2Element.h"

const gpaString gpaGBVER2Element::m_typeName     = "GB-VER-2";
const gpaString gpaGBVER2Element::m_description  = "gpaGBVER2Element";