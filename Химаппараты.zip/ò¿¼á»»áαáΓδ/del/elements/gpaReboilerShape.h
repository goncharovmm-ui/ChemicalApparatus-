#include "gpaInclude.h"
#include "gpaVolumeShape.h"
#include "spline.h"
#include <numbers>
#include <vector>


class gpaReboilerShape : public gpaVolumeShape {
public:
  gpaReboilerShape(const gpaVolumeElement *volume, gpaReal hMin, gpaReal hMax,
                   gpaReal lCone, // Конусная часть, м
                   gpaReal lEll,  // Эллипсная часть, м
                   gpaReal lCyl,  // Большой цилиндр, м
                   gpaReal lmCyl, // Малый цилиндр, м
                   gpaReal lPart)
      : gpaVolumeShape(volume), m_hMin(hMin), m_hMax(hMax), m_lCone(lCone),
        m_lEll(lEll), m_lCyl(lCyl), m_lmCyl(lmCyl), m_lPart(lPart), m_tableV(),
        m_tableH() {}

  gpaVolumeShape *copy() const override { return new gpaReboilerShape(*this); }

  gpaReal getHeight() const override { return m_hMax; }

  gpaReal getTotalArea() const override {
    gpaReal rMax = m_hMax / 2;
    gpaReal rMin = m_hMin / 2;
    gpaReal eps = vmSqrt(1 - vmPower(m_lEll, 2) / vmPower(rMax, 2));
    return std::numbers::pi * (rMax + rMin) * m_lCone +
           2 * std::numbers::pi * rMin * m_lmCyl +
           2 * std::numbers::pi * rMax * m_lCyl +
           2 * std::numbers::pi * vmPower(rMax, 2) +
           std::numbers::pi * vmPower(m_lEll, 2) / eps *
               log((1 + eps) / (1 - eps));
  }

  gpaReal getBottomArea() const override { return 0; }

  gpaReal getTopArea() const override { return 0; }

  gpaReal getSideArea() const override { return 0; }

  gpaReal getPerimeterAt(gpaReal height) const override { return 0; }

  gpaReal getSliceAreaAt(gpaReal height) const override { return 0; }

  gpaReal getSideAreaAt(gpaReal height) const override { return 0; }

  gpaReal getVolume() const override {
    gpaReal rMax = m_hMax / 2;
    gpaReal rMin = m_hMin / 2;
    gpaReal V_min = std::numbers::pi * vmPower(rMin, 2) * m_lmCyl;
    gpaReal V_max = std::numbers::pi * vmPower(rMax, 2) * m_lCyl;
    gpaReal V_cone = std::numbers::pi * m_lCone / 3 *
                     (vmPower(rMin, 2) + vmPower(rMax, 2) + rMax * rMin);
    gpaReal V_ell = 2 / 3 * std::numbers::pi * vmPower(m_lEll, 2) * rMax;
    // gpaReal V_M_PIpe = m_nPipe * (2 * m_lPipe + std::numbers::pi * m_hPipe /
    // 2) * std::numbers::pi * vmPower(m_dPipe / 2 + m_deltaPipe, 2);
    return V_min + V_cone + V_max + V_ell;
  }

  gpaReal getFirstVolume() const { return getFirstVolumeAt(getHeight()); }

  gpaReal getFirstArea() const {
    gpaReal rMax = m_hMax / 2;
    gpaReal rMin = m_hMin / 2;
    gpaReal s_con = std::numbers::pi * (rMin + rMax) * m_lCone;
    gpaReal s_mCyl = 2 * std::numbers::pi * rMin * m_lmCyl;
    gpaReal s_cyl = 2 * std::numbers::pi * rMax * m_lPart;
    return s_con + s_mCyl + s_cyl;
  }

  gpaReal getFirstVolumeAt(gpaReal height) const {
    gpaReal rMax = m_hMax / 2;
    gpaReal rMin = m_hMin / 2;
    return getCylynderVolumeAt(height, rMax, m_lPart) +
           getCylynderVolumeAt(height, rMin, m_lmCyl) + getConeVolumeAt(height);
  }

  gpaReal getSecondVolume() const { return getSecondVolumeAt(getHeight()); }

  gpaReal getSecondArea() const {
    gpaReal rMax = m_hMax / 2;
    gpaReal rMin = m_hMin / 2;
    gpaReal eps = vmSqrt(1 - vmPower(m_lEll, 2) / vmPower(rMax, 2));
    gpaReal s_ell = 2 * std::numbers::pi * vmPower(rMax, 2) +
                    std::numbers::pi * vmPower(m_lEll, 2) / eps *
                        log((1 + eps) / (1 - eps));
    gpaReal s_cyl = 2 * std::numbers::pi * rMax * (m_lCyl - m_lPart);
    return s_cyl + s_ell;
  }

  gpaReal getSecondVolumeAt(gpaReal height) const {
    gpaReal rMax = m_hMax / 2;
    gpaReal rMin = m_hMin / 2;
    return getCylynderVolumeAt(height, rMax, m_lCyl - m_lPart) +
           getEllipseVolumeAt(height);
  }

  gpaReal getCylynderVolumeAt(gpaReal height, gpaReal radius,
                              gpaReal length) const {
    if ((height >= 0) && (height < 2 * radius)) {
      gpaReal theta = 2 * acos(1 - height / radius);
      return length / 2 * vmPower(radius, 2) * (theta - sin(theta));
    } else {
      return std::numbers::pi * vmPower(radius, 2) * length;
    }
  }

  gpaReal getEllipseVolumeAt(gpaReal height) const {
    gpaReal rMax = m_hMax / 2;
    return std::numbers::pi * vmPower(m_lEll, 2) * vmPower(height, 2) *
           (3 * rMax - height) / (3 * vmPower(rMax, 2));
  }

  gpaReal getConeVolumeAt(gpaReal height) const {
    gpaReal rMax = m_hMax / 2;
    gpaReal rMin = m_hMin / 2;
    if ((height >= 0) && (height <= m_hMin)) {
      gpaReal v1 =
          std::numbers::pi * m_lCone / 6 * (rMax + m_hMin) * (rMax - rMin);
      gpaReal sqrt_part1 = vmSqrt((2 * rMax - height) * height);
      gpaReal v2 = (sqrt_part1 * m_lCone / (9 * (rMax - rMin))) *
                   (3 * rMax - height) * (2 * height - rMax);

      gpaReal sqrt_part2 = vmSqrt((2 * rMin - height) * height);
      gpaReal v3 = (sqrt_part2 * m_lCone / (9 * (rMax - rMin))) *
                   (9 * rMax * (rMin - height) +
                    2 * rMin * (height - 3 * rMin) + 2 * vmPower(height, 2));

      gpaReal arcsin_part1 = asin(1 - height / rMin);
      gpaReal arcsin_part2 = asin(1 - height / rMax);
      gpaReal v4 = (m_lCone / (3 * (rMax - rMin))) *
                   (vmPower(rMin, 2) * (3 * rMax - 2 * rMin) * arcsin_part1 -
                    vmPower(rMax, 3) * arcsin_part2);

      return v1 + v2 + v3 + v4;
    } else {
      gpaReal v1 = (std::numbers::pi * m_lCone / (12 * (rMax - rMin))) *
                   (vmPower(height, 2) * (3 * rMax - height) -
                    4 * vmPower(rMin, 2) * (3 * rMax - 2 * rMin));

      gpaReal sqrt_part = sqrt((2 * rMax - height) * height);
      gpaReal v2 = (sqrt_part * m_lCone / (9 * (rMax - rMin))) *
                   (rMax - 2 * height) * (3 * rMax - height);

      gpaReal v3 = (std::numbers::pi * vmPower(height, 2) *
                    (3 * rMax - height) * m_lCone / (12 * (rMax - rMin)));

      gpaReal arccos_part = acos(1 - height / rMax);
      gpaReal v4 =
          (vmPower(rMax, 3) * m_lCone / (3 * (rMax - rMin))) * arccos_part;

      return v1 - v2 - v3 + v4;
    }
  }

  gpaReal getVolumeAt(gpaReal height) const override {
    if (height < 0 || height > getHeight())
      return 0;

    gpaReal rMax = m_hMax / 2;
    gpaReal rMin = m_hMin / 2;
    gpaReal V_min = std::numbers::pi * vmPower(rMin, 2) * m_lmCyl;

    gpaReal retval =
        std::numbers::pi / 2 * vmPower(m_lEll * height, 2) *
            (3 * rMax - height) / 3 / vmPower(rMax, 2) +
        m_lCyl * vmPower(rMax, 2) *
            (acos(1 - height / rMax) -
             (1 - height / rMax) *
                 vmSqrt(2 * height / rMax - vmPower(height / rMax, 2)));

    return retval + height > 2 * rMin
               ? V_min
               : m_lmCyl * vmPower(rMin, 2) *
                         (acos(1 - height / rMin) -
                          (1 - height / rMin) *
                              vmSqrt(2 * height / rMin -
                                     vmPower(height / rMin, 2))) +
                     getConeVolumeAt(height);
  }

  gpaReal getLevelFor(gpaReal volume) const override {
    if (volume == getVolume())
      return getHeight();
    if (!checkVolume(volume))
      return 0;

    if (m_tableV.empty() || m_tableH.empty())
      for (gpaUInt i = 0; i < 200; i++) {
        m_tableH.push_back(i * m_hMax / 200);
        m_tableV.push_back(getVolumeAt(i * m_hMax / 200));
      }

    return tk::spline(m_tableV, m_tableH)(volume);
  }

  gpaReal getFirstLevelFor(gpaReal volume) const {
    volume = vmMin(vmMax(volume, .0), getFirstVolume());
    if (volume == getFirstVolume())
      return getHeight();
    if (volume < 0 || volume > getFirstVolume())
      return 0;

    if (m_tableFirstV.empty() || m_tableFirstH.empty())
      for (gpaUInt i = 0; i < 200; i++) {
        m_tableFirstH.push_back(i * m_hMax / 200);
        m_tableFirstV.push_back(getFirstVolumeAt(i * m_hMax / 200));
      }

    return tk::spline(m_tableFirstV, m_tableFirstH)(volume);
  }

  gpaReal getSecondLevelFor(gpaReal volume) const {
    volume = vmMin(vmMax(volume, .0), getSecondVolume());
    if (volume == getSecondVolume())
      return getHeight();
    if (volume < 0 || volume > getSecondVolume())
      return 0;

    if (m_tableSecondV.empty() || m_tableSecondH.empty())
      for (gpaUInt i = 0; i < 200; i++) {
        m_tableSecondH.push_back(i * m_hMax / 200);
        m_tableSecondV.push_back(getSecondVolumeAt(i * m_hMax / 200));
      }

    return tk::spline(m_tableSecondV, m_tableSecondH)(volume);
  }

private:
  gpaReal m_hMin;  // Высота малой цилиндрической части, м
  gpaReal m_hMax;  // Высота большой цилиндрической части, м
  gpaReal m_lCone; // Длина конусной части, м
  gpaReal m_lEll;  // Эллипсная часть кожуха, м
  gpaReal m_lCyl;  // Длина большой цилиндр части, м
  gpaReal m_lmCyl; // Длина малой цилиндр части, м
  gpaReal m_lPart;
  mutable std::vector<double> m_tableV;
  mutable std::vector<double> m_tableH;
  mutable std::vector<double> m_tableFirstV;
  mutable std::vector<double> m_tableFirstH;
  mutable std::vector<double> m_tableSecondV;
  mutable std::vector<double> m_tableSecondH;
};
