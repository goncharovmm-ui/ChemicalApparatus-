#include "gpaIncinerator.h"
#include <iostream>
#include "gpaZeroRadiation.h"
#include "gpaThinWall.h"
#include <gpaLogMeanTempDifference.h>

constexpr gpaUInt ID_CIRCUIT_INNER = 0;
constexpr gpaUInt NUM_CIRCUITS = 1;

constexpr gpaUInt ID_PORT_INLET = 0;
constexpr gpaUInt ID_PORT_OUTLET = 1;
constexpr gpaUInt NUM_PORTS = 2;

// Gas Blower Parameters IDs
constexpr gpaUInt ID_PARAM_RADLOSS = 0x00;
constexpr gpaUInt ID_PARAM_K_CO_2 = 0x01;
constexpr gpaUInt ID_PARAM_K_NO_2 = 0x02;
constexpr gpaUInt ID_PARAM_ENVIRONMENT_TEMP = 0x03;
constexpr gpaUInt ID_PARAM_PIPE_DIAM = 0x04;
constexpr gpaUInt ID_PARAM_PIPE_LEN = 0x05;

constexpr gpaUInt ID_SENSOR_PRESSURE_DIFF = 0x00;
constexpr gpaUInt ID_SENSOR_TEMPERATURE_DIFF = 0x01;
constexpr gpaUInt ID_SENSOR_NR_FLOWRATE = 0x02;
constexpr gpaUInt ID_SENSOR_OVERAGE_COEF = 0x03;

const gpaString gpaIncinerator::m_typeName = "incinerator";
const gpaString gpaIncinerator::m_description = "Инсинератор";

const gpaStringVector gpaIncinerator::m_circuitNames =
    {
        "Incinerator circuit"};

const gpaStringVector gpaIncinerator::m_portNames =
    {
        "Вход смеси",
        "Дымовые газы"
        // "122-065",
        // "122-077"
};

const gpaParameterInfoVector gpaIncinerator::m_parameters =
    {
        realParam("radiation-loss", "Доля тепловых потерь в виде излучения", GPA_DIMLESS_UNIT, false, 0.1),
        realParam("k_CO_2", "Доля углерода, окисляющегося до CO2", GPA_DIMLESS_UNIT, false, 1.0),
        realParam("k_NO_2", "Доля азота, превращающегося в NO2", GPA_DIMLESS_UNIT, false, 0.2),
        realParam("env_temp", "Температура окружающей среды", GPA_TEMPERATURE_UNIT, false, 21.0),
        realParam("pipe_diam", "Диаметр дымовой трубы", GPA_LENGTH_UNIT, false, 2.2),
        realParam("pipe_len", "Длина дымовой трубы", GPA_LENGTH_UNIT, false, 20.0),
};

const gpaSensorInfoVector gpaIncinerator::m_sensors =
    {
        scalarSensor("pressure-diff", "Перепад давления", GPA_PRES_DIFFER_UNIT),
        scalarSensor("temperature-diff", "Перепад температуры", GPA_TEMP_DIFFER_UNIT),
        scalarSensor("nonreacting-flowrate", " Молярный расход несгоревшего потока", GPA_MASS_RATE_UNIT),
        scalarSensor("overage-coef", "Избыток кислорода в реакции горения", GPA_DIMLESS_UNIT),
};

gpaIncinerator::gpaIncinerator(const gpaCoreInterfaces *interfaces, gpaCoreReference importRef) : gpaExportSystem(interfaces, importRef),
                                                                                                  m_incinerator(asParent()), m_environment(asParent())
{
}

gpaUInt gpaIncinerator::getDeviceNumMixCircuits()
{
    return NUM_CIRCUITS;
}

gpaUInt gpaIncinerator::getDeviceMinNumMixPorts(gpaUInt index)
{
    return index < NUM_CIRCUITS ? NUM_PORTS : 0;
}

gpaUInt gpaIncinerator::getDeviceMaxNumMixPorts(gpaUInt index)
{
    return index < NUM_CIRCUITS ? NUM_PORTS : 0;
}

gpaResult gpaIncinerator::checkParamValues(const gpaExtParameter *) const
{
    return GPA_RESULT_OK;
}

const gpaString *gpaIncinerator::getDeviceMixCircuitName(gpaUInt index)
{
    return index < NUM_CIRCUITS ? &m_circuitNames[index] : NULL;
}

const gpaString *gpaIncinerator::getDeviceMixPortName(gpaUInt circIdx, gpaUInt portIdx)
{
    return portIdx < NUM_PORTS ? &m_portNames[portIdx + circIdx * 2] : NULL;
}

void gpaIncinerator::setNames()
{
    m_incinerator.setName("incinerator");
    m_environment.setName("env");
}

gpaResult gpaIncinerator::setParamValues(const gpaExtParameter *values, bool checkNeeded)
{
    m_incinerator.setPressureModel(std::make_unique<PressureGradientModel>(
        1e-4,
        values[ID_PARAM_PIPE_LEN].value.realValue,
        values[ID_PARAM_PIPE_DIAM].value.realValue,
        values[ID_PARAM_PIPE_LEN].value.realValue,
        0));
    m_incinerator.setRadiationLossCoef(values[ID_PARAM_RADLOSS].value.realValue);
    m_incinerator.setGeometry(values[ID_PARAM_PIPE_DIAM].value.realValue, values[ID_PARAM_PIPE_LEN].value.realValue);
    m_incinerator.setOxidationCoef(values[ID_PARAM_K_CO_2].value.realValue, values[ID_PARAM_K_NO_2].value.realValue);
    m_incinerator.setHeatTransferCoef(1);
    m_environment.setTemperature(GPA_CELCIUS_TO_KELVIN + values[ID_PARAM_ENVIRONMENT_TEMP].value.realValue);
    m_environment.setHeatTransferCoef(2);

    m_convection.setCounterFlow(true);
    m_convection.setConvectLossCoef(0.1);

    gpaLogMeanTempDifference *tempDiff = new gpaLogMeanTempDifference();
    m_convection.setConvTempDiff(tempDiff);
    m_convection.setRadiation(new gpaZeroRadiation());

    gpaThinWall *wall = new gpaThinWall();
    wall->setFinningFactor(2.25 / 2);
    wall->calcPipeHeatCoef(1, 2, 2.25);
    m_convection.setWallModel(wall);
    return GPA_RESULT_OK;
}

gpaResult gpaIncinerator::buildDevice()
{
    bool good = true;

    good = good && m_incinerator.connectMixStream(GPA_ELEM_CIRCUIT_0, ID_PORT_INLET, getEdgeMixStream(ID_CIRCUIT_INNER, ID_PORT_INLET), GPA_STREAM_INLET);
    good = good && m_incinerator.connectMixStream(GPA_ELEM_CIRCUIT_0, ID_PORT_OUTLET, getEdgeMixStream(ID_CIRCUIT_INNER, ID_PORT_OUTLET), GPA_STREAM_OUTLET);
    good = good && m_incinerator.connectHeatStream(0, &m_convection, GPA_STREAM_INLET);
    good = good && m_environment.connectHeatStream(0, &m_convection, GPA_STREAM_OUTLET);
    // Добавляем в систему все элементы и потоки
    setElements({&m_incinerator});
    setStreams({&m_convection});
    return GPA_RESULT_OK;
}

gpaResult gpaIncinerator::initialize()
{
    // Подключить экспортируемый элемент к потокам в интеграторе
    gpaResult res = linkToCoreStreams();
    if (res != GPA_RESULT_OK)
        return res;
    // Соединяем все элементы друг с другом
    res = buildDevice();
    if (res != GPA_RESULT_OK)
        return res;
    // Создаем схемы течений (нужны соединенные элементы)
    auto oe1 = getOuterEntrance(ID_CIRCUIT_INNER, ID_PORT_INLET);
    auto oe2 = getOuterEntrance(ID_CIRCUIT_INNER, ID_PORT_OUTLET);
    auto ret = createSimStructures({}, {oe1});
    if (!ret)
        return GPA_ERROR_WRONG_ARGS;
    // Инициализируем систему
    return gpaExportSystem::initialize();
}

gpaResult gpaIncinerator::calcSensors(gpaVector &sensors) const
{
    setSensorValue(sensors, ID_SENSOR_PRESSURE_DIFF,
                   m_incinerator.getMixPort(ID_CIRCUIT_INNER, ID_PORT_OUTLET)->getStreamPressure() -
                       m_incinerator.getMixPort(ID_CIRCUIT_INNER, ID_PORT_INLET)->getStreamPressure());
    setSensorValue(sensors, ID_SENSOR_TEMPERATURE_DIFF,
                   m_incinerator.getMixPort(ID_CIRCUIT_INNER, ID_PORT_OUTLET)->getStreamTemperature() -
                       m_incinerator.getMixPort(ID_CIRCUIT_INNER, ID_PORT_INLET)->getStreamTemperature());
    setSensorValue(sensors, ID_SENSOR_NR_FLOWRATE,
                   0);
    setSensorValue(sensors, ID_SENSOR_OVERAGE_COEF,
                   0);
    return GPA_RESULT_OK;
}
