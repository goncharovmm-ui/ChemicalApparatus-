#include "gpaVolumeVaporator.h"
#include "gpaVolumeVaporatorInfo.h"

gpaVolumeVaporatorInfo::gpaVolumeVaporatorInfo()
    : gpaDeviceInfo(gpaVolumeVaporator::getDeviceTypeName(),
                    gpaVolumeVaporator::getDeviceDescription()) {
  setParameters(gpaVolumeVaporator::getParametersInfo());
  setSensors(gpaVolumeVaporator::getSensorsInfo());
}

gpaUInt gpaVolumeVaporatorInfo::getNumMixCircuits() const {
  return gpaVolumeVaporator::getDeviceNumMixCircuits();
}

gpaUInt gpaVolumeVaporatorInfo::getMinNumMixPorts(gpaUInt index) const {
  return gpaVolumeVaporator::getDeviceMinNumMixPorts(index);
}

gpaUInt gpaVolumeVaporatorInfo::getMaxNumMixPorts(gpaUInt index) const {
  return gpaVolumeVaporator::getDeviceMaxNumMixPorts(index);
}

const gpaString *gpaVolumeVaporatorInfo::getMixPortName(gpaUInt circIdx,
                                                        gpaUInt portIdx) const {
  return gpaVolumeVaporator::getDeviceMixPortName(circIdx, portIdx);
}

const gpaString *
gpaVolumeVaporatorInfo::getMixCircuitName(gpaUInt index) const {
  return gpaVolumeVaporator::getDeviceMixCircuitName(index);
}

gpaElement *
gpaVolumeVaporatorInfo::createDevice(const gpaCoreInterfaces *interfaces,
                                     gpaCoreReference pairDevice,
                                     const gpaExtObjectModel *model) const {
  gpaVolumeVaporator *separator =
      new gpaVolumeVaporator(interfaces, pairDevice);
  gpaResult res = separator->specifyModel(model);
  if (res == GPA_RESULT_OK)
    return separator;
  delete separator;
  return NULL;
}
