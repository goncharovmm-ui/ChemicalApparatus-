#include "gpaLogMeanTempDifference.h"
#include "gpaZeroRadiation.h"
#include "gpaThinWall.h"
#include "gpaFillingRiser.h"
#include <iostream>

constexpr gpaUInt ID_CIRCUIT_INNER      = 0;
constexpr gpaUInt NUM_CIRCUITS          = 1;

constexpr gpaUInt ID_CIRCUIT = 0;

constexpr gpaUInt ID_PORT_LIQ_OUTLET = 0;
constexpr gpaUInt ID_PORT_GAS_OUTLET = 1;
constexpr gpaUInt ID_PORT_INLET         = 0;
constexpr gpaUInt ID_PORT_OUTLET        = 1;
constexpr gpaUInt NUM_PORTS             = 2;

constexpr gpaUInt  ID_PARAM_PIPE_LENGTH                         =  0;
constexpr gpaUInt  ID_PARAM_HEIGHT                        =  1;
constexpr gpaUInt  ID_PARAM_WALL_DIAMET1                        =  2;
constexpr gpaUInt  ID_PARAM_WALL_DIAMET2                        =  3;
constexpr gpaUInt  ID_PARAM_WALL_DIAMET3                        =  4;
constexpr gpaUInt  ID_PARAM_WALL_THERMAL1                       =  5;
constexpr gpaUInt  ID_PARAM_WALL_THERMAL2                       =  6;
constexpr gpaUInt  ID_PARAM_HEAT_EXPANSION                      =  7;
constexpr gpaUInt  ID_PARAM_OUTER_DENS                          =  8;
constexpr gpaUInt  ID_PARAM_OUTER_VISCOS                        =  9;
constexpr gpaUInt  ID_PARAM_OUTER_COPACITY                      =  10;
constexpr gpaUInt  ID_PARAM_THERM_COPACITY                      =  11;
constexpr gpaUInt  ID_PARAM_OUTER_VELOCITY                      =  12;
constexpr gpaUInt  ID_PARAM_OUTER_THERM                         =  13;
constexpr gpaUInt  ID_PARAM_COEFF_HYDRO                         =  14;
constexpr gpaUInt  ID_PARAM_BEND_RADIUS                         =  15;
constexpr gpaUInt  ID_PARAM_BEND_ANGLE                          =  16;
constexpr gpaUInt  ID_PARAM_BEND_NUMBER                         =  17;


//constexpr gpaUInt ID_PARAM_MOLAR_FLOW                = 0x00;
//constexpr gpaUInt ID_PARAM_ROUGHNESS                 = 0x01;
//constexpr gpaUInt ID_PARAM_SECTION_ANGLE             = 0x02;
//constexpr gpaUInt ID_PARAM_SECTION_DIAMETER          = 0x03;
//constexpr gpaUInt ID_PARAM_SECTION_LENGTH            = 0x04;
//constexpr gpaUInt ID_PARAM_TRANSITION_LENGTH         = 0x05;
//constexpr gpaUInt ID_PARAM_DYNAMIC_VISCOSITY         = 0x06;
//constexpr gpaUInt ID_PARAM_DENSITY                   = 0x07;
//constexpr gpaUInt ID_PARAM_BEND_RADIUS               = 0x08;
//constexpr gpaUInt ID_PARAM_BEND_ANGLE                = 0x09;
//constexpr gpaUInt ID_PARAM_EXTERNAL_HEAT_COEF        = 0x0A;
//constexpr gpaUInt ID_PARAM_IN_THERMAL_EXPANSION      = 0x0B;
//constexpr gpaUInt ID_PARAM_OUT_THERMAL_EXPANSION     = 0x0C;
//constexpr gpaUInt ID_PARAM_IN_PRESSURE               = 0x0D;
//constexpr gpaUInt ID_PARAM_OUT_PRESSURE              = 0x0E;
//constexpr gpaUInt ID_PARAM_IN_VISCOSITY              = 0x0F;
//constexpr gpaUInt ID_PARAM_OUT_VISCOSITY             = 0x10;
//constexpr gpaUInt ID_PARAM_IN_HEAT_CAPACITY          = 0x11;
//constexpr gpaUInt ID_PARAM_OUT_HEAT_CAPACITY         = 0x12;
//constexpr gpaUInt ID_PARAM_IN_THERMAL_CONDUCTIVITY   = 0x13;
//constexpr gpaUInt ID_PARAM_OUT_THERMAL_CONDUCTIVITY  = 0x14;
//constexpr gpaUInt ID_PARAM_IN_MOLAR_FLOW             = 0x15;
//constexpr gpaUInt ID_PARAM_IN_FLOW_VELOCITY          = 0x16;
//constexpr gpaUInt ID_PARAM_OUT_FLOW_VELOCITY         = 0x17;
//constexpr gpaUInt ID_PARAM_DIAMETER_LAYER            = 0x18;
//constexpr gpaUInt ID_PARAM_THERMAL_LAYER             = 0x19;
//constexpr gpaUInt ID_PARAM_PIPE_LENGTH               = 0x1A;
//constexpr gpaUInt ID_PARAM_AMBIENT_TEMP              = 0x1B;
//constexpr gpaUInt ID_PARAM_IN_TEMP                   = 0x1C;
//constexpr gpaUInt ID_PARAM_OUT_TEMP                  = 0x1D;

constexpr gpaUInt ID_SENSOR_PRESSURE_DROP      = 0x00;
constexpr gpaUInt ID_SENSOR_FLOW_VELOCITY      = 0x01;
constexpr gpaUInt ID_SENSOR_HEAT_FLOW          = 0x02;
constexpr gpaUInt ID_SENSOR_INNER_WALL_TEMP    = 0x03;
constexpr gpaUInt ID_SENSOR_OUTER_WALL_TEMP    = 0x04;

const gpaString gpaFillingRiser::m_typeName      = "filling-riser";
const gpaString gpaFillingRiser::m_description   = "Стояка налива";

const gpaStringVector gpaFillingRiser::m_circuitNames =
{
    "Контру",
};

const gpaStringVector gpaFillingRiser::m_portNames =
{
    "Вход ",
    "Выход ",
};




const gpaParameterInfoVector gpaFillingRiser::m_parameters =
{
    realParam("pipe-length",                             "Длина трубы",       GPA_LENGTH_UNIT, false,    4.0),
    realParam("outer-height",                 "Высота между патрубками",       GPA_LENGTH_UNIT, false,  0.026),
    realParam("wall-diamet1",         "Диаметры слоя боковой стенки 1",       GPA_LENGTH_UNIT, false,      0.2476),
    realParam("wall-diamet2",         "Диаметры слоя боковой стенки 2",       GPA_LENGTH_UNIT, false,      0.273),
    realParam("wall-diamet3",         "Диаметры слоя боковой стенки 3",       GPA_LENGTH_UNIT, false,      0.373),
    realParam("wall-thermal1",        "Коэффициент тепловроводности внетренней стенки",       GPA_CONDUCTIVITY_UNIT,false,  60),
    realParam("wall-thermal2",        "Коэффициент тепловроводности изоляции",       GPA_CONDUCTIVITY_UNIT,false,  1),
    realParam("heat-expansion",            "Коэффициент теплового расширения окружающей среды",GPA_DIMLESS_UNIT,false,3.4e-3),
    realParam("outer-dens",               "Плотность окружающей среды",       GPA_DIMLESS_UNIT,false,             1.225),
    realParam("outer-viscos",      "Динамическая вязкость окружающей среды",       GPA_DIMLESS_UNIT,false,            1.81e-5),
    realParam("outer-copacity",        "Теплоемкость окружающей среды",       GPA_HEATTRANS_COEF_UNIT,false,            1.005),
    realParam("therm-copacity",    "Теплопроводность окружающей среды",       GPA_HEAT_CAPACITY_UNIT,false,            0.0257),
    realParam("outer-velocity",    "Скорость движения окружающей среды",       GPA_VELOCITY_UNIT,false,            1),
    realParam("outer-therm",            "Температура окружающей среды",       GPA_TEMPERATURE_UNIT,false,            20),
    realParam("coeff-hydro",       "Коэффицинет гидравлических потерь",       GPA_DIMLESS_UNIT, false, 1),
    realParam("bend-radius",              "Радиус кривизны поворота, м",       GPA_LENGTH_UNIT,            false, 10.0),
    realParam("bend-angle",         "Угол поворота в местах сочленения, градусы",      GPA_DIMLESS_UNIT,           false, 10.0),
    realParam("bend-number",                 "Колличество изгибов",            GPA_DIMLESS_UNIT,           false, 10.0),
};

//{
//    realParam("molar-flow",                 "Мольный расход через трубопровод, моль/с",                         GPA_MOLAR_RATE_UNIT,        false, 10.0),
//    realParam("roughness",                  "Шероховатость внутренней стенки, м",                               GPA_LENGTH_UNIT,            false, 10.0),
//    realParam("section-angle",              "Угол наклона участка стояка, градусы",                             GPA_DIMLESS_UNIT,           false, 10.0),
//    realParam("section-diameter",           "Внутренний диаметр участка трубопровода, м",                       GPA_LENGTH_UNIT,            false, 10.0),
//    realParam("section-length",             "Длина участка трубопровода, м",                                    GPA_LENGTH_UNIT,            false, 10.0),
//    realParam("transition-length",          "Длина перехода диаметра трубопровода, м",                          GPA_LENGTH_UNIT,            false, 10.0),
//    realParam("dynamic-viscosity",          "Динамическая вязкость смеси потока, Па·с",                         NAN,                        false, 10.0),
//    realParam("density",                    "Плотность смеси потока, кг/м^3",                                   NAN,                        false, 10.0),
//    realParam("bend-radius",                "Радиус кривизны поворота, м",                                      GPA_LENGTH_UNIT,            false, 10.0),
//    realParam("bend-angle",                 "Угол поворота в местах сочленения, градусы",                       GPA_DIMLESS_UNIT,           false, 10.0),
//    realParam("external-heat-coef",         "Коэффициент внешней теплоотдачи, Вт/(м^2·К)",                      GPA_HEATTRANS_COEF_UNIT,    false, 10.0),
//    realParam("in-thermal-expansion",       "Коэффициент теплового расширения технологической среды, 1/К",      NAN,                        false, 10.0),
//    realParam("out-thermal-expansion",      "Коэффициент теплового расширения окружающей среды, 1/К",           NAN,                        false, 10.0),
//    realParam("in-pressure",                "Плотность технологической среды, 1/К",                             NAN,                        false, 10.0),
//    realParam("out-pressure",               "Плотность окружающей среды, 1/К",                                  NAN,                        false, 10.0),
//    realParam("in-viscosity",               "Вязкость технологической среды, Па·с",                             NAN,                        false, 10.0),
//    realParam("out-viscosity",              "Вязкость окружающей среды, Па·с",                                  NAN,                        false, 10.0),
//    realParam("in-heat-capacity",           "Теплоемкость технологической среды, Дж/(кг·К)",                    NAN,                        false, 10.0),
//    realParam("out-heat-capacity",          "Теплоемкость окружающей среды, Дж/(кг·К)",                         NAN,                        false, 10.0),
//    realParam("in-thermal-conductivity",    "Теплопроводность технологической среды, Вт/(м·К)",                 GPA_CONDUCTIVITY_UNIT,      false, 10.0),
//    realParam("out-thermal-conductivit",   "Теплопроводность окружающей среды, Вт/(м·К)",                      GPA_CONDUCTIVITY_UNIT,      false, 10.0), realParam("in-molar-flow",              "Мольный расход технологической среды, моль/с",                     GPA_MOLAR_RATE_UNIT,      false, 0.10),
//    realParam("in-flow-velocity",           "Скорость движения технологической среды, м/с",                     GPA_VELOCITY_UNIT,          false, 10.0),
//    realParam("out-flow-velocity",          "Скорость движения окружающей среды, м/с",                          GPA_VELOCITY_UNIT,          false, 10.0),
//    realParam("diameter-layer",             "Диаметры границ слоев, м",                                         GPA_LENGTH_UNIT,            false, 10.0),
//    realParam("thermal-layer",              "Коэффициенты теплопроводности слоев, Вт/(м^2·К)",                  GPA_HEATTRANS_COEF_UNIT,    false, 10.0),
//    realParam("pipe-length",                "Длина трубопровода, м",                                            GPA_LENGTH_UNIT,            false, 10.0),
//    realParam("ambient-temp",               "Температура окружающей среды, К",                                  GPA_TEMPERATURE_UNIT,       false, 10.0),
//    realParam("in-temp",                    "Температура входящего потока, К",                                  GPA_TEMPERATURE_UNIT,       false, 10.0),
//    realParam("out-temp",                   "Температура выходящего потока, К",                                 GPA_TEMPERATURE_UNIT,       false, 10.0)
//};

const gpaSensorInfoVector gpaFillingRiser::m_sensors =
{
    scalarSensor("pressure-drop",    "Перепад давления на трубопроводе, Па",                 GPA_PRES_DIFFER_UNIT),
    scalarSensor("flow-velocity",    "Скорость движения смеси в трубопроводе, м/с",          GPA_VELOCITY_UNIT),
    scalarSensor("heat-flow",        "Тепловой поток, Вт",                                   GPA_HEAT_RATE_UNIT),
 //   scalarSensor("inner-wall-temp",  "Температура внутренней стенки, К",                     GPA_TEMPERATURE_UNIT),
 //   scalarSensor("outer-wall-temp",  "Температура наружной стенки, К",                       GPA_TEMPERATURE_UNIT)
};

gpaFillingRiser::gpaFillingRiser(const gpaCoreInterfaces* interfaces, gpaCoreReference importRef) :
    gpaExportSystem (interfaces, importRef),
    m_heatPipes      (asParent())
{
}

gpaResult gpaFillingRiser::calcSensors(gpaVector& sensors) const
{
    setSensorValue(sensors, ID_SENSOR_PRESSURE_DROP,      m_heatPipes.getDeltaPres()      );
    setSensorValue(sensors, ID_SENSOR_FLOW_VELOCITY,      m_heatPipes.getVelocity2()      );
    setSensorValue(sensors, ID_SENSOR_HEAT_FLOW,          m_heatPipes.m_Qout      );
 //   setSensorValue(sensors, ID_SENSOR_INNER_WALL_TEMP,    m_heatPipes->m      );
//    setSensorValue(sensors, ID_SENSOR_OUTER_WALL_TEMP,    0.0      );

    return GPA_RESULT_OK;
}
gpaResult gpaFillingRiser::checkParamValues(const gpaExtParameter *values) const
{
    (void)values;
    return GPA_RESULT_OK;
}

void gpaFillingRiser::setNames()
{
    m_heatPipes.setName("pipes");
}

gpaResult gpaFillingRiser::initMixtureFlow(const gpaExtParameter *values)
{
    // Назначаем параметры проточных элементов
    bool good = true;
    return GPA_RESULT_OK;
}

gpaResult gpaFillingRiser::setParamValues(const gpaExtParameter *values, bool checkNeeded)
{
    gpaHeatCoeffPrm*   hc1 = new gpaHeatCoeffPrm(
        values[ID_PARAM_WALL_DIAMET1].value.realValue,
        values[ID_PARAM_PIPE_LENGTH].value.realValue,
        values[ID_PARAM_HEAT_EXPANSION].value.realValue,
        gpaReal(273.0),
        values[ID_PARAM_OUTER_THERM].value.realValue+273,
        values[ID_PARAM_OUTER_DENS].value.realValue,
        values[ID_PARAM_OUTER_VISCOS].value.realValue,
        values[ID_PARAM_OUTER_COPACITY].value.realValue,
        1,
        1,
        false
    );
    m_heatPipes.m_heatCoef1 = hc1;
    m_heatPipes.m_l=values[ID_PARAM_PIPE_LENGTH].value.realValue;
    m_heatPipes.m_dh=values[ID_PARAM_HEIGHT].value.realValue;
    m_heatPipes.m_wall_conductive1 = values[ID_PARAM_WALL_THERMAL1].value.realValue;
    m_heatPipes.m_wall_conductive2 = values[ID_PARAM_WALL_THERMAL2].value.realValue;
    //m_heatPipes.m_wall_conductive3 = values[ID_PARAM_WALL_THERMAL3].value.realValue;
    m_heatPipes.m_wall_diamet1 = values[ID_PARAM_WALL_DIAMET1].value.realValue;
    m_heatPipes.m_wall_diamet2 = values[ID_PARAM_WALL_DIAMET2].value.realValue;
    m_heatPipes.m_wall_diamet3 = values[ID_PARAM_WALL_DIAMET3].value.realValue;
    m_heatPipes.m_hydro_coeff= values[ID_PARAM_COEFF_HYDRO].value.realValue; 

    m_heatPipes.m_diametr = values[ID_PARAM_WALL_DIAMET1].value.realValue;
    m_heatPipes.m_eps = 5e-5;

 


    // Проверка параметров, если требуется
    if (checkNeeded)
    {
        gpaResult res = checkParamValues(values);
        if (res != GPA_RESULT_OK)
            return res;
    }
    // Даем названия элементам и потокам
    setNames();
    // Инициализируются элементы с потоком смеси
    gpaResult res = initMixtureFlow(values);
    if (res != GPA_RESULT_OK)
        return res;
    // Обновляем параметры воздуха на входе
    return res;
}

gpaResult gpaFillingRiser::buildDevice()
{
    bool good = true;
    // Соединяем поток смеси по трубам с граничными потоками смеси системы
    good = good && m_heatPipes.connectMixStream(GPA_ELEM_CIRCUIT_0, ID_PORT_INLET, getEdgeMixStream(ID_CIRCUIT, ID_PORT_INLET), GPA_STREAM_INLET);
    good = good && m_heatPipes.connectMixStream(GPA_ELEM_CIRCUIT_0, ID_PORT_GAS_OUTLET, getEdgeMixStream(ID_CIRCUIT, ID_PORT_GAS_OUTLET), GPA_STREAM_OUTLET);
    if (!good)
        return GPA_ERROR_WRONG_ARGS;
    // Добавляем в систему все элементы и потоки
    setElements({&m_heatPipes});
    setStreams({});
    return GPA_RESULT_OK;
}

gpaResult gpaFillingRiser::initialize()
{
    // Подключить экспортируемый элемент к потокам в интеграторе
    gpaResult res = linkToCoreStreams();
    if (res != GPA_RESULT_OK)
        return res;
    // Соединяем все элементы друг с другом
    res = buildDevice();
    if (res != GPA_RESULT_OK)
        return res;
    // Создаем схемы течений (нужны соединенные элементы)
    if (!createSimStructures({}, {getOuterEntrance(ID_CIRCUIT, ID_PORT_INLET)}))
        return GPA_ERROR_WRONG_ARGS;
    // Инициализируем систему
    return gpaExportSystem::initialize();
}

gpaResult gpaFillingRiser::setSignals(const gpaConstVector &signals)
{
    return GPA_RESULT_OK;
}
const gpaString* gpaFillingRiser::getDeviceMixCircuitName(gpaUInt index)
{
    return index < NUM_CIRCUITS ? &m_circuitNames[index] : NULL;
}
const gpaString* gpaFillingRiser::getDeviceMixPortName(gpaUInt circIdx, gpaUInt portIdx)
{
    if (circIdx == ID_CIRCUIT)
        return portIdx < NUM_PORTS ? &m_portNames[portIdx] : NULL;
    return NULL;
}





