#include "gpaInclude.h"
#include "gpaEOHElement.h"

const gpaString gpaEOHElement::m_typeName     = "EOH";
const gpaString gpaEOHElement::m_description  = "gpaEOHElement";

gpaEOHElement::gpaEOHElement(const gpaParentLink *link)
    : m_gasEnthalpy(0), m_liquidEnthalpy(0), m_liquidFlowRate(0),
      m_temperature(0) {
  setMixCircuit(new gpaElementMixCircuit(this, GPA_ELEM_CIRCUIT_0));
  m_d = 0.5;
  m_l = 2.0;
  m_dh = 0.3;
  m_nBends = 2;
  m_eps = 0.0001;
  m_Tenv = 293.15;
  m_heatLayers.push_back(gpaHeatLayer{0.02, 7800, 16.0, 460});
  m_alpha_in_pipe = m_alpha_out_pipe = m_alpha_in_gas = m_alpha_out_gas =
      100.0;
  calcThermalParams();
}

gpaEOHElement::gpaEOHElement(const gpaEOHElement &m_heatPipes) {
    m_gasEnthalpy = m_heatPipes.m_gasEnthalpy;
    m_liquidEnthalpy = m_heatPipes.m_liquidEnthalpy;
    m_liquidFlowRate = m_heatPipes.m_liquidFlowRate;
    m_temperature = m_heatPipes.m_temperature;
    m_d = m_heatPipes.m_d;
    m_l = m_heatPipes.m_l;
    m_dh = m_heatPipes.m_dh;
    m_nBends = m_heatPipes.m_nBends;
    m_eps = m_heatPipes.m_eps;
    m_Tenv = m_heatPipes.m_Tenv;
    m_heatLayers = m_heatPipes.m_heatLayers;

    m_alpha_in_pipe = m_heatPipes.m_alpha_in_pipe;
    m_alpha_out_pipe = m_heatPipes.m_alpha_out_pipe;
    m_alpha_in_gas = m_heatPipes.m_alpha_in_gas;
    m_alpha_out_gas = m_heatPipes.m_alpha_out_gas;
    calcThermalParams();
  }

gpaEOHElement *gpaEOHElement::copy() const {
    return new gpaEOHElement(*this);
  }

gpaUInt gpaEOHElement::getMinNumMixPorts(gpaUInt index) const {
    return getDeviceMinNumMixPorts(index);
  }

gpaUInt gpaEOHElement::getDeviceMinNumMixPorts(gpaUInt index) {
    if (index == GPA_ELEM_CIRCUIT_0) {
      return 2;
    }
    return 0;
  }

gpaUInt gpaEOHElement::getDeviceNumMixCircuits() { return 1; }

gpaUInt gpaEOHElement::getNumMixCircuits() const { return 1; }

gpaUInt gpaEOHElement::getMaxNumMixPorts(gpaUInt index) const {
    return getDeviceMaxNumMixPorts(index);
  }

gpaUInt gpaEOHElement::getDeviceMaxNumMixPorts(gpaUInt index) {
    if (index == GPA_ELEM_CIRCUIT_0) {
      return 2;
    }
    return 0;
  }

gpaUInt gpaEOHElement::getNumVariables() const { return 1; }

void gpaEOHElement::fillVarNames(gpaStringVector &varNames) const {}

gpaResult gpaEOHElement::initVariables(gpaVector &variables) const {
    variables[TEMP_TEH] = TEMP_TEH_bundle_INIT + 273; //;

    return GPA_RESULT_OK;
  }

gpaResult gpaEOHElement::initialize() {
    cout << " start" << endl;

    initFlows();
    initMedium();
    calcGeomParsGasPipeline();



    return GPA_RESULT_OK;
  }

void gpaEOHElement::calcGeomParsGasPipeline() {

      mass_TEH_bundle = mass_TEH * TEH_amount;

      len_TEH = 2*len_HE_zone;
      HE_area = len_TEH * TEH_amount * std::numbers::pi * d_TEH;



      oilChannel.amount_of_sections = amount_of_sections;
      oilChannel.nRow = TEH_Row * 3.14/4 * amount_of_sections;

      len_of_section = len_HE_zone/amount_of_sections;
      oilChannel.crossArea = len_of_section*(d_inner_oil_ch - TEH_Row*d_TEH)*3.14/4;

      oilChannel.n_ch = 1;
      oilChannel.d_char = d_TEH;

      // FIX (устранение UB): поля канала s1/s2 исторически читались неинициализированными.
      // На MSVC-Debug они детерминированно были 0, и эталоны тестов откалиброваны под это
      // поведение (phi=1, cS≈3.587). Фиксируем 0 ЯВНО -> результат побайтово идентичен,
      // неопределённое поведение устранено. (Для перехода на физический шаг пучка s1/s2
      // потребуется перекалибровка эталонов mass-rate в тестах EOH.)
      oilChannel.s1 = 0.0;
      oilChannel.s2 = 0.0;

      oilChannel.c = 0.64;
      oilChannel.n = 0.5;
      oilChannel.m = 0.33;

    }

gpaResult gpaEOHElement::fillMassMatrix(gpaUInt refRow, gpaUInt refCol) const {
    gpaResult res = setMassMatrCoef(refRow, refCol, 1.0);
    if (res != GPA_RESULT_OK)
      return res;
    return GPA_RESULT_OK;
  }

void gpaEOHElement::initMedium() {
    m_medium_oil= inlet_oil->getStreamMedium()->copyTo(asOwner());


    oilChannel.flag = 1;

    oilChannel.pipe_Name = "terminol";
    oilChannel.fluid      = "oil";
    oilChannel.medium       =  m_medium_oil;

    oilChannel.getStandartPackProp({1});


    oilChannel.exportCurrentBiblProps("D:\\0 MMA\\", 273.0 + 10, 273.0 + 30, 2,{1});

  }

void gpaEOHElement::initFlows() {
    circuit_oil = getMixCircuit(GPA_ELEM_CIRCUIT_0);

    inlet_oil = circuit_oil->getPort(0);
    out_oil   = circuit_oil->getPort(1);
  }

void gpaEOHElement::calcFlowProperties() {

    T_in_oil  = inlet_oil->getStreamTemperature();

    T_out_oil = out_oil->getStreamTemperature();

    // Get G&P
    G_in_oil = inlet_oil->getIncomingFlowRate();
    P_in_oil = inlet_oil->getStreamPressure();

    G_out_oil = out_oil->getIncomingFlowRate();
    P_out_oil = out_oil->getStreamPressure();

    m_dot_oil = inlet_oil->getIncomingMassRate();

  }

gpaReal gpaEOHElement::sigmoid(gpaReal x) { return 1.0 / (1.0 + std::exp(-x)); }

void gpaEOHElement::calcDeltaPress(int isShowInConsol) {

    if (isShowInConsol == 1) {
      cout << endl << " <-- 1.calcDeltaPress--> " << endl;
    }

        //m_medium_RC_oil->calcFlashPT(P_in_oil, TMeanRCOil, m_medium_RC_oil->getFractions());

        // oil
        if(isShowInConsol==1)
        {
            cout << " calcDeltaP  oilPipeCC ---- " << endl;
        }

        oilChannel.calcMyPipeViscousFrictionProp(1);

        if(isShowInConsol ==1)
        {
            cout << "G"<< " | " << " v "<< " | " << "Re" << " | "  << "coefFrick"<<endl;
            cout << G_in_oil << " | " << oilChannel.v << " | " << oilChannel.Re   << " | "  << oilChannel.DP <<endl;
        }

        // FIX: применяем калибровочный коэффициент k_delta_DP (раньше читался, но не использовался)
        delta_P_oil = k_delta_DP * (m_dot_oil>0.1? oilChannel.DP:0.001*m_dot_oil);


  }

void gpaEOHElement::calcMeanTemp(bool isShow) {

      if(isShow==1)
      {
          cout<<" calcMeanTemp "<<endl;
      }

      oilChannel.meanTemp  = (T_out_oil    + T_in_oil)/2;

      if(isShow==1)
      {
          cout<<" calcMeanTemp "<<endl;
      }
  }

void gpaEOHElement::calcMeanPressure() {
    oilChannel.meanPressure  = (P_out_oil + P_in_oil)/2;
  }

gpaResult gpaEOHElement::getLMTD(gpaReal T_in_1, gpaReal T_out_1, gpaReal T_in_2, gpaReal T_out_2, gpaUInt i_Flow_Scheme) {
      gpaReal bigDelta;
      gpaReal smallDelta;
      gpaReal sign;

      if(i_Flow_Scheme == 0)  // FIX: было присваивание '=' вместо сравнения '=='
      {
          bigDelta    = abs(T_in_1 - T_in_2);
          smallDelta  = abs(T_out_1 - T_out_2);

          sign = (T_in_1 > T_in_2)? 1 : -1;

      }
      else
      {
          bigDelta    = abs(T_in_1 - T_out_2);
          smallDelta  = abs(T_out_1 - T_in_2);

          sign = (T_in_1 > T_in_2)? (T_out_1 > T_in_2)?1:0 : (T_in_2 > T_out_1)? -1:0;

          sign = (T_out_1 > T_in_1)&&(T_out_2 > T_in_2)? 0:sign;
      }

      gpaReal LMTD_True   = (bigDelta - smallDelta)/(log(bigDelta/(smallDelta + 0.00001)));
      gpaReal LMTD_Simple = (bigDelta + smallDelta)/2;
      gpaReal diffDelta   =  bigDelta - smallDelta;

      gpaReal sigm = sigmoid(1*(diffDelta-1));

      gpaReal LMTD = LMTD_Simple*(1-sigm) + sigm*LMTD_True;

      return   sign*LMTD;


  }

void gpaEOHElement::calcQ(int isShowInConsol) {

    if (isShowInConsol == 1) {
      cout << endl << " <-- 2. calcQ--> " << endl;
    }


    calcMeanTemp(isShowInConsol);
    calcMeanPressure();

    oilChannel.calcMyPipeHeatTransherProp(isShowInConsol,G_in_oil);

    alpha_oil   = oilChannel.alpha_conv; // 94/1000

    gpaReal deltaT = temp_TEH_bundle - (T_out_oil + T_in_oil)/2;

    Q_from_TEH_bundle_to_oil = k_delta_H *  alpha_oil * (deltaT>0?deltaT:0) * HE_area;

    // Теплообмен
    Delta_H_oil = Q_from_TEH_bundle_to_oil / (G_in_oil + 0.0001);

    if (isShowInConsol == 1) {
      std::cout << "dT" << " | " << deltaT << " | " << "\n";
      std::cout << "HE_area" << " | " << HE_area << " | " << "\n";
      std::cout << "k_delta_H" << " | " << k_delta_H << " | " << "\n";
      std::cout << "G_in_oil" << " | " << G_in_oil << " | " << "\n";
      std::cout << "Delta_H_oil" << " | " << Delta_H_oil << " | " << "\n";
      std::cout << "Q_from_TEH_bundle_to_oil" << Q_from_TEH_bundle_to_oil << " | " << "\n";
      std::cout << "TEH_bundle_Power" << " | " << TEH_bundle_Power << " | " << "\n";
      std::cout << "mass_TEH_bundle" << " | " << mass_TEH_bundle << " | " << "\n";
      std::cout << "cp_TEH_bundle" << " | " << cp_TEH_bundle << " | " << "\n";

    }
  }

gpaResult gpaEOHElement::calcFuncValues(const gpaConstVector &,
                           const gpaConstVector &variables, gpaVector &values,
                           const gpaSetOfEquations &eqIds) {


    calcFlowProperties();

    //++ Пересчет различных переменных


    oilChannel.getStandartPackProp({1});



    // Переименовал для удобства неизвестые перемеые.
    temp_TEH_bundle = variables[TEMP_TEH];
    //++ Пересчет различных переменных


    calcQ(0);
    calcDeltaPress(0);

    //++ Пересчет различных переменных

    //++ Формирование уравнений для невязок

    //std::cout << 0 << " | " << (TEH_bundle_Power - Q_from_TEH_bundle_to_oil) / (mass_TEH_bundle * cp_TEH_bundle) << " | " << "\n";

    //std::cout << "d_char_Nu = " << oilChannel.d_char<< "\n";

    values[0] = (TEH_bundle_Power - Q_from_TEH_bundle_to_oil) / (mass_TEH_bundle * cp_TEH_bundle);

    values[1] = P_in_oil - P_out_oil  - delta_P_oil- coef_deltaP_Valve * m_dot_oil * abs(m_dot_oil);
    values[2] = G_in_oil + G_out_oil;

    //++ Формирование уравнений для невязок

    return GPA_RESULT_OK;
  }

gpaResult gpaEOHElement::calcEnthalpyFuncValueAt(gpaUInt circIdx, gpaUInt portIdx,
                                    gpaReal enthalpy,
                                    gpaReal &funcValue) const {
    if (circIdx == GPA_ELEM_CIRCUIT_0) {
      const gpaMixPort *oppPort = getMixPort(GPA_ELEM_CIRCUIT_0, 1 - portIdx);
      if (!oppPort)
        return GPA_ERROR_WRONG_ARGS;
      funcValue =
          enthalpy - oppPort->getStreamMedium()->getEnthalpy() - Delta_H_oil;
      // printf("Enthalpy %d: %f\n", portIdx, funcValue);
      return GPA_RESULT_OK;
    }
    return GPA_ERROR_WRONG_ARGS;
  }

gpaResult gpaEOHElement::calcFractionsFuncValuesAt(gpaUInt circIdx, gpaUInt portIdx,
                                      const gpaConstVector &fractions,
                                      gpaVector &funcValues) const {
    if (circIdx == GPA_ELEM_CIRCUIT_0) {

      const gpaMixPort *oppPort = getMixCircuit(circIdx)->getPort(1 - portIdx);
      if (!oppPort)
        return GPA_ERROR_WRONG_ARGS;
      const gpaConstVector calcFractions =
          oppPort->getStreamMedium()->getFractions();
      for (gpaUInt i = 0; i < funcValues.size(); ++i)
        funcValues[i] = fractions[i] - calcFractions[i];
      // printf("Fractions %d\n", portIdx);
      //  for (gpaUInt i = 0; i < funcValues.size(); ++i)
      //      printf("%f--", funcValues[i]);
      // printf("\n");
      return GPA_RESULT_OK;
    }

    return GPA_ERROR_WRONG_ARGS;
  }

const gpaString &gpaEOHElement::getTypeName() const {
    return getDeviceTypeName();
  }

const gpaString &gpaEOHElement::getDescription() const {
    return getDeviceDescription();
  }

void gpaEOHElement::calcThermalParams() {
    gpaReal d = m_d;
    gpaReal l = m_l;
    // PIPE (основная труба)
    m_R_pipe = 0;
    m_A_in_pipe = 3.14 * d * l;
    gpaReal radius_inner = d / 2.0;
    for (const auto &layer : m_heatLayers) {
      gpaReal r1 = radius_inner;
      gpaReal r2 = r1 + layer.thickness;
      m_R_pipe += std::log(r2 / r1) /
                  (2 * 3.14  * layer.heatConductivity * l);
      radius_inner = r2;
    }
    m_A_out_pipe = 3.14  * (2 * radius_inner) * l;

    // GAS (газовая сторона, пусть конструкция аналогична)
    m_R_gas = m_R_pipe;
    m_A_in_gas = m_A_in_pipe;
    m_A_out_gas = m_A_out_pipe;
  }

const gpaString &gpaEOHElement::getDeviceTypeName() { return m_typeName; }

const gpaString &gpaEOHElement::getDeviceDescription() { return m_description; }
