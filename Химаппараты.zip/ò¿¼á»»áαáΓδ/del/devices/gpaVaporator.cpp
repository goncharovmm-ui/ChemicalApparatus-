#include "gpaVaporator.h"
#include "gpaHeatCoeffPrm.h"
#include "gpaLogMeanTempDifference.h"
#include "gpaMolarMixtureCondition.h"
#include "gpaPressureCondition.h"
#include "gpaThinWall.h"
#include "gpaZeroRadiation.h"
#include <iostream>
#include <numbers>

constexpr gpaUInt ID_CIRCUIT = 0;
constexpr gpaUInt NUM_CIRCUITS = 1;

constexpr gpaUInt ID_PORT_INLET = 0;
constexpr gpaUInt ID_PORT_OUTLET = 1;
constexpr gpaUInt NUM_PORTS = 2;

constexpr gpaUInt ID_SENSOR_AIR_OUT_TEMP = 0x00;
constexpr gpaUInt ID_SENSOR_MIX_DELTA_TEMP = 0x01;

constexpr gpaUInt ID_SENSOR_TEMPERATURE_TEN1 = 0x02;
constexpr gpaUInt ID_SENSOR_TEMPERATURE_TEN2 = 0x03;
constexpr gpaUInt ID_SENSOR_TEMPERATURE_TEN3 = 0x04;
constexpr gpaUInt ID_SENSOR_LENGTH1 = 0x05;
constexpr gpaUInt ID_SENSOR_LENGTH2 = 0x06;
constexpr gpaUInt ID_SENSOR_LENGTH3 = 0x07;

constexpr gpaUInt ID_SENSOR_TEMPERATURE_M1 = 8;
constexpr gpaUInt ID_SENSOR_TEMPERATURE_M2 = 9;
constexpr gpaUInt ID_SENSOR_TEMPERATURE_M3 = 10;

constexpr gpaUInt ID_PARAM_VAPORATOR_POW = 0;
constexpr gpaUInt ID_PARAM_PIPE_LENGTH = 1;
constexpr gpaUInt ID_PARAM_ALPHA = 2;
constexpr gpaUInt ID_PARAM_INNER_DIAM = 3;
constexpr gpaUInt ID_PARAM_HEIGHT = 4;
constexpr gpaUInt ID_PARAM_WALL_DIAMETR1 = 5;
constexpr gpaUInt ID_PARAM_WALL_DIAMETR2 = 6;
constexpr gpaUInt ID_PARAM_WALL_DIAMETR3 = 7;
constexpr gpaUInt ID_PARAM_WALL_THERMAL1 = 8;
constexpr gpaUInt ID_PARAM_WALL_THERMAL2 = 9;
constexpr gpaUInt ID_PARAM_HEAT_EXPANSION = 10;
constexpr gpaUInt ID_PARAM_OUTER_DENS = 11;
constexpr gpaUInt ID_PARAM_OUTER_VISCOS = 12;
constexpr gpaUInt ID_PARAM_OUTER_COPACITY = 13;
constexpr gpaUInt ID_PARAM_THERM_COPACITY = 14;
constexpr gpaUInt ID_PARAM_OUTER_VELOCITY = 15;
constexpr gpaUInt ID_PARAM_OUTER_THERM = 16;
constexpr gpaUInt ID_PARAM_N_TEN = 17;
constexpr gpaUInt ID_PARAM_COEFF_TEN = 18;
constexpr gpaUInt ID_PARAM_COEFF_HYDOR = 19;
constexpr gpaUInt ID_PARAM_COEFF_EPS = 20;

const gpaString gpaVaporator::m_typeName = "vaporator";
const gpaString gpaVaporator::m_description = "Аппарат испаритель";

const gpaParameterInfoVector gpaVaporator::m_parameters = {
    realParam("vaporator-power", "Мощность электрического нагревателя.",
              GPA_HEAT_RATE_UNIT, false, 520000),
    realParam("pipe-length", "Длина трубы", GPA_LENGTH_UNIT, false, 4.0),
    realParam("heat-coeff", "Параметр теплоотадчи ТЭНа в технологическую среду",
              GPA_HEATTRANS_COEF_UNIT, false, 1.0),
    realParam("inner-diam", "Диаметр труб ТЭНа", GPA_LENGTH_UNIT, false,
              0.022),
    realParam("outer-height", "Высота между патрубками", GPA_LENGTH_UNIT,
              false, 0.026),
    realParam("wall-diamet1", "Толщина слоя изоляции 1", GPA_LENGTH_UNIT,
              false, 0.2476),
    realParam("wall-diamet2", "Толщина слоя изоляции 2", GPA_LENGTH_UNIT,
              false, 0.273),
    realParam("wall-diamet3", "Толщина слоя изоляции 3", GPA_LENGTH_UNIT,
              false, 0.373),
    realParam("wall-thermal1", "Коэффициент тепловроводности внутренней стенки",
              GPA_CONDUCTIVITY_UNIT, false, 60),
    realParam("wall-thermal2", "Коэффициент тепловроводности изоляции",
              GPA_CONDUCTIVITY_UNIT, false, 1),
    realParam("heat-expansion",
              "Коэффициент теплового расширения окружающей среды",
              GPA_DIMLESS_UNIT, false, 3.4e-3),
    realParam("outer-dens", "Плотность окружающей среды", GPA_DIMLESS_UNIT,
              false, 1.225),
    realParam("outer-viscos", "Динамическая вязкость окружающей среды",
              GPA_DIMLESS_UNIT, false, 1.81e-5),
    realParam("outer-copacity", "Теплоемкость окружающей среды",
              GPA_HEATTRANS_COEF_UNIT, false, 1.005),
    realParam("therm-copacity", "Теплопроводность окружающей среды",
              GPA_HEAT_CAPACITY_UNIT, false, 0.0257),
    realParam("outer-velocity", "Скорость движения окружающей среды",
              GPA_VELOCITY_UNIT, false, 1),
    realParam("outer-therm", "Температура окружающей среды",
              GPA_TEMPERATURE_UNIT, false, 20),
    realParam("n-ten", "Колличество трубок тена", GPA_LENGTH_UNIT, false, 4),
    realParam("coeff-ten", "Коэффицинет управления мощьностью тена",
              GPA_DIMLESS_UNIT, true, 1),
    realParam("coeff-hydro", "Коэффицинет гидравлических потерь",
              GPA_DIMLESS_UNIT, false, 1),
    realParam("rough-coef", "Коэффициент шероховатости труб", GPA_DIMLESS_UNIT,
              false, 1.13),
};

const gpaSensorInfoVector gpaVaporator::m_sensors = {
    scalarSensor("air-out-temp", "Перепад давления в аппарате",
                 GPA_PRES_DIFFER_UNIT),
    scalarSensor("air-delta-temp", "Перепад температуры в аппарате",
                 GPA_TEMP_DIFFER_UNIT),
    scalarSensor("mix-delta-temp-1", "Средняя температура тена зон 1",
                 GPA_TEMPERATURE_UNIT),
    scalarSensor("mix-delta-temp-2", "Средняя температура тена зон 2",
                 GPA_TEMPERATURE_UNIT),
    scalarSensor("mix-delta-temp-3", "Средняя температура тена зон 3",
                 GPA_TEMPERATURE_UNIT),
    scalarSensor("zone-length-1", "Длины зон нагрева жидкости",
                 GPA_LENGTH_UNIT),
    scalarSensor("zone-length-2", "Длины зон кипения", GPA_LENGTH_UNIT),
    scalarSensor("zone-length-3", "Длины зон нагрева нагрева газа",
                 GPA_LENGTH_UNIT),
    scalarSensor("zone-medium-temp-1", "Температура среды 1",
                 GPA_TEMPERATURE_UNIT),
    scalarSensor("zone-medium-temp-2", "Температура среды 2",
                 GPA_TEMPERATURE_UNIT),
    scalarSensor("zone-medium-temp-3", "Температура среды 3",
                 GPA_TEMPERATURE_UNIT),
};

gpaVaporator::gpaVaporator(const gpaCoreInterfaces *interfaces,
                           gpaCoreReference importRef)
    : gpaExportSystem(interfaces, importRef), m_air(), m_heatPipes(asParent()),
      m_pipesGeom(NULL), m_frictionModel(NULL), m_heatCoef(NULL),
      m_airFlow(asParent()), m_convection(asParent()), m_inletRate(NULL),
      m_inletTemp(NULL), m_airInlet(asParent()), m_airOutlet(asParent()),
      m_airInletStr(asParent()), m_airOutletStr(asParent()), m_fan(asOwner()),
      m_blinds(asOwner()) {}
const gpaStringVector gpaVaporator::m_circuitNames = {"Контур  продукта"};

const gpaStringVector gpaVaporator::m_portNames = {
    "Вход нагреваемого  продукта", "Выход нагреваемого продукта"};

gpaUInt gpaVaporator::getDeviceNumMixCircuits() { return NUM_CIRCUITS; }

gpaUInt gpaVaporator::getDeviceMinNumMixPorts(gpaUInt index) {
  return index < NUM_CIRCUITS ? NUM_PORTS : 0;
}

gpaUInt gpaVaporator::getDeviceMaxNumMixPorts(gpaUInt index) {
  return index < NUM_CIRCUITS ? NUM_PORTS : 0;
}

gpaResult gpaVaporator::checkParamValues(const gpaExtParameter *) const {
  return GPA_RESULT_OK;
}

void gpaVaporator::setNames() {
  m_heatPipes.setName("pipes");
  m_airFlow.setName("airflow");
  m_convection.setName("convect");
  m_airInlet.setName("air-in");
  m_airOutlet.setName("air-out");
  m_airInletStr.setName("air-istr");
  m_airOutletStr.setName("air-ostr");
}

gpaResult gpaVaporator::initMixtureFlow(const gpaExtParameter *values) {
  // Назначаем параметры проточных элементов
  bool good = true;
  // m_pipesGeom = new gpaFixedGeometry(asOwner());
  m_pipesGeom = new gpaUPipesGeometry(asOwner());

  m_frictionModel = new gpaFrictionExponential(asOwner());
  m_heatCoef = new gpaPowerHeatCoef(asOwner());
  m_heatCoef->setPipeCoefficients();

  m_frictionModel->setGeometry(m_pipesGeom);
  good &= m_pipesGeom->setDiameters(
      values[ID_PARAM_WALL_DIAMETR1].value.realValue,
      values[ID_PARAM_WALL_DIAMETR2].value.realValue);
  good &= m_frictionModel->setCorrector(1.13);
  good &= m_frictionModel->setAlphaFrictionCoef(0.38);
  good &= m_frictionModel->setBetaFrictionCoef(-0.25);
  //
  // good &= m_pipesGeom->setNumPipes(43);
  // good &= m_pipesGeom->setNumStrokes(3);
  // good &= m_pipesGeom->setCoef(10);

  //  good &=
  //  m_heatCoef->setCorrectionCoef(values[ID_PARAM_EPS_E].value.realValue);
  //
  good &=
      m_heatPipes.setLength(values[ID_PARAM_PIPE_LENGTH].value.realValue);
  good &=
      m_heatPipes.setPower(values[ID_PARAM_VAPORATOR_POW].value.realValue);
  good &=
      m_heatPipes.setPowerCoeff(values[ID_PARAM_COEFF_TEN].value.realValue);
  good &= m_heatPipes.setAlphaCoef(values[ID_PARAM_ALPHA].value.realValue);

  gpaHeatCoeffPrm *hc1 = new gpaHeatCoeffPrm(
      values[ID_PARAM_INNER_DIAM].value.realValue,
      values[ID_PARAM_PIPE_LENGTH].value.realValue,
      values[ID_PARAM_HEAT_EXPANSION].value.realValue, gpaReal(273.0),
      values[ID_PARAM_OUTER_THERM].value.realValue,
      values[ID_PARAM_OUTER_DENS].value.realValue,
      values[ID_PARAM_OUTER_VISCOS].value.realValue,
      values[ID_PARAM_OUTER_COPACITY].value.realValue, 1, 1, false);

  gpaHeatCoeffPrm hc2(
      values[ID_PARAM_INNER_DIAM].value.realValue,
      values[ID_PARAM_PIPE_LENGTH].value.realValue,
      values[ID_PARAM_HEAT_EXPANSION].value.realValue, gpaReal(273.0),
      values[ID_PARAM_OUTER_THERM].value.realValue,
      values[ID_PARAM_OUTER_DENS].value.realValue,
      values[ID_PARAM_OUTER_VISCOS].value.realValue,
      values[ID_PARAM_OUTER_COPACITY].value.realValue,
      values[ID_PARAM_THERM_COPACITY].value.realValue,
      values[ID_PARAM_OUTER_VELOCITY].value.realValue, false);
  m_heatPipes.m_heatCoef1 = hc1;
  m_heatPipes.m_heatCoef2 = &hc2;

  if (!good)
    return GPA_ERROR_WRONG_ARGS;
  m_heatPipes.setGeometry(m_pipesGeom);
  m_heatPipes.setFriction(m_frictionModel);
  m_heatPipes.setHeatCoefficient(m_heatCoef);
  m_heatPipes.setDeltaLevel(values[ID_PARAM_HEIGHT].value.realValue);
  m_heatPipes.m_wall_conductive1 =
      values[ID_PARAM_WALL_THERMAL1].value.realValue;
  m_heatPipes.m_wall_conductive2 =
      values[ID_PARAM_WALL_THERMAL2].value.realValue;
  // m_heatPipes.m_wall_conductive3 =
  // values[ID_PARAM_WALL_THERMAL3].value.realValue;
  m_heatPipes.m_wall_diamet1 =
      values[ID_PARAM_WALL_DIAMETR1].value.realValue;
  m_heatPipes.m_wall_diamet2 =
      values[ID_PARAM_WALL_DIAMETR2].value.realValue;
  m_heatPipes.m_wall_diamet3 =
      values[ID_PARAM_WALL_DIAMETR3].value.realValue;
  m_heatPipes.m_hydro_coeff = values[ID_PARAM_COEFF_HYDOR].value.realValue;

  gpaReal S =
      std::numbers::pi *
      (vmPower(values[ID_PARAM_WALL_DIAMETR1].value.realValue / 2, 2) -
       values[ID_PARAM_N_TEN].value.realValue *
           vmPower(values[ID_PARAM_INNER_DIAM].value.realValue / 2, 2));
  gpaReal diamter = 2 * vmSqrt(S / std::numbers::pi);

  m_heatPipes.m_diametr = diamter;
  m_heatPipes.m_eps = values[ID_PARAM_COEFF_EPS].value.realValue;
  return GPA_RESULT_OK;
}

gpaResult gpaVaporator::initAirFlow(const gpaExtParameter *values) {
  // Задаем параметры потока воздуха
  bool good = true;
  //    good &=
  //    m_airFlow.setArea(values[ID_PARAM_AIR_AREA].value.realValue); good
  //    &=
  //    m_airFlow.setLengthScale(values[ID_PARAM_AIR_LIN_DIM].value.realValue);
  //    good &=
  //    m_airFlow.setNarrowingCoef(values[ID_PARAM_NARROW_COEF].value.realValue);
  //    if (!good)
  //       return GPA_ERROR_WRONG_ARGS;
  // Создаем составляющие граничных условий для воздуха
  m_inletRate = new gpaVolumeRateCondition(asOwner());
  m_inletTemp = new gpaTemperatureCondition(asOwner());
  gpaMolarMixtureCondition *inletMolar =
      new gpaMolarMixtureCondition(asOwner());
  gpaPressureCondition *outletPres = new gpaPressureCondition(asOwner());
  gpaTemperatureCondition *outletTemp = new gpaTemperatureCondition(asOwner());
  gpaMolarMixtureCondition *outletMolar =
      new gpaMolarMixtureCondition(asOwner());
  // Назначаем составляющие граничных условий для воздуха
  //    m_airInlet.setHydraulicCondition(m_inletRate);
  //    m_airInlet.setThermalCondition(m_inletTemp);
  //    m_airInlet.setCompositionCondition(inletMolar);
  //    m_airOutlet.setHydraulicCondition(outletPres);
  //    m_airOutlet.setThermalCondition(outletTemp);
  //    m_airOutlet.setCompositionCondition(outletMolar);
  gpaDataVector airFractions(1);
  airFractions[0] = 1.0;
  good &= inletMolar->setMolarFractions(airFractions);
  good &= outletMolar->setMolarFractions(airFractions);
  if (!good)
    return GPA_ERROR_WRONG_ARGS;
  // Устанавливаем ориентацию на входе и давление на выходе
  good &= m_inletRate->setOrientation(GPA_STREAM_INLET);
  good &= outletPres->setPressure(GPA_ATMOSPHERIC_PRESSURE);
  if (!good)
    return GPA_ERROR_WRONG_ARGS;
  return GPA_RESULT_OK;
}

gpaResult gpaVaporator::initHeatTransfer(const gpaExtParameter *values) {
  // Задаем параметры теплообмена
  bool good = true;
  // gpaReal innerDiam = values[ID_PARAM_INNER_DIAM].value.realValue;
  // gpaReal outerDiam = values[ID_PARAM_OUTER_DIAM].value.realValue;
  good &= m_convection.setCounterFlow(true);
  //   good &=
  //   m_convection.setConvectionHeatLossCoef(values[ID_PARAM_LOSS_COEF].value.realValue);

  gpaLogMeanTempDifference *tempDiff = new gpaLogMeanTempDifference();
  //    good &=
  //    tempDiff->setTempDifCoef(values[ID_PARAM_EPS_DT].value.realValue);
  m_convection.setConvTempDiff(tempDiff);
  m_convection.setRadiation(new gpaZeroRadiation());

  gpaThinWall *wall = new gpaThinWall();
  // good &=
  // wall->setFinningFactor(values[ID_PARAM_FIN_FACTOR].value.realValue *
  // outerDiam / innerDiam);
  // good &=
  // wall->calcPipeHeatCoef(values[ID_PARAM_PIPE_CONDUCT].value.realValue,
  // innerDiam, outerDiam);
  m_convection.setWallModel(wall);

  if (!good)
    return GPA_ERROR_WRONG_ARGS;
  return GPA_RESULT_OK;
}

gpaResult gpaVaporator::setParamValues(const gpaExtParameter *values,
                                       bool checkNeeded) {
  // Проверка параметров, если требуется
  if (checkNeeded) {
    gpaResult res = checkParamValues(values);
    if (res != GPA_RESULT_OK)
      return res;
  }
  // Даем названия элементам и потокам
  setNames();
  // Инициализируются элементы с потоком смеси
  gpaResult res = initMixtureFlow(values);
  if (res != GPA_RESULT_OK)
    return res;
  // Инициализируются элементы с потоком воздуха
  res = initAirFlow(values);
  if (res != GPA_RESULT_OK)
    return res;
  // Инициализируются элементы теплопередачи
  res = initHeatTransfer(values);
  if (res != GPA_RESULT_OK)
    return res;
  // Инициализируются устройства управления потоком воздуха
  if (res != GPA_RESULT_OK)
    return res;
  // Обновляем параметры воздуха на входе
  return res; // updateAirInlet();
}

gpaResult gpaVaporator::buildDevice() {
  bool good = true;
  // Соединяем поток смеси по трубам с граничными потоками смеси системы
  good =
      good && m_heatPipes.connectCircuitStream(
                  GPA_FLOW_INLET, getEdgeMixStream(ID_CIRCUIT, ID_PORT_INLET),
                  GPA_STREAM_OUTLET);
  good = good &&
         m_heatPipes.connectMixStream(
             GPA_ELEM_CIRCUIT_0, GPA_FLOW_OUTLET,
             getEdgeMixStream(ID_CIRCUIT, ID_PORT_OUTLET), GPA_STREAM_INLET);
  // Соединяем граничные условия с соответствующими потоками воздуха
  //   good = good && m_airInlet.connectMixStream(GPA_ELEM_CIRCUIT_0,
  //   GPA_BOUNDARY_PORT, &m_airInletStr, GPA_STREAM_INLET); good = good &&
  //   m_airOutlet.connectMixStream(GPA_ELEM_CIRCUIT_0, GPA_BOUNDARY_PORT,
  //   &m_airOutletStr, GPA_STREAM_OUTLET);
  // Соединяем поток воздуха снаружи труб с соответствующими потоками воздуха
  //   good = good && m_airFlow.connectMixStream(GPA_ELEM_CIRCUIT_0,
  //   GPA_FLOW_INLET, &m_airInletStr, GPA_STREAM_OUTLET); good = good &&
  //   m_airFlow.connectMixStream(GPA_ELEM_CIRCUIT_0, GPA_FLOW_OUTLET,
  //   &m_airOutletStr, GPA_STREAM_INLET);
  // Устанавливаем теплообмен между потоком воздуха снаружи труб и потоком смеси
  // по трубам
  //////// good = good && m_heatPipes.connectHeatStream(0, &m_convection,
  /// GPA_STREAM_INLET); /good = good && m_airFlow.connectHeatStream(0,
  ///&m_convection, GPA_STREAM_OUTLET);
  if (!good)
    return GPA_ERROR_WRONG_ARGS;
  // Добавляем в систему все элементы и потоки
  setElements({&m_heatPipes});
  setStreams({});
  return GPA_RESULT_OK;
}

gpaResult gpaVaporator::initialize() {
  // Подключить экспортируемый элемент к потокам в интеграторе
  gpaResult res = linkToCoreStreams();
  if (res != GPA_RESULT_OK)
    return res;
  // Соединяем все элементы друг с другом
  res = buildDevice();
  if (res != GPA_RESULT_OK)
    return res;
  // Создаем схемы течений (нужны соединенные элементы)
  if (!createSimStructures({}, {getOuterEntrance(ID_CIRCUIT, ID_PORT_INLET)}))
    return GPA_ERROR_WRONG_ARGS;
  // Инициализируем систему
  return gpaExportSystem::initialize();
}

gpaResult gpaVaporator::updateAirInlet() {
  // Назначаем параметры входного потока воздуха
  bool good = true;
  // good &= m_inletTemp->setTemperature(m_blinds.calcInletTemperature());
  // good &= m_inletRate->setVolumeRate(m_fan.calcAirVolumeRate());
  // if (!good)
  //     return GPA_ERROR_WRONG_ARGS;
  gpaDataVector fractions = {1.0};
  return m_air.calcFlashPT(GPA_ATMOSPHERIC_PRESSURE,
                           m_inletTemp->getTemperature(), fractions);
}

gpaResult gpaVaporator::setSignals(const gpaConstVector &signals) {
  gpaReal value;
  bool good = true;

  if (getSignalValue(signals, ID_PARAM_COEFF_TEN, value))
    good &= m_heatPipes.setPowerCoeff(value);
  return updateAirInlet();
}

gpaResult gpaVaporator::calcSensors(gpaVector &sensors) const {
  setSensorValue(
      sensors, ID_SENSOR_AIR_OUT_TEMP,
      getMixPort(ID_CIRCUIT, ID_PORT_INLET)->getStreamPressure() -
          getMixPort(ID_CIRCUIT, ID_PORT_OUTLET)->getStreamPressure());
  setSensorValue(
      sensors, ID_SENSOR_MIX_DELTA_TEMP,
      getMixPort(ID_CIRCUIT, ID_PORT_OUTLET)->getStreamTemperature() -
          getMixPort(ID_CIRCUIT, ID_PORT_INLET)->getStreamTemperature());
  setSensorValue(sensors, ID_SENSOR_LENGTH1, m_heatPipes.getLength1());
  setSensorValue(sensors, ID_SENSOR_LENGTH2, m_heatPipes.getLength2());
  setSensorValue(sensors, ID_SENSOR_LENGTH3, m_heatPipes.getLength3());

  setSensorValue(sensors, ID_SENSOR_TEMPERATURE_TEN1, m_heatPipes.t1);
  setSensorValue(sensors, ID_SENSOR_TEMPERATURE_TEN2, m_heatPipes.t2);
  setSensorValue(sensors, ID_SENSOR_TEMPERATURE_TEN3, m_heatPipes.t3);

  setSensorValue(sensors, ID_SENSOR_TEMPERATURE_M1,
                 m_heatPipes.getTempMedium1());
  setSensorValue(sensors, ID_SENSOR_TEMPERATURE_M2,
                 m_heatPipes.getTempMedium2());
  setSensorValue(sensors, ID_SENSOR_TEMPERATURE_M3,
                 m_heatPipes.getTempMedium3());
  return GPA_RESULT_OK;
}
const gpaString *gpaVaporator::getDeviceMixCircuitName(gpaUInt index) {
  return index < NUM_CIRCUITS ? &m_circuitNames[index] : NULL;
}

const gpaString *gpaVaporator::getDeviceMixPortName(gpaUInt circIdx,
                                                    gpaUInt portIdx) {
  if (circIdx == ID_CIRCUIT)
    return portIdx < NUM_PORTS ? &m_portNames[portIdx] : NULL;
  return NULL;
}
