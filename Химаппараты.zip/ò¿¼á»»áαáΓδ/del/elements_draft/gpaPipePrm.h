/*!
 *  \file      gpaPipePrm.h
 *  \brief     Класс, описывающий течение по трубе
 *  \author    Фролов Алексей
 *  \date      2024
 */
#ifndef GPA_VAPORATOR_PIPE_H
#define GPA_VAPORATOR_PIPE_H

#include "gpaInclude.h"
#include "gpaLongFlow.h"
#include "gpaPipeFriction.h"
#include "gpaPipesGeometry.h"
#include "gpaFlowHeatCoef.h"

/*!
 * \class gpaPipePrm
 * \brief Класс, реализующий течение по трубе
 */
class gpaPipePrm : public gpaLongFlow
{
public:
    /*!
     * Конструктор по умолчанию
     * \param link ссылки на родительские контейнеры
     */
    gpaPipePrm(const gpaParentLink* link = NULL);
    /*!
     * Конструктор копирования
     * \param pipe труба для копирования
     */
    gpaPipePrm(const gpaPipePrm& pipe);
    /*!
     * Деструктор по умолчанию
     */
    virtual ~gpaPipePrm() override;
    /*!
     * Функция копирования трубы
     * \return скопированная труба
     */
    virtual gpaPipePrm* copy() const override;
    /*!
     * Получить название типа элемента
     * \return название типа элемента
     */
    virtual const gpaString& getTypeName() const override { return getDeviceTypeName(); }
    /*!
     * Получить описание элемента
     * \return описание элемента
     */
    virtual const gpaString& getDescription() const override { return getDeviceDescription(); }
    /*!
     * Получить значение длины
     * \return значение длины
     */
    gpaReal getLength() const { return m_length; }
    /*!
     * Получить модель геометрии
     * \return модель геометрии
     */
    gpaPipesGeometry* getGeometry() const { return m_geometry; }
    /*!
     * Получить модель сопротивления
     * \return модель сопротивления
     */
    gpaPipeFriction* getFriction() const { return m_friction; }
    /*!
     * Получить модель коэффициента теплопередачи
     * \return модель коэффициента теплопередачи
     */
    gpaFlowHeatCoef* getHeatCoefficient() const { return m_heatCoef; }
    /*!
     * Получить значение диаметра
     * \return значение диаметра
     */
    gpaReal getDiameter() const;
    /*!
     * Получить значение объема
     * \return значение объема
     */
    gpaReal getVolume() const;
    /*!
     * Получить флаг наличия площади теплопередачи
     * \return флаг наличия площади теплопередачи
     */
    virtual bool hasHeatArea() const override { return true; }
    /*!
     * Получить значение площади теплопередачи
     * \return значение площади теплопередачи
     */
    virtual gpaReal getHeatArea() const override;
    /*!
     * Получить значение площади поперечного сечения
     * \return значение площади поперечного сечения
     */
    virtual gpaReal getCrossArea() const override;
    /*!
     * Задать значение длины
     * \param length значение длины
     * \return флаг успеха назначения параметра
     */
    bool setLength(gpaReal length);
    bool setPower(gpaReal power);
    bool setAlphaCoef(gpaReal length);
    /*!
     * Задать опдмодель геометрии
     * \param geometry модель геометрии
     */
    void setGeometry(gpaPipesGeometry* geometry);
    /*!
     * Задать модель сопротивления
     * \param fricModel модель сопротивления
     */
    void setFriction(gpaPipeFriction* friction);
    /*!
     * Задать модель коэффициента теплопередачи
     * \param heatCoef модель коэффициента теплопередачи
     */
    void setHeatCoefficient(gpaFlowHeatCoef* heatCoef);
    /*!
     * Получить значение коэффициента теплопередачи [Вт/(м^2*K)]
     * \return значение коэффициента теплопередачи [Вт/(м^2*K)]
     */
    virtual gpaReal getHeatTransferCoef() const override;
    virtual gpaReal getTenHeatTransferCoef() const ;
    /*!
     * Инициализация расчета
     * \return код операции
     */
    virtual gpaResult initialize() override;
    virtual gpaUInt getNumVariables() const override {return 4;};
    void setLength1(gpaReal l){m_length1=l;};
    void setLength2(gpaReal l){m_length2=l;};
    void setLength3(gpaReal l){m_length3=l;};

    gpaReal getLength1() const {return m_length1;};
    gpaReal getLength2() const {return m_length2;};
    gpaReal getLength3() const {return m_length3;};



protected:
    /*!
     * Функция для определения невязки уравнения трения
     * \param deltaPres перепад давления
     * \param rate мольный расход
     * \return невязка уравнения трения
     */
    virtual gpaReal calcFrictionFunc(gpaReal deltaPres, gpaReal rate) const override;
    /*!
     * Вычислить коэффициент теплового трения
     * \return коэффициент теплового трения
     */
    gpaReal calcHeatFricCoef() const;


protected:
    /*!
     * Функция получения вектора с названиями подмоделей элемента
     * \return вектор с названиями подмоделей элемента
     */
    virtual const gpaModelNameInfoVector* getModelNames() const override { return &getSubModelNames(); }
    /*!
     * Функция получения подмодели по индексу
     * \param index индекс подмодели
     * \return подмодель
     */
    virtual gpaSubModel* getSubModel(gpaUInt index) const override;

private:
    //! Длина
    gpaReal                 m_length;
    gpaReal                 m_power;
    gpaReal                 m_alphaCoef;
    //! Модель геометрии
    gpaPipesGeometry*       m_geometry;
    //! Модель сопротивления
    gpaPipeFriction*        m_friction;
    //! Модель коэффициента теплопередачи
    gpaFlowHeatCoef*        m_heatCoef;

    gpaMedium*              m_medium_1;
    gpaMedium*              m_medium_2;
    gpaMedium*              m_medium_3;

    gpaReal                 m_length1;
    gpaReal                 m_length2;
    gpaReal                 m_length3;

    /*!
     * Проверить значения параметров
     * \param length новое значение длины
     * \return флаг успешности проверки
     */
    bool checkParameterValues(gpaReal length) const;
    /*!
     * Назначить значения парметров подмодели
     * \param length новое значение длины
     * \param checkNeeded флаг о необходимости проверить параметры
     * \return флаг успешности операции
     */
    bool setParameterValues(gpaReal length, bool checkNeeded = true);
    /*!
     * Очистить модель геометрию
     */
    void clearGeometry();
    /*!
     * Очистить модель сопротивления
     */
    void clearFriction();
    /*!
     * Очистить модель коэффициента теплопередачи
     */
    void clearHeatCoef();

public:
    /*!
     * Получить название типа элемента
     * \return название типа элемента
     */
    static const gpaString& getDeviceTypeName() { return m_typeName; }
    /*!
     * Получить описание элемента
     * \return описание элемента
     */
    static const gpaString& getDeviceDescription() { return m_description; }
    /*!
     * Получить вектор описаний параметров элемента
     * \return вектор описаний параметров элемента
     */
    static const gpaModelNameInfoVector& getSubModelNames() { return m_modelNames; }
    /*!
     * Получить вектор описаний параметров элемента
     * \return вектор описаний параметров элемента
     */
    static const gpaParameterInfoVector* getParametersInfo() { return &m_parameters; }
    gpaMixPort* connectCircuitStream(gpaUInt  	index, gpaMixStream *  	stream, gpaReal  	orientation );

    gpaReal                 m_ten_diametr;
    gpaReal                 m_pip_diametr;
    gpaReal                 m_wall_diamet1;
    gpaReal                 m_wall_diamet2;
    gpaReal                 m_wall_diamet3;
    gpaReal                 m_wall_conductive1;
    gpaReal                 m_wall_conductive2;
    gpaReal                 m_wall_conductive3;
    
    gpaReal                 m_outer_dens;
    gpaReal                 outer_viscos;
    gpaReal                 outer_copacity;
    gpaReal                 therm_copacity;
    gpaReal                 outer_velocity;
    gpaReal                 outer_therm;   
    gpaReal t1;
    gpaReal t2;
    gpaReal t3;


protected:
    /*!
     * Функция получения вектора с описаниями параметров элемента
     * \return вектор с описаниями параметров элемента
     */
    virtual const gpaParameterInfoVector* getParamsInfo() const override { return getParametersInfo(); }
    /*!
     * Функция проверки значений параметров элемента
     * \param values вектор параметров элемента
     * \return код операции
     */
    virtual gpaResult checkParamValues(const gpaExtParameter* values) const override;
    /*!
     * Функция назначения параметров элемента
     * \param values вектор параметров элемента
     * \param checkNeeded флаг о необходимости проверить параметры
     * \return код операции
     */
    virtual gpaResult setParamValues(const gpaExtParameter* values, bool checkNeeded = true) override;

    virtual gpaResult calcFuncValues(const gpaConstVector& states, const gpaConstVector& variables, gpaVector& values) override;

    virtual gpaResult calcEnthalpyFuncValueAt(gpaUInt circIdx, gpaUInt portIdx, gpaReal enthalpy, gpaReal& funcValue) const override;

    virtual gpaResult initVariables(gpaVector& variables) const override;

private:
    //! Название элемента
    static const gpaString                  m_typeName;
    //! Описание элемента
    static const gpaString                  m_description;
    //! Вектор названий подмоделей элемента
    static const gpaModelNameInfoVector     m_modelNames;
    //! Вектор описаний параметров элемента
    static const gpaParameterInfoVector     m_parameters;
};

#endif
