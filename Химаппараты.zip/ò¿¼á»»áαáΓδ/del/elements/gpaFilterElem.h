/*!
 *  \file      gpaFilterElem.h
 *  \brief     Класс для описания однослойного объемного элемента
 *  \author    Мельников Роман
 *  \date      2025
 */
#ifndef GPA_FILTER_ELEM_H
#define GPA_FILTER_ELEM_H

#include "gpaCircuitElement.h"
#include "gpaInclude.h"
#include "gpaMedium.h"
#include "heatTransferModel.h"
#include <memory>

/*!
 * \class gpaFilterElem
 * \brief Класс, реализующий однослойный объемный элемента
 */
class gpaFilterElem : public gpaCircuitElement {
public:
  /*!
   * Конструктор по умолчанию
   * \param link ссылки на родительские контейнеры
   */
  gpaFilterElem(const gpaParentLink *link = NULL);
  /*!
   * Конструктор копирования
   * \param volume объемный элемент для копирования
   */
  gpaFilterElem(const gpaFilterElem &volume);
  /*!
   * Деструктор по умолчанию
   */
  virtual ~gpaFilterElem() override;
  /*!
   * Функция копирования объемного элемента
   * \return скопированный объемный элемент
   */
  virtual gpaFilterElem *copy() const override;
  bool setFilterParameter(gpaReal length, gpaReal radius, gpaReal num_elem,
                             gpaReal diameter, gpaReal porosity,
                             gpaReal lambda);
  bool setHeatTransferModel(std::unique_ptr<LMTDHeatTransfer> model);
  gpaReal getPermeabilityCoef() const;
  gpaReal getHeatRate() const;
  /*!
   * Получить название типа элемента
   * \return название типа элемента
   */
  virtual const gpaString &getTypeName() const override {
    return getDeviceTypeName();
  }
  /*!
   * Получить описание элемента
   * \return описание элемента
   */
  virtual const gpaString &getDescription() const override {
    return getDeviceDescription();
  }
  /*!
   * Функция получения минимального количества портов в материальном контуре
   * элемента
   * \param index индекс контура
   * \return минимальное количество портов
   */
  virtual gpaUInt getMinNumMixPorts(gpaUInt index) const override;
  /*!
   * Функция получения максимального количества портов в материальном контуре
   * элемента
   * \param index индекс контура
   * \return максимальное количество портов
   */
  virtual gpaUInt getMaxNumMixPorts(gpaUInt index) const override;
  /*!
   * Получить значение размерности
   * \return значение размерности
   */
  virtual gpaUInt getNumVariables() const override;
  /*!
   * Заполнить названия неизвестных
   * \param [out] varNames названия неизвестных
   */
  virtual void fillVarNames(gpaStringVector &varNames) const override;
  /*!
   * Инициализировать камеру и ее параметры для расчета
   * \return код операции
   */
  virtual gpaResult initialize() override;
  /*!
   * Заполнить матрицу масс камеры
   * \param refRow первая строка подматрицы
   * \param refCol первый столбец подматрицы
   * \return код ошибки
   */
  virtual gpaResult fillMassMatrix(gpaUInt refRow,
                                   gpaUInt refCol) const override;
  /*!
   * Инициализировать решение заданным вектором
   * \param [out] variables вектор неизвестных
   * \return код ошибки
   */
  virtual gpaResult initVariables(gpaVector &variables) const override;
  /*!
   * Рассчитать значения функций правых частей
   * \param [in] states вектор состояний
   * \param [in] variables вектор неизвестных
   * \param [out] values вектор значений функций правых частей
   * \return код операции
   */
  virtual gpaResult calcFuncValues(const gpaConstVector &states,
                                   const gpaConstVector &variables,
                                   gpaVector &values,
                                   const gpaSetOfEquations &eqIds) override;
  /*!
   * Получить невязку уравнения для удельной мольной энтальпии для заданного
   * порта материального потока
   * \param circIdx индекс материального контура
   * \param portIdx индекс порта материального потока
   * \param enthalpy текущее значение энтальпии (относительно которого требуется
   * невязка)
   * \param [out] funcValue значение невязки уравнения для удельной мольной
   * энтальпии для заданного порта материального потока
   * \param код операции
   */
  virtual gpaResult calcEnthalpyFuncValueAt(gpaUInt circIdx, gpaUInt portIdx,
                                            gpaReal enthalpy,
                                            gpaReal &funcValue) const override;
  /*!
   * Получить невязки уравнений для мольных долей компонентов смеси для
   * заданного порта материального потока
   * \param circIdx индекс материального контура
   * \param portIdx индекс порта материального потока
   * \param fractions текущие значения мольных долей компонентов (относительно
   * которых требуется невязка)
   * \param [out] funcValues вектор невязок уравнений для мольных долей
   * компонентов смеси для заданного порта материального потока
   * \param код операции
   */
  virtual gpaResult
  calcFractionsFuncValuesAt(gpaUInt circIdx, gpaUInt portIdx,
                            const gpaConstVector &fractions,
                            gpaVector &funcValues) const override;

private:
  // Properties
  gpaMedium *m_medium;
  std::unique_ptr<LMTDHeatTransfer> m_modelHT;
  gpaReal m_lambda;
  gpaReal m_numElements;
  gpaReal m_Q;
  gpaReal m_R;
  gpaReal m_k0;
  gpaReal m_kp;
  gpaReal m_porosity;
  gpaReal m_length;
  gpaReal m_filterRadius;
  gpaReal m_elementsDiameter;
  gpaReal m_S;

public:
  /*!
   * Получить название типа элемента
   * \return название типа элемента
   */
  static const gpaString &getDeviceTypeName() { return m_typeName; }
  /*!
   * Получить описание элемента
   * \return описание элемента
   */
  static const gpaString &getDeviceDescription() { return m_description; }

private:
  //! Название элемента
  static const gpaString m_typeName;
  //! Описание элемента
  static const gpaString m_description;
};

#endif
