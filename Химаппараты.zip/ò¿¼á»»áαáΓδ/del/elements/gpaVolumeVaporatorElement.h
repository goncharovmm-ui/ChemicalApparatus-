/*!
 *  \file      gpaVolumeVaporatorElement.h
 *  \brief     Класс для описания однослойного объемного элемента
 *  \author    Фролов Алексей
 *  \date      2024
 */
#ifndef GPA_VOlUME_VAPARATOR_ELEMENT_H
#define GPA_VOlUME_VAPARATOR_ELEMENT_H

#include "gpaDefinitions.h"
#include "gpaHeatLayer.h"
#include "gpaInclude.h"
#include "gpaMedium.h"
#include "gpaVolumeElement.h"

/*!
 * \class gpaVolumeVaporatorElement
 * \brief Класс, реализующий однослойный объемный элемента
 */
class gpaVolumeVaporatorElement : public gpaVolumeElement {
  public:
    /*!
     * Конструктор по умолчанию
     * \param link ссылки на родительские контейнеры
     */
    gpaVolumeVaporatorElement(const gpaParentLink *link = NULL);
    /*!
     * Конструктор копирования
     * \param volume объемный элемент для копирования
     */
    gpaVolumeVaporatorElement(const gpaVolumeVaporatorElement &volume);
    /*!
     * Деструктор по умолчанию
     */
    virtual ~gpaVolumeVaporatorElement() override;
    /*!
     * Функция копирования объемного элемента
     * \return скопированный объемный элемент
     */
    virtual gpaVolumeVaporatorElement *copy() const override;
    /*!
     * Получить название типа элемента
     * \return название типа элемента
     */
    virtual const gpaString &getTypeName() const override {
        return getDeviceTypeName();
    }
    /*!
     * Получить описание элемента
     * \return описание элемента
     */
    virtual const gpaString &getDescription() const override {
        return getDeviceDescription();
    }
    /*!
     * Задать начальное значение давления
     * \param initPressure начальное значение давления
     * \return флаг успеха назначения параметра
     */
    bool setInitPressure(gpaReal initPressure);
    /*!
     * Задать начальную объёмную долю жидкости
     * \param volumeFraction начальное значение объёмной доли жидкости
     * \return флаг успеха назначения параметра
     */
    bool setInitLiqVolumeFraction(gpaReal volumeFraction);
    /*!
     * Задать начальное значение температуры
     * \param initTemperature начальное значение температуры
     * \return флаг успеха назначения параметра
     */
    bool setInitTemperature(gpaReal initTemperature);
    /*!
     * Задать начальные значения мольных долей компонентов смеси
     * \param fractions начальные значения мольных долей компонентов смеси
     * \return флаг успеха назначения параметра
     */
    bool setInitFractions(const gpaConstVector &fractions);

    /*!
     * Задать значение коэффициента теплопередачи к стенке по газу [Вт/(м^2*K)]
     * \param liqHeatTransCoef значение коэффициента теплопередачи к стенке по
     * газу [Вт/(м^2*K)]
     * \return флаг успеха назначения параметра
     */
    bool setLiqHeatTransCoef(gpaReal liqHeatTransCoef);
    /*!
     * Задать значение коэффициента теплопередачи к стенке по жидкости
     * [Вт/(м^2*K)]
     * \param gasHeatTransCoef значение коэффициента теплопередачи к стенке по
     * жидкости [Вт/(м^2*K)]
     * \return флаг успеха назначения параметра
     */
    bool setGasHeatTransCoef(gpaReal gasHeatTransCoef);

    bool setExternalVolume(gpaReal p) {
        m_external_volume = p;
        return true;
    };
    /*!
     * Получить значение давления на определенном уровне [кПа]
     * \param level уровень (высота)
     * \return значение давления на определенном уровне [кПа]
     */
    virtual gpaReal getPressureAt(gpaReal level) const override;
    /*!
     * Получить значение температуры на определенном уровне [К]
     * \param level уровень (высота)
     * \return значение температуры на определенном уровне [К]
     */
    virtual gpaReal getTemperatureAt(gpaReal level) const override;
    /*!
     * Получить значение молярной массы для линейной комбинации равновесных фаз
     * для заданной объемной доли газа [кг/кмоль]
     * \param gasVolumeFraction заданная объемная доля газа в среде
     * \return значение молярной массы для линейной комбинации равновесных фаз
     * для заданной объемной доли газа [кг/кмоль]
     */
    virtual gpaReal getMolarMassFor(gpaReal gasVolumeFraction) const override;
    /*!
     * Получить значение удельной мольной энтальпии для линейной комбинации
     * равновесных фаз для заданной объемной доли газа [кДж/кмоль]
     * \param gasVolumeFraction заданная объемная доля газа в среде
     * \return значение удельной мольной энтальпии для линейной комбинации
     * равновесных фаз для заданной объемной доли газа [кДж/кмоль]
     */
    virtual gpaReal getEnthalpyFor(gpaReal gasVolumeFraction) const override;
    /*!
     * Получить значение плотности для линейной комбинации равновесных фаз для
     * заданной объемной доли газа [кг/м3]
     * \param gasVolumeFraction заданная объемная доля газа в среде
     * \return значение плотности для линейной комбинации равновесных фаз для
     * заданной объемной доли газа [кг/м3]
     */
    virtual gpaReal getDensityFor(gpaReal gasVolumeFraction) const override;
    /*!
     * Получить значение вязкости для линейной комбинации равновесных фаз для
     * заданной объемной доли газа [Па*с]
     * \param gasVolumeFraction заданная объемная доля газа в среде
     * \return значение вязкости для линейной комбинации равновесных фаз для
     * заданной объемной доли газа [Па*с]
     */
    virtual gpaReal getViscosityFor(gpaReal gasVolumeFraction) const override;
    /*!
     * Получить значение коэффициента теплопередачи для жидкости [Вт/(м^2*K)]
     * \return значение коэффициента теплопередачи для жидкости [Вт/(м^2*K)]
     */
    virtual gpaReal getLiquidHeatTransferCoef() const override {
        return m_alpha_in_liq;
    }
    /*!
     * Получить значение коэффициента теплопередачи для газа [Вт/(м^2*K)]
     * \return значение коэффициента теплопередачи для газа [Вт/(м^2*K)]
     */
    virtual gpaReal getGasHeatTransferCoef() const override {
        return m_alpha_in_gas;
    }
    /*!
     * Получить значения мольных долей на выходе
     * \param fractions мольные доли на выходе
     * \param gasVolumeFraction объемная доля газа в смеси
     * \return значение мольных долей на выходе
     */
    virtual void getFractionsFor(gpaDataVector &fractions,
                                 gpaReal gasVolumeFraction) const override;
    /*!
     * Получить значение уровня жидкости
     * \return значение уровня жидкости
     */
    virtual gpaReal getLiquidLevel() const override { return m_liquidLevel; }

    virtual gpaReal getLiquidVolume() const override;

    gpaConstVector getInitFraction() const { return m_fractions; }

    virtual const gpaMedium *getMedium() const { return m_medium; }

    virtual gpaReal getTransitionLevel(gpaReal level,
                                       gpaReal radius) const override;

    virtual gpaReal getTransitionRadius(gpaReal level,
                                        gpaReal radius) const override;

    /*!
     * Получить значение U
     * \return значение U
     */
    gpaReal getMixEnergy() const;
    /*!
     * Получить значение N
     * \return значение N
     */
    gpaReal getMixMoles() const;
    /*!
     * Получить значение CondensationRate
     * \return значение CondensationRate
     */
    gpaReal getCondensationRate() const;
    /*!
     * Получить значение EvaporationRate
     * \return значение EvaporationRate
     */
    gpaReal getEvaporationRate() const;
    /*!
     * Получить значение IncomingGasHeatRate
     * \return значение IncomingGasHeatRate
     */
    gpaReal getIncomingGasHeatRate() const;
    /*!
     * Получить значение LiquidHeatRate
     * \return значение LiquidHeatRate
     */
    gpaReal getIncomingLiquidHeatRate() const;
    /*!
     * Получить значение размерности
     * \return значение размерности
     */
    virtual gpaUInt getNumVariables() const override;
    bool calcLayersProperties();
    /*!
     * Заполнить названия неизвестных
     * \param [out] varNames названия неизвестных
     */
    virtual void fillVarNames(gpaStringVector &varNames) const override;

    /*!
     * Заполнить названия неизвестных
     * \param [out] varNames названия неизвестных
     */
    virtual void fillEquationNames(gpaStringVector &eqNames) const override;
    /*!
     * Инициализировать камеру и ее параметры для расчета
     * \return код операции
     */
    virtual gpaResult initialize() override;
    /*!
     * Заполнить матрицу масс камеры
     * \param refRow первая строка подматрицы
     * \param refCol первый столбец подматрицы
     * \return код ошибки
     */
    virtual gpaResult fillMassMatrix(gpaUInt refRow,
                                     gpaUInt refCol) const override;
    /*!
     * Инициализировать решение заданным вектором
     * \param [out] variables вектор неизвестных
     * \return код ошибки
     */
    virtual gpaResult initVariables(gpaVector &variables) const override;
    /*!
     * Рассчитать значения функций правых частей
     * \param [in] states вектор состояний
     * \param [in] variables вектор неизвестных
     * \param [out] values вектор значений функций правых частей
     * \return код операции
     */
    virtual gpaResult calcFuncValues(const gpaConstVector &states,
                                     const gpaConstVector &variables,
                                     gpaVector &values,
                                     const gpaSetOfEquations &eqIds) override;
    /*!
     * Получить невязку уравнения для удельной мольной энтальпии для заданного
     * порта материального потока
     * \param circIdx индекс материального контура
     * \param portIdx индекс порта материального потока
     * \param enthalpy текущее значение энтальпии (относительно которого
     * требуется невязка)
     * \param [out] funcValue значение невязки уравнения для удельной мольной
     * энтальпии для заданного порта материального потока
     * \param код операции
     */
    // virtual gpaResult calcEnthalpyFuncValueAt(gpaUInt circIdx, gpaUInt
    // portIdx,
    //                                           gpaReal enthalpy,
    //                                           gpaReal &funcValue) const
    //                                           override;
    /*!
     * Получить невязки уравнений для мольных долей компонентов смеси для
     * заданного порта материального потока
     * \param circIdx индекс материального контура
     * \param portIdx индекс порта материального потока
     * \param fractions текущие значения мольных долей компонентов (относительно
     * которых требуется невязка)
     * \param [out] funcValues вектор невязок уравнений для мольных долей
     * компонентов смеси для заданного порта материального потока
     * \param код операции
     */
    // virtual gpaResult
    // calcFractionsFuncValuesAt(gpaUInt circIdx, gpaUInt portIdx,
    //                           const gpaConstVector &fractions,
    //                           gpaVector &funcValues) const override;

    bool setEvaporationTimeConstant(gpaReal tau_kip);

    bool setVaporizationTimeConstant(gpaReal tau_vaporisate);

    bool setEvaporationThreshold(gpaReal eps_N_L);

    bool setWallLayer(gpaHeatLayer layer);

    bool addIsolationLayer(gpaHeatLayer layer);

    bool setGasHeatTransferCoeff(gpaReal alpha_in_gas);

    bool setLiquidHeatTransferCoeff(gpaReal alpha_in_liq);

    bool setMiddleLayerCoeff(gpaReal alpha_m);

    bool setOuterLayerCoeff(gpaReal alpha_out);

    bool setAmbientTemperature(gpaReal T_out);

    bool setHeatTransferParams(gpaReal alpha_in_gas, gpaReal alpha_in_liq);

    bool setQHeater(gpaReal q) {
        m_q_heater_nominal = q;
        m_q_heater = m_q_heater_coeff * m_q_heater_nominal;
        return true;
    };
    bool setQHeaterCoeff(gpaReal q) {
        gpaReal qq = vmMin(q, 1);
        m_q_heater_coeff = vmMax(0, qq);
        m_q_heater = m_q_heater_coeff * m_q_heater_nominal;
        return true;
    };

    gpaReal getLiquidLevelPressure() const { return m_medium->getPressure(); }

  protected:
    /*!
     * Освободить текущую среду
     */
    void finalizeMedium();
    /*!
     * Рассчитать внутренний параметры камеры
     */
    void updateLiquidLevel(gpaReal mixMoles);

    bool aboveLiquidSurface(gpaReal level) const;

  private:
    //! Флаг отсчет гидростатики от крышки
    bool m_topHydroStatic;
    //! Заданная среда
    gpaMedium *m_medium;

    //! Заданная среда 2
    gpaMedium *m_medium2;
    //! Флаг использования флэша по давлению и энтальпии
    bool m_useFlashPH;
    //! Внутренняя энергия
    gpaReal m_mixEnergy;
    //! Количество вещества
    gpaReal m_mixMoles;
    //! теплопоток от стенок
    gpaReal Q_G;
    //! теплопоток от стенок
    gpaReal Q_L;
    //! расход испарения
    gpaReal G_evap;
    //! расход конденсации
    gpaReal G_cond;
    //! Начальное давление
    gpaReal m_initPressure;
    //! Начальная температура
    gpaReal m_initTemperature;
    //! Начальные мольные доли
    gpaDataVector m_fractions;
    //! Уровень жидкости
    gpaReal m_liquidLevel;
    //! Вектор сохраненных неизвестных
    gpaDataVector m_savedVariables;
    //! начальное отношение объёма жидкости к газу
    gpaReal m_initLiqVolumeFraction;

    gpaReal m_tau_evap;       // Evaporation time constant
    gpaReal m_tau_vaporisate; // Vaporization time constant
    gpaReal m_eps_N_L;        // Evaporation threshold
    gpaReal Cm_wall;
    gpaReal Cm_iso;
    gpaHeatLayerVector m_isolationLayers;
    gpaHeatLayer m_wallLayer;
    gpaReal m_A_in;             // Inner heat transfer area
    gpaReal m_alpha_in_gas;     // Gas heat transfer coeff
    gpaReal m_alpha_in_liq;     // Liquid heat transfer coeff
    gpaReal m_A_m;              // Middle layer area
    gpaReal m_alpha_m;          // Middle layer coeff
    gpaReal m_A_out;            // Outer layer area
    gpaReal m_alpha_out;        // Outer layer coeff
    gpaReal m_T_out;            // Ambient temperature
    gpaReal m_external_volume;  // Ambient temperature
    gpaReal m_q_heater;         // Ambient temperature
    gpaReal m_q_heater_coeff;   // Ambient temperature
    gpaReal m_q_heater_nominal; // Ambient temperature

  public:
    gpaReal m_vel_1;    // Ambient temperature
    gpaReal m_vel_2;    // Ambient temperature
    gpaReal m_alpha_in; // Ambient temperature
    gpaReal m_ten_T;    // Ambient temperature
    /*!
     * Получить название типа элемента
     * \return название типа элемента
     */
    static const gpaString &getDeviceTypeName() { return m_typeName; }
    /*!
     * Получить описание элемента
     * \return описание элемента
     */
    static const gpaString &getDeviceDescription() { return m_description; }

  private:
    //! Название элемента
    static const gpaString m_typeName;
    //! Описание элемента
    static const gpaString m_description;
};

#endif
