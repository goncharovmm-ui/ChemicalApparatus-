#include "gpaFillingRiserInfo.h"
#include "gpaFillingRiser.h"

gpaFillingRiserInfo::gpaFillingRiserInfo() :
    gpaDeviceInfo  (gpaFillingRiser::getDeviceTypeName(),
                    gpaFillingRiser::getDeviceDescription())
{
    setParameters(gpaFillingRiser::getParametersInfo());
    setSensors(gpaFillingRiser::getSensorsInfo());
}

gpaUInt gpaFillingRiserInfo::getNumMixCircuits() const
{
    return gpaFillingRiser::getDeviceNumMixCircuits();
}

gpaUInt gpaFillingRiserInfo::getMinNumMixPorts(gpaUInt index) const
{
    return gpaFillingRiser::getDeviceMinNumMixPorts(index);
}

gpaUInt gpaFillingRiserInfo::getMaxNumMixPorts(gpaUInt index) const
{
    return gpaFillingRiser::getDeviceMaxNumMixPorts(index);
}
const gpaString *gpaFillingRiserInfo::getMixPortName(gpaUInt circIdx, gpaUInt portIdx) const
{
    return gpaFillingRiser::getDeviceMixPortName(circIdx, portIdx);
}

const gpaString *gpaFillingRiserInfo::getMixCircuitName(gpaUInt index) const
{
    return gpaFillingRiser::getDeviceMixCircuitName(index);
}



gpaElement* gpaFillingRiserInfo::createDevice(const gpaCoreInterfaces* interfaces, gpaCoreReference pairDevice,
                                             const gpaExtObjectModel* model) const
{
    gpaFillingRiser* cooler = new gpaFillingRiser(interfaces, pairDevice);
    gpaResult res = cooler->specifyModel(model);
    if (res == GPA_RESULT_OK)
        return cooler;
    delete cooler;
    return NULL;
}
