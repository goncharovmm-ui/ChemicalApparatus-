/*!
 *  \file      gpaIncineratorElem.h
 *  \brief     Класс для описания однослойного объемного элемента
 *  \author    Мельников Роман
 *  \date      2025
 */
#ifndef GPA_INCINERATOR_ELEM_H
#define GPA_INCINERATOR_ELEM_H

#include "gpaInclude.h"
#include "gpaLongFlow.h"
#include "gpaMedium.h"
#include "pressureGradientModel.h"
#include <memory>

/*!
 * \class gpaIncineratorElem
 * \brief Класс, реализующий однослойный объемный элемента
 */
class gpaIncineratorElem : public gpaLongFlow {
public:
  /*!
   * Конструктор по умолчанию
   * \param link ссылки на родительские контейнеры
   */
  gpaIncineratorElem(const gpaParentLink *link = NULL);
  /*!
   * Конструктор копирования
   * \param volume объемный элемент для копирования
   */
  gpaIncineratorElem(const gpaIncineratorElem &volume);
  /*!
   * Деструктор по умолчанию
   */
  virtual ~gpaIncineratorElem() override;
  /*!
   * Функция копирования объемного элемента
   * \return скопированный объемный элемент
   */
   virtual gpaIncineratorElem *copy() const override;
  /*!
   * Получить название типа элемента
   * \return название типа элемента
   */
  virtual const gpaString &getTypeName() const override {
    return getDeviceTypeName();
  }
  /*!
   * Получить описание элемента
   * \return описание элемента
   */
  virtual const gpaString &getDescription() const override {
    return getDeviceDescription();
  }
  /*!
   * Функция получения минимального количества портов в материальном контуре
   * элемента
   * \param index индекс контура
   * \return минимальное количество портов
   */
  virtual gpaUInt getMinNumMixPorts(gpaUInt index) const override;
  /*!
   * Функция получения максимального количества портов в материальном контуре
   * элемента
   * \param index индекс контура
   * \return максимальное количество портов
   */
  virtual gpaUInt getMaxNumMixPorts(gpaUInt index) const override;
  /*!
   * Получить значение размерности
   * \return значение размерности
   */
  virtual gpaUInt getNumVariables() const override;
  /*!
   * Заполнить названия неизвестных
   * \param [out] varNames названия неизвестных
   */
  virtual void fillVarNames(gpaStringVector &varNames) const override;
  /*!
     * Заполнить названия неизвестных
     * \param [out] varNames названия неизвестных
     */
  virtual void fillEquationNames(gpaStringVector& eqNames) const override;
  /*!
   * Инициализировать камеру и ее параметры для расчета
   * \return код операции
   */
  virtual gpaResult initialize() override;
  /*!
   * Инициализировать решение заданным вектором
   * \param [out] variables вектор неизвестных
   * \return код ошибки
   */
  virtual gpaResult initVariables(gpaVector &variables) const override;
  /*!
   * Рассчитать значения функций правых частей
   * \param [in] states вектор состояний
   * \param [in] variables вектор неизвестных
   * \param [out] values вектор значений функций правых частей
   * \return код операции
   */
  virtual gpaResult calcFuncValues(const gpaConstVector &states,
                                   const gpaConstVector &variables,
                                   gpaVector &values,
                                   const gpaSetOfEquations &eqIds) override;
  /*!
   * Получить невязку уравнения для удельной мольной энтальпии для заданного
   * порта материального потока
   * \param circIdx индекс материального контура
   * \param portIdx индекс порта материального потока
   * \param enthalpy текущее значение энтальпии (относительно которого требуется
   * невязка)
   * \param [out] funcValue значение невязки уравнения для удельной мольной
   * энтальпии для заданного порта материального потока
   * \param код операции
   */
  virtual gpaResult calcEnthalpyFuncValueAt(gpaUInt circIdx, gpaUInt portIdx,
                                            gpaReal enthalpy,
                                            gpaReal &funcValue) const override;
  /*!
   * Получить невязки уравнений для мольных долей компонентов смеси для
   * заданного порта материального потока
   * \param circIdx индекс материального контура
   * \param portIdx индекс порта материального потока
   * \param fractions текущие значения мольных долей компонентов (относительно
   * которых требуется невязка)
   * \param [out] funcValues вектор невязок уравнений для мольных долей
   * компонентов смеси для заданного порта материального потока
   * \param код операции
   */
  virtual gpaResult
  calcFractionsFuncValuesAt(gpaUInt circIdx, gpaUInt portIdx,
                            const gpaConstVector &fractions,
                            gpaVector &funcValues) const override;
  virtual gpaReal calcFrictionFunc(gpaReal deltaPres, gpaReal rate) const override;
  gpaResult calcReaction(gpaReal outOxygenFraction);

  bool setPressureModel(std::unique_ptr<PressureGradientModel> model);
  bool setGeometry(gpaReal diameter, gpaReal length);
  bool setHeatTransferCoef(gpaReal coef);
  bool setOxidationCoef(gpaReal k_CO_2, gpaReal k_NO_2);
  bool setRadiationLossCoef(gpaReal coef);
  bool setExcessOxygen(gpaReal c) {
    m_excess_oxygen = c;
    return true;
  }
  bool setCoefCO2(gpaReal k_CO_2) {
    m_k_CO_2 = k_CO_2;
    return true;
  }
  bool setCoefNO(gpaReal k_NO_2) {
    m_k_NO_2 = k_NO_2;
    return true;
  }

  bool setBurner5Switch(gpaReal c) {
    m_burner5_switch = c;
    return true;
  };
  bool setBurner4Switch(gpaReal c) {
    m_burner4_switch = c;
    return true;
  };
  bool setBurner3Switch(gpaReal c) {
    m_burner3_switch = c;
    return true;
  };

  bool setBurner2Switch(gpaReal c) {
    m_burner2_switch = c;
    return true;
  };
  bool setBurner1Switch(gpaReal c) {
    m_burner1_switch = c;
    return true;
  };
  bool setNumBurner(gpaReal c) {
    m_num_burner = c;
    return true;
  };
  gpaReal getOverageCoef() const;
  gpaReal getNonreactingFlowRate() const;
  virtual bool hasHeatArea() const override { return true; }
  virtual gpaReal getHeatArea() const override;
  virtual gpaReal getCrossArea() const override;
  virtual gpaReal getHeatTransferCoef() const override;
  virtual bool calcValuesPerLength() override { return true; };

  gpaReal m_burner1_temp;
  gpaReal m_burner2_temp;
  gpaReal m_burner3_temp;
  gpaReal m_burner4_temp;
  gpaReal m_burner5_temp;
  gpaReal m_ari_temp;
  gpaReal m_q_stream;
  gpaReal m_NO_out;
  gpaReal m_NO2_out;

private:
  // Properties
  gpaMedium *m_medium;
  gpaMedium *m_medium_mixin;

  std::unique_ptr<PressureGradientModel> m_pressure_model;
  gpaReal m_alpha;
  gpaReal m_diameter;
  gpaReal m_length;
  gpaReal m_enthalpy; // [Номинальный расход, кг/с]
  gpaReal m_k_CO_2;
  gpaReal m_k_NO_2;
  gpaReal m_radLossCoef;
  gpaDataVector m_fractions;

  gpaReal m_excess_oxygen;
  gpaReal m_num_burner;
  gpaReal m_burner1_switch;
  gpaReal m_burner2_switch;
  gpaReal m_burner3_switch;
  gpaReal m_burner4_switch;
  gpaReal m_burner5_switch;
  gpaComponentID m_oxygen_id;
  gpaComponentID m_NO_id;
  gpaComponentID m_NO2_id;
  gpaComponentID m_nitro_id;
  gpaReal m_oxygen_needed;

public:
  /*!
   * Получить название типа элемента
   * \return название типа элемента
   */
  static const gpaString &getDeviceTypeName() { return m_typeName; }
  /*!
   * Получить описание элемента
   * \return описание элемента
   */
  static const gpaString &getDeviceDescription() { return m_description; }

  static gpaUInt getDeviceNumMixCircuits() { return 1; }

  gpaReal m_Q_reaction;
  gpaReal m_oxygen_last;

private:
  //! Название элемента
  static const gpaString m_typeName;
  //! Описание элемента
  static const gpaString m_description;
};

#endif
