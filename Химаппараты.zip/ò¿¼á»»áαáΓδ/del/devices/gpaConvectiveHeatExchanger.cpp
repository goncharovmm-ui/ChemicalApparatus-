#include "gpaLogMeanTempDifference.h"
#include "gpaZeroRadiation.h"
#include "gpaThinWall.h"
#include "gpaConvectiveHeatExchanger.h"
#include <iostream>


constexpr gpaUInt NUM_CIRCUITS          = 2;

constexpr gpaUInt ID_CIRCUIT = 0;
constexpr gpaUInt ID_CIRCUIT_2 = 1;

constexpr gpaUInt ID_PORT_GAS_INLET  = 0;
constexpr gpaUInt ID_PORT_GAS_OUTLET = 1;
constexpr gpaUInt ID_PORT_OIL_INLET  = 0;
constexpr gpaUInt ID_PORT_OIL_OUTLET = 1;

constexpr gpaUInt NUM_PORTS          = 2;


enum id_Param: gpaUInt {
    //Перечень входных геометрических параметров КК (СC - convection chamber) 16
    ID_PARAM_burnerModel               =0,
    ID_PARAM_lPipeCC            ,
    ID_PARAM_dPipeCC            ,
    ID_PARAM_aCC                ,
    ID_PARAM_bCC               ,
    ID_PARAM_hCC1               ,
    ID_PARAM_hCC2               ,
    ID_PARAM_nPipeSmСС         ,
    ID_PARAM_nPipeCorСС        ,
    ID_PARAM_deltaPipeCC        ,
    ID_PARAM_epsilonСС         ,
    ID_PARAM_kRib               ,
    ID_PARAM_deltaRib          ,
    ID_PARAM_hRib             ,
    ID_PARAM_s1                ,
    ID_PARAM_s2                 ,
    ID_PARAM_s3                 ,
    //ID_PARAM_setParsMethodFlag ,

    ID_PARAM_alphaAtmCC          ,
    ID_PARAM_lambdaAtmCC         ,
    ID_PARAM_dIsoCC              ,
    ID_PARAM_TAirAtm             ,

    ID_PARAM_total_local_frick_coef_CC          ,
    ID_PARAM_local_frick_coef_damper,
    ID_PARAM_diam_damper         ,
    ID_PARAM_rule_angle_damper             ,
    ID_PARAM_ratio_frick_coef_delta_angle             ,
    ID_PARAM_ratio_frick_coef_delta_angle_2             ,
    ID_PARAM_hight_CC             ,

};


// sensors
constexpr gpaUInt ID_SENSOR_GAS_IN_TEMP         = 0;
constexpr gpaUInt ID_SENSOR_GAS_OUT_TEMP        = 1;
constexpr gpaUInt ID_SENSOR_OIL_IN_TEMP         = 2;
constexpr gpaUInt ID_SENSOR_OIL_OUT_TEMP        = 3;

constexpr gpaUInt ID_SENSOR_alphaCC      = 4;
constexpr gpaUInt ID_SENSOR_sSideCC      = 5;
constexpr gpaUInt ID_SENSOR_LMTDCC       = 6;

constexpr gpaUInt ID_SENSOR_GAS_IN_MHC      = 7;
constexpr gpaUInt ID_SENSOR_GAS_OUT_MHC     = 8;
constexpr gpaUInt ID_SENSOR_OIL_IN_MHC      = 9;
constexpr gpaUInt ID_SENSOR_OIL_OUT_MHC     = 10;

constexpr gpaUInt ID_SENSOR_Delta_H_Gas     = 11;
constexpr gpaUInt ID_SENSOR_Delta_H_Oil     = 12;

constexpr gpaUInt ID_SENSOR_Q               = 13;

constexpr gpaUInt ID_SENSOR_QAtmCC          = 14;

constexpr gpaUInt ID_SENSOR_deltaP_oil      = 15;
constexpr gpaUInt ID_SENSOR_deltaP_gas      = 16;

constexpr gpaUInt ID_SENSOR_oilPipeCC_density        = 17;
constexpr gpaUInt ID_SENSOR_oilPipeCC_viscosity      = 18;
constexpr gpaUInt ID_SENSOR_oilPipeCC_mu             = 19;
constexpr gpaUInt ID_SENSOR_oilPipeCC_v              = 20;
constexpr gpaUInt ID_SENSOR_oilPipeCC_Re             = 21;
constexpr gpaUInt ID_SENSOR_oilPipeCC_deltaH         = 22;
constexpr gpaUInt ID_SENSOR_oilPipeCC_coefFrick      = 23;
constexpr gpaUInt ID_SENSOR_oilPipeCC_DP_Frick       = 24;
constexpr gpaUInt ID_SENSOR_oilPipeCC_DP_DH          = 25;
constexpr gpaUInt ID_SENSOR_oilPipeCC_DP             = 26;

constexpr gpaUInt ID_SENSOR_sSideCORCC             = 27;
constexpr gpaUInt ID_SENSOR_sSideSMCCP             = 28;


const gpaString gpaConvectiveHeatExchanger::m_typeName      = "CHE";
const gpaString gpaConvectiveHeatExchanger::m_description   = "Конвектвная камера ОПГМ";

const gpaStringVector gpaConvectiveHeatExchanger::m_circuitNames =
{
    "Контур ДГ",
    "Контур ГМ",
};

const gpaStringVector gpaConvectiveHeatExchanger::m_portNames =
{
    "Вход ТС",
    "Выход ДГ",
    "Вход ГМ",
    "Выход ГМ",
};



const gpaParameterInfoVector gpaConvectiveHeatExchanger::m_parameters =
{
    //Перечень входных геометрических параметров КК (СC - convection chamber)
    realParam("burnerModel",                  "Модель ОПГМ (1 - G1-87Y0, 2- L03-87Y01)",                                    NAN, false, 2),
    realParam("lPipeCC",                  "Длина труб масляного канала внутри",                                    GPA_LENGTH_UNIT, false, 6.7),
    realParam("dPipeCC",                  "Внутренний диаметр труб масляного канала внутри",                       GPA_LENGTH_UNIT, false, 0.102),
    realParam("aCC",                      "Длина газового канала",                                                 GPA_LENGTH_UNIT, false, 1),
    realParam("bCC",                      "Ширина газового канала",                                                GPA_LENGTH_UNIT, false, 6),
    realParam("hCC1",                     "Высота прямоугольного участка трубопровода",                            GPA_LENGTH_UNIT, false, 5),
    realParam("hCC2",                     "Эффективная высота участка общего дымохода",                            GPA_LENGTH_UNIT, false, 1.7),
    realParam("nPipeSmСС",                "Количество гладких труб масляного канала внутри одного змеевика",       NAN,             false, 5),
    realParam("nPipeCorСС",               "Количество оребренных труб масляного канала внутри одного змеевика",    NAN,             false, 18),
    realParam("deltaPipeCC",              "Толщина труб с маслом канала",                                          GPA_LENGTH_UNIT, false, 0.006),
    realParam("epsilonСС",                "Шероховатость трубопровода",                                               GPA_LENGTH_UNIT, false, 0.0002),
    realParam("kRib",                     "Шаг ребр, шт/м",                                                           NAN,             false, 167),
    realParam("deltaRib",                 "Толщина ребра",                                                            GPA_LENGTH_UNIT, false, 0.0012),
    realParam("hRib",                     "Высота ребра",                                                             GPA_LENGTH_UNIT, false, 0.015),
    realParam("s1",                       "Горизонтальный шаг",                                                       GPA_LENGTH_UNIT, false, 0.2),
    realParam("s2",                       "Вертикальный шаг",                                                         GPA_LENGTH_UNIT, false, 0.0865),
    realParam("s3",                       "Диагональный шаг",                                                         GPA_LENGTH_UNIT, false, 0.200),
    //realParam("setParsMethodFlag",                       "Переключатель метода расчета параметров регулировки",       NAN, false, 0),

    realParam("alphaAtmCC",                   "Коэффициент теплоотдачи от поверхности теплоизоляции, Вт/м^2/К",        GPA_LENGTH_UNIT, false, 10),
    realParam("lambdaAtmCC",                  "Коэффициент теплопроводности стенки изоляции, Вт/м/К",                              NAN, false, 0.15),
    realParam("dIsoCC",                       "Толщина изоляции",                                                        GPA_LENGTH_UNIT, false, 0.150),
    realParam("TAirAtm",                      "Температура окружающей среды, К",                                           NAN, false, 300),

    realParam("total_local_frick_coef_CC",    "Общий коэффицент  прочих местных потерь масла",                                        NAN, false, 10),

    realParam("local_frick_coef_damper",      "Коэффицент местных потерь шибера при полном открытии",                                        NAN, false, 0.01),
    realParam("diam_damper",                  "Диаметр шибера",                                                              GPA_LENGTH_UNIT, false, 3),
    realParam("rule_angle_damper",            "Угол поворота шибера, град.",                                                    NAN , true, 0),
    realParam("ratio_frick_coef_delta_angle", "Линейный коэффицент сопротивления шибера, 1/град",             NAN, false, 1),
    realParam("ratio_frick_coef_delta_angle_2", "Квадратичный коэффицент сопротивления шибера, 1/град^2",             NAN, false, 1),

    realParam("hight_CC", "Разница между высотами входа и выхода масла",             GPA_LENGTH_UNIT, false, 5),


};





const gpaSensorInfoVector gpaConvectiveHeatExchanger::m_sensors =
{
    //6
    scalarSensor("GAS_IN_TEMP",      "T1 Температура газа на входе",                 GPA_TEMPERATURE_UNIT),
    scalarSensor("GAS_OUT_TEMP",     "T2 Температура газа на выходе",               GPA_TEMPERATURE_UNIT),
    scalarSensor("OIL_IN_TEMP",      "T3 Температура масла на входе",               GPA_TEMPERATURE_UNIT),
    scalarSensor("OIL_OUT_TEMP",     "T4 Температура масла на выходе",              GPA_TEMPERATURE_UNIT),
    //6
    scalarSensor("ID_SENSOR_alphaCC",     "Коэффициент теплоотдачи с поверхности змеевиков КК, КВт/м^2/K",             NAN),
    scalarSensor("ID_SENSOR_sSideCC",     "Площадь поверхности теплоотдачи змеевиков КК",             GPA_AREA_UNIT),
    scalarSensor("ID_SENSOR_LMTDCC",      "Средне-логарифмический перепад температур КК, K",              GPA_TEMPERATURE_UNIT),
    //6
    scalarSensor("GAS_IN_MHC",      "1    Теплоемкость  газа на входе в КР, КДж/кмоль/К",            NAN),
    scalarSensor("GAS_OUT_MHC",     "2    Теплоемкость газа на выходе из КК, КДж/кмоль/К",           NAN),
    scalarSensor("OIL_IN_MHC",      "3    Теплоемкость масла на входе  в КК, КДж/кмоль/К",           NAN),
    scalarSensor("OIL_OUT_MHC",     "4    Теплоемкость масла на выходе из КР, КДж/кмоль/К",          NAN),
    //4
    scalarSensor("Delta_H_Gas",     "Изменение этальпии газа, кДж/кмоль",   NAN),
    scalarSensor("Delta_H_Oil",     "Изменение энтальпии масла, кДж/кмоль", NAN),
    scalarSensor("Q",               "Переданное маслу тепло, кДж",           NAN),
    scalarSensor("QAtmCC",          "Ушедшее в атмосферу тепло, кДж",               NAN),

    scalarSensor("deltaP_oil",      "Перепад давлений по маслу",            GPA_PRESSURE_UNIT),
    scalarSensor("deltaP_gas",      "Перепад давлений по газу",             GPA_PRESSURE_UNIT),


    scalarSensor("oilPipeCC_density",      "Плотность ГМ в КК, кг/(м^3)",                 GPA_DENSITY_UNIT),
    scalarSensor("oilPipeCC_viscosity",    "Вязкость ГМ в КК, мкПа*с",                      GPA_DIMLESS_UNIT),
    scalarSensor("oilPipeCC_mu",           "Молярная масса ГМ в КК, КГ/КМоль",            GPA_DIMLESS_UNIT),
    scalarSensor("oilPipeCC_v",            "Скорость ГМ в КК_v, м/c",                     GPA_VELOCITY_UNIT),
    scalarSensor("oilPipeCC_Re",           "Число Рейнольдса ГМ в КК",                    GPA_DIMLESS_UNIT),
    scalarSensor("oilPipeCC_deltaH",       "Перепад высот канала ГМ в КК",                GPA_LENGTH_UNIT),
    scalarSensor("oilPipeCC_coefFrick",    "Коэффициент трения ГМ в КК",                  GPA_DIMLESS_UNIT),
    scalarSensor("oilPipeCC_DP_Frick",     "Гидравлические потери давления ГМ в КК",  GPA_PRESSURE_UNIT),
    scalarSensor("oilPipeCC_DP_DH",        "Гидростатический напор ГМ в КК",         GPA_PRESSURE_UNIT),
    scalarSensor("oilPipeCC_DP",           "Суммарные потери давления ГМ в КК",      GPA_PRESSURE_UNIT),

    //2
    scalarSensor("sSideCORCC",           "Площадь гладких труб",      GPA_AREA_UNIT),
    scalarSensor("sSideSMCCP",           "Площадь оребренных труб",      GPA_AREA_UNIT),



};

gpaConvectiveHeatExchanger::gpaConvectiveHeatExchanger(const gpaCoreInterfaces* interfaces, gpaCoreReference importRef) :
    gpaExportSystem (interfaces, importRef),
    m_heatPipes      (asParent())
{
}

gpaResult gpaConvectiveHeatExchanger::calcSensors(gpaVector& sensors) const
{

    // (QBurn-Q)/abs(G_in_gas)
    setSensorValue(sensors, ID_SENSOR_GAS_IN_TEMP,      m_heatPipes.T_in_gas   - 273.15); // m_heatPipes.T_in_gas   - 273.15
    setSensorValue(sensors, ID_SENSOR_GAS_OUT_TEMP,     m_heatPipes.T_out_gas  - 273.15);//
    setSensorValue(sensors, ID_SENSOR_OIL_IN_TEMP,      m_heatPipes.T_in_oil   - 273.15);//T_in_oil - 273.15
    setSensorValue(sensors, ID_SENSOR_OIL_OUT_TEMP,     m_heatPipes.T_out_oil  - 273.15);//T_out_oil - 273.15

    setSensorValue(sensors, ID_SENSOR_alphaCC,     m_heatPipes.alphaCC);//m_heatPipes.alphaCC
    setSensorValue(sensors, ID_SENSOR_sSideCC,     m_heatPipes.sSideCC);
    setSensorValue(sensors, ID_SENSOR_LMTDCC,      m_heatPipes.LMTDCC);

    setSensorValue(sensors, ID_SENSOR_GAS_IN_MHC,     m_heatPipes.Cp_M_in_gas);
    setSensorValue(sensors, ID_SENSOR_GAS_OUT_MHC,    m_heatPipes.Cp_M_out_gas);
    setSensorValue(sensors, ID_SENSOR_OIL_IN_MHC,     m_heatPipes.Cp_M_in_oil);
    setSensorValue(sensors, ID_SENSOR_OIL_OUT_MHC,    m_heatPipes.Cp_M_out_oil);

    setSensorValue(sensors, ID_SENSOR_Delta_H_Gas,    m_heatPipes.Delta_H_Gas_Fixed);
    setSensorValue(sensors, ID_SENSOR_Delta_H_Oil,    m_heatPipes.Delta_H_Oil_Fixed);
    setSensorValue(sensors, ID_SENSOR_Q,              m_heatPipes.Q);
    setSensorValue(sensors, ID_SENSOR_QAtmCC,         m_heatPipes.QAtmCC);//

    setSensorValue(sensors, ID_SENSOR_deltaP_oil,         m_heatPipes.deltaP_oil);//
    setSensorValue(sensors, ID_SENSOR_deltaP_gas,         m_heatPipes.deltaP_gas);//


    setSensorValue(sensors, ID_SENSOR_oilPipeCC_density,       m_heatPipes.oilPipeCC.density);//
    setSensorValue(sensors, ID_SENSOR_oilPipeCC_viscosity,     1000000*m_heatPipes.oilPipeCC.viscosity);//
    setSensorValue(sensors, ID_SENSOR_oilPipeCC_mu,            m_heatPipes.oilPipeCC.mu);//
    setSensorValue(sensors, ID_SENSOR_oilPipeCC_v,             m_heatPipes.oilPipeCC.v);//
    setSensorValue(sensors, ID_SENSOR_oilPipeCC_Re,            m_heatPipes.oilPipeCC.Re);//
    setSensorValue(sensors, ID_SENSOR_oilPipeCC_deltaH,        m_heatPipes.oilPipeCC.deltaH);//
    setSensorValue(sensors, ID_SENSOR_oilPipeCC_coefFrick,     m_heatPipes.oilPipeCC.coefFrick/pow(m_heatPipes.oilPipeCC.Re, 2));//
    setSensorValue(sensors, ID_SENSOR_oilPipeCC_DP_Frick,      m_heatPipes.oilPipeCC.DP_Frick);//
    setSensorValue(sensors, ID_SENSOR_oilPipeCC_DP_DH,         m_heatPipes.oilPipeCC.DP_DH);//
    setSensorValue(sensors, ID_SENSOR_oilPipeCC_DP,            m_heatPipes.oilPipeCC.DP);//

    setSensorValue(sensors, ID_SENSOR_sSideCORCC,            m_heatPipes.sSideCORCC);//
    setSensorValue(sensors, ID_SENSOR_sSideSMCCP,            m_heatPipes.sSideSMCC);//

    return GPA_RESULT_OK;
}
gpaResult gpaConvectiveHeatExchanger::checkParamValues(const gpaExtParameter *values) const
{
    (void)values;
    return GPA_RESULT_OK;
}

void gpaConvectiveHeatExchanger::setNames()
{
    m_heatPipes.setName("pipes");
}

gpaResult gpaConvectiveHeatExchanger::initMixtureFlow(const gpaExtParameter *values)
{
    // Назначаем параметры проточных элементов
    bool good = true;
    return GPA_RESULT_OK;
}

gpaResult gpaConvectiveHeatExchanger::setParamValues(const gpaExtParameter *values, bool checkNeeded)
{

    //Параметры геометрии

    //Перечень входных геометрических параметров КК (СC - convection chamber) 16

    m_heatPipes.burnerModel =   values[ID_PARAM_burnerModel].value.realValue;

    m_heatPipes.lPipeCC =   values[ID_PARAM_lPipeCC].value.realValue;
    m_heatPipes.dPipeCC =   values[ID_PARAM_dPipeCC].value.realValue;

    m_heatPipes.aCC =       values[ID_PARAM_aCC].value.realValue;
    m_heatPipes.bCC =       values[ID_PARAM_bCC].value.realValue;

    m_heatPipes.hCC1=       values[ID_PARAM_hCC1].value.realValue;
    m_heatPipes.hCC2=       values[ID_PARAM_hCC2].value.realValue;

    m_heatPipes.nPipeSmСС=  values[ID_PARAM_nPipeSmСС].value.realValue;
    m_heatPipes.nPipeCorСС= values[ID_PARAM_nPipeCorСС].value.realValue;
    m_heatPipes.deltaPipeCC=values[ID_PARAM_deltaPipeCC].value.realValue;
    m_heatPipes.epsilonСС=  values[ID_PARAM_epsilonСС].value.realValue;

    m_heatPipes.kRib=       values[ID_PARAM_kRib].value.realValue;
    m_heatPipes.deltaRib=   values[ID_PARAM_deltaRib].value.realValue;
    m_heatPipes.hRib=       values[ID_PARAM_hRib].value.realValue;

    m_heatPipes.s1=         values[ID_PARAM_s1].value.realValue;
    m_heatPipes.s2=         values[ID_PARAM_s2].value.realValue;
    m_heatPipes.s3=         values[ID_PARAM_s3].value.realValue;


    m_heatPipes.alphaAtmCC=         values[ID_PARAM_alphaAtmCC].value.realValue;
    m_heatPipes.lambdaAtmCC=         values[ID_PARAM_lambdaAtmCC].value.realValue;
    m_heatPipes.dIsoCC=         values[ID_PARAM_dIsoCC].value.realValue;
    m_heatPipes.TAirAtm=         values[ID_PARAM_TAirAtm].value.realValue;

    m_heatPipes.total_local_frick_coef_CC   = values[ID_PARAM_total_local_frick_coef_CC].value.realValue;

    m_heatPipes.local_frick_coef_damper   = values[ID_PARAM_local_frick_coef_damper].value.realValue;
    m_heatPipes.diam_damper                 = values[ID_PARAM_diam_damper].value.realValue;
    m_heatPipes.rule_angle_damper           = values[ID_PARAM_rule_angle_damper].value.realValue;
    m_heatPipes.ratio_frick_coef_delta_angle= values[ID_PARAM_ratio_frick_coef_delta_angle].value.realValue;
    m_heatPipes.ratio_frick_coef_delta_angle_2= values[ID_PARAM_ratio_frick_coef_delta_angle_2].value.realValue;

    m_heatPipes.hight_CC= values[ID_PARAM_hight_CC].value.realValue;




    //Параметры геометрии
    //m_heatPipes.setParsMethodFlag=values[ID_PARAM_setParsMethodFlag].value.realValue;


    // Проверка параметров, если требуется
    if (checkNeeded)
    {
        gpaResult res = checkParamValues(values);
        if (res != GPA_RESULT_OK)
            return res;
    }
    // Даем названия элементам и потокам
    setNames();
    // Инициализируются элементы с потоком смеси
    gpaResult res = initMixtureFlow(values);
    if (res != GPA_RESULT_OK)
        return res;
    // Обновляем параметры воздуха на входе
    return res;
}

gpaResult gpaConvectiveHeatExchanger::buildDevice()
{
    bool good = true;
    // Соединяем поток смеси по трубам с граничными потоками смеси системы
    good = good && m_heatPipes.connectMixStream(GPA_ELEM_CIRCUIT_0, ID_PORT_GAS_INLET,  getEdgeMixStream(ID_CIRCUIT,   ID_PORT_GAS_INLET),  GPA_STREAM_INLET);
    good = good && m_heatPipes.connectMixStream(GPA_ELEM_CIRCUIT_0, ID_PORT_GAS_OUTLET, getEdgeMixStream(ID_CIRCUIT,   ID_PORT_GAS_OUTLET), GPA_STREAM_OUTLET);
    good = good && m_heatPipes.connectMixStream(GPA_ELEM_CIRCUIT_Oil_CHE, ID_PORT_OIL_INLET,  getEdgeMixStream(ID_CIRCUIT_2, ID_PORT_OIL_INLET),  GPA_STREAM_INLET);
    good = good && m_heatPipes.connectMixStream(GPA_ELEM_CIRCUIT_Oil_CHE, ID_PORT_OIL_OUTLET, getEdgeMixStream(ID_CIRCUIT_2, ID_PORT_OIL_OUTLET), GPA_STREAM_OUTLET);
    if (!good)
        return GPA_ERROR_WRONG_ARGS;
    // Добавляем в систему все элементы и потоки
    setElements({&m_heatPipes});
    setStreams({});
    return GPA_RESULT_OK;
}

gpaResult gpaConvectiveHeatExchanger::initialize()
{
    // Подключить экспортируемый элемент к потокам в интеграторе
    gpaResult res = linkToCoreStreams();
    if (res != GPA_RESULT_OK)
        return res;
    // Соединяем все элементы друг с другом
    res = buildDevice();
    if (res != GPA_RESULT_OK)
        return res;
    // Создаем схемы течений (нужны соединенные элементы)
    if (!createSimStructures({}, {getOuterEntrance(ID_CIRCUIT, ID_PORT_GAS_INLET),
                                  getOuterEntrance(ID_CIRCUIT_2, ID_PORT_OIL_INLET)}))
        return GPA_ERROR_WRONG_ARGS;
    // Инициализируем систему
    return gpaExportSystem::initialize();
}

gpaResult gpaConvectiveHeatExchanger::setSignals(const gpaConstVector &signals)
{

    gpaReal value;
    bool good = true;

    if (getSignalValue(signals, ID_PARAM_rule_angle_damper, value))
    m_heatPipes.rule_angle_damper               = value;
    // if (getSignalValue(signals, ID_PARAM_kQRC, value))
    // m_heatPipes.kQRC               = value;

    return GPA_RESULT_OK;
}
const gpaString* gpaConvectiveHeatExchanger::getDeviceMixCircuitName(gpaUInt index)
{
    return index < NUM_CIRCUITS ? &m_circuitNames[index] : NULL;
}
const gpaString* gpaConvectiveHeatExchanger::getDeviceMixPortName(gpaUInt circIdx, gpaUInt portIdx)
{
    return portIdx + circIdx*2 < 4 ? &m_portNames[portIdx + circIdx*2] : NULL;
}





