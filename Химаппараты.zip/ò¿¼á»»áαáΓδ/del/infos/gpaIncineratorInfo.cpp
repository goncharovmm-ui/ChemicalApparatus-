#include "gpaIncineratorInfo.h"
#include "gpaIncinerator.h"

gpaIncineratorInfo::gpaIncineratorInfo() : gpaDeviceInfo(gpaIncinerator::getDeviceTypeName(),
                                               gpaIncinerator::getDeviceDescription())
{
    setParameters(gpaIncinerator::getParametersInfo());
    setSensors(gpaIncinerator::getSensorsInfo());
}

gpaUInt gpaIncineratorInfo::getNumMixCircuits() const
{
    return gpaIncinerator::getDeviceNumMixCircuits();
}

gpaUInt gpaIncineratorInfo::getMinNumMixPorts(gpaUInt index) const
{
    return gpaIncinerator::getDeviceMinNumMixPorts(index);
}

gpaUInt gpaIncineratorInfo::getMaxNumMixPorts(gpaUInt index) const
{
    return gpaIncinerator::getDeviceMaxNumMixPorts(index);
}
const gpaString *gpaIncineratorInfo::getMixPortName(gpaUInt circIdx, gpaUInt portIdx) const
{
    return gpaIncinerator::getDeviceMixPortName(circIdx, portIdx);
}

const gpaString *gpaIncineratorInfo::getMixCircuitName(gpaUInt index) const
{
    return gpaIncinerator::getDeviceMixCircuitName(index);
}

gpaElement *gpaIncineratorInfo::createDevice(const gpaCoreInterfaces *interfaces, gpaCoreReference pairDevice,
                                        const gpaExtObjectModel *model) const
{
    gpaIncinerator *cooler = new gpaIncinerator(interfaces, pairDevice);
    gpaResult res = cooler->specifyModel(model);
    if (res == GPA_RESULT_OK)
        return cooler;
    delete cooler;
    return NULL;
}
