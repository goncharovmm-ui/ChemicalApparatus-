#include "gpaGasFilterInfo.h"
#include "gpaGasFilter.h"

gpaGasFilterInfo::gpaGasFilterInfo() : gpaDeviceInfo(gpaGasFilter::getDeviceTypeName(),
                                               gpaGasFilter::getDeviceDescription())
{
    setParameters(gpaGasFilter::getParametersInfo());
    setSensors(gpaGasFilter::getSensorsInfo());
}

gpaUInt gpaGasFilterInfo::getNumMixCircuits() const
{
    return gpaGasFilter::getDeviceNumMixCircuits();
}

gpaUInt gpaGasFilterInfo::getMinNumMixPorts(gpaUInt index) const
{
    return gpaGasFilter::getDeviceMinNumMixPorts(index);
}

gpaUInt gpaGasFilterInfo::getMaxNumMixPorts(gpaUInt index) const
{
    return gpaGasFilter::getDeviceMaxNumMixPorts(index);
}
const gpaString *gpaGasFilterInfo::getMixPortName(gpaUInt circIdx, gpaUInt portIdx) const
{
    return gpaGasFilter::getDeviceMixPortName(circIdx, portIdx);
}

const gpaString *gpaGasFilterInfo::getMixCircuitName(gpaUInt index) const
{
    return gpaGasFilter::getDeviceMixCircuitName(index);
}

gpaElement *gpaGasFilterInfo::createDevice(const gpaCoreInterfaces *interfaces, gpaCoreReference pairDevice,
                                        const gpaExtObjectModel *model) const
{
    gpaGasFilter *cooler = new gpaGasFilter(interfaces, pairDevice);
    gpaResult res = cooler->specifyModel(model);
    if (res == GPA_RESULT_OK)
        return cooler;
    delete cooler;
    return NULL;
}
