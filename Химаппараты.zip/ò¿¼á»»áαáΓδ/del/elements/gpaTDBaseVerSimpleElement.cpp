#include "gpaInclude.h"
#include "gpaTDBaseVerSimpleElement.h"

const gpaString gpaTDBaseVerSimpleElement::m_typeName     = "TD-BaseVer-Simple";
const gpaString gpaTDBaseVerSimpleElement::m_description  = "TDBaseVerSimpleElement";