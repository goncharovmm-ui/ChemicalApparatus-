#include <algorithm>
#include <string> #include <vector>

#ifndef GPA_HEAT_COEFF_PRM_H
#define GPA_HEAT_COEFF_PRM_H
class gpaHeatCoeffPrm {
public:
  // Физические параметры
  gpaReal diameter = 1;
  gpaReal length = 1;
  gpaReal beta = 1;
  gpaReal Tst = 1;
  gpaReal Tsr = 1;
  gpaReal density = 1;
  gpaReal viscosity = 1;
  gpaReal Cp = 1;
  gpaReal thermal_conductivity = 1;
  gpaReal velocity = 1;
  bool inclination = false;

  // Константы

  // Коэффициенты для интерполяции (из Bergman)
  const std::vector<gpaReal> c_array = {0.989, 0.911, 0.683, 0.193, 0.027};
  const std::vector<gpaReal> m_array = {0.33, 0.385, 0.466, 0.618, 0.805};
  const std::vector<gpaReal> Re_array = {2, 18, 1980, 18000, 180000};

public:
  // Конструктор
  gpaHeatCoeffPrm(gpaReal d)
      : diameter(d), length(d), beta(1), Tst(273), Tsr(273), density(1),
        viscosity(1), Cp(1), thermal_conductivity(1), velocity(1),
        inclination(1) {}

  gpaHeatCoeffPrm(gpaReal d, gpaReal l, gpaReal b, gpaReal Tst, gpaReal Tsr,
                  const gpaReal dens, const gpaReal visc, const gpaReal cp,
                  const gpaReal therm_cond, const gpaReal vel, const bool incl)
      : diameter(d), length(l), beta(b), Tst(Tst), Tsr(Tsr), density(dens),
        viscosity(visc), Cp(cp), thermal_conductivity(therm_cond),
        velocity(vel), inclination(incl) {}

  // Метод для расчета коэффициента теплоотдачи
  gpaReal calculate() {

    // Вычисление характерного размера
    gpaReal character_length = std::min(diameter, length);

    // Вычисление чисел подобия
    gpaReal Gr = GPA_GRAVITY_ACCELERATION * beta * std::abs(Tst - Tsr) *
                 std::pow(character_length, 3) * std::pow(density, 2) /
                 std::pow(viscosity, 2);

    gpaReal Pr = viscosity * Cp / thermal_conductivity;
    gpaReal Re = density * std::abs(velocity) * diameter / viscosity;
    gpaReal Ra = Gr * Pr;

    // Интерполяция коэффициентов (упрощенная линейная)
    gpaReal C_v = 0.0;
    gpaReal m = 0.0;
    for (size_t i = 0; i < Re_array.size() - 1; ++i) {
      if (Re >= Re_array[i] && Re < Re_array[i + 1]) {
        gpaReal t = (Re - Re_array[i]) / (Re_array[i + 1] - Re_array[i]);
        C_v = c_array[i] + t * (c_array[i + 1] - c_array[i]);
        m = m_array[i] + t * (m_array[i + 1] - m_array[i]);
        break;
      }
    }

    // Определение коэффициентов в зависимости от ориентации
    gpaReal C, s;
    if (inclination) {
      if (Ra < 1e9) {
        C = 0.59;
        s = 0.25;
      } else {
        C = 0.1;
        s = 1.0 / 3.0;
      }
    } else {
      if (Ra < 1e9) {
        C = 0.53;
        s = 0.25;
      } else {
        C = 0.13;
        s = 1.0 / 3.0;
      }
    }

    // Вычисление чисел Нуссельта
    gpaReal Nue = C * std::pow(Ra, s);
    gpaReal Nuv = C_v * std::pow(Re, m) * std::pow(Pr, 1.0 / 3.0);

    // Комбинирование чисел Нуссельта
    gpaReal Nu = std::max(Nuv, Nue);

    // Вычисление коэффициента теплоотдачи
    return Nu * thermal_conductivity / diameter;
  }
};
#endif
