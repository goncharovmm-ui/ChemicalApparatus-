#include "gpaLogMeanTempDifference.h"
#include "gpaZeroRadiation.h"
#include "gpaThinWall.h"
#include "gpaTDBaseVerSimple.h"
#include <iostream>

constexpr gpaUInt ID_CIRCUIT_INNER      = 0;
constexpr gpaUInt NUM_CIRCUITS          = 2;

constexpr gpaUInt ID_CIRCUIT = 0;
constexpr gpaUInt ID_CIRCUIT_2 = 1;

constexpr gpaUInt ID_PORT_GAS_INLET = 0;
constexpr gpaUInt ID_PORT_GAS_OUTLET = 1;
constexpr gpaUInt ID_PORT_OIL_INLET  = 0;
constexpr gpaUInt ID_PORT_OIL_OUTLET = 1;

constexpr gpaUInt NUM_PORTS          = 2;

// Перечень параметров для расчета
constexpr gpaUInt ID_PARAM_numb_case   = 0;
constexpr gpaUInt ID_PARAM_k_delta_H_TES   = 1;
constexpr gpaUInt ID_PARAM_k_delta_H_CS   = 2;
constexpr gpaUInt ID_PARAM_omegaInit   = 3;
constexpr gpaUInt ID_PARAM_I_shaft        = 4;

constexpr gpaUInt ID_PARAM_isNeedApproxCurvesNewRegime        = 5;

constexpr gpaUInt ID_PARAM_TES_mdot_1 = 6;
constexpr gpaUInt ID_PARAM_TES_mdot_2 = 7;
constexpr gpaUInt ID_PARAM_TES_mdot_3 = 8;
constexpr gpaUInt ID_PARAM_TES_mdot_4 = 9;
constexpr gpaUInt ID_PARAM_TES_mdot_5 = 10;
constexpr gpaUInt ID_PARAM_TES_P_1 = 11;
constexpr gpaUInt ID_PARAM_TES_P_2 = 12;
constexpr gpaUInt ID_PARAM_TES_P_3 = 13;
constexpr gpaUInt ID_PARAM_TES_P_4 = 14;
constexpr gpaUInt ID_PARAM_TES_P_5 = 15;
constexpr gpaUInt ID_PARAM_CS_mdot_1 = 16;
constexpr gpaUInt ID_PARAM_CS_mdot_2 = 17;
constexpr gpaUInt ID_PARAM_CS_mdot_3 = 18;
constexpr gpaUInt ID_PARAM_CS_mdot_4 = 19;
constexpr gpaUInt ID_PARAM_CS_mdot_5 = 20;
constexpr gpaUInt ID_PARAM_CS_P_1 = 21;
constexpr gpaUInt ID_PARAM_CS_P_2 = 22;
constexpr gpaUInt ID_PARAM_CS_P_3 = 23;
constexpr gpaUInt ID_PARAM_CS_P_4 = 24;
constexpr gpaUInt ID_PARAM_CS_P_5 = 25;
constexpr gpaUInt ID_PARAM_TES_fun_In_exp = 26;
constexpr gpaUInt ID_PARAM_TES_m_dot_Nom = 27;
constexpr gpaUInt ID_PARAM_TES_omega_Nom = 28;
constexpr gpaUInt ID_PARAM_CS_fun_In_exp = 29;
constexpr gpaUInt ID_PARAM_CS_m_dot_Nom = 30;
constexpr gpaUInt ID_PARAM_CS_omega_Nom = 31;

constexpr gpaUInt ID_PARAM_TES_omega_coef_A = 32;
constexpr gpaUInt ID_PARAM_TES_omega_coef_B = 33;
constexpr gpaUInt ID_PARAM_CS_omega_coef_A = 34;
constexpr gpaUInt ID_PARAM_CS_omega_coef_B = 35;

// sensors
constexpr gpaUInt ID_SENSOR_OMEGA      = 0;
constexpr gpaUInt ID_SENSOR_TES_IN_TEMP     = 1;
constexpr gpaUInt ID_SENSOR_TES_OUT_TEMP     = 2;
constexpr gpaUInt ID_SENSOR_CS_IN_TEMP      = 3;
constexpr gpaUInt ID_SENSOR_CS_OUT_TEMP     = 4;

constexpr gpaUInt ID_SENSOR_Delta_H_TES      = 5;
constexpr gpaUInt ID_SENSOR_Delta_H_CS      = 6;

constexpr gpaUInt ID_SENSOR_deltaP_TES       = 7;
constexpr gpaUInt ID_SENSOR_deltaP_CS       = 8;

constexpr gpaUInt ID_SENSOR_k_CS       = 9;
constexpr gpaUInt ID_SENSOR_n_CS       = 10;

constexpr gpaUInt ID_SENSOR_Q_TES       = 11;
constexpr gpaUInt ID_SENSOR_Q_CS       = 12;

constexpr gpaUInt ID_SENSOR_momentTES       = 13;
constexpr gpaUInt ID_SENSOR_momentCS       = 14;

const gpaString gpaTDBaseVerSimple::m_typeName      = "TD-BaseVer-Simple";
const gpaString gpaTDBaseVerSimple::m_description   = "ТД (модель из отчета без динамики)";

const gpaStringVector gpaTDBaseVerSimple::m_circuitNames =
{
    "Контур ТДС",
    "Контур КС",
};

const gpaStringVector gpaTDBaseVerSimple::m_portNames =
{
    "Вход в ТДС",
    "Выход из ТДС",
    "Вход в КС",
    "Выход из КС",
};



const gpaParameterInfoVector gpaTDBaseVerSimple::m_parameters =
{
    realParam("numb_case",         "Номер режима",                      GPA_DIMLESS_UNIT,     false, 100.0),
    realParam("k_delta_H_TES",         "Коэффициент коррекции перепада энтальпии в ТДС",                      GPA_DIMLESS_UNIT,     false, 1.0),
    realParam("k_delta_H_CS",         "Коэффициент коррекции перепада энтальпии в КС",                      GPA_DIMLESS_UNIT,     false, 1.0),

    realParam("omegaInit",         "Частота вращения вала, об/мин",                      GPA_DIMLESS_UNIT,     true, 9000.0),
    realParam("I_shaft",              "Момент инерции вала, кг*м^2",                                               GPA_DIMLESS_UNIT,     false, 10000),

    realParam("isNeedApproxCurvesNewRegime",              "Режим ввода кривых 1 -ГДХ, 2 - ручной",                                               GPA_DIMLESS_UNIT,     false, 1),

    realParam("TES_mdot_1" , "Массовый расход ТДС 1, тонн/ч", GPA_DIMLESS_UNIT, false, 284.217),
    realParam("TES_mdot_2" , "Массовый расход ТДС 2, тонн/ч", GPA_DIMLESS_UNIT, false, 350.362),
    realParam("TES_mdot_3" , "Массовый расход ТДС 3, тонн/ч", GPA_DIMLESS_UNIT, false, 461.957),
    realParam("TES_mdot_4" , "Массовый расход ТДС 4, тонн/ч", GPA_DIMLESS_UNIT, false, 257.926),
    realParam("TES_mdot_5" , "Массовый расход ТДС 5, тонн/ч", GPA_DIMLESS_UNIT, false, 321.291),

    realParam("TES_P_1" , "Давление  ТДС 1, МПа", GPA_DIMLESS_UNIT, false, 2.19395),
    realParam("TES_P_2" , "Давление  ТДС 2, МПа", GPA_DIMLESS_UNIT, false, 2.50353),
    realParam("TES_P_3" , "Давление  ТДС 3, МПа", GPA_DIMLESS_UNIT, false, 2.87059),
    realParam("TES_P_4" , "Давление  ТДС 4, МПа", GPA_DIMLESS_UNIT, false, 2.13189),
    realParam("TES_P_5" , "Давление  ТДС 5, МПа", GPA_DIMLESS_UNIT, false, 2.57483),

    realParam("CS_mdot_1" , "Массовый расход КС 1, тонн/ч", GPA_DIMLESS_UNIT, false, 284.217),
    realParam("CS_mdot_2" , "Массовый расход КС 2, тонн/ч", GPA_DIMLESS_UNIT, false, 350.362),
    realParam("CS_mdot_3" , "Массовый расход КС 3, тонн/ч", GPA_DIMLESS_UNIT, false, 461.957),
    realParam("CS_mdot_4" , "Массовый расход КС 4, тонн/ч", GPA_DIMLESS_UNIT, false, 257.926),
    realParam("CS_mdot_5" , "Массовый расход КС 5, тонн/ч", GPA_DIMLESS_UNIT, false, 321.291),

    realParam("CS_P_1" , "Давление  КС 1, МПа", GPA_DIMLESS_UNIT, false, 2.19395),
    realParam("CS_P_2" , "Давление  КС 2, МПа", GPA_DIMLESS_UNIT, false, 2.50353),
    realParam("CS_P_3" , "Давление  КС 3, МПа", GPA_DIMLESS_UNIT, false, 2.87059),
    realParam("CS_P_4" , "Давление  КС 4, МПа", GPA_DIMLESS_UNIT, false, 2.13189),
    realParam("CS_P_5" , "Давление  КС 5, МПа", GPA_DIMLESS_UNIT, false, 2.57483),

    realParam("TES_fun_In_exp" , "Давление на фиксированном порту из ГДХ ТДС, МПа", GPA_DIMLESS_UNIT, false, 7.99),
    realParam("TES_m_dot_Nom" , "Номинальный расход ТДС, тонн/ч", GPA_DIMLESS_UNIT, false, 107.2),
    realParam("TES_omega_Nom" , "Номинальная частота ТДС, об/мин", GPA_DIMLESS_UNIT, false, 10000),

    realParam("CS_fun_In_exp" ,  "Давление на фиксированном порту из ГДХ КС, МПа", GPA_DIMLESS_UNIT, false, 2.595),
    realParam("CS_m_dot_Nom" , "Номинальный расход КС, тонн/ч", GPA_DIMLESS_UNIT, false, 149.3),
    realParam("CS_omega_Nom" , "Номинальная частота КС, об/мин", GPA_DIMLESS_UNIT, false, 10000),

    realParam("TES_omega_coef_A" ,  "Коэффициент A ТДС ", GPA_DIMLESS_UNIT, false, 1),
    realParam("TES_omega_coef_B" ,  "Коэффициент B ТДС", GPA_DIMLESS_UNIT, false, 1),
    realParam("CS_omega_coef_A" ,   "Коэффициент A КС", GPA_DIMLESS_UNIT, false, 1),
    realParam("CS_omega_coef_B" ,   "Коэффициент B КС", GPA_DIMLESS_UNIT, false, 1),

};


const gpaSensorInfoVector gpaTDBaseVerSimple::m_sensors =
{
    //6
    scalarSensor("OMEGA",      "Частота вращения вала, об/мин",                 GPA_DIMLESS_UNIT),
    scalarSensor("TES_IN_TEMP",     "T1 Температура газа на входе в ТДС",               GPA_TEMPERATURE_UNIT),
    scalarSensor("TES_OUT_TEMP",     "T2 Температура газа на выходе из ТДС",               GPA_TEMPERATURE_UNIT),
    scalarSensor("CS_IN_TEMP",      "T3 Температура газа на входе  в КС",               GPA_TEMPERATURE_UNIT),
    scalarSensor("CS_OUT_TEMP",     "T4 Температура газа на выходе из КС",              GPA_TEMPERATURE_UNIT),

    scalarSensor("Delta_H_TES",     "Изменение этальпии газа в КС, кДж/кмоль",   NAN),
    scalarSensor("Delta_H_CS",     "Изменение энтальпии газа в ТДС, кДж/кмоль", NAN),

    scalarSensor("deltaP_TES",      "Перепад давлений ТДС, МПа",            GPA_DIMLESS_UNIT),
    scalarSensor("deltaP_CS",      "Перепад давлений КС, МПа",             GPA_DIMLESS_UNIT),
    scalarSensor("k_out_cs",       "Показатель адиабаты газа на выходе из КС",             GPA_DIMLESS_UNIT),
    scalarSensor("n_out_cs",      "Показатель политропы газа на выходе из КС",             GPA_DIMLESS_UNIT),

    scalarSensor("Q_TES",       "Изменение энергии газа  в канале ТДС, кВт",             GPA_DIMLESS_UNIT),
    scalarSensor("Q_CS",      "Изменение энергии газа  в канале КС, кВт",             GPA_DIMLESS_UNIT),

    scalarSensor("momentTES",       "Момент газа  в канале ТДС, Н*м",             GPA_DIMLESS_UNIT),
    scalarSensor("momentCS",      "Момент газа  в канале КС, Н*м",             GPA_DIMLESS_UNIT),


};

gpaTDBaseVerSimple::gpaTDBaseVerSimple(const gpaCoreInterfaces* interfaces, gpaCoreReference importRef) :
    gpaExportSystem (interfaces, importRef),
    m_heatPipes      (asParent())
{
}

gpaResult gpaTDBaseVerSimple::calcSensors(gpaVector& sensors) const
{

    setSensorValue(sensors, ID_SENSOR_OMEGA,      m_heatPipes.omega*60); //
    setSensorValue(sensors, ID_SENSOR_TES_IN_TEMP,     m_heatPipes.T_in_TES - 273.15);//
    setSensorValue(sensors, ID_SENSOR_TES_OUT_TEMP,     m_heatPipes.T_out_TES - 273.15);//
    setSensorValue(sensors, ID_SENSOR_CS_IN_TEMP,      m_heatPipes.T_in_CS - 273.15);//T_in_oil - 273.15
    setSensorValue(sensors, ID_SENSOR_CS_OUT_TEMP,     m_heatPipes.T_out_CS - 273.15);//T_out_oil - 273.15

    setSensorValue(sensors, ID_SENSOR_Delta_H_TES,    m_heatPipes.Delta_H_TES);
    setSensorValue(sensors, ID_SENSOR_Delta_H_CS,    m_heatPipes.Delta_H_CS);

    setSensorValue(sensors, ID_SENSOR_deltaP_TES,         m_heatPipes.deltaP_TES/1000);//
    setSensorValue(sensors, ID_SENSOR_deltaP_CS,         m_heatPipes.deltaP_CS/1000);//

    setSensorValue(sensors, ID_SENSOR_k_CS,         m_heatPipes.k_out_cs);//
    setSensorValue(sensors, ID_SENSOR_n_CS,         m_heatPipes.n_out_cs);//

    setSensorValue(sensors, ID_SENSOR_Q_TES,         m_heatPipes.Q_TES/1000);//
    setSensorValue(sensors, ID_SENSOR_Q_CS,         m_heatPipes.Q_CS/1000);//

    setSensorValue(sensors, ID_SENSOR_momentTES,         m_heatPipes.momentTES/1000);//
    setSensorValue(sensors, ID_SENSOR_momentCS,         m_heatPipes.momentCS/1000);//

    return GPA_RESULT_OK;
}
gpaResult gpaTDBaseVerSimple::checkParamValues(const gpaExtParameter *values) const
{
    (void)values;
    return GPA_RESULT_OK;
}

void gpaTDBaseVerSimple::setNames()
{
    m_heatPipes.setName("pipes");
}

gpaResult gpaTDBaseVerSimple::initMixtureFlow(const gpaExtParameter *values)
{
    // Назначаем параметры проточных элементов
    bool good = true;
    return GPA_RESULT_OK;
}

gpaResult gpaTDBaseVerSimple::setParamValues(const gpaExtParameter *values, bool checkNeeded)
{

    //Передача введенных параметров
    m_heatPipes.k_delta_H_TES = values[ID_PARAM_k_delta_H_TES].value.realValue;
    m_heatPipes.k_delta_H_CS  = values[ID_PARAM_k_delta_H_CS].value.realValue;

    m_heatPipes.name_case     = to_string(int(values[ID_PARAM_numb_case].value.realValue));

    m_heatPipes.omegaInit     = values[ID_PARAM_omegaInit].value.realValue;
    m_heatPipes.I_shaft       = values[ID_PARAM_I_shaft].value.realValue;

    m_heatPipes.isNeedApproxCurvesNewRegime      = values[ID_PARAM_isNeedApproxCurvesNewRegime].value.realValue;

    if(values[ID_PARAM_isNeedApproxCurvesNewRegime].value.realValue==2)
    {
        m_heatPipes.p_curve_TES.m_Dot_Points[0] = values[ID_PARAM_TES_mdot_1].value.realValue;
        m_heatPipes.p_curve_TES.m_Dot_Points[1] = values[ID_PARAM_TES_mdot_2].value.realValue;
        m_heatPipes.p_curve_TES.m_Dot_Points[2] = values[ID_PARAM_TES_mdot_3].value.realValue;
        m_heatPipes.p_curve_TES.m_Dot_Points[3] = values[ID_PARAM_TES_mdot_4].value.realValue;
        m_heatPipes.p_curve_TES.m_Dot_Points[4] = values[ID_PARAM_TES_mdot_5].value.realValue;
        m_heatPipes.p_curve_TES.pressure_Points[0] = values[ID_PARAM_TES_P_1].value.realValue;
        m_heatPipes.p_curve_TES.pressure_Points[1] = values[ID_PARAM_TES_P_2].value.realValue;
        m_heatPipes.p_curve_TES.pressure_Points[2] = values[ID_PARAM_TES_P_3].value.realValue;
        m_heatPipes.p_curve_TES.pressure_Points[3] = values[ID_PARAM_TES_P_4].value.realValue;
        m_heatPipes.p_curve_TES.pressure_Points[4] = values[ID_PARAM_TES_P_5].value.realValue;

        m_heatPipes.p_curve_CS.m_Dot_Points[0] = values[ID_PARAM_CS_mdot_1].value.realValue;
        m_heatPipes.p_curve_CS.m_Dot_Points[1] = values[ID_PARAM_CS_mdot_2].value.realValue;
        m_heatPipes.p_curve_CS.m_Dot_Points[2] = values[ID_PARAM_CS_mdot_3].value.realValue;
        m_heatPipes.p_curve_CS.m_Dot_Points[3] = values[ID_PARAM_CS_mdot_4].value.realValue;
        m_heatPipes.p_curve_CS.m_Dot_Points[4] = values[ID_PARAM_CS_mdot_5].value.realValue;
        m_heatPipes.p_curve_CS.pressure_Points[0] = values[ID_PARAM_CS_P_1].value.realValue;
        m_heatPipes.p_curve_CS.pressure_Points[1] = values[ID_PARAM_CS_P_2].value.realValue;
        m_heatPipes.p_curve_CS.pressure_Points[2] = values[ID_PARAM_CS_P_3].value.realValue;
        m_heatPipes.p_curve_CS.pressure_Points[3] = values[ID_PARAM_CS_P_4].value.realValue;
        m_heatPipes.p_curve_CS.pressure_Points[4] = values[ID_PARAM_CS_P_5].value.realValue;


        m_heatPipes.p_curve_TES.const_pressure_on_one_port = values[ID_PARAM_TES_fun_In_exp].value.realValue;
        m_heatPipes.p_curve_TES.nom_m_dot                  = values[ID_PARAM_TES_m_dot_Nom] .value.realValue;
        m_heatPipes.p_curve_TES.nom_omega                  = values[ID_PARAM_TES_omega_Nom] .value.realValue;

        m_heatPipes.p_curve_CS.const_pressure_on_one_port = values[ID_PARAM_CS_fun_In_exp].value.realValue;
        m_heatPipes.p_curve_CS.nom_m_dot                  = values[ID_PARAM_CS_m_dot_Nom] .value.realValue;
        m_heatPipes.p_curve_CS.nom_omega                  = values[ID_PARAM_CS_omega_Nom] .value.realValue;

        m_heatPipes.p_curve_TES.omega_coef_A              = values[ID_PARAM_TES_omega_coef_A] .value.realValue;
        m_heatPipes.p_curve_TES.omega_coef_B              = values[ID_PARAM_TES_omega_coef_B] .value.realValue;
        m_heatPipes.p_curve_CS.omega_coef_A               = values[ID_PARAM_CS_omega_coef_A]  .value.realValue;
        m_heatPipes.p_curve_CS.omega_coef_B               = values[ID_PARAM_CS_omega_coef_B]  .value.realValue;
    }

    if(values[ID_PARAM_isNeedApproxCurvesNewRegime].value.realValue>2)
    {
        m_heatPipes.delInt_TES.m_dot[0] = values[ID_PARAM_TES_mdot_1].value.realValue;
        m_heatPipes.delInt_TES.m_dot[1] = values[ID_PARAM_TES_mdot_2].value.realValue;
        m_heatPipes.delInt_TES.m_dot[2] = values[ID_PARAM_TES_mdot_3].value.realValue;
        m_heatPipes.delInt_TES.m_dot[3] = values[ID_PARAM_TES_mdot_4].value.realValue;
        m_heatPipes.delInt_TES.m_dot[4] = values[ID_PARAM_TES_mdot_5].value.realValue;

        m_heatPipes.delInt_TES.pressure[0] = values[ID_PARAM_TES_P_1].value.realValue;
        m_heatPipes.delInt_TES.pressure[1] = values[ID_PARAM_TES_P_2].value.realValue;
        m_heatPipes.delInt_TES.pressure[2] = values[ID_PARAM_TES_P_3].value.realValue;
        m_heatPipes.delInt_TES.pressure[3] = values[ID_PARAM_TES_P_4].value.realValue;
        m_heatPipes.delInt_TES.pressure[4] = values[ID_PARAM_TES_P_5].value.realValue;

        m_heatPipes.delInt_CS.m_dot[0] = values[ID_PARAM_CS_mdot_1].value.realValue;
        m_heatPipes.delInt_CS.m_dot[1] = values[ID_PARAM_CS_mdot_2].value.realValue;
        m_heatPipes.delInt_CS.m_dot[2] = values[ID_PARAM_CS_mdot_3].value.realValue;
        m_heatPipes.delInt_CS.m_dot[3] = values[ID_PARAM_CS_mdot_4].value.realValue;
        m_heatPipes.delInt_CS.m_dot[4] = values[ID_PARAM_CS_mdot_5].value.realValue;

        m_heatPipes.delInt_CS.pressure[0] = values[ID_PARAM_CS_P_1].value.realValue;
        m_heatPipes.delInt_CS.pressure[1] = values[ID_PARAM_CS_P_2].value.realValue;
        m_heatPipes.delInt_CS.pressure[2] = values[ID_PARAM_CS_P_3].value.realValue;
        m_heatPipes.delInt_CS.pressure[3] = values[ID_PARAM_CS_P_4].value.realValue;
        m_heatPipes.delInt_CS.pressure[4] = values[ID_PARAM_CS_P_5].value.realValue;

        m_heatPipes.curve_Pout_TES.fun_In_exp = values[ID_PARAM_TES_fun_In_exp].value.realValue;
        m_heatPipes.curve_Pout_TES.m_dot_Nom  = values[ID_PARAM_TES_m_dot_Nom] .value.realValue;

        m_heatPipes.curve_Pout_CS.fun_In_exp  = values[ID_PARAM_CS_fun_In_exp] .value.realValue;
        m_heatPipes.curve_Pout_CS.m_dot_Nom   = values[ID_PARAM_CS_m_dot_Nom]  .value.realValue;

    }

    // Проверка параметров, если требуется
    if (checkNeeded)
    {
        gpaResult res = checkParamValues(values);
        if (res != GPA_RESULT_OK)
            return res;
    }
    // Даем названия элементам и потокам
    setNames();
    // Инициализируются элементы с потоком смеси
    gpaResult res = initMixtureFlow(values);
    if (res != GPA_RESULT_OK)
        return res;
    // Обновляем параметры воздуха на входе
    return res;
}

gpaResult gpaTDBaseVerSimple::buildDevice()
{
    bool good = true;
    // Соединяем поток смеси по трубам с граничными потоками смеси системы
    good = good && m_heatPipes.connectMixStream(GPA_ELEM_CIRCUIT_0, ID_PORT_GAS_INLET,  getEdgeMixStream(ID_CIRCUIT,   ID_PORT_GAS_INLET),  GPA_STREAM_INLET);
    good = good && m_heatPipes.connectMixStream(GPA_ELEM_CIRCUIT_0, ID_PORT_GAS_OUTLET, getEdgeMixStream(ID_CIRCUIT,   ID_PORT_GAS_OUTLET), GPA_STREAM_OUTLET);
    good = good && m_heatPipes.connectMixStream(GPA_ELEM_CIRCUIT_1, ID_PORT_OIL_INLET,  getEdgeMixStream(ID_CIRCUIT_2, ID_PORT_OIL_INLET),  GPA_STREAM_INLET);
    good = good && m_heatPipes.connectMixStream(GPA_ELEM_CIRCUIT_1, ID_PORT_OIL_OUTLET, getEdgeMixStream(ID_CIRCUIT_2, ID_PORT_OIL_OUTLET), GPA_STREAM_OUTLET);
    if (!good)
        return GPA_ERROR_WRONG_ARGS;
    // Добавляем в систему все элементы и потоки
    setElements({&m_heatPipes});
    setStreams({});
    return GPA_RESULT_OK;
}

gpaResult gpaTDBaseVerSimple::initialize()
{
    // Подключить экспортируемый элемент к потокам в интеграторе
    gpaResult res = linkToCoreStreams();
    if (res != GPA_RESULT_OK)
        return res;
    // Соединяем все элементы друг с другом
    res = buildDevice();
    if (res != GPA_RESULT_OK)
        return res;
    // Создаем схемы течений (нужны соединенные элементы)
    if (!createSimStructures({}, {getOuterEntrance(ID_CIRCUIT, ID_PORT_GAS_INLET),
                                  getOuterEntrance(ID_CIRCUIT_2, ID_PORT_OIL_INLET)}))
        return GPA_ERROR_WRONG_ARGS;
    // Инициализируем систему
    return gpaExportSystem::initialize();
}

gpaResult gpaTDBaseVerSimple::setSignals(const gpaConstVector &signals)
{
    gpaReal value;
    bool good = true;

    if (getSignalValue(signals, ID_PARAM_omegaInit, value))
    m_heatPipes.omegaInit               = value;

    return GPA_RESULT_OK;
}
const gpaString* gpaTDBaseVerSimple::getDeviceMixCircuitName(gpaUInt index)
{
    return index < NUM_CIRCUITS ? &m_circuitNames[index] : NULL;
}
const gpaString* gpaTDBaseVerSimple::getDeviceMixPortName(gpaUInt circIdx, gpaUInt portIdx)
{
    return portIdx + circIdx*2 < 4 ? &m_portNames[portIdx + circIdx*2] : NULL;
}





