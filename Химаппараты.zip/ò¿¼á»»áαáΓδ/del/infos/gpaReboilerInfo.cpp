#include "gpaReboilerInfo.h"
#include "gpaReboiler.h"

gpaReboilerInfo::gpaReboilerInfo() : gpaDeviceInfo(gpaReboiler::getDeviceTypeName(),
                                                   gpaReboiler::getDeviceDescription())
{
    setParameters(gpaReboiler::getParametersInfo());
    setSensors(gpaReboiler::getSensorsInfo());
}

gpaUInt gpaReboilerInfo::getNumMixCircuits() const
{
    return gpaReboiler::getDeviceNumMixCircuits();
}

gpaUInt gpaReboilerInfo::getMinNumMixPorts(gpaUInt index) const
{
    return gpaReboiler::getDeviceMinNumMixPorts(index);
}

gpaUInt gpaReboilerInfo::getMaxNumMixPorts(gpaUInt index) const
{
    return gpaReboiler::getDeviceMaxNumMixPorts(index);
}

const gpaString *gpaReboilerInfo::getMixPortName(gpaUInt circIdx, gpaUInt portIdx) const
{
    return gpaReboiler::getDeviceMixPortName(circIdx, portIdx);
}

const gpaString *gpaReboilerInfo::getMixCircuitName(gpaUInt index) const
{
    return gpaReboiler::getDeviceMixCircuitName(index);
}

gpaElement *gpaReboilerInfo::createDevice(const gpaCoreInterfaces *interfaces, gpaCoreReference pairDevice,
                                          const gpaExtObjectModel *model) const
{
    gpaReboiler *cooler = new gpaReboiler(interfaces, pairDevice);
    gpaResult res = cooler->specifyModel(model);
    if (res == GPA_RESULT_OK)
        return cooler;
    delete cooler;
    return NULL;
}
