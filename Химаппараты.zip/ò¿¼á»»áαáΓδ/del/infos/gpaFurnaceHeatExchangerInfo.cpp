#include "gpaFurnaceHeatExchangerInfo.h"
#include "gpaFurnaceHeatExchanger.h"

gpaFurnaceHeatExchangerInfo::gpaFurnaceHeatExchangerInfo() :
    gpaDeviceInfo  (gpaFurnaceHeatExchanger::getDeviceTypeName(),
                    gpaFurnaceHeatExchanger::getDeviceDescription())
{
    setParameters(gpaFurnaceHeatExchanger::getParametersInfo());
    setSensors(gpaFurnaceHeatExchanger::getSensorsInfo());
}

gpaUInt gpaFurnaceHeatExchangerInfo::getNumMixCircuits() const
{
    return gpaFurnaceHeatExchanger::getDeviceNumMixCircuits();
}

gpaUInt gpaFurnaceHeatExchangerInfo::getMinNumMixPorts(gpaUInt index) const
{
    return gpaFurnaceHeatExchanger::getDeviceMinNumMixPorts(index);
}

gpaUInt gpaFurnaceHeatExchangerInfo::getMaxNumMixPorts(gpaUInt index) const
{
    return gpaFurnaceHeatExchanger::getDeviceMaxNumMixPorts(index);
}
const gpaString *gpaFurnaceHeatExchangerInfo::getMixPortName(gpaUInt circIdx, gpaUInt portIdx) const
{
    return gpaFurnaceHeatExchanger::getDeviceMixPortName(circIdx, portIdx);
}

const gpaString *gpaFurnaceHeatExchangerInfo::getMixCircuitName(gpaUInt index) const
{
    return gpaFurnaceHeatExchanger::getDeviceMixCircuitName(index);
}



gpaElement* gpaFurnaceHeatExchangerInfo::createDevice(const gpaCoreInterfaces* interfaces, gpaCoreReference pairDevice,
                                             const gpaExtObjectModel* model) const
{
    gpaFurnaceHeatExchanger* cooler = new gpaFurnaceHeatExchanger(interfaces, pairDevice);
    gpaResult res = cooler->specifyModel(model);
    if (res == GPA_RESULT_OK)
        return cooler;
    delete cooler;
    return NULL;
}
