#ifndef GPA_GB_VER_2_Element_H
#define GPA_GB_VER_2_Element_H
#include "gpaFlowElement.h"
#include "gpaHeatLayer.h"
#include "gpaInclude.h"
#include <fstream>
#include <iostream>
#include <numbers>
using namespace std;

#include <vector>

#include <string>

#include <filesystem>

using namespace std;
namespace fs = std::filesystem;

class PolynomialLeastSquares {
private:
  // Решение системы линейных уравнений методом Гаусса
  std::vector<double> gaussElimination(std::vector<std::vector<double>> &A,
                                       std::vector<double> &B) {
    int n = B.size();

    // Прямой ход
    for (int i = 0; i < n; i++) {
      // Поиск максимального элемента в столбце
      double maxEl = fabs(A[i][i]);
      int maxRow = i;
      for (int k = i + 1; k < n; k++) {
        if (fabs(A[k][i]) > maxEl) {
          maxEl = fabs(A[k][i]);
          maxRow = k;
        }
      }

      // Перестановка строк
      for (int k = i; k < n; k++) {
        std::swap(A[maxRow][k], A[i][k]);
      }
      std::swap(B[maxRow], B[i]);

      // Приведение к треугольному виду
      for (int k = i + 1; k < n; k++) {
        double c = -A[k][i] / A[i][i];
        for (int j = i; j < n; j++) {
          if (i == j) {
            A[k][j] = 0;
          } else {
            A[k][j] += c * A[i][j];
          }
        }
        B[k] += c * B[i];
      }
    }

    // Обратный ход
    std::vector<double> x(n);
    for (int i = n - 1; i >= 0; i--) {
      x[i] = B[i] / A[i][i];
      for (int k = i - 1; k >= 0; k--) {
        B[k] -= A[k][i] * x[i];
      }
    }

    return x;
  }

public:
  int degree;

  std::vector<double> coefficients; // Коэффициенты полинома

  void fit(const std::vector<double> &x, const std::vector<double> &y) {
    if (x.size() != y.size() || x.empty()) {
      throw std::invalid_argument("Invalid input data");
    }

    int n = x.size();
    int m = degree + 1;

    // Создание матрицы системы уравнений
    std::vector<std::vector<double>> A(m, std::vector<double>(m, 0.0));
    std::vector<double> B(m, 0.0);

    // Заполнение матрицы A и вектора B
    for (int k = 0; k < m; k++) {
      for (int j = 0; j < m; j++) {
        double sum = 0.0;
        for (int i = 0; i < n; i++) {
          sum += pow(x[i], j + k);
        }
        A[j][k] = sum;
      }

      double sum = 0.0;
      for (int i = 0; i < n; i++) {
        sum += y[i] * pow(x[i], k);
      }
      B[k] = sum;
    }

    // Решение системы уравнений
    coefficients = gaussElimination(A, B);
  }

  double predict(double x) const {
    double result = 0.0;
    for (int i = 0; i <= degree; i++) {
      result += coefficients[i] * pow(x, i);
    }
    return result;
  }

  double getRMSE(const std::vector<double> &x, const std::vector<double> &y) {
    // Расчет среднеквадратичной ошибки
    double rmse = 0.0;
    for (size_t i = 0; i < x.size(); i++) {
      double error = 100 * (predict(x[i]) - y[i]) / y[i];
      rmse += error * error;
    }
    rmse = 2 * pow(rmse / x.size(), 0.5);
    return rmse;
  }

  const std::vector<double> &getCoefficients() const { return coefficients; }
};

class GBChannel {

public:
  //----- Параметры из конфигурации режима необходимые для описания функции

  // Номинальная частота вращения, об/мин
  gpaReal nom_omega = 0;

  vector<gpaReal> coef_approx;

  // Точки для ручного ввода напорной хар-ки
  gpaReal m_Dot_Points[3] = {0, 0, 0};
  gpaReal pressure_Points[3] = {0, 0, 0};

  gpaReal delta_P_Points[3] = {0, 0, 0};

  gpaReal const_pressure_on_one_port = 0.0;

  bool GB_type = 0;

  gpaReal coef_A = 0;

  gpaReal T_in = 300;
  gpaReal P_in = 101;
  // Частота вращения, об/мин
  gpaReal omega = 500;
  // Массовый расход газа, тонн/ч
  gpaReal mass_flow = 1;
  // Объемный расход газа, м^3/ч
  gpaReal vol_flow = 1;

  //++++ Вспомогательные функции

  // Находит максимум
  gpaReal max(vector<double> x) {
    gpaReal max = 0;
    for (size_t i = 0; i < x.size(); i++) {
      if (x[i] > max) {
        max = x[i];
      }
    }

    return max;
  }

  // Находит минимум
  gpaReal min(vector<double> x) {
    gpaReal min = 1000;
    for (size_t i = 0; i < x.size(); i++) {
      if (x[i] < min) {
        min = x[i];
      }
    }

    return min;
  }

  // Функция округления
  gpaReal myRound(gpaReal x, gpaReal n) {
    return round(x * pow(10, n)) / pow(10, n);
  }

  //++++ Вспомогательные функции

  //+++++++++++++ Модификация данных режимов

  // Функция сигмойда
  gpaReal sigmoid(gpaReal x) { return 1.0 / (1.0 + std::exp(-x)); }

  // Расчет перепада давления
  void get_Approx_DeltaP_VS_m_Dot() {

    calc_deltaP_points();

    // Аппроксимация полиномом 2-й степени левой части кривых
    PolynomialLeastSquares plsL;
    plsL.degree = 2;
    // апрроксимация
    vector<gpaReal> m_Dot_Points2 = {0, 0, 0};

    for (size_t i = 0; i < 3; i++) {
      m_Dot_Points2[i] = m_Dot_Points[i];
    }
    vector<gpaReal> delta_P_Points2 = {0, 0, 0};

    for (size_t i = 0; i < 3; i++) {
      delta_P_Points2[i] = delta_P_Points[i];
    }

    plsL.fit(m_Dot_Points2, delta_P_Points2);
    coef_approx = plsL.coefficients;
  }

  gpaReal buildPolinom(vector<vector<gpaReal>> cM, gpaReal fr, gpaReal mf,
                       gpaReal m, gpaReal n) {
    gpaReal sum = 0;
    for (size_t i = 0; i < cM.size(); i++) {
      for (size_t j = 0; j < cM[0].size(); j++) {
        sum += cM[i][j] * pow(fr, j + m) * pow(mf, i + n);
      }
    }
    return sum;
  }

  gpaReal buildPolinomOneVar(vector<gpaReal> cM, gpaReal x) {
    gpaReal sum = 0;
    for (size_t i = 0; i < cM.size(); i++) {
      sum += cM[i] * pow(x, i);
    }
    return sum;
  }

  void calc_deltaP_points() {

    if (pressure_Points[0] < const_pressure_on_one_port) {
      for (size_t i = 0; i < 3; i++) {
        delta_P_Points[i] = const_pressure_on_one_port - pressure_Points[i];
      }
    } else {
      for (size_t i = 0; i < 3; i++) {
        delta_P_Points[i] = pressure_Points[i] - const_pressure_on_one_port;
      }
    }
  }

  void set_nom_omega() {
    nom_omega = (GB_type == 0) ? 730 : 14617;
  }

  // get DeltaP By task list
  gpaReal getDeltaP_TL() {

    if (GB_type == 0) {
      // mf = volflow

      vector<vector<gpaReal>> coef_List_fitsLow_Omega = {
          {193325., -612.287, 0.492421},
          {-1949.91, 6.13384, -0.00488782},
          {4.95989, -0.0155304, 0.0000122892}};
      vector<vector<gpaReal>> coef_List_fitsHigh_Omega = {
          {-134952., 207.601}, {1084.62, -1.67015}, {-2.18059, 0.00336087}};

      gpaReal fitsLow_Omega =
          buildPolinom(coef_List_fitsLow_Omega, omega, vol_flow, 0, 0);
      gpaReal fitsHigh_Omega =
          buildPolinom(coef_List_fitsHigh_Omega, omega, vol_flow, 0, 0);

      gpaReal sm = sigmoid(0.3 * (omega - 670));

      return (fitsLow_Omega * (1 - sm) + sm * fitsHigh_Omega);

    } else {

      // mf = massFlow
      nom_omega = 14617;

      // fr scaling
      gpaReal relOmega = (omega + 0.001) / nom_omega;

      return relOmega * relOmega *
             (get_P_out_TL_mf(mass_flow / relOmega) - P_in / 1000) * 1000;
    }
  }

  gpaReal get_P_out_TL_mf(gpaReal mf) {

    gpaReal shift_P =
        -2.37522 + 1.40169 * P_in / 1000 - 0.00315636 * (T_in - 273);
    gpaReal shift_m_dot =
        21.3814 - 14.0919 * P_in / 1000 + 0.101585 * (T_in - 273);

    vector<gpaReal> coef_Approx_TL = {1.94306, 0.0482797, -0.00199361,
                                      +0.000017512};

    // p_out, МПа
    gpaReal p_out =
        (buildPolinomOneVar(coef_Approx_TL, mf - shift_m_dot) + shift_P);

    // L&R points on base curve
    gpaReal p_out_L = 2.374 - 0.001682950 * mf;
    gpaReal p_out_R = 2.890 - 0.0245 * mf;

    gpaReal sm = sigmoid(mf - 16);
    gpaReal sm2 = sigmoid(mf - 32);

    // extrapolation curve
    gpaReal p_out_sm_L = p_out_L * (1 - sm) + sm * p_out;

    return p_out_sm_L * (1 - sm2) + sm2 * p_out_R;
  }

  // get DeltaP By task list
  gpaReal getDeltaP_Manual() {

    if (GB_type == 0) {
      gpaReal relOmega = (omega - nom_omega) / nom_omega;
      // mf = volflow
      return buildPolinomOneVar(coef_approx, vol_flow) *
             (1 - coef_A * relOmega);
    } else {
      gpaReal relOmega = (omega - nom_omega) / nom_omega;
      // mf = mass_flow
      gpaReal sm = sigmoid(mass_flow - 16);
      return (2340 - 1825) * (1 - sm) +
             sm * buildPolinomOneVar(coef_approx, mass_flow) *
                 (1 - coef_A * relOmega);
    }
  }
};

class gpaGBVER2Element : public gpaFlowElement {
public:
  // не убирать
  gpaGBVER2Element(const gpaParentLink *link)
      : m_gasEnthalpy(0), m_liquidEnthalpy(0), m_liquidFlowRate(0),
        m_temperature(0) {

    setMixCircuit(new gpaElementMixCircuit(this, GPA_ELEM_CIRCUIT_0));
    m_d = 0.5;
    m_l = 2.0;
    m_dh = 0.3;
    m_nBends = 2;
    m_eps = 0.0001;
    m_Tenv = 293.15;
    m_heatLayers.push_back(gpaHeatLayer{0.02, 7800, 16.0, 460});
    m_alpha_in_pipe = m_alpha_out_pipe = m_alpha_in_gas = m_alpha_out_gas =
        100.0;
    calcThermalParams();
  }
  gpaGBVER2Element(const gpaGBVER2Element &m_heatPipes) {
    m_gasEnthalpy = m_heatPipes.m_gasEnthalpy;
    m_liquidEnthalpy = m_heatPipes.m_liquidEnthalpy;
    m_liquidFlowRate = m_heatPipes.m_liquidFlowRate;
    m_temperature = m_heatPipes.m_temperature;
    m_d = m_heatPipes.m_d;
    m_l = m_heatPipes.m_l;
    m_dh = m_heatPipes.m_dh;
    m_nBends = m_heatPipes.m_nBends;
    m_eps = m_heatPipes.m_eps;
    m_Tenv = m_heatPipes.m_Tenv;
    m_heatLayers = m_heatPipes.m_heatLayers;

    m_alpha_in_pipe = m_heatPipes.m_alpha_in_pipe;
    m_alpha_out_pipe = m_heatPipes.m_alpha_out_pipe;
    m_alpha_in_gas = m_heatPipes.m_alpha_in_gas;
    m_alpha_out_gas = m_heatPipes.m_alpha_out_gas;
    calcThermalParams();
  }
  virtual gpaGBVER2Element *copy() const override {
    return new gpaGBVER2Element(*this);
  }
  // не убирать

  virtual gpaUInt getMinNumMixPorts(gpaUInt index) const override {
    return getDeviceMinNumMixPorts(index);
  }
  static gpaUInt getDeviceMinNumMixPorts(gpaUInt index) {
    if (index == GPA_ELEM_CIRCUIT_0) {
      return 2;
    }
    return 0;
  }
  static gpaUInt getDeviceNumMixCircuits() { return 1; }
  virtual gpaUInt getNumMixCircuits() const  override { return 1; }
  virtual gpaUInt getMaxNumMixPorts(gpaUInt index) const override {
    return getDeviceMaxNumMixPorts(index);
  }
  static gpaUInt getDeviceMaxNumMixPorts(gpaUInt index) {
    if (index == GPA_ELEM_CIRCUIT_0) {
      return 2;
    }
    return 0;
  }

  //+++++++++++ Инициализация переменных

  // Кол-во переменных
  gpaUInt getNumVariables() const override { return 1; }

  // Нумирация переменных
  enum {
    OMEGA = 0,
  };

  void fillVarNames(gpaStringVector &varNames) const override {}

  // Задаем начальные условия для переменнных
  gpaResult initVariables(gpaVector &variables) const override {
    variables[OMEGA] = omegaInit / 60; //;

    return GPA_RESULT_OK;
  }

  //++++++++++++ Инициализация переменных

  //+++++++++++++ Инициализация остального

  //+++++++++++++ Функции для работы с файлами

  //+++++++++++++ Функции для работы с файлами

  // Главная функция инициалзации
  gpaResult initialize() override {
    initFlows();
    initMedium();

    gb_channel.set_nom_omega();
    if (numb_calc_delta_P_regime == 1) {
      gb_channel.get_Approx_DeltaP_VS_m_Dot();
    }

    // while (1>0)
    // {
    //     /* code */
    // }

    // exportCurrentBiblProps(dataBaseWay);
    // exportBiblPropsInSomePoints();

    return GPA_RESULT_OK;
  }

  void exportBiblPropsInSomePoints() {
    vector<gpaString> name_Mix = {"303BL", "103BL", "303PL", "103PL"};

    vector<gpaDataVector> fracs = {{14.1557, 55.0275, 30.6629, 0.1431},
                                   {21.388, 50.79, 27.6879, 0.1243},
                                   {5.132, 94.7719, 0.0934, 0.0025},
                                   {5.7217, 94.1831, 0.0921, 0.0025}};

    vector<gpaReal> tempIn = {-5.9, -9.059, -41.15, -41.15};
    vector<gpaReal> tempOut = {12.9, 10.37, -17.9, -17.87};
    vector<gpaReal> tempMean = {0, 0, 0, 0};

    for (size_t i = 0; i < tempIn.size(); i++) {
      tempMean[i] = (tempIn[i] + tempOut[i]) / 2;
    }

    gpaReal pIn = 101 + 5;
    gpaReal pOut = pIn + 90;
    gpaReal pMean = pIn + 90 / 2;

    for (size_t i = 0; i < name_Mix.size(); i++) {
      vector<gpaReal> tempMix = {tempIn[i], tempMean[i], tempOut[i]};
      for (size_t i = 0; i < tempMix.size(); i++) {
        tempMix[i] += 273.15;
      }

      exportCurrentBiblProps(name_Mix[i],
                             fs::current_path().string() + "\\libs\\dbTDA\\",
                             tempMix, {pIn, pMean, pOut}, fracs[i]);
    }
  }

  // Запись матрицы в CSV файл
  bool writeMatrixToCSV(const vector<vector<double>> &matrix,
                        const string &filename, char delimiter = ',',
                        int precision = 3, bool includeHeaders = false,
                        const vector<string> &rowHeaders = {},
                        const vector<string> &colHeaders = {}) {

    ofstream file(filename);

    if (!file.is_open()) {
      cerr << "Ошибка: не удалось открыть файл " << filename << " для записи"
           << endl;
      return false;
    }

    // Устанавливаем точность вывода
    file << scientific << setprecision(precision);

    int rows = matrix.size();
    if (rows == 0) {
      cerr << "Ошибка: пустая матрица" << endl;
      file.close();
      return false;
    }

    int cols = matrix[0].size();

    // Проверка корректности матрицы (все строки одинаковой длины)
    for (int i = 1; i < rows; i++) {
      if (matrix[i].size() != static_cast<size_t>(cols)) {
        cerr << "Ошибка: строки матрицы имеют разную длину" << endl;
        file.close();
        return false;
      }
    }

    // Записываем заголовки столбцов (если нужно)
    if (includeHeaders && !colHeaders.empty()) {
      // Если есть заголовки строк, первая ячейка пустая
      if (!rowHeaders.empty()) {
        file << delimiter;
      }

      // Записываем заголовки столбцов
      for (int j = 0; j < cols; j++) {
        if (j < static_cast<int>(colHeaders.size())) {
          // Если в заголовках есть запятые, заключаем в кавычки
          if (colHeaders[j].find(delimiter) != string::npos) {
            file << "\"" << colHeaders[j] << "\"";
          } else {
            file << colHeaders[j];
          }
        } else {
          file << "Column_" << (j + 1);
        }

        if (j < cols - 1) {
          file << delimiter;
        }
      }
      file << endl;
    }

    // Записываем данные матрицы
    for (int i = 0; i < rows; i++) {
      // Заголовок строки (если есть)
      if (includeHeaders && !rowHeaders.empty()) {
        if (i < static_cast<int>(rowHeaders.size())) {
          // Если в заголовках есть запятые, заключаем в кавычки
          if (rowHeaders[i].find(delimiter) != string::npos) {
            file << "\"" << rowHeaders[i] << "\"";
          } else {
            file << rowHeaders[i];
          }
        } else {
          file << "Row_" << (i + 1);
        }
        file << delimiter;
      }

      // Элементы строки матрицы
      for (int j = 0; j < cols; j++) {
        file << matrix[i][j];
        if (j < cols - 1) {
          file << delimiter;
        }
      }
      file << endl;
    }

    file.close();

    if (file.fail()) {
      cerr << "Ошибка при записи в файл" << endl;
      return false;
    }

    return true;
  }

  // Проверка существования директории (кросс-платформенная)
  bool directoryExists(const string &path) {
    return fs::exists(path) && fs::is_directory(path);
  }

  // Создание директории (кросс-платформенная)
  bool createDirectory(const string &path) {
    try {
      return fs::create_directory(path);
    } catch (const fs::filesystem_error &e) {
      cerr << "Ошибка при создании директории: " << e.what() << endl;
      return false;
    }
  }

  void exportCurrentBiblProps(string name_Mix, string way, vector<gpaReal> temp,
                              vector<gpaReal> pressure, gpaDataVector fract) {

    vector<vector<gpaReal>> parsVST;
    vector<gpaReal> pars = {0, 0, 0, 0, 0, 0};

    for (gpaInt nPoint = 0; nPoint < temp.size(); nPoint = nPoint + 1) {
      m_medium_CS_inlet->calcFlashPT(pressure[nPoint], temp[nPoint], fract);

      pars[0] = temp[nPoint];
      pars[1] = m_medium_CS_inlet->getConductivity();
      pars[2] = m_medium_CS_inlet->getDensity();
      pars[3] = m_medium_CS_inlet->getViscosity();
      pars[4] = m_medium_CS_inlet->getHeatCapacity() /
                m_medium_CS_inlet->getMolarMass();
      pars[5] = m_medium_CS_inlet->getMolarMass();

      parsVST.push_back(pars);
    }
    gpaString nameExport_CM = name_Mix + " .csv";
  }

  gpaResult fillMassMatrix(gpaUInt refRow, gpaUInt refCol) const override{
    gpaResult res = setMassMatrCoef(refRow, refCol, 1.0);
    if (res != GPA_RESULT_OK)
      return res;
    return GPA_RESULT_OK;
  }

  // Инициализация среды
  void initMedium() {
    m_medium_CS_inlet = inlet_CS->getStreamMedium()->copyTo(asOwner());
    m_medium_CS_outlet_star = out_CS->getStreamMedium()->copyTo(asOwner());
  }

  // Инициализация потоков
  void initFlows() {
    circuit_CS = getMixCircuit(GPA_ELEM_CIRCUIT_0);

    inlet_CS = circuit_CS->getPort(0);
    out_CS = circuit_CS->getPort(1);
  }

  //+++++++++++++++++ Инициализация остального

  //+++++++++++++++++ Функции, которые будут использоваться на каждой итерации

  //+++ Расчет свойств потоков
  void calcFlowProperties() {

    T_in_CS = inlet_CS->getStreamTemperature();

    T_out_CS = out_CS->getStreamTemperature();

    // Get G&P
    G_in_CS = inlet_CS->getIncomingFlowRate();
    P_in_CS = inlet_CS->getStreamPressure();

    G_out_CS = out_CS->getIncomingFlowRate();
    P_out_CS = out_CS->getStreamPressure();

    m_dot_CS = inlet_CS->getIncomingMassRate();
  }
  //+++ Расчет свойств потоков

  //+++ Расчет теплообмена

  // Функция сигмойда
  gpaReal sigmoid(gpaReal x) { return 1.0 / (1.0 + std::exp(-x)); }

  // Расчет перепада давления
  void calcDeltaPress() {
    gb_channel.omega = 60 * omega;
    gb_channel.mass_flow = 3.6 * m_dot_CS;
    gb_channel.vol_flow = 60 * inlet_CS->getIncomingVolRate();
    gb_channel.T_in = T_in_CS;
    gb_channel.P_in = P_in_CS;

    deltaP_CS = (numb_calc_delta_P_regime == 0) ? gb_channel.getDeltaP_TL()
                                                : gb_channel.getDeltaP_Manual();

    gpaReal smVal = sigmoid(30 * (gb_channel.mass_flow - 5));
    // deltaP_CS =  - deltaP_CS * smVal + (1-smVal) * (0.05 -
    // gb_channel.mass_flow/100);

    deltaP_CS = -deltaP_CS;
  }

  // Расчет теплообмена
  void calcQ() {
    // Свойства входного потока
    gpaReal h_in_CS = inlet_CS->getStreamEnthalpy();
    gpaReal rho_in_CS = inlet_CS->getStreamDensity();

    m_medium_CS_inlet->calcFlashPH(P_in_CS, h_in_CS,
                                   inlet_CS->getStreamFractions());
    gpaReal S_in_CS = m_medium_CS_inlet->getEntropy();

    gpaReal p_after_CS = P_in_CS - deltaP_CS + 0.01;

    gpaReal polit_eta_CS = 0; // good
    gpaReal polit_eta_CS_coef[3] = {0.350499, 0.0464187, -0.00124533}; // mf tonn/h

    gpaReal polit_eta_CS_coef_2[3] = {0.665322, 0.00668781, 0}; // mf tonn/h

    gpaReal sm = sigmoid(3.6 * m_dot_CS - 16);

    for (size_t i = 0; i < 3; i++) {
      polit_eta_CS +=
          (polit_eta_CS_coef[i] * sm + (1 - sm) * polit_eta_CS_coef_2[i]) *
          pow(3.6 * m_dot_CS, i);
    }

    gpaReal adiab_eta_CS = polit_eta_CS;

    // Параметры выходящего потока, если было бы идиальное сжатие
    m_medium_CS_outlet_star->calcFlashPS(p_after_CS, S_in_CS,
                                         inlet_CS->getStreamFractions());

    gpaReal h_tilda_out_CS = m_medium_CS_outlet_star->getEnthalpy();

    if (-deltaP_CS > 1) {

      gpaReal rho_tilda_out_CS = m_medium_CS_outlet_star->getDensity();

      // Параметры выходящего из аппарата потока

      m_medium_CS_outlet_star->calcFlashPH(
          p_after_CS, h_in_CS + (h_tilda_out_CS - h_in_CS) / (polit_eta_CS),
          inlet_CS->getStreamFractions());

      gpaReal rho_out_CS = m_medium_CS_outlet_star->getDensity();

      k_out_cs = log(p_after_CS / (P_in_CS + 0.001)) /
                 log(rho_tilda_out_CS / (rho_in_CS + 0.001)); // good
      n_out_cs = log(p_after_CS / (P_in_CS + 0.001)) /
                 log(rho_out_CS / (rho_in_CS + 0.001));

      k_out_cs = k_out_cs < 2 ? k_out_cs : 1.2;
      n_out_cs = n_out_cs < 2 ? n_out_cs : 1.3;

      gpaReal adiab_eta_CS =
          polit_eta_CS *
          (pow(p_after_CS / P_in_CS, (k_out_cs - 1) / k_out_cs) - 1) /
          (pow(p_after_CS / P_in_CS, (n_out_cs - 1) / n_out_cs) - 1) *
          ((n_out_cs - 1) / n_out_cs) * (k_out_cs / (k_out_cs - 1));
    }

    // Теплообмен
    Delta_H_CS = (h_tilda_out_CS - h_in_CS) / (adiab_eta_CS);

    // Расчет моментов вращения
    Q_EM = -EM_Power * 1000;
    Q_CS = G_in_CS * Delta_H_CS * 1000;

    // Расчет моментов вращения
    momentEM = Q_EM / (omega + 0.001);
    momentCS = Q_CS / (omega + 0.001);
  }

  // Главная функция: полный набор уравнений для "стрелок" и фазового равновесия
  gpaResult calcFuncValues(const gpaConstVector &,
                           const gpaConstVector &variables, gpaVector &values,
                           const gpaSetOfEquations &eqIds) override {

    calcFlowProperties();

    // Переименовал для удобства неизвестые перемеые.
    omega = variables[OMEGA];
    //++ Пересчет различных переменных

    calcDeltaPress();
    calcQ();

    //++ Пересчет различных переменных

    //++ Формирование уравнений для невязок

    values[0] = (momentEM + momentCS) / I_shaft;

    values[1] = P_in_CS - P_out_CS -
                coef_deltaP_Valve * m_dot_CS * abs(m_dot_CS) - deltaP_CS;
    values[2] = G_in_CS + G_out_CS;

    //++ Формирование уравнений для невязок

    return GPA_RESULT_OK;
  }

  // Невязка по энтальпии
  gpaResult calcEnthalpyFuncValueAt(gpaUInt circIdx, gpaUInt portIdx,
                                    gpaReal enthalpy,
                                    gpaReal &funcValue) const override {
    if (circIdx == GPA_ELEM_CIRCUIT_0) {
      const gpaMixPort *oppPort = getMixPort(GPA_ELEM_CIRCUIT_0, 1 - portIdx);
      if (!oppPort)
        return GPA_ERROR_WRONG_ARGS;
      funcValue =
          enthalpy - oppPort->getStreamMedium()->getEnthalpy() - Delta_H_CS;
      // printf("Enthalpy %d: %f\n", portIdx, funcValue);
      return GPA_RESULT_OK;
    }
    return GPA_ERROR_WRONG_ARGS;
  }

  // Невязка по компонентам — для выходных портов сравниваем с переменными
  // разделителя
  gpaResult calcFractionsFuncValuesAt(gpaUInt circIdx, gpaUInt portIdx,
                                      const gpaConstVector &fractions,
                                      gpaVector &funcValues) const override {
    if (circIdx == GPA_ELEM_CIRCUIT_0) {

      const gpaMixPort *oppPort = getMixCircuit(circIdx)->getPort(1 - portIdx);
      if (!oppPort)
        return GPA_ERROR_WRONG_ARGS;
      const gpaConstVector calcFractions =
          oppPort->getStreamMedium()->getFractions();
      for (gpaUInt i = 0; i < funcValues.size(); ++i)
        funcValues[i] = fractions[i] - calcFractions[i];
      // printf("Fractions %d\n", portIdx);
      //  for (gpaUInt i = 0; i < funcValues.size(); ++i)
      //      printf("%f--", funcValues[i]);
      // printf("\n");
      return GPA_RESULT_OK;
    }

    return GPA_ERROR_WRONG_ARGS;
  }

  virtual const gpaString &getTypeName() const override {
    return getDeviceTypeName();
  }
  virtual const gpaString &getDescription() const override {
    return getDeviceDescription();
  }

private:
  gpaElementMixCircuit *circuit_TES;
  gpaElementMixCircuit *circuit_CS;

  void calcThermalParams() {
    gpaReal d = m_d;
    gpaReal l = m_l;
    // PIPE (основная труба)
    m_R_pipe = 0;
    m_A_in_pipe = std::numbers::pi * d * l;
    gpaReal radius_inner = d / 2.0;
    for (const auto &layer : m_heatLayers) {
      gpaReal r1 = radius_inner;
      gpaReal r2 = r1 + layer.thickness;
      m_R_pipe += std::log(r2 / r1) /
                  (2 * std::numbers::pi * layer.heatConductivity * l);
      radius_inner = r2;
    }
    m_A_out_pipe = std::numbers::pi * (2 * radius_inner) * l;

    // GAS (газовая сторона, пусть конструкция аналогична)
    m_R_gas = m_R_pipe;
    m_A_in_gas = m_A_in_pipe;
    m_A_out_gas = m_A_out_pipe;
  }

public:
  // Переключатель библиотек
  gpaReal flagMixBibl = 0.0;

  // Параметры геометрии:
  gpaReal m_d = 0.0;       // внутренний диаметр (м)
  gpaReal m_l = 0.0;       // длина аппарата (м)
  gpaReal m_dh = 0.0;      // гидростат. напор (м)
  gpaReal m_nBends = 0.0;  // число колен
  gpaReal m_eps = 0.0;     // шероховатость (м)
  gpaReal m_Tenv = 298.15; // температура окружающей среды (К)

  gpaHeatLayerVector m_heatLayers;

  // PIPE (общая труба)
  gpaReal m_R_pipe = 1.0;
  gpaReal m_A_in = 0.0;
  gpaReal m_A_out = 0.0;
  gpaReal m_A_in_pipe = 0.0;
  gpaReal m_A_out_pipe = 0.0;
  gpaReal m_alpha_in_pipe = 0.0;
  gpaReal m_alpha_out_pipe = 0.0;

  // GAS (газовая)
  gpaReal m_R_gas = 1.0;
  gpaReal m_A_in_gas = 0.0;
  gpaReal m_A_out_gas = 0.0;
  gpaReal m_alpha_in_gas = 0.0;
  gpaReal m_alpha_out_gas = 0.0;
  gpaReal m_wall_diamet1;
  gpaReal m_wall_diamet2;
  gpaReal m_wall_diamet3;
  gpaReal m_hydro_coeff;
  gpaReal m_diametr;
  gpaReal m_wall_conductive1;
  gpaReal m_wall_conductive2;

  // Порты ступеней
  const gpaMixPort *inlet_CS;
  const gpaMixPort *out_CS;

  // Частота вращения начальная, об/сек
  gpaReal omegaInit;
  // Частота вращения текущая, об/сек
  gpaReal omega;

  // Момент инерции вала
  gpaReal I_shaft;

  gpaReal EM_Power = 6500;

  // Моменты
  gpaReal momentCS;
  gpaReal momentEM;

  // Тип расхода (0 - массовый, 1 - объемный)
  bool mdot_type = 0;
  // Вариант аппроксимации напорной кривой (0 - соглавно ОЛ, 1 - ручной ввод )
  gpaReal numb_calc_delta_P_regime;

  GBChannel gb_channel;

  // Теплообмен
  gpaReal k_delta_H_CS;
  gpaReal Delta_H_CS; //
  gpaReal Q_CS;
  gpaReal Q_EM;

  // Свойства потоков
  gpaReal P_in_CS;
  gpaReal P_out_CS;

  // Показатель адиабаты газа на выходе из канала КС
  gpaReal k_out_cs = 1.1;
  // Показатель политропы газа на выходе из канала КС
  gpaReal n_out_cs = 1.2;

  // Перепад давлений по КС
  gpaReal deltaP_CS;

  gpaReal coef_deltaP_Valve = 1;

  // Массовый расход входящего в КС, кг/c
  gpaReal m_dot_CS;

  // Мольные расходы
  gpaReal G_in_CS;
  gpaReal G_out_CS;

  // Temperature
  gpaReal T_in_CS;
  gpaReal T_out_CS;

  // Medium
  gpaMedium *m_medium_CS_inlet;
  gpaMedium *m_medium_CS_outlet_star;

  // Old
  gpaReal m_temperature = 0.0;
  gpaReal m_gasEnthalpy = 0.0;
  gpaReal m_liquidEnthalpy = 0.0;
  gpaReal m_liquidFlowRate = 0.0;

public:
  static const gpaString &getDeviceTypeName() { return m_typeName; }
  static const gpaString &getDeviceDescription() { return m_description; }

private:
  static const gpaString m_typeName;
  static const gpaString m_description;
  static const gpaSensorInfoVector m_sensors;
};
#endif
