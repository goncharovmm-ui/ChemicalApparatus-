#include "gpaInclude.h"
#include "gpaFurnaceHeatExchangerElement.h"

const gpaString gpaFurnaceHeatExchangerElement::m_typeName     = "furnace-heat-exchanger";
const gpaString gpaFurnaceHeatExchangerElement::m_description  = "  fgf";

gpaFurnaceHeatExchangerElement::gpaFurnaceHeatExchangerElement(
    const gpaParentLink *link)
    : m_gasEnthalpy(0), m_liquidEnthalpy(0), m_liquidFlowRate(0),
      m_temperature(0) {
  setMixCircuit(new gpaElementMixCircuit(this, GPA_ELEM_CIRCUIT_1));
  m_d = 0.5;
  m_l = 2.0;
  m_dh = 0.3;
  m_nBends = 2;
  m_eps = 0.0001;
  m_Tenv = 293.15;
  m_heatLayers.push_back(gpaHeatLayer{0.02, 7800, 16.0, 460});
  m_alpha_in_pipe = m_alpha_out_pipe = m_alpha_in_gas = m_alpha_out_gas =
      100.0;
  calcThermalParams();
}

gpaFurnaceHeatExchangerElement::gpaFurnaceHeatExchangerElement(
      const gpaFurnaceHeatExchangerElement &m_heatPipes) {
    m_gasEnthalpy = m_heatPipes.m_gasEnthalpy;
    m_liquidEnthalpy = m_heatPipes.m_liquidEnthalpy;
    m_liquidFlowRate = m_heatPipes.m_liquidFlowRate;
    m_temperature = m_heatPipes.m_temperature;
    m_d = m_heatPipes.m_d;
    m_l = m_heatPipes.m_l;
    m_dh = m_heatPipes.m_dh;
    m_nBends = m_heatPipes.m_nBends;
    m_eps = m_heatPipes.m_eps;
    m_Tenv = m_heatPipes.m_Tenv;
    m_heatLayers = m_heatPipes.m_heatLayers;

    m_alpha_in_pipe = m_heatPipes.m_alpha_in_pipe;
    m_alpha_out_pipe = m_heatPipes.m_alpha_out_pipe;
    m_alpha_in_gas = m_heatPipes.m_alpha_in_gas;
    m_alpha_out_gas = m_heatPipes.m_alpha_out_gas;
    calcThermalParams();
  }

gpaFurnaceHeatExchangerElement *gpaFurnaceHeatExchangerElement::copy() const {
    return new gpaFurnaceHeatExchangerElement(*this);
  }

gpaUInt gpaFurnaceHeatExchangerElement::getMinNumMixPorts(gpaUInt index) const {
    return getDeviceMinNumMixPorts(index);
  }

gpaUInt gpaFurnaceHeatExchangerElement::getDeviceMinNumMixPorts(gpaUInt index) {
    if (index == GPA_ELEM_CIRCUIT_0) {
      return 2;
    }
    if (index == GPA_ELEM_CIRCUIT_1) {
      return 2;
    }
    return 0;
  }

gpaUInt gpaFurnaceHeatExchangerElement::getDeviceNumMixCircuits() { return 2; }

gpaUInt gpaFurnaceHeatExchangerElement::getNumMixCircuits() const { return 2; }

gpaUInt gpaFurnaceHeatExchangerElement::getMaxNumMixPorts(gpaUInt index) const {
    return getDeviceMaxNumMixPorts(index);
  }

gpaUInt gpaFurnaceHeatExchangerElement::getDeviceMaxNumMixPorts(gpaUInt index) {
    if (index == GPA_ELEM_CIRCUIT_0) {
      return 2;
    }
    if (index == GPA_ELEM_CIRCUIT_1) {
      return 2;
    }
    return 0;
  }

gpaUInt gpaFurnaceHeatExchangerElement::getNumVariables() const { return 0; }

void gpaFurnaceHeatExchangerElement::fillVarNames(gpaStringVector &varNames) const {}

gpaResult gpaFurnaceHeatExchangerElement::initVariables(gpaVector &variables) const {
    // variables[TEMP_GAS_STAR] = temp_gas_star_zero;//872+273;
    // variables[TEMP_OIL_STAR] = temp_gas_oil_zero;//459+273;
    // variables[VOL_OIL] = 0;//459+273;
    return GPA_RESULT_OK;
  }

gpaResult gpaFurnaceHeatExchangerElement::initialize() {

    initFlows();

    initMedium();
    calcOutSurfArea();

    calcGeomParsGasPipeline();
    calcGeomParsHotOilPipeline();

    return GPA_RESULT_OK;
  }

void gpaFurnaceHeatExchangerElement::calcOutSurfArea() {

    if (burnerModel == 1) {
      // RC
      sAtmSideRC = 2.0 * (aRC + bRC + 4.0 * dIsoRC) * lPipeRC;
    }

    if (burnerModel == 2) {
      // RC
      sAtmSideRC = std::numbers::pi * (dRC + dIsoRC) * lPipeRC;
    }
  }

void gpaFurnaceHeatExchangerElement::calcGeomParsGasPipeline() {

    gpaReal DPipeRC;
    gpaReal sLSRC;
    gpaReal pWetRC;
    gpaReal dGasRC;

    if (burnerModel == 1) {
      // RC
      DPipeRC = dPipeRC + deltaPipeRC;
      sLSRC = aRC * bRC - 8 * nPipeRC * (std::numbers::pi * pow(DPipeRC, 2)) /
                              4; //(s_"жс")_"КР"
      pWetRC = std::numbers::pi * DPipeRC * 8 * nPipeRC + 2 * (aRC + bRC);
      dGasRC = 4 * sLSRC / pWetRC;
    }

    if (burnerModel == 2) {
      // RC
      DPipeRC = dPipeRC + deltaPipeRC;
      sLSRC = std::numbers::pi *
              (dRC * dRC / 4 -
               oilPipeRC.n_ch * nPipeRC * pow(DPipeRC, 2) / 4); //(s_"жс")_"КР"
      pWetRC = std::numbers::pi * (DPipeRC * oilPipeRC.n_ch * nPipeRC + dRC);
      dGasRC = 4 * sLSRC / pWetRC;
    }

    gasPipeRC.d_char = dGasRC;
    gasPipeRC.crossArea = sLSRC;
    gasPipeRC.l_ch = lPipeRC;
    gasPipeRC.epsilon = epsilonRC;
    gasPipeRC.deltaH = lPipeRC;

    // RC
  }

void gpaFurnaceHeatExchangerElement::calcGeomParsHotOilPipeline() {

    if (burnerModel == 1) {
      oilPipeRC.n_ch = 8.0;
    }

    if (burnerModel == 2) {
      oilPipeRC.n_ch = 4.0;
    }

    oilPipeRC.d_char = dPipeRC;
    oilPipeRC.crossArea = std::numbers::pi * pow(dPipeRC, 2.0) / 4.0;
    oilPipeRC.l_ch = nPipeRC * lPipeRC;
    oilPipeRC.epsilon = epsilonRC;
    oilPipeRC.deltaH = -lPipeRC;
    oilPipeRC.calcVolume();
  }

void gpaFurnaceHeatExchangerElement::initMedium() {

    m_medium_Gas = gasInlet->getStreamMedium()->copyTo(asOwner());
    m_medium_ExchGas = gasOut->getStreamMedium()->copyTo(asOwner());
    m_medium_Oil = oilInlet->getStreamMedium()->copyTo(asOwner());

    oilPipeRC.flag = gasPipeRC.flag = flagMixBibl;

    oilPipeRC.pipe_Name = "terminol";
    oilPipeRC.fluid = "oil";
    oilPipeRC.medium = m_medium_Oil;

    gasPipeRC.pipe_Name = "exhaustGas";
    gasPipeRC.fluid = "gas";
    gasPipeRC.medium = m_medium_Gas;

    // exportBiblProps("C:\\Users\\workstation777\\Desktop\\Matvey\\0
    // Saturn\\db\\");

    burner.concMin = 0.05;
    burner.flueGasPort = gasInlet;
    burner.medium = m_medium_Gas;

    burner.calcBurning(0);

    updateAllPipeProperties();
  }

void gpaFurnaceHeatExchangerElement::exportBiblProps(string way) {
    cout << " Export props VS T " << endl;
    gpaDataVector frFuelGas = gasInlet->getStreamFractions();
    gpaDataVector frOil = oilInlet->getStreamFractions();
    gpaDataVector frExhaustGas = {0, 0, 0, 0, 0};

    cout << endl;

    oilPipeRC.exportCurrentBiblProps(way, 293.0, 600.0, 10.0, frOil);

    cout << " FuelGas --> ";
    for (size_t i = 0; i < frExhaustGas.size(); i++) {
      cout << frFuelGas[i] << " ";
    }

    cout << endl;

    oilPipeRC.pipe_Name = "fuelGas";
    oilPipeRC.exportCurrentBiblProps(way, 293.0, 2273.0, 10.0, frFuelGas);

    cout << " ExhaustGas --> ";
    gpaReal total = 0.0;
    frExhaustGas = {0, 0, 0, 0, 0};

    for (int i = 0; i < frExhaustGas.size(); i++) {
      frExhaustGas[i] = frFuelGas[i] + delta_gas_fraction[i];
      total += frExhaustGas[i];
      cout << frExhaustGas[i] << " " << delta_gas_fraction[i] << " | ";
    }

    oilPipeRC.pipe_Name = "exhaustGas c_CH4 = " + to_string(frExhaustGas[2]);
    oilPipeRC.exportCurrentBiblProps(way, 293.0, 2273.0, 10.0, frExhaustGas);

    for (size_t j = 0; j <= 10; j++) {
      cout << " ExhaustGas --> ";
      gpaReal total = 0.0;
      frExhaustGas = {0, 0, 0, 0, 0};

      for (int i = 0; i < frExhaustGas.size(); i++) {
        frExhaustGas[i] = frFuelGas[i] + j / 10.0 * delta_gas_fraction[i];
        total += frExhaustGas[i];
        cout << frExhaustGas[i] << " " << j / 10.0 * delta_gas_fraction[i]
             << " | ";
      }

      oilPipeRC.pipe_Name = "exhaustGas c_CH4 = " + to_string(frExhaustGas[2]);
      oilPipeRC.exportCurrentBiblProps(way, 293.0, 2273.0, 10.0, frExhaustGas);
    }

    cout << " ------- " << endl;

    // while (1>0)
    // {

    // }
  }

void gpaFurnaceHeatExchangerElement::updateAllPipeProperties() {
    oilPipeRC.getStandartPackProp({1});

    // gpaDataVector fr = gasInlet->getStreamFractions();

    gasPipeRC.getStandartPackProp(burner.fr_EG_Out);
  }

void gpaFurnaceHeatExchangerElement::initFlows() {
    circuit_Gas = getMixCircuit(GPA_ELEM_CIRCUIT_0);
    circuit_Oil = getMixCircuit(GPA_ELEM_CIRCUIT_1);

    gasInlet = circuit_Gas->getPort(0);
    gasOut = circuit_Gas->getPort(1);
    oilInlet = circuit_Oil->getPort(0);
    oilOut = circuit_Oil->getPort(1);
  }

gpaReal gpaFurnaceHeatExchangerElement::getOilProp(gpaString par, gpaReal T) {
    if (par == "rho") {
      return 1236.69 - 0.745665 * T; // kg/m^3
    }
    if (par == "cp") {
      return (0.5211052170945513 + 0.0035340139549585384 * T); // kJ/kg/K
    }
    if (par == "lambda") {
      return (0.15395 - 0.000103468 * T) / 1000; // kW/K/m
    }
    if (par == "eta") {
      return 21.834 / pow(T - 273, 1.912); // Pa*s
    }
    if (par == "mu") {
      return 252.0; // kg/kmol
    }
  }

gpaReal gpaFurnaceHeatExchangerElement::getGasProp(gpaString par, gpaReal T) {
    if (par == "rho") {
      return 365.863 / T;
    }
    if (par == "cp") {
      return (-229.668 + 463.18 * pow(T, 0.168614)) / 1000.0;
    }
    if (par == "lambda") {
      return (0.00396343 + 0.0000706675 * T) / 1000.0;
    }
    if (par == "eta") {
      return -2.96295 * pow(10.0, -6.0) +
             3.65048 * pow(10.0, -7.0) * pow(T, 0.696601);
    }
    if (par == "mu") {
      return 29.0;
    }
  }

void gpaFurnaceHeatExchangerElement::calcDeltaP(bool isShow) {

    // m_medium_RC_oil->calcFlashPT(P_in_oil, TMeanRCOil,
    // m_medium_RC_oil->getFractions());

    // prop
    updateAllPipeProperties();

    // oil
    oilPipeRC.calcMyPipeMeanFlowProp2(isShow, G_in_oil);

    deltaP_oil = oilPipeRC.DP_Frick;

    // gas

    gasPipeRC.calcMyPipeMeanFlowProp2(isShow, G_in_gas);

    if (isShow == 1) {
      std::cout << "  gasPipeRC " << " | " << gasPipeRC.DP << " | " << "\n";
    }

    deltaP_gas = gasPipeRC.DP;
  }

void gpaFurnaceHeatExchangerElement::calcFlowProperties() {

    T_in_gas = gasInlet->getStreamTemperature();
    T_in_oil = oilInlet->getStreamTemperature();

    T_out_gas = gasOut->getStreamTemperature();
    T_out_oil = oilOut->getStreamTemperature();

    // Get G&P
    G_in_gas = gasInlet->getIncomingFlowRate();
    P_in_gas = gasInlet->getStreamPressure();
    G_in_oil = oilInlet->getIncomingFlowRate();
    P_in_oil = oilInlet->getStreamPressure();

    G_out_gas = gasOut->getIncomingFlowRate();
    G_out_oil = oilOut->getIncomingFlowRate();
    P_out_gas = gasOut->getStreamPressure();
    P_out_oil = oilOut->getStreamPressure();

    m_dot_gas = gasInlet->getIncomingMassRate();
    m_dot_oil = oilInlet->getIncomingMassRate();
  }

void gpaFurnaceHeatExchangerElement::calcQInAtm(bool isShow) {
    QAtmRC = alphaAtmRC / 1000.0 * sAtmSideRC * (gasPipeRC.meanTemp - TAirAtm) /
             (1 + (alphaAtmRC * dIsoRC) / lambdaAtmRC);

    if (isShow == 1) {
      cout << "   -- Atm --  " << endl;

      cout << "QAtmRC = " << QAtmRC << "| QAtmRC/Q = " << 100 * QAtmRC / Q
           << endl;

      cout << "   -- Atm --  " << endl;
    }
  }

void gpaFurnaceHeatExchangerElement::calcMeanTemp(bool isShow) {

    if (isShow == 1) {
      cout << " calcMeanTemp " << endl;
    }

    gasPipeRC.meanTemp = (burner.T_Burned_gas + T_out_gas) / 2;
    oilPipeRC.meanTemp = (T_out_oil + T_in_oil) / 2;

    if (isShow == 1) {
      cout << " calcMeanTemp " << endl;
    }
  }

void gpaFurnaceHeatExchangerElement::calcMeanPressure() {
    gasPipeRC.meanPressure = (P_out_gas + P_in_gas) / 2;
    oilPipeRC.meanPressure = (P_in_oil + P_out_oil) / 2;
  }

gpaReal gpaFurnaceHeatExchangerElement::myRound(gpaReal x, gpaReal n) {
    return round(x * pow(10, n)) / pow(10, n);
  }

gpaReal gpaFurnaceHeatExchangerElement::build_polinom(vector<gpaReal> coef_List, gpaReal x) {
    gpaReal res = 0;
    for (size_t i = 0; i < coef_List.size(); i++) {
      res += coef_List[i] * pow(x, i);
    }
    return res;
  }

gpaReal gpaFurnaceHeatExchangerElement::sigmoid(gpaReal x) { return 1.0 / (1.0 + std::exp(-x)); }

gpaResult gpaFurnaceHeatExchangerElement::getLMTD(gpaReal T_in_1, gpaReal T_out_1, gpaReal T_in_2,
                    gpaReal T_out_2, gpaUInt i_Flow_Scheme) {
    gpaReal bigDelta;
    gpaReal smallDelta;
    gpaReal sign;

    if (i_Flow_Scheme = 0) {
      bigDelta = abs(T_in_1 - T_in_2);
      smallDelta = abs(T_out_1 - T_out_2);

      sign = (T_in_1 > T_in_2) ? 1 : -1;

    } else {
      bigDelta = abs(T_in_1 - T_out_2);
      smallDelta = abs(T_out_1 - T_in_2);

      sign = (T_in_1 > T_in_2)    ? (T_out_1 > T_in_2) ? 1 : 0
             : (T_in_2 > T_out_1) ? -1
                                  : 0;
    }

    gpaReal LMTD_True =
        (bigDelta - smallDelta) / (log(bigDelta / (smallDelta + 0.00001)));
    gpaReal LMTD_Simple = (bigDelta + smallDelta) / 2;
    gpaReal diffDelta = bigDelta - smallDelta;

    gpaReal sigm = sigmoid(1 * (diffDelta - 1));

    gpaReal LMTD = LMTD_Simple * (1 - sigm) + sigm * LMTD_True;

    return sign * LMTD;
  }

void gpaFurnaceHeatExchangerElement::setCurrentHTPars(bool isShow) {

    if (burnerModel == 1) {

      vector<gpaReal> coef_List_kQCC = {0.871725, -0.258519, 0.0353535,
                                        -0.00116684};
      vector<gpaReal> coef_List_kQRC = {0.167331, -0.0371499, 0.0139911,
                                        -0.00052326};

      if (m_dot_gas < 3) {
        kQRC = 0.12;
      } else {
        if (m_dot_gas > 16.712) {
          kQRC = 1;
        } else {
          kQRC = build_polinom(coef_List_kQRC, m_dot_gas);
        }
      }
    }

    if (burnerModel == 2) {
      kQRC = 1;
    }

    if (isShow == 1) {
      cout << endl << " <--- current HT correction --->" << endl;
      cout << "m_dot_gas" << " | " << "kQRC" << " | " << endl;
      cout << m_dot_gas << " | " << kQRC << " | " << endl;
      cout << "<--- set pars --->" << endl << endl;
    }
  }

void gpaFurnaceHeatExchangerElement::calcHeatEchange(bool isShow) {

    if (isShow == 1) {
      std::cout << "  <--  calcHeatEchange --> " << "\n";
    }

    qRadRC = sigmoid(m_dot_gas - 2) *
             burner.getqRadRC(isShow, gasPipeRC.meanTemp, oilPipeRC.meanTemp) /
             1000; // m_dot_gas> ... нужно, чтобы не выпадала ошибка с якобианом

    LMTDRC = getLMTD(burner.T_Burned_gas, T_out_gas, T_in_oil, T_out_oil,
                     1); // 817.727

    alphaRC = gasPipeRC.alpha_conv; // 47/1000

    sSideRC = oilPipeRC.n_ch * std::numbers::pi * dPipeRC * lPipeRC *
              nPipeRC; /// 2.0;//512.708

    if (m_dot_gas > 1.3) // flow limits
    {
      if (setParsMethodFlag == 1) {
        setCurrentHTPars(isShow);
      }
    }

    QRC = kQRC * (alphaRC * LMTDRC + qRadRC) * sSideRC;

    // vol_Switcher = 0.1 + sigmoid((vol_oil - total_volume_oil)/deltaVolume);
    // Q   = vol_Switcher*(QCC + QRC);

    Q = 1 * (QRC);
    // Разница энтальпии между входом и выходом

    Delta_H_Gas_Fixed =
        burner.q_burn_unit_flow -
        (Q + QAtmRC) / (G_in_gas + 0.01); // dQ/dot_m/mu КДж/КМоль // mdotCond
    Delta_H_Oil_Fixed =
        Q / (G_in_oil + 0.01); // dQ/dot_m/mu КДж/КМоль // mdotCond

    if (isShow == 1) {
      std::cout << "  LMTD  " << LMTDRC << " | " << 0 << "\n";
      std::cout << "  alpha  " << alphaRC << " | " << 0 << "\n";
      std::cout << "  S  " << sSideRC << " | " << 0 << "\n";
      std::cout << "  QPart  " << QRC << " | " << 0 << "| Q ->  " << " | " << Q
                << "\n";
      std::cout << "  calcDeltaH  " << Delta_H_Gas_Fixed << " | "
                << Delta_H_Oil_Fixed << "\n";
    }
  }

gpaResult gpaFurnaceHeatExchangerElement::calcFuncValues(const gpaConstVector &,
                           const gpaConstVector &variables, gpaVector &values,
                           const gpaSetOfEquations &eqIds) {
    burner.calcBurning(0);
    calcFlowProperties();

    //++ Пересчет различных переменных
    calcQInAtm(0);
    calcMeanTemp(0);

    gasPipeRC.calcMyPipeHeatTransherProp(0);
    oilPipeRC.calcMyPipeHeatTransherProp(0);

    calcHeatEchange(0);

    calcDeltaP(0);

    // calcMeanPressure();

    //++ Пересчет различных переменных

    getProps(0); // Вывод различных переменных

    deltaP_oil = deltaP_oil + total_local_frick_coef_RC * oilPipeRC.density *
                                  oilPipeRC.v * oilPipeRC.v / 2;

    //++ Формирование уравнений для невязок

    values[0] = P_in_gas - P_out_gas - deltaP_gas;
    values[1] = G_in_gas + G_out_gas;
    values[2] = P_in_oil - P_out_oil - deltaP_oil;
    values[3] = G_in_oil + G_out_oil;

    // gpaReal volRate = oilInlet->getIncomingVolRate();

    // values[6] =  volRate * (1 - vol_Switcher);

    // cout << " volRate "   << " | "  <<  volRate  << endl;
    // cout << " vol_oil "   << " | "  <<  vol_oil  << endl;
    // cout << " v_oil_CC "   << " | "  <<  oilPipeCC.volume  << " v_oil_RC " <<
    // " | "  <<  oilPipeRC.volume  << " total_volume_oil "   << " | "  <<
    // total_volume_oil  << endl;
    //++ Формирование уравнений для невязок

    return GPA_RESULT_OK;
  }

void gpaFurnaceHeatExchangerElement::getProps(bool imShow) {

    getCpOnPorts();

    if (imShow == 1) {
      cout << endl << "  <-- Props --> " << endl;

      cout << " Cp_M_in_gas " << " | " << "Cp_M_out_gas " << endl;
      cout << Cp_M_in_gas << " | " << Cp_M_out_gas << endl;

      cout << " oilPipeRC.cp " << endl;
      cout << oilPipeRC.cp << endl;

      cout << "P_in_gas" << " | " << "P_out_gas" << endl;
      cout << P_in_gas << " | " << P_out_gas << endl;

      cout << "P_in_oil" << " | " << "P_out_oil" << endl;
      cout << P_in_oil << " | " << P_out_oil << endl;

      cout << "T_in_gas" << " | " << "T_Burned_gas" << " | " << "T_out_gas"
           << endl;
      cout << T_in_gas - 273 << " | " << burner.T_Burned_gas - 273 << " | "
           << T_out_gas - 273 << endl;
      cout << "        " << " | " << "T_out_oil" << " | " << "T_in_oil" << endl;
      cout << "        " << " | " << T_out_oil - 273 << " | " << " | "
           << T_in_oil - 273 << endl;

      cout << "-- m_dot_gas -> " << m_dot_gas << " | -- m_dot_oil -> "
           << m_dot_oil << endl;
    }
  }

void gpaFurnaceHeatExchangerElement::getCpOnPorts() {

    if (flagMixBibl == 0.0) {
      // Расчет теплоемкости входщих потоков ТС и ГМ
      Cp_M_in_gas = getGasProp("cp", T_in_gas);
      Cp_M_in_oil = getOilProp("cp", T_in_oil);

      // Расчет теплоемкости выходящих потоков ДГ и ГМ для сравнения с ИД
      Cp_M_out_gas = getGasProp("cp", T_out_gas);
      Cp_M_out_oil = getOilProp("cp", T_out_oil);

      // trustCpAndQBalance(0);
    } else {

      // Расчет теплоемкости входщих потоков ТС и ГМ
      Cp_M_in_gas = gasInlet->getStreamMedium()->getHeatCapacity() /
                    gasInlet->getStreamMedium()->getMolarMass();
      Cp_M_in_oil = oilInlet->getStreamMedium()->getHeatCapacity() /
                    oilInlet->getStreamMedium()->getMolarMass();

      // Расчет теплоемкости выходящих потоков ТС и ГМ
      Cp_M_out_gas = gasOut->getStreamMedium()->getHeatCapacity() /
                     gasOut->getStreamMedium()->getMolarMass();
      Cp_M_out_oil = oilOut->getStreamMedium()->getHeatCapacity() /
                     oilOut->getStreamMedium()->getMolarMass();
    }
  }

void gpaFurnaceHeatExchangerElement::trustCpAndQBalance(bool isNeedShowCpVST) {

    // trust cp
    std::cout << "  -port-   " << " | " << "P_in_gas" << " | " << "T" << " | "
              << "bibl" << " | " << "table" << " | " << "delta, %" << "\n";

    m_medium_Gas->calcFlashPT(P_in_gas, T_in_gas, m_medium_Gas->getFractions());
    gpaReal current_cp_1 =
        m_medium_Gas->getHeatCapacity() / m_medium_Gas->getMolarMass();
    std::cout << "  in_gas   " << " | " << P_in_gas << " | "
              << myRound(T_in_gas - 273, 1) << " | " << myRound(current_cp_1, 2)
              << " | " << myRound(Cp_M_in_gas, 2) << " | "
              << myRound(100 * (current_cp_1 - Cp_M_in_gas) / Cp_M_in_gas, 1)
              << "\n";

    m_medium_Gas->calcFlashPT(P_out_gas, T_out_gas,
                              m_medium_Gas->getFractions());
    gpaReal current_cp_2 =
        m_medium_Gas->getHeatCapacity() / m_medium_Gas->getMolarMass();
    std::cout << "  out_gas  " << " | " << P_out_gas << " | "
              << myRound(T_out_gas - 273, 1) << " | "
              << myRound(current_cp_2, 2) << " | " << myRound(Cp_M_out_gas, 2)
              << " | "
              << myRound(100 * (current_cp_2 - Cp_M_out_gas) / Cp_M_out_gas, 1)
              << "\n";

    m_medium_Oil->calcFlashPT(P_in_oil, T_in_oil, m_medium_Oil->getFractions());
    gpaReal current_cp_3 =
        m_medium_Oil->getHeatCapacity() / m_medium_Oil->getMolarMass();
    std::cout << "  in_oil   " << " | " << P_in_oil << " | "
              << myRound(T_in_oil - 273, 1) << " | " << myRound(current_cp_3, 2)
              << " | " << myRound(Cp_M_in_oil, 2) << " | "
              << myRound(100 * (current_cp_3 - Cp_M_in_oil) / Cp_M_in_oil, 1)
              << "\n";

    m_medium_Oil->calcFlashPT(P_out_oil, T_out_oil,
                              m_medium_Oil->getFractions());
    gpaReal current_cp_4 =
        m_medium_Oil->getHeatCapacity() / m_medium_Oil->getMolarMass();
    std::cout << "  out_oil  " << " | " << P_out_oil << " | "
              << myRound(T_out_oil - 273, 1) << " | "
              << myRound(current_cp_4, 2) << " | " << myRound(Cp_M_out_oil, 2)
              << " | "
              << myRound(100 * (current_cp_4 - Cp_M_out_oil) / Cp_M_out_oil, 1)
              << "\n";

    // trust cp
    gpaReal Q1 =
        (current_cp_1 + current_cp_2) / 2 * m_dot_gas * (T_out_gas - T_in_gas);
    gpaReal Q2 =
        (Cp_M_in_gas + Cp_M_out_gas) / 2 * m_dot_gas * (T_out_gas - T_in_gas);
    gpaReal Q3 =
        (current_cp_3 + current_cp_4) / 2 * m_dot_oil * (T_out_oil - T_in_oil);
    gpaReal Q4 =
        (Cp_M_in_oil + Cp_M_out_oil) / 2 * m_dot_oil * (T_out_oil - T_in_oil);

    std::cout << " " << "\n";
    std::cout << " <-- Q balance --> " << "\n";
    std::cout << " Q_gas  " << " | " << myRound(Q1, 1) << " | "
              << myRound(Q2, 1) << " | " << myRound((Q1 - Q2) / Q2 * 100, 1)
              << "\n";
    std::cout << " Q_oil  " << " | " << myRound(Q3, 1) << " | "
              << myRound(Q4, 1) << " | " << myRound((Q3 - Q4) / Q4 * 100, 1)
              << "\n";
    std::cout << " Q_total " << " | " << myRound(Q3 + Q1, 1) << " | "
              << myRound(Q4 + Q2, 1) << " | "
              << myRound((Q1 + Q3 - Q4 - Q2) / (Q4 + Q2) * 100, 1) << "\n";

    std::cout << " <-- Q balance --> " << "\n";
    std::cout << " " << "\n";
  }

gpaResult gpaFurnaceHeatExchangerElement::calcEnthalpyFuncValueAt(gpaUInt circIdx, gpaUInt portIdx,
                                    gpaReal enthalpy,
                                    gpaReal &funcValue) const {
    if (circIdx == GPA_ELEM_CIRCUIT_0) {
      const gpaMixPort *oppPort = getMixPort(GPA_ELEM_CIRCUIT_0, 1 - portIdx);
      if (!oppPort)
        return GPA_ERROR_WRONG_ARGS;
      funcValue = enthalpy - oppPort->getStreamMedium()->getEnthalpy() -
                  Delta_H_Gas_Fixed;
      // printf("Gas enthalpy %d: %f\n", portIdx, funcValue);
      return GPA_RESULT_OK;
    }
    if (circIdx == GPA_ELEM_CIRCUIT_1) {
      const gpaMixPort *oppPort2 = getMixPort(GPA_ELEM_CIRCUIT_1, 1 - portIdx);
      if (!oppPort2)
        return GPA_ERROR_WRONG_ARGS;
      funcValue = enthalpy - oppPort2->getStreamMedium()->getEnthalpy() -
                  Delta_H_Oil_Fixed;
      // printf("Oil enthalpy %d: %f\n", portIdx, funcValue);
      return GPA_RESULT_OK;
    }
    return GPA_ERROR_WRONG_ARGS;
  }

gpaResult gpaFurnaceHeatExchangerElement::calcFractionsFuncValuesAt(gpaUInt circIdx, gpaUInt portIdx,
                                      const gpaConstVector &fractions,
                                      gpaVector &funcValues) const {
    if (circIdx == GPA_ELEM_CIRCUIT_0) {

      const gpaMixPort *oppPort = getMixCircuit(circIdx)->getPort(1 - portIdx);
      if (!oppPort)
        return GPA_ERROR_WRONG_ARGS;
      const gpaConstVector calcFractions =
          oppPort->getStreamMedium()->getFractions();

      for (gpaUInt i = 0; i < funcValues.size(); ++i)
        funcValues[i] = fractions[i] - burner.fr_EG_Out[i];

      // printf("Gas fractions %d\n", portIdx);
      //  for (gpaUInt i = 0; i < funcValues.size(); ++i)
      //      printf("%f | ", funcValues[i]);
      //  printf("\n");
      return GPA_RESULT_OK;
    }

    if (circIdx == GPA_ELEM_CIRCUIT_1) {

      const gpaMixPort *oppPort2 = getMixCircuit(circIdx)->getPort(1 - portIdx);
      ;
      if (!oppPort2)
        return GPA_ERROR_WRONG_ARGS;
      const gpaConstVector calcFractions2 =
          oppPort2->getStreamMedium()->getFractions();
      for (gpaUInt i = 0; i < funcValues.size(); ++i)
        funcValues[i] = fractions[i] - calcFractions2[i];
      // printf("Oil fractions %d\n", portIdx);
      //  for (gpaUInt i = 0; i < funcValues.size(); ++i)
      //      printf("%f | ", funcValues[i]);
      //  printf("\n");
      return GPA_RESULT_OK;
    }

    return GPA_ERROR_WRONG_ARGS;
  }

const gpaString &gpaFurnaceHeatExchangerElement::getTypeName() const {
    return getDeviceTypeName();
  }

const gpaString &gpaFurnaceHeatExchangerElement::getDescription() const {
    return getDeviceDescription();
  }

void gpaFurnaceHeatExchangerElement::calcThermalParams() {
    gpaReal d = m_d;
    gpaReal l = m_l;
    // PIPE (основная труба)
    m_R_pipe = 0;
    m_A_in_pipe = std::numbers::pi * d * l;
    gpaReal radius_inner = d / 2.0;
    for (const auto &layer : m_heatLayers) {
      gpaReal r1 = radius_inner;
      gpaReal r2 = r1 + layer.thickness;
      m_R_pipe += std::log(r2 / r1) /
                  (2 * std::numbers::pi * layer.heatConductivity * l);
      radius_inner = r2;
    }
    m_A_out_pipe = std::numbers::pi * (2 * radius_inner) * l;

    // GAS (газовая сторона, пусть конструкция аналогична)
    m_R_gas = m_R_pipe;
    m_A_in_gas = m_A_in_pipe;
    m_A_out_gas = m_A_out_pipe;
  }

const gpaString &gpaFurnaceHeatExchangerElement::getDeviceTypeName() { return m_typeName; }

const gpaString &gpaFurnaceHeatExchangerElement::getDeviceDescription() { return m_description; }
