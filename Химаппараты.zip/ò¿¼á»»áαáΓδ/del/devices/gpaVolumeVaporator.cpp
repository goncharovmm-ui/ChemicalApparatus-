#include "gpaVolumeVaporator.h"
#include "gpaDefinitions.h"
#include "gpaHorizontalCylinder.h"
#include "gpaInclude.h"
#include "gpaLogMeanTempDifference.h"
#include "gpaThinWall.h"
#include "gpaZeroRadiation.h"
#include "vmInclude.h"
#include <iostream>

constexpr gpaUInt ID_CIRCUIT = 0;
constexpr gpaUInt NUM_CIRCUITS = 1;

constexpr gpaUInt GPA_N01_INLET = 0;
constexpr gpaUInt GPA_N02_INLET = 1;
constexpr gpaUInt GPA_N03_INLET = 2;
constexpr gpaUInt GPA_N04_INLET = 3;
constexpr gpaUInt GPA_N05_INLET = 4;

constexpr gpaUInt ID_PARAM_PRES0 = 0x00;
constexpr gpaUInt ID_PARAM_TEMP0 = 0x01;
constexpr gpaUInt ID_PARAM_LIQ_FRACTIONS = 0x02;
constexpr gpaUInt ID_PARAM_D = 0x03;
constexpr gpaUInt ID_PARAM_H = 0x04;
constexpr gpaUInt ID_PARAM_H_PORTS = 0x05;
constexpr gpaUInt ID_PARAM_PORT_R01 = 0x06;
constexpr gpaUInt ID_PARAM_PORT_R02 = 0x07;
constexpr gpaUInt ID_PARAM_PORT_R03 = 0x08;
constexpr gpaUInt ID_PARAM_PORT_R04 = 0x09;
constexpr gpaUInt ID_PARAM_PORT_R05 = 0x0a;
constexpr gpaUInt ID_PARAM_HEATER = 0x0b;
constexpr gpaUInt ID_PARAM_HEATER_COEFF = 0x0c;
constexpr gpaUInt ID_PARAM_ALPHA_IN = 0x0d;

constexpr gpaUInt ID_SENSOR_PRESSURE = 0x00;
constexpr gpaUInt ID_SENSOR_LIQ_TEMPERATURE = 0x01;
constexpr gpaUInt ID_SENSOR_GAS_TEMPERATURE = 0x02;
constexpr gpaUInt ID_SENSOR_INLET_PRES = 0x03;
constexpr gpaUInt ID_SENSOR_OUT_LIQ_PRES = 0x04;
constexpr gpaUInt ID_SENSOR_LIQUID_LEVEL = 0x05;
constexpr gpaUInt ID_SENSOR_LEV_FULLNESS = 0x06;
constexpr gpaUInt ID_SENSOR_VOL_FULLNESS = 0x07;
constexpr gpaUInt ID_SENSOR_ENTHALPY = 0x08;
constexpr gpaUInt ID_SENSOR_MOLES = 0x09;
constexpr gpaUInt ID_SENSOR_FRACTION0 = 0x0c;
constexpr gpaUInt ID_SENSOR_FRACTION1 = 0x0d;
constexpr gpaUInt ID_SENSOR_FRACTION2 = 0x0e;
constexpr gpaUInt ID_SENSOR_FRACTION3 = 0x0f;
constexpr gpaUInt ID_SENSOR_FRACTION4 = 0x10;
constexpr gpaUInt ID_SENSOR_FRACTION5 = 0x11;
constexpr gpaUInt ID_SENSOR_N15_VAPOR = 0x12;
constexpr gpaUInt ID_SENSOR_VOL = 0x13;

const gpaString gpaVolumeVaporator::m_typeName = "volume-vaporator";
const gpaString gpaVolumeVaporator::m_description = "Объемный испаритель";

const gpaParameterInfoVector gpaVolumeVaporator::m_parameters = {
    realParam("initial-pressure", "Начальное давление в резервуаре",
              GPA_PRESSURE_UNIT, false, 1e+2),
    realParam("initial-temp", "Начальная температура в резервуаре",
              GPA_TEMPERATURE_UNIT, false, 20.0),
    realVecFracsParam("liq_fractions",
                      "Начальные мольные доли жидких компонентов",
                      GPA_DIMLESS_UNIT, false, 0),
    realParam("d", "Рабочий внутренний диаметр аппарата", GPA_LENGTH_UNIT,
              false, 1.2),
    realParam("H", "Длина цилиндрической рабочей части аппарата",
              GPA_LENGTH_UNIT, false, 2.3),
    realParam("H-ports", "Высоты патрубков подключения (от дна), набор",
              GPA_LENGTH_UNIT, false, 0.0),
    realParam("r01", "Внутренни диаметр на порту 01", GPA_LENGTH_UNIT, false,
              0.3),
    realParam("r02", "Внутренни диаметр на порту 02", GPA_LENGTH_UNIT, false,
              0.7),
    realParam("r03", "Внутренни диаметр на порту 03", GPA_LENGTH_UNIT, false,
              0.5),
    realParam("r04", "Внутренни диаметр на порту 04", GPA_LENGTH_UNIT, false,
              0.2),
    realParam("r05", "Внутренни диаметр на порту 05", GPA_LENGTH_UNIT, false,
              0.2),

    realParam("q_heater", "Мощьность нагревателя", GPA_HEAT_RATE_UNIT, false,
              0.2),
    realParam("q_heater_coeff", "Коэффициент управления мощностью ТЭНа",
              GPA_DIMLESS_UNIT, true, 1),

    realParam("ten_coeff", "Коэффициент теплопередачи в технологическую среду",
              GPA_CONDUCTIVITY_UNIT, true, 0.01),
};

const gpaSensorInfoVector gpaVolumeVaporator::m_sensors = {
    scalarSensor("pressure", "Давление в аппарате", GPA_PRESSURE_UNIT),
    scalarSensor("gas-temperature", "Температура в аппарате",
                 GPA_TEMPERATURE_UNIT),
    scalarSensor("mix-pressure", "Давление на входе в аппарат",
                 GPA_PRESSURE_UNIT),
    scalarSensor("liquid-level", "Уровень жидкости в аппарате",
                 GPA_LENGTH_UNIT),
    scalarSensor("lev-fullness",
                 " Заполненность по уровню жидкости (% по высоте), [0 , 1]",
                 GPA_DIMLESS_UNIT),
    scalarSensor("vol-fullness",
                 "Заполненность по объему (% по объему), [0 , 1]",
                 GPA_DIMLESS_UNIT),
    scalarSensor("moles", "Сумма количества вещества газа и жидкости",
                 GPA_AMOUNT_UNIT),
    scalarSensor("fraction0", "Доля компонента 1", GPA_DIMLESS_UNIT),
    scalarSensor("fraction1", "Доля компонента 2", GPA_DIMLESS_UNIT),
    scalarSensor("fraction2", "Доля компонента 3", GPA_DIMLESS_UNIT),
    scalarSensor("fraction3", "Доля компонента 4", GPA_DIMLESS_UNIT),
    scalarSensor("fraction4", "Доля компонента 5", GPA_DIMLESS_UNIT),
    scalarSensor("fraction5", "Доля компонента 6", GPA_DIMLESS_UNIT),
    scalarSensor("pres_p1", " Давление на входе (порт 1)", GPA_PRESSURE_UNIT),
    scalarSensor("pres_p2", " Давление на выходе (порт 2)", GPA_PRESSURE_UNIT),
    scalarSensor("pres_p3", " Давление на выходе (порт 3)", GPA_PRESSURE_UNIT),
    scalarSensor("delta_pres1", "Перепад давления ", GPA_PRESSURE_UNIT),
    scalarSensor("volume", "Внутренний объем аппарата (м3)", GPA_DIMLESS_UNIT),
    scalarSensor("m_ten", "Температура ТЭНа", GPA_TEMPERATURE_UNIT)};

gpaVolumeVaporator::gpaVolumeVaporator(const gpaCoreInterfaces *interfaces,
                                       gpaCoreReference importRef)
    : gpaExportSystem(interfaces, importRef), m_volume(asParent()),
      m_environment(asParent()) {}

gpaVolumeVaporator::~gpaVolumeVaporator() {}

const gpaStringVector gpaVolumeVaporator::m_circuitNames = {"Circuit"};

const gpaStringVector gpaVolumeVaporator::m_portNames = {
    "Вход продукта",          "Уравнительная линия / выход газа",
    "Насос / выход жидкости", "Разгерм. газ",
    "Разгерм. жидкость",
};

gpaUInt gpaVolumeVaporator::getDeviceNumMixCircuits() { return NUM_CIRCUITS; }

gpaUInt gpaVolumeVaporator::getDeviceMinNumMixPorts(gpaUInt index) {
    return index < NUM_CIRCUITS ? GPA_VOLUME_VAPORATOR_MIN_PORT : 0;
}

gpaUInt gpaVolumeVaporator::getDeviceMaxNumMixPorts(gpaUInt index) {
    return index < NUM_CIRCUITS ? GPA_VOLUME_VAPORATOR_MAX_PORT : 0;
}

const gpaString *gpaVolumeVaporator::getDeviceMixCircuitName(gpaUInt index) {
    return index < NUM_CIRCUITS ? &m_circuitNames[index] : NULL;
}

const gpaString *gpaVolumeVaporator::getDeviceMixPortName(gpaUInt circIdx,
                                                          gpaUInt portIdx) {
    return portIdx < GPA_VOLUME_VAPORATOR_MAX_PORT ? &m_portNames[portIdx]
                                                   : NULL;
}

gpaResult
gpaVolumeVaporator::checkParamValues(const gpaExtParameter *values) const {
    (void)values;
    return GPA_RESULT_OK;
}

void gpaVolumeVaporator::setNames() {
    m_volume.setName("Vol");
    m_environment.setName("Env");
}

gpaResult gpaVolumeVaporator::initVolumes(const gpaExtParameter *values) {
    // Формируем вектор начальных мольных долей в резервуаре
    // gpaVector gasFractions(values[ID_PARAM_GAS_FRACTIONS].value.realVector,
    //                       values[ID_PARAM_GAS_FRACTIONS].size);
    gpaVector fractions(values[ID_PARAM_LIQ_FRACTIONS].value.realVector,
                        values[ID_PARAM_LIQ_FRACTIONS].size);
    // Назначаем параметры сепрационной секции
    bool good = true;
    gpaHorizontalCylinder *shape = new gpaHorizontalCylinder(&m_volume);
    good &= shape->setDiameter(values[ID_PARAM_D].value.realValue);
    good &= shape->setLength(values[ID_PARAM_H].value.realValue);
    if (!good)
        return GPA_ERROR_WRONG_ARGS;
    m_volume.setShape(shape);
    good &= m_volume.setInitFractions(fractions);
    good &= m_volume.setInitPressure(values[ID_PARAM_PRES0].value.realValue);
    good &= m_volume.setInitTemperature(values[ID_PARAM_TEMP0].value.realValue +
                                        GPA_CELCIUS_TO_KELVIN);
    good &= m_volume.setHeatTransferParams(2, 6);
    good &= m_volume.setMiddleLayerCoeff(6);
    good &= m_volume.setWallLayer({0.05, 7800, 60, 500});
    good &= m_volume.addIsolationLayer({0.1, 1.25, 1, 20});
    good &= m_volume.addIsolationLayer({0.2, 7800, 60, 500});
    good &= m_volume.setQHeater(values[ID_PARAM_HEATER].value.realValue);
    good &=
        m_volume.setQHeaterCoeff(values[ID_PARAM_HEATER_COEFF].value.realValue);

    m_volume.m_alpha_in = values[ID_PARAM_ALPHA_IN].value.realValue;
    if (!good)
        return GPA_ERROR_WRONG_ARGS;
    return GPA_RESULT_OK;
}

gpaResult
gpaVolumeVaporator::initPortParameters(const gpaExtParameter *values) {
    bool good = true;
    // Создаем отверсие для входа смеси и назначаем его характеристики
    gpaVolumeFittingData *port = NULL;
    port = new gpaVolumeFittingData(&m_volume);
    good &= port->setVolumeBottom(values[ID_PARAM_PORT_R01].value.realValue);
    good &= m_volume.setFittingPortData(GPA_N01_INLET, port);
    // Создаем отверсие для выхода газа и назначаем его характеристики
    port = new gpaVolumeFittingData(&m_volume);
    good &= port->setVolumeTop(values[ID_PARAM_PORT_R02].value.realValue);
    good &= m_volume.setFittingPortData(GPA_N02_INLET, port);
    // Создаем отверсие для выхода жидкости и назначаем его характеристики
    port = new gpaVolumeFittingData(&m_volume);
    good &= port->setVolumeBottom(values[ID_PARAM_PORT_R03].value.realValue);
    good &= m_volume.setFittingPortData(GPA_N03_INLET, port);

    port = new gpaVolumeFittingData(&m_volume);
    good &= port->setVolumeBottom(values[ID_PARAM_PORT_R04].value.realValue);
    good &= m_volume.setFittingPortData(GPA_N04_INLET, port);

    port = new gpaVolumeFittingData(&m_volume);
    good &= port->setVolumeBottom(values[ID_PARAM_PORT_R05].value.realValue);
    good &= m_volume.setFittingPortData(GPA_N05_INLET, port);

    if (!good)
        return GPA_ERROR_WRONG_ARGS;
    return GPA_RESULT_OK;
}

gpaResult gpaVolumeVaporator::setParamValues(const gpaExtParameter *values,
                                             bool checkNeeded) {
    // Проверка параметров, если требуется
    if (checkNeeded) {
        gpaResult res = checkParamValues(values);
        if (res != GPA_RESULT_OK)
            return res;
    }
    // Даем названия элементам и потокам
    setNames();
    // Инициализируем резервуар
    gpaResult res = initVolumes(values);
    if (res != GPA_RESULT_OK)
        return res;
    // Назначаем параметры портов
    res = initPortParameters(values);
    if (res != GPA_RESULT_OK)
        return res;
    // Инициализируем внешнюю среду
    return updateEnvironment(values);
}

gpaResult gpaVolumeVaporator::buildDevice() {
    bool good = true;
    gpaUInt numPorts = getMixCircuit(GPA_ELEM_CIRCUIT_0)->getNumPorts();
    // Соединяем резервуар с граничными потоками смеси системы
    good = good &&
           m_volume.connectMixStream(
               GPA_ELEM_CIRCUIT_0, GPA_N01_INLET,
               getEdgeMixStream(ID_CIRCUIT, GPA_N01_INLET), GPA_STREAM_INLET);
    good = good &&
           m_volume.connectMixStream(
               GPA_ELEM_CIRCUIT_0, GPA_N02_INLET,
               getEdgeMixStream(ID_CIRCUIT, GPA_N02_INLET), GPA_STREAM_OUTLET);
    good = good &&
           m_volume.connectMixStream(
               GPA_ELEM_CIRCUIT_0, GPA_N03_INLET,
               getEdgeMixStream(ID_CIRCUIT, GPA_N03_INLET), GPA_STREAM_OUTLET);
    if (numPorts > GPA_VOLUME_VAPORATOR_MIN_PORT) {
        bool goodOther = false;
        for (gpaUInt i = GPA_VOLUME_VAPORATOR_MIN_PORT;
             i < GPA_VOLUME_VAPORATOR_MAX_PORT; i++) {
            goodOther =
                (m_volume).connectMixStream(GPA_ELEM_CIRCUIT_0, i,
                                            getEdgeMixStream(ID_CIRCUIT, i),
                                            GPA_STREAM_OUTLET) ||
                goodOther;
        }
        good = good && goodOther;
    }
    if (!good)
        return GPA_ERROR_WRONG_ARGS;
    // Добавляем в систему все элементы и потоки
    setElements({&m_volume});
    setStreams({});
    return GPA_RESULT_OK;
}

gpaResult gpaVolumeVaporator::initialize() {
    // Подключить экспортируемый элемент к потокам в интеграторе
    gpaResult res = linkToCoreStreams();
    if (res != GPA_RESULT_OK)
        return res;
    // Соединяем все элементы друг с другом
    res = buildDevice();
    if (res != GPA_RESULT_OK)
        return res;
    // Создаем схемы течений (нужны соединенные элементы)
    if (!createSimStructures({},
                             {
                                 {getOuterEntrance(ID_CIRCUIT, GPA_N01_INLET)},
                                 // {getEdgeMixStream(GPA_N02_INLET),
                                 // getMediumAt(GPA_N02_INLET)},
                                 //{getEdgeMixStream(GPA_N03_INLET),
                                 // getMediumAt(GPA_N03_INLET)},
                                 // {getEdgeMixStream(GPA_N04_INLET),
                                 // getMediumAt(GPA_N04_INLET)},
                                 // {getEdgeMixStream(GPA_N05_INLET),
                                 // getMediumAt(GPA_N05_INLET)},
                                 // {getEdgeMixStream(GPA_N06_INLET),
                                 // getMediumAt(GPA_N06_INLET)},
                                 // {getEdgeMixStream(GPA_N18_INLET),
                                 // getMediumAt(GPA_N18_INLET)},
                             }))
        return GPA_ERROR_WRONG_ARGS;
    // Инициализируем систему
    return gpaExportSystem::initialize();
}

gpaResult gpaVolumeVaporator::updateEnvironment(const gpaExtParameter *values) {
    // Обновление параметров окружающей среды
    bool good = true;
    good &= m_environment.setTemperature(22. + GPA_CELCIUS_TO_KELVIN);
    good &= m_environment.setHeatTransferCoef(2.54);
    if (!good)
        return GPA_ERROR_WRONG_ARGS;
    return GPA_RESULT_OK;
}

gpaResult gpaVolumeVaporator::setSignals(const gpaConstVector &signals) {
    gpaReal value;
    bool good = true;
    if (getSignalValue(signals, ID_PARAM_HEATER_COEFF, value))
        good &= m_volume.setQHeaterCoeff(value);
    // if (!good)
    //     return GPA_ERROR_WRONG_ARGS;
    return GPA_RESULT_OK;
}

gpaResult gpaVolumeVaporator::calcSensors(gpaVector &sensors) const {
    setSensorValue(sensors, 0, m_volume.getLiquidLevelPressure());
    setSensorValue(sensors, 1,
                   m_volume.getMedium()->getTemperature() -
                       GPA_CELCIUS_TO_KELVIN);
    setSensorValue(sensors, 2,
                   m_volume.getFittingData(GPA_N01_INLET)->getPressure());
    setSensorValue(sensors, 3, m_volume.getLiquidLevel());
    setSensorValue(sensors, 4,
                   m_volume.getLiquidLevel() /
                       m_volume.getShape()->getHeight());
    setSensorValue(sensors, 5,
                   m_volume.getLiquidVolume() /
                       m_volume.getShape()->getVolume());
    setSensorValue(sensors, 6, m_volume.getMixMoles());
    gpaConstVector fractions = m_volume.getInitFraction();
    gpaUInt max_fraction = vmMin(fractions.size(), 5);
    for (gpaUInt i = 0; i < max_fraction; ++i) {
        setSensorValue(sensors, i + 7, fractions[i]);
    }

    gpaReal p1 = m_volume.getFittingData(GPA_N01_INLET)->getPressure();
    gpaReal p2 = m_volume.getFittingData(GPA_N02_INLET)->getPressure();
    gpaReal p3 = m_volume.getFittingData(GPA_N03_INLET)->getPressure();

    setSensorValue(sensors, 13, p1);
    setSensorValue(sensors, 14, p2);
    setSensorValue(sensors, 15, p3);
    setSensorValue(sensors, 16, p1 - p2);
    setSensorValue(sensors, 17, m_volume.getShape()->getVolume());
    setSensorValue(sensors, 18, m_volume.m_ten_T - GPA_CELCIUS_TO_KELVIN);

    return GPA_RESULT_OK;
}
