#include "gpaHeatRecoveryUnitInfo.h"
#include "gpaHeatRecoveryUnit.h"


gpaHeatRecoveryUnitInfo::gpaHeatRecoveryUnitInfo() :
    gpaDeviceInfo  (gpaHeatRecoveryUnit::getDeviceTypeName(),
                    gpaHeatRecoveryUnit::getDeviceDescription())
{
    setParameters(gpaHeatRecoveryUnit::getParametersInfo());
    setSensors(gpaHeatRecoveryUnit::getSensorsInfo());
}

gpaUInt gpaHeatRecoveryUnitInfo::getNumMixCircuits() const
{
    return gpaHeatRecoveryUnit::getDeviceNumMixCircuits();
}

gpaUInt gpaHeatRecoveryUnitInfo::getMinNumMixPorts(gpaUInt index) const
{
    return gpaHeatRecoveryUnit::getDeviceMinNumMixPorts(index);
}

gpaUInt gpaHeatRecoveryUnitInfo::getMaxNumMixPorts(gpaUInt index) const
{
    return gpaHeatRecoveryUnit::getDeviceMaxNumMixPorts(index);
}
const gpaString *gpaHeatRecoveryUnitInfo::getMixPortName(gpaUInt circIdx, gpaUInt portIdx) const
{
    return gpaHeatRecoveryUnit::getDeviceMixPortName(circIdx, portIdx);
}

const gpaString *gpaHeatRecoveryUnitInfo::getMixCircuitName(gpaUInt index) const
{
    return gpaHeatRecoveryUnit::getDeviceMixCircuitName(index);
}



gpaElement* gpaHeatRecoveryUnitInfo::createDevice(const gpaCoreInterfaces* interfaces, gpaCoreReference pairDevice,
                                             const gpaExtObjectModel* model) const
{
    gpaHeatRecoveryUnit* cooler = new gpaHeatRecoveryUnit(interfaces, pairDevice);
    gpaResult res = cooler->specifyModel(model);
    if (res == GPA_RESULT_OK)
        return cooler;
    delete cooler;
    return NULL;
}
