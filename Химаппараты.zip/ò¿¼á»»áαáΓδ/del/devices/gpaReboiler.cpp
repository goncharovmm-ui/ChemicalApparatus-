#include "gpaReboiler.h"
#include "gpaLogMeanTempDifference.h"
#include "gpaThinWall.h"
#include "gpaZeroRadiation.h"
#include <gpaReboilerShape.h>

constexpr gpaUInt ID_CIRCUIT_VOLUME = 0;
constexpr gpaUInt ID_CIRCUIT_SHELL = 1;
constexpr gpaUInt NUM_CIRCUITS = 2;

constexpr gpaUInt GPA_N01_INLET = 0;
constexpr gpaUInt GPA_N02_OUTLET = 1;
constexpr gpaUInt GPA_N03_INLET = 0;
constexpr gpaUInt GPA_N04_OUTLET = 1;
constexpr gpaUInt GPA_N05_OUTLET = 2;
constexpr gpaUInt GPA_N06_OUTLET = 3;
constexpr gpaUInt GPA_N07_OUTLET = 4;
constexpr gpaUInt NUM_PORTS = 7;

constexpr gpaUInt ID_PARAM_NUM_PIPES = 0x00;
constexpr gpaUInt ID_PARAM_PIPE_LENGTH = 0x01;
constexpr gpaUInt ID_PARAM_INNER_DIAM = 0x02;
constexpr gpaUInt ID_PARAM_WALL_THICKNESS = 0x03;
constexpr gpaUInt ID_PARAM_VESSEL_HEIGHT = 0x04;
constexpr gpaUInt ID_PARAM_BUNDLE_DIAM = 0x05;
constexpr gpaUInt ID_PARAM_PIPE_SPACING = 0x06;
constexpr gpaUInt ID_PARAM_SMALL_CYL_LENGTH = 0x07;
constexpr gpaUInt ID_PARAM_CONE_LENGTH = 0x08;
constexpr gpaUInt ID_PARAM_CYL_LENGTH = 0x09;
constexpr gpaUInt ID_PARAM_ELLIPSOID_LENGTH = 0x0A;
constexpr gpaUInt ID_PARAM_HEAT_TRANSFER_COEF = 0x0B;
constexpr gpaUInt ID_PARAM_THERMAL_EXPANSION = 0x0C;
constexpr gpaUInt ID_PARAM_OUT_DENSITY = 0x0D;
constexpr gpaUInt ID_PARAM_OUT_VISCOSITY = 0x0E;
constexpr gpaUInt ID_PARAM_OUT_HEAT_CAPACITY = 0x0F;
constexpr gpaUInt ID_PARAM_OUT_CONDUCTIVITY = 0x10;
constexpr gpaUInt ID_PARAM_OUT_VELOCITY = 0x11;
constexpr gpaUInt ID_PARAM_OUT_TEMPERATURE = 0x12;
constexpr gpaUInt ID_PARAM_FRACTIONS = 0x13;
constexpr gpaUInt ID_PARAM_PRES0 = 0x14;
constexpr gpaUInt ID_PARAM_TEMP0 = 0x15;

constexpr gpaUInt ID_SENSOR_PRESSURE = 0x00;
constexpr gpaUInt ID_SENSOR_TEMPERATURE = 0x01;
constexpr gpaUInt ID_SENSOR_MOLAR_FLOW = 0x02;
constexpr gpaUInt ID_SENSOR_LIQUID_LEVEL = 0x03;
constexpr gpaUInt ID_SENSOR_NOZZLE_PRESSURE = 0x04;
constexpr gpaUInt ID_SENSOR_DELTA_TEMPERATURE = 0x05;

const gpaString gpaReboiler::m_typeName = "reboiler";
const gpaString gpaReboiler::m_description = "Реблойлер";

const gpaParameterInfoVector gpaReboiler::m_parameters = {
    intParam("num-pipes", "Количество линий труб в пучке", 10),
    realParam("pipe-length", "Длина трубного пучка, м", GPA_LENGTH_UNIT,
              false, 4),
    realParam("inner-diam",
              "Внутренний диаметр одной теплообменной трубки пучка, м",
              GPA_LENGTH_UNIT, false, 0.05),
    realParam("wall-thickness",
              "Толщина стенки одной теплообменной трубки пучка, м",
              GPA_LENGTH_UNIT, false, 0.5e-2),
    realParam(
        "vessel-height",
        "Высота большой цилиндрической части парового пространства аппарата, м",
        GPA_LENGTH_UNIT, false, 2.1),
    realParam("bundle-diam", "Диаметр аппарата вблизи трубного пучка, м",
              GPA_LENGTH_UNIT, false, 0.9),
    realParam("pipe-spacing",
              "Среднее расстояние между трубками одной линии трубного пучка, м",
              GPA_LENGTH_UNIT, false, 0.6),
    realParam("small-cyl-length",
              "Длина малой цилиндрической части вблизи трубного пучка, м",
              GPA_LENGTH_UNIT, false, 0.2),
    realParam("cone-length", "Длина конусной части, м", GPA_LENGTH_UNIT,
              false, 2.078),
    realParam("cyl-lenght", "Длина цилиндрической части, м", GPA_LENGTH_UNIT,
              false, 3.223),
    realParam("ellipsoid-length", "Длина части эллипсоида вращения, м",
              GPA_LENGTH_UNIT, false, 0.5),
    realParam("heat-transfer-coef",
              "Коэффициент внешней теплоотдачи, Вт/(м²·К)",
              GPA_HEATTRANS_COEF_UNIT, false, 0.0),
    realParam("thermal-expansion",
              "Коэффициент теплового расширения окружающей среды, 1/К",
              GPA_DIMLESS_UNIT, false, 0.0),
    realParam("out-density", "Плотность окружающей среды, кг/м³",
              GPA_DIMLESS_UNIT, false, 0.0),
    realParam("out-viscosity", "Динамическая вязкость окружающей среды, Па·с",
              GPA_DIMLESS_UNIT, false, 0.0),
    realParam("out-heat-capacity", "Теплоемкость окружающей среды, Дж/(кг·К)",
              GPA_DIMLESS_UNIT, false, 0.0),
    realParam("out-conductivity", "Теплопроводность окружающей среды, Вт/(м·К)",
              GPA_CONDUCTIVITY_UNIT, false, 0.0),
    realParam("out-velocity", "Скорость движения окружающей среды, м/с",
              GPA_VELOCITY_UNIT, false, 0.0),
    realParam("out-temperature", "Температура окружающей среды, К",
              GPA_TEMPERATURE_UNIT, false, 300.),
    realVecFracsParam("fractions", "Начальные мольные доли компонентов",
                      GPA_DIMLESS_UNIT, false, 0),
    realParam("initial-pressure", "Начальное давление в резервуаре",
              GPA_PRESSURE_UNIT, false, 1e3),
    realParam("initial-temp", "Начальная температура в резервуаре",
              GPA_TEMPERATURE_UNIT, false, 20.0),
};

const gpaSensorInfoVector gpaReboiler::m_sensors = {
    scalarSensor("pressure", "Давление, Па", GPA_PRESSURE_UNIT),
    scalarSensor("temperature", "Температура, К", GPA_TEMPERATURE_UNIT),
    scalarSensor("molar-flow", "Молярный расход, моль/с", GPA_MOLAR_RATE_UNIT),
    scalarSensor("liquid-level", "Уровень жидкости в аппарате, м",
                 GPA_LENGTH_UNIT),
    scalarSensor("nozzle-pressure", "Давление на патрубках, Па",
                 GPA_PRESSURE_UNIT),
    scalarSensor("delta-temperature", "Перепад температур, К",
                 GPA_TEMP_DIFFER_UNIT)};

gpaReboiler::gpaReboiler(const gpaCoreInterfaces *interfaces,
                         gpaCoreReference importRef)
    : gpaExportSystem(interfaces, importRef), m_volume(asParent()) {}

const gpaStringVector gpaReboiler::m_circuitNames = {"Volume circuit",
                                                     "Heat shell circuit"};

const gpaStringVector gpaReboiler::m_portNames = {"N01", "N02", "N05",
                                                  "N06", "N03", "N04"};

gpaUInt gpaReboiler::getDeviceNumMixCircuits() { return 2; }

gpaUInt gpaReboiler::getDeviceMinNumMixPorts(gpaUInt index) {
  switch (index) {
  case ID_CIRCUIT_VOLUME:
    return 4;
    break;
  case ID_CIRCUIT_SHELL:
    return 2;
    break;

  default:
    return 0;
    break;
  }
}

gpaUInt gpaReboiler::getDeviceMaxNumMixPorts(gpaUInt index) {
  switch (index) {
  case ID_CIRCUIT_VOLUME:
    return 4;
    break;
  case ID_CIRCUIT_SHELL:
    return 2;
    break;

  default:
    return 0;
    break;
  }
}

const gpaString *gpaReboiler::getDeviceMixCircuitName(gpaUInt index) {
  return index < NUM_CIRCUITS ? &m_circuitNames[index] : NULL;
}

const gpaString *gpaReboiler::getDeviceMixPortName(gpaUInt circIdx,
                                                   gpaUInt portIdx) {
  return portIdx < NUM_PORTS ? &m_portNames[portIdx + circIdx * 4] : NULL;
}

gpaResult gpaReboiler::checkParamValues(const gpaExtParameter *) const {
  return GPA_RESULT_OK;
}

void gpaReboiler::setNames() { m_volume.setName("volume"); }

gpaResult gpaReboiler::setParamValues(const gpaExtParameter *values,
                                      bool checkNeeded) {
  gpaResult good;
  gpaReboilerShape *shape = new gpaReboilerShape(
      &m_volume, values[ID_PARAM_BUNDLE_DIAM].value.realValue,
      values[ID_PARAM_VESSEL_HEIGHT].value.realValue,
      values[ID_PARAM_CONE_LENGTH].value.realValue,
      values[ID_PARAM_ELLIPSOID_LENGTH].value.realValue,
      values[ID_PARAM_CYL_LENGTH].value.realValue,
      values[ID_PARAM_SMALL_CYL_LENGTH].value.realValue, 1.5);
  m_volume.setShape(shape);
  m_volume.setPartitionProperties(1.05, 10, 1, 1e3, 1e-1);
  m_volume.setLiquidHeatTransferCoeff(6.);
  m_volume.setGasHeatTransferCoeff(6.);
  m_volume.setWallParameters(500, 7800);
  m_volume.setInitLiqVolumeFraction(0.1);
  m_volume.setShellParameters(
      1e-5, values[ID_PARAM_SMALL_CYL_LENGTH].value.realValue + 0.1,
      values[ID_PARAM_SMALL_CYL_LENGTH].value.realValue - 0.1,
      values[ID_PARAM_INNER_DIAM].value.realValue,
      values[ID_PARAM_PIPE_SPACING].value.realValue, 0.5e-2,
      values[ID_PARAM_PIPE_LENGTH].value.realValue,
      values[ID_PARAM_NUM_PIPES].value.intValue);
  // m_volume.setShellMixHeatTransferParams(1e3, 20, 5e2);
  m_volume.setShellMixHeatTransferParams(0, 0, 0);
  m_volume.setInitPressure(values[ID_PARAM_PRES0].value.realValue);
  m_volume.setInitTemperature(values[ID_PARAM_TEMP0].value.realValue +
                              GPA_CELCIUS_TO_KELVIN);
  gpaConstVector fractions(values[ID_PARAM_FRACTIONS].value.realVector,
                           values[ID_PARAM_FRACTIONS].size);
  m_volume.setInitFirstFractions(fractions);
  m_volume.setInitSecondFractions(fractions);
  m_volume.setAmbientTemperature(
      values[ID_PARAM_OUT_TEMPERATURE].value.realValue);
  m_volume.setGeometryParameters(
      values[ID_PARAM_CYL_LENGTH].value.realValue,
      values[ID_PARAM_VESSEL_HEIGHT].value.realValue,
      values[ID_PARAM_SMALL_CYL_LENGTH].value.realValue,
      values[ID_PARAM_BUNDLE_DIAM].value.realValue,
      values[ID_PARAM_WALL_THICKNESS].value.realValue);

  gpaVolumeFittingData *port = NULL;
  gpaReal maxHeight = values[ID_PARAM_VESSEL_HEIGHT].value.realValue;
  gpaReal heights[5]{maxHeight, maxHeight, .0, maxHeight, .0};
  for (gpaUInt i = 0; i < 5; i++) {
    port = new gpaVolumeFittingData(&m_volume);
    good &= port->setParameters(heights[i], 3.);
    good &= m_volume.setFittingPortData(i, port);
  }
  return GPA_RESULT_OK;
}

gpaResult gpaReboiler::buildDevice() {
  bool good = true;

  good = good && m_volume.connectMixStream(
                     ID_CIRCUIT_VOLUME, GPA_N01_INLET,
                     getEdgeMixStream(ID_CIRCUIT_VOLUME, GPA_N01_INLET),
                     GPA_STREAM_INLET);
  good = good && m_volume.connectMixStream(
                     ID_CIRCUIT_VOLUME, GPA_N02_OUTLET,
                     getEdgeMixStream(ID_CIRCUIT_VOLUME, GPA_N02_OUTLET),
                     GPA_STREAM_OUTLET);
  good = good && m_volume.connectMixStream(
                     ID_CIRCUIT_SHELL, GPA_N03_INLET,
                     getEdgeMixStream(ID_CIRCUIT_SHELL, GPA_N03_INLET),
                     GPA_STREAM_INLET);
  good = good && m_volume.connectMixStream(
                     ID_CIRCUIT_SHELL, GPA_N04_OUTLET,
                     getEdgeMixStream(ID_CIRCUIT_SHELL, GPA_N04_OUTLET),
                     GPA_STREAM_OUTLET);
  good = good && m_volume.connectMixStream(
                     ID_CIRCUIT_VOLUME, GPA_N05_OUTLET,
                     getEdgeMixStream(ID_CIRCUIT_VOLUME, GPA_N05_OUTLET),
                     GPA_STREAM_OUTLET);
  good = good && m_volume.connectMixStream(
                     ID_CIRCUIT_VOLUME, GPA_N06_OUTLET,
                     getEdgeMixStream(ID_CIRCUIT_VOLUME, GPA_N06_OUTLET),
                     GPA_STREAM_OUTLET);
  good = good && m_volume.connectMixStream(
                     ID_CIRCUIT_VOLUME, GPA_N07_OUTLET,
                     getEdgeMixStream(ID_CIRCUIT_VOLUME, GPA_N07_OUTLET),
                     GPA_STREAM_OUTLET);
  // Добавляем в систему все элементы и потоки
  setElements({&m_volume});
  setStreams({});
  return GPA_RESULT_OK;
}

gpaResult gpaReboiler::initialize() {
  // Подключить экспортируемый элемент к потокам в интеграторе
  gpaResult res = linkToCoreStreams();
  if (res != GPA_RESULT_OK)
    return res;
  // Соединяем все элементы друг с другом
  res = buildDevice();
  if (res != GPA_RESULT_OK)
    return res;
  // Создаем схемы течений (нужны соединенные элементы)
  if (!createSimStructures(
          {}, {
                  getOuterEntrance(ID_CIRCUIT_VOLUME, GPA_N01_INLET),
                  getOuterEntrance(ID_CIRCUIT_SHELL, GPA_N03_INLET),
              }))
    return GPA_ERROR_WRONG_ARGS;
  // Инициализируем систему
  return gpaExportSystem::initialize();
}

gpaResult gpaReboiler::calcSensors(gpaVector &sensors) const {
  setSensorValue(sensors, ID_SENSOR_PRESSURE,
                 m_volume.getLiquidLevelPressure());
  setSensorValue(sensors, ID_SENSOR_TEMPERATURE,
                 m_volume.getTemperatureAt(.0) - GPA_CELCIUS_TO_KELVIN);
  setSensorValue(sensors, ID_SENSOR_MOLAR_FLOW,
                 m_volume.getPartitionFlowRate());
  setSensorValue(sensors, ID_SENSOR_LIQUID_LEVEL, m_volume.getLiquidLevel());
  setSensorValue(sensors, ID_SENSOR_NOZZLE_PRESSURE, 0);
  setSensorValue(sensors, ID_SENSOR_DELTA_TEMPERATURE, 0);

  return GPA_RESULT_OK;
}
