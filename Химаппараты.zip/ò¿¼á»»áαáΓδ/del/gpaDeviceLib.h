/*!
 *  \file      gpaDeviceLib.h
 *  \brief     Класс, реализующий библиотеку аппаратов СПбПУ
 *  \author    Фролов Алексей
 *  \date      2024
 */
#ifndef GPA_DEVICE_LIB_H
#define GPA_DEVICE_LIB_H

#include "gpaGeneralDeviceLib.h"
#include "gpaInclude.h"

/*!
 * \class gpaDeviceLib
 * \brief Класс, реализующий библиотеку аппаратов СПбПУ
 */
class gpaDeviceLib : public gpaGeneralDeviceLib {
public:
  /*!
   * Конструктор по умолчанию
   * \param [in] interfaces интерфейсы взаимодействия с интегратором
   */
  gpaDeviceLib(const gpaCoreInterfaces *interfaces);
  /*!
   * Деструктор по умолчанию
   */
  virtual ~gpaDeviceLib() = default;
  /*!
   * Получить название библиотеки
   * \return название библиотеки
   */
  virtual gpaBaseCStr getName() const override { return m_name.c_str(); }
  /*!
   * Получить версию библиотеки
   * \return версию библиотеки
   */
  virtual gpaBaseCStr getVersion() const override { return m_version.c_str(); }
  /*!
   * Получить описание библиотеки
   * \return описание библиотеки
   */
  virtual gpaBaseCStr getDescription() const override {
    return m_description.c_str();
  }

private:
  //! Название библиотеки аппаратов
  static const gpaString m_name;
  //! Версия библиотеки аппаратов
  static const gpaString m_version;
  //! Описание библиотеки аппаратов
  static const gpaString m_description;
};

#endif
