#include "gpaFilterElem.h"
#include "spline.h"
#include <cassert>
#include <memory>
#include <numbers>

constexpr gpaUInt ID_PORT_INLET = 0;
constexpr gpaUInt ID_PORT_OUTLET = 1;

const gpaString initPresErrorStr = "Initial volume pressure must be positive";
const gpaString initTempErrorStr =
    "Initial volume temperature must be positive";
const gpaString initFractErrorStr =
    "Initial mole fractions must be in range [0,1] and their sum is less or "
    "equal to 1.0";
const gpaString liqHeatTransCoefErrorStr =
    "Gas-wall heat transfer coefficient must be non-negative";
const gpaString gasHeatTransCoefErrorStr =
    "Liquid-wall heat transfer coefficient must be non-negative";

const gpaString gpaFilterElem::m_typeName = "filter";
const gpaString gpaFilterElem::m_description = "Однослойный объем";

gpaFilterElem::gpaFilterElem(const gpaParentLink *link) {}

gpaFilterElem::gpaFilterElem(const gpaFilterElem &expander) {}

gpaFilterElem::~gpaFilterElem() {
  if (m_medium != 0)
    delete m_medium;
}

gpaFilterElem *gpaFilterElem::copy() const { return new gpaFilterElem(*this); }

bool gpaFilterElem::setFilterParameter(gpaReal length, gpaReal radius,
                                          gpaReal num_elem, gpaReal diameter,
                                          gpaReal porosity, gpaReal lambda) {
  m_length = length;
  m_filterRadius = radius;
  m_numElements = num_elem;
  m_porosity = porosity;
  m_elementsDiameter = diameter;
  m_lambda = lambda;
  return true;
}

gpaUInt gpaFilterElem::getMinNumMixPorts(gpaUInt index) const {
  return index == GPA_ELEM_CIRCUIT_0 ? 2 : 0;
}

gpaUInt gpaFilterElem::getMaxNumMixPorts(gpaUInt index) const {
  return index == GPA_ELEM_CIRCUIT_0 ? 2 : 0;
}

gpaUInt gpaFilterElem::getNumVariables() const { return 1; }

gpaResult gpaFilterElem::initialize() {
  const gpaMedium *medium = getCircuitMediumAt(GPA_ELEM_CIRCUIT_0);
  if (!medium)
    return GPA_ERROR_WRONG_ARGS;
  if (!medium->supportsFlash(PS_FLASH) || !medium->supportsFlash(PH_FLASH))
    return GPA_ERROR_UNSUPPORTED;
  m_medium = medium->copyTo(asOwner());
  m_S = m_numElements * std::numbers::pi * m_filterRadius * m_filterRadius;
  m_k0 = m_elementsDiameter * m_elementsDiameter * m_porosity * m_porosity *
         m_porosity / 180 / (1 - m_porosity) / (1 - m_porosity);
  return GPA_RESULT_OK;
}

gpaReal gpaFilterElem::getPermeabilityCoef() const { return m_kp; }

gpaReal gpaFilterElem::getHeatRate() const { return m_Q; }

void gpaFilterElem::fillVarNames(gpaStringVector &varNames) const {
  varNames[0] = "degree of pollution";
  // varNames[1] = getName() + GPA_VAR_POINTER + "Hz";
}

gpaResult gpaFilterElem::initVariables(gpaVector &variables) const {
  variables[0] = 1;
  // variables[1] = 1;
  return GPA_RESULT_OK;
}

bool
gpaFilterElem::setHeatTransferModel(std::unique_ptr<LMTDHeatTransfer> model) {
  m_modelHT = std::move(model);
  return true;
}

gpaResult gpaFilterElem::fillMassMatrix(gpaUInt refRow, gpaUInt refCol) const {
  gpaResult res = setMassMatrCoef(refRow, refCol, 1.0);
  if (res != GPA_RESULT_OK)
    return res;
  return GPA_RESULT_OK;
}

gpaResult gpaFilterElem::calcFuncValues(const gpaConstVector &,
                                        const gpaConstVector &variables,
                                        gpaVector &values,
                                        const gpaSetOfEquations &eqIds) {
  gpaReal f = variables[0];
  // gpaReal dP = variables[1];

  gpaMixPort *inletPort = getMixPort(GPA_ELEM_CIRCUIT_0, ID_PORT_INLET);
  gpaMixPort *outletPort = getMixPort(GPA_ELEM_CIRCUIT_0, ID_PORT_OUTLET);

  m_kp = m_k0 * vmMax(m_porosity, f);

  gpaReal dP = inletPort->getIncomingVolRate() *
               inletPort->getStreamViscosity() * m_length / m_kp / m_S /
               GPA_KILOPASCAL_TO_PASCAL;

  values(0) = -m_lambda * inletPort->getIncomingMassRate();
  gpaResult res = m_medium->calcFlashPH(outletPort->getStreamPressure(),
                                        outletPort->getStreamEnthalpy(),
                                        inletPort->getStreamFractions());
  if (res != GPA_RESULT_OK)
    return res;
  // m_Q = 1 / m_R * (outletPort->getStreamTemperature() -
  // m_medium->getTemperature()) /
  //       log((outletPort->getStreamTemperature() - m_Tenv) /
  //       (m_medium->getTemperature() - m_Tenv));
  // m_Q = m_modelHT->calcQ(inletPort->getStreamTemperature(),
  // m_medium->getTemperature());
  //  m_Q = m_modelHT->calcQ(inletPort->getStreamTemperature(),
  //  outletPort->getStreamTemperature());

  values(1) =
      outletPort->getStreamPressure() - inletPort->getStreamPressure() + dP;
  values(2) =
      outletPort->getIncomingFlowRate() + inletPort->getIncomingFlowRate();
  // values(3) = 0.0363 * 1e-3 * vmPower(w, 2) - dP;
  return GPA_RESULT_OK;
}

gpaResult gpaFilterElem::calcEnthalpyFuncValueAt(gpaUInt circIdx,
                                                 gpaUInt portIdx,
                                                 gpaReal enthalpy,
                                                 gpaReal &funcValue) const {

  gpaMixPort *oppPort = getMixCircuit(circIdx)->getPort(1 - portIdx);
  gpaReal portEnthalpy = oppPort->getStreamEnthalpy();
  gpaReal G = vmAbs(oppPort->getIncomingFlowRate());
  if (G < 1.e-6) {
    funcValue = enthalpy - oppPort->getStreamEnthalpy();
  } else {
    funcValue = (enthalpy - oppPort->getStreamEnthalpy()) * G + m_Q;
  }
  printf("Enthalpy for %d-%d: %f %f\n", circIdx, portIdx, funcValue, m_Q);

  return GPA_RESULT_OK;
}

gpaResult
gpaFilterElem::calcFractionsFuncValuesAt(gpaUInt circIdx, gpaUInt portIdx,
                                         const gpaConstVector &fractions,
                                         gpaVector &funcValues) const {

  gpaMixPort *oppPort = getMixCircuit(circIdx)->getPort(1 - portIdx);
  gpaDataVector portFractions = oppPort->getStreamFractions();
  for (gpaUInt i = 0; i < funcValues.size(); i++) {
    funcValues[i] = fractions[i] - portFractions[i];
  }

  return GPA_RESULT_OK;
}
