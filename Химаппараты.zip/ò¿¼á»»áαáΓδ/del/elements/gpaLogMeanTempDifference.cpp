#include "gpaLogMeanTempDifference.h"

const gpaReal LOG_DIFF_ZERO_SMOOTHING_DELTA_TEMP    = 0.1;

const gpaString gpaLogMeanTempDifference::m_modelName   = "log-difference";
const gpaString gpaLogMeanTempDifference::m_modelDescr  = "Среднелогарифмический температурный напор";

gpaLogMeanTempDifference::gpaLogMeanTempDifference(const gpaOwnerLink* link) :
    gpaConvectionTempDifference  (link)
{
}

gpaLogMeanTempDifference::gpaLogMeanTempDifference(const gpaLogMeanTempDifference& difference, const gpaOwnerLink* link) :
    gpaConvectionTempDifference  (difference, link)
{
}

gpaLogMeanTempDifference* gpaLogMeanTempDifference::copyTo(const gpaOwnerLink* link) const
{
    return new gpaLogMeanTempDifference(*this, link);
}

gpaReal gpaLogMeanTempDifference::calcTemperatureDiff(gpaReal leftDeltaTemp, gpaReal rightDeltaTemp) const
{
    if (leftDeltaTemp * rightDeltaTemp <= 0.0)
        return 0.0;
    gpaReal deltaTemp = 0.5 * (leftDeltaTemp + rightDeltaTemp);
    if (leftDeltaTemp != rightDeltaTemp)
    {
        gpaReal absRatio = vmAbs(leftDeltaTemp / rightDeltaTemp);
        gpaReal meanDeltaTemp = vmSign(deltaTemp) * vmAbs(rightDeltaTemp) * (absRatio - 1.0) / log(absRatio);
        gpaReal deltaTempVar = vmAbs(leftDeltaTemp - rightDeltaTemp) / GPA_DELTA_TEMP_BOUND;
        deltaTemp = vmSmoothAbsZero(deltaTempVar, deltaTemp, meanDeltaTemp);
    }
    gpaReal coef = vmMin(vmAbs(leftDeltaTemp), vmAbs(rightDeltaTemp)) / LOG_DIFF_ZERO_SMOOTHING_DELTA_TEMP;
    if (coef < 1.0)
        deltaTemp = vmSmoothAbsZero(coef, 0.0, deltaTemp);
    return getTempDifCoef() * deltaTemp;
}
