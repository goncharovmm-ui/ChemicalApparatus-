#ifndef GPA_EOH_Element_H
#define GPA_EOH_Element_H
#include "gpaFlowElement.h"
#include "gpaHeatLayer.h"
#include "gpaInclude.h"
#include <fstream>
#include <iostream>
#include <numbers>
using namespace std;

#include <vector>

#include <string>

#include <filesystem>

using namespace std;
namespace fs = std::filesystem;

class PolynomialLeastSquares {
private:
  // Решение системы линейных уравнений методом Гаусса
  std::vector<double> gaussElimination(std::vector<std::vector<double>> &A,
                                       std::vector<double> &B) {
    int n = B.size();

    // Прямой ход
    for (int i = 0; i < n; i++) {
      // Поиск максимального элемента в столбце
      double maxEl = fabs(A[i][i]);
      int maxRow = i;
      for (int k = i + 1; k < n; k++) {
        if (fabs(A[k][i]) > maxEl) {
          maxEl = fabs(A[k][i]);
          maxRow = k;
        }
      }

      // Перестановка строк
      for (int k = i; k < n; k++) {
        std::swap(A[maxRow][k], A[i][k]);
      }
      std::swap(B[maxRow], B[i]);

      // Приведение к треугольному виду
      for (int k = i + 1; k < n; k++) {
        double c = -A[k][i] / A[i][i];
        for (int j = i; j < n; j++) {
          if (i == j) {
            A[k][j] = 0;
          } else {
            A[k][j] += c * A[i][j];
          }
        }
        B[k] += c * B[i];
      }
    }

    // Обратный ход
    std::vector<double> x(n);
    for (int i = n - 1; i >= 0; i--) {
      x[i] = B[i] / A[i][i];
      for (int k = i - 1; k >= 0; k--) {
        B[k] -= A[k][i] * x[i];
      }
    }

    return x;
  }

public:
  int degree;

  std::vector<double> coefficients; // Коэффициенты полинома

  void fit(const std::vector<double> &x, const std::vector<double> &y) {
    if (x.size() != y.size() || x.empty()) {
      throw std::invalid_argument("Invalid input data");
    }

    int n = x.size();
    int m = degree + 1;

    // Создание матрицы системы уравнений
    std::vector<std::vector<double>> A(m, std::vector<double>(m, 0.0));
    std::vector<double> B(m, 0.0);

    // Заполнение матрицы A и вектора B
    for (int k = 0; k < m; k++) {
      for (int j = 0; j < m; j++) {
        double sum = 0.0;
        for (int i = 0; i < n; i++) {
          sum += pow(x[i], j + k);
        }
        A[j][k] = sum;
      }

      double sum = 0.0;
      for (int i = 0; i < n; i++) {
        sum += y[i] * pow(x[i], k);
      }
      B[k] = sum;
    }

    // Решение системы уравнений
    coefficients = gaussElimination(A, B);
  }

  double predict(double x) const {
    double result = 0.0;
    for (int i = 0; i <= degree; i++) {
      result += coefficients[i] * pow(x, i);
    }
    return result;
  }

  void printCoefficients() const {
    std::cout << "y = ";
    for (int i = degree; i >= 0; i--) {
      if (i == degree) {
        std::cout << coefficients[i] << " * x^" << i;
      } else if (i > 0) {
        std::cout << " + " << coefficients[i] << " * x^" << i;
      } else {
        std::cout << " + " << coefficients[i];
      }
    }
    std::cout << std::endl;
  }

  double getRMSE(const std::vector<double> &x, const std::vector<double> &y) {
    // Расчет среднеквадратичной ошибки
    double rmse = 0.0;
    for (size_t i = 0; i < x.size(); i++) {
      double error = 100 * (predict(x[i]) - y[i]) / y[i];
      rmse += error * error;
    }
    rmse = 2 * pow(rmse / x.size(), 0.5);
    return rmse;
  }

  const std::vector<double> &getCoefficients() const { return coefficients; }
};

class myPipeRib_EOH
{

    public:
    
    gpaString pipe_Name;
    gpaString fluid;
    gpaMedium* medium;

    gpaReal flag = 0.0;
    gpaReal meanPressure = 101.0;
    gpaReal meanTemp = 300.0;

    gpaReal n_ch    = 1.0;

    //gpaReal l_ch    = 1.0;
    gpaReal deltaH  = 1.0;
   
    gpaReal density   = 1.0;
    gpaReal viscosity = 1.0;
    gpaReal mu        = 1.0;
    gpaReal cp = 1.0;
    gpaReal lambda = 1.0;

    gpaReal v  = 1.0;
    gpaReal Re = 1.0;
    gpaReal volume =0.0;

    gpaReal DP        = 1.0;

    gpaReal crossArea = 0.2;

    gpaReal Pr = 1.0;
    gpaReal Nu = 1.0;
    gpaReal alpha_conv=0.1;

    gpaReal s1 = 0.0;   // FIX: дефолтная инициализация (устранение UB; см. gpaEOHElement.cpp)
    gpaReal s2 = 0.0;

    gpaReal amount_of_sections; 

    gpaReal c;
    gpaReal n;
    gpaReal m;

    gpaReal d_char; 

    gpaReal nRow;

    // Запись матрицы в CSV файл
    bool writeMatrixToCSV(const vector<vector<double>>& matrix, 
                        const string& filename, 
                        char delimiter = ',',
                        int precision = 3,
                        bool includeHeaders = false,
                        const vector<string>& rowHeaders = {},
                        const vector<string>& colHeaders = {}) {
        
        ofstream file(filename);
        
        if (!file.is_open()) {
            cerr << "Ошибка: не удалось открыть файл " << filename << " для записи" << endl;
            return false;
        }
        
        // Устанавливаем точность вывода
        file << scientific << setprecision(precision);
        
        int rows = matrix.size();
        if (rows == 0) {
            cerr << "Ошибка: пустая матрица" << endl;
            file.close();
            return false;
        }
        
        int cols = matrix[0].size();
        
        // Проверка корректности матрицы (все строки одинаковой длины)
        for (int i = 1; i < rows; i++) {
            if (matrix[i].size() != static_cast<size_t>(cols)) {
                cerr << "Ошибка: строки матрицы имеют разную длину" << endl;
                file.close();
                return false;
            }
        }
        
        // Записываем заголовки столбцов (если нужно)
        if (includeHeaders && !colHeaders.empty()) {
            // Если есть заголовки строк, первая ячейка пустая
            if (!rowHeaders.empty()) {
                file << delimiter;
            }
            
            // Записываем заголовки столбцов
            for (int j = 0; j < cols; j++) {
                if (j < static_cast<int>(colHeaders.size())) {
                    // Если в заголовках есть запятые, заключаем в кавычки
                    if (colHeaders[j].find(delimiter) != string::npos) {
                        file << "\"" << colHeaders[j] << "\"";
                    } else {
                        file << colHeaders[j];
                    }
                } else {
                    file << "Column_" << (j + 1);
                }
                
                if (j < cols - 1) {
                    file << delimiter;
                }
            }
            file << endl;
        }
        
        // Записываем данные матрицы
        for (int i = 0; i < rows; i++) {
            // Заголовок строки (если есть)
            if (includeHeaders && !rowHeaders.empty()) {
                if (i < static_cast<int>(rowHeaders.size())) {
                    // Если в заголовках есть запятые, заключаем в кавычки
                    if (rowHeaders[i].find(delimiter) != string::npos) {
                        file << "\"" << rowHeaders[i] << "\"";
                    } else {
                        file << rowHeaders[i];
                    }
                } else {
                    file << "Row_" << (i + 1);
                }
                file << delimiter;
            }
            
            // Элементы строки матрицы
            for (int j = 0; j < cols; j++) {
                file << matrix[i][j];
                if (j < cols - 1) {
                    file << delimiter;
                }
            }
            file << endl;
        }
        
        file.close();
        
        if (file.fail()) {
            cerr << "Ошибка при записи в файл" << endl;
            return false;
        }
        
        return true;
    }


    // Проверка существования директории (кросс-платформенная)
    bool directoryExists(const string& path) {
        return fs::exists(path) && fs::is_directory(path);
    }

    // Создание директории (кросс-платформенная)
    bool createDirectory(const string& path) {
        try {
            return fs::create_directory(path);
        } catch (const fs::filesystem_error& e) {
            cerr << "Ошибка при создании директории: " << e.what() << endl;
            return false;
        }
    }

    void exportCurrentBiblProps(string way, gpaReal tempStart, gpaReal tempEnd, gpaReal deltaTemp, gpaDataVector fractions)
    {  
        
        cout << "  cp_gas = f(T)   " << " | " <<"\n";

        vector <vector<gpaReal>> parsVST;
        vector<gpaReal> pars={0,0,0,0,0,0};
        for (gpaReal temp = tempStart; temp < tempEnd; temp = temp + deltaTemp)
        {
            //cout<<temp <<endl;
            medium->calcFlashPT(meanPressure, temp, fractions); 

            pars[0] = temp;
            pars[1] = medium->getConductivity();
            pars[2] = medium->getDensity();
            pars[3] = medium->getViscosity();
            pars[4] = medium->getHeatCapacity()/medium->getMolarMass();
            pars[5] = medium->getMolarMass();

            parsVST.push_back(pars);
        }

        gpaString nameExport_CM = pipe_Name + " " + fluid + " " + to_string(meanPressure) + " .csv";
        cout << "--> export "<< " | "  << nameExport_CM << " " << writeMatrixToCSV(parsVST, way + nameExport_CM) <<endl;

        std::cout << "  ---------   " <<"\n"; 
    
        
    }

    // Функция, выдающая свойства ГМ. Функции получены интерполяцией табличных зависимостей терминола 66
    gpaReal getOilProp(gpaString par, gpaReal T)
    {
        if(par == "rho"){
           return   1236.69 - 0.745665*T;//kg/m^3
        }
        if(par == "cp"){
           return   (0.5211052170945513 + 0.0035340139549585384*T);//kJ/kg/K
        }
        if(par == "lambda"){
           return   (0.15395 - 0.000103468*T)/1000;//kW/K/m
        }  
        if(par == "eta"){
           return   21.834/pow(T-273,1.912);//Pa*s
        }
        if(par == "mu"){
           return   252.0;//kg/kmol
        }
    }

    // Функция, выдающая свойства ГС и ДГ. Для простоты взяты табличные зависимости воздуха при 1 атм 
    gpaReal getGasProp(gpaString par, gpaReal T)
    {
        if(par == "rho"){
           return   365.863/T;
        }
        if(par == "cp"){
           return   (-229.668 + 463.18*pow(T,0.168614))/1000.0;
        }
        if(par == "lambda"){
           return   (0.00396343 + 0.0000706675*T)/1000.0;
        }  
        if(par == "eta"){
           return   -2.96295*pow(10.0,-6.0) + 3.65048*pow(10.0,-7.0)*pow(T,0.696601);
        }
        if(par == "mu"){
           return   29.0;
        }
    }

    //Получить теплопроводность, плотность, динамическую вязкость,теплоемкость, молярную массу
    void getStandartPackProp(gpaDataVector fractions)
    {
      medium->calcFlashPT(meanPressure, meanTemp, fractions);
      //std::cout << " gas | is good calcFlash | "<< res<< "\n";
      lambda     = medium->getConductivity();
      density    = medium->getDensity();
      viscosity  = medium->getViscosity();
      cp         = medium->getHeatCapacity()/medium->getMolarMass();
      mu         = medium->getMolarMass();

    }

   //Функция сигмойда
    gpaReal sigmoid(gpaReal x)
    {
        return 1.0 / (1.0 + std::exp(-x));
    }

    //Выдает сглаженное значение кусочно-заданной функции по числу Рейнолдса
    gpaReal smFun(gpaReal fL,gpaReal fR, gpaReal ReStar, gpaReal ReDelta)
    {
        gpaReal ReDim = (Re - ReStar) / ReDelta;
        return fL * (1.0 - sigmoid(ReDim)) + fR * sigmoid(ReDim);
    } 
    
    void calcMyPipeHeatTransherProp(bool imShow,  gpaReal G)
    {   
      v  = G * mu / n_ch / density / crossArea;

      Re = v * density * d_char / viscosity;
      
      Pr = viscosity*cp/lambda;
      Nu = smFun(1, c * pow(abs(Re), n) *  pow(Pr, m) , 10, 10);

      if(imShow==1)
      {
          std::cout << "  Re | Nu " <<"\n";
          std::cout << Re << " | " <<  Nu << " | "   <<"\n";
          std::cout << c << " | " <<  n << " | " << m  <<"\n";
      }

      gpaReal alphaEG   = Nu*lambda/d_char;
      alpha_conv = alphaEG;

    }

    void calcMyPipeViscousFrictionProp(bool isShow)
    {
        gpaReal sigma1 = s1/d_char;
        gpaReal sigma2 = s2/d_char;
        gpaReal phi = (sigma1 - 1)/(sigma2 - 1);
        // FIX: основание степени не может быть отрицательным (pow(neg,1.5)=NaN).
        gpaReal base = (1.7 - phi) > 0.0 ? (1.7 - phi) : 0.0;
        gpaReal cS = 3.2 + 0.66 * pow(base,1.5);
        gpaReal epslilonZero_Low_Re = cS * pow(100,-0.27);
        gpaReal epslilonZero = cS * pow(Re + 1,-0.27);

        gpaReal epsilonDP = (nRow + 1)*smFun(epslilonZero_Low_Re, epslilonZero,100,100);


        DP       = epsilonDP * density * v*abs(v) / 2  / 1000;//kPa

        if(isShow==1)
        {
          std::cout << "   zeta_0  " << epslilonZero <<"\n";
          std::cout << "   zeta  " << epsilonDP <<"\n";

          std::cout << "   Re  " << Re <<"\n";
          std::cout << "  DP " << " | " <<  DP  <<"\n";
        }
    }

};


class gpaEOHElement : public gpaFlowElement {
public:
  // не убирать
  gpaEOHElement(const gpaParentLink *link);
  gpaEOHElement(const gpaEOHElement &m_heatPipes);
  virtual gpaEOHElement *copy() const override;
  // не убирать

  virtual gpaUInt getMinNumMixPorts(gpaUInt index) const override;
  static gpaUInt getDeviceMinNumMixPorts(gpaUInt index);
  static gpaUInt getDeviceNumMixCircuits();
  virtual gpaUInt getNumMixCircuits() const;
  virtual gpaUInt getMaxNumMixPorts(gpaUInt index) const override;
  static gpaUInt getDeviceMaxNumMixPorts(gpaUInt index);

  //+++++++++++ Инициализация переменных

  // Кол-во переменных
  gpaUInt getNumVariables() const override;

  // Нумирация переменных
  enum {
    TEMP_TEH = 0,
  };

  void fillVarNames(gpaStringVector &varNames) const override;

  // Задаем начальные условия для переменнных
  gpaResult initVariables(gpaVector &variables) const override;

  //++++++++++++ Инициализация переменных

  //+++++++++++++ Инициализация остального

  //+++++++++++++ Функции для работы с файлами

  //+++++++++++++ Функции для работы с файлами

  // Главная функция инициалзации
  gpaResult initialize() override;


      //для расчета тепломассопереноса в межтрубном пространстве
    void calcGeomParsGasPipeline();


  gpaResult fillMassMatrix(gpaUInt refRow, gpaUInt refCol) const;

  // Инициализация среды
  void initMedium();

  // Инициализация потоков
  void initFlows();

  //+++++++++++++++++ Инициализация остального

  //+++++++++++++++++ Функции, которые будут использоваться на каждой итерации

  //+++ Расчет свойств потоков
  void calcFlowProperties();
  //+++ Расчет свойств потоков

  //+++ Расчет теплообмена

  // Функция сигмойда
  gpaReal sigmoid(gpaReal x);

  // Расчет перепада давления
  void calcDeltaPress(int isShowInConsol);

  //Расчет средних температур в каналах
  void calcMeanTemp(bool isShow);

  //Расчет средних значений давлений в каналах
  void calcMeanPressure();

  //Получить средне-логарифмический перепад температур 0 -  соноправленное течение, 1 - противонаправленное течение
  gpaResult getLMTD(gpaReal T_in_1, gpaReal T_out_1, gpaReal T_in_2, gpaReal T_out_2, gpaUInt i_Flow_Scheme);


  // Расчет теплообмена
  void calcQ(int isShowInConsol);

  // Главная функция: полный набор уравнений для "стрелок" и фазового равновесия
  gpaResult calcFuncValues(const gpaConstVector &,
                           const gpaConstVector &variables, gpaVector &values,
                           const gpaSetOfEquations &eqIds) override;

  // Невязка по энтальпии
  gpaResult calcEnthalpyFuncValueAt(gpaUInt circIdx, gpaUInt portIdx,
                                    gpaReal enthalpy,
                                    gpaReal &funcValue) const override;

  // Невязка по компонентам — для выходных портов сравниваем с переменными
  // разделителя
  gpaResult calcFractionsFuncValuesAt(gpaUInt circIdx, gpaUInt portIdx,
                                      const gpaConstVector &fractions,
                                      gpaVector &funcValues) const override;

  virtual const gpaString &getTypeName() const override;
  virtual const gpaString &getDescription() const override;

private:
  gpaElementMixCircuit *circuit_oil;

  void calcThermalParams();

public:
  // Переключатель библиотек
  gpaReal flagMixBibl = 0.0;

  // Параметры геометрии:
  gpaReal m_d = 0.0;       // внутренний диаметр (м)
  gpaReal m_l = 0.0;       // длина аппарата (м)
  gpaReal m_dh = 0.0;      // гидростат. напор (м)
  gpaReal m_nBends = 0.0;  // число колен
  gpaReal m_eps = 0.0;     // шероховатость (м)
  gpaReal m_Tenv = 298.15; // температура окружающей среды (К)

  gpaHeatLayerVector m_heatLayers;

  // PIPE (общая труба)
  gpaReal m_R_pipe = 1.0;
  gpaReal m_A_in = 0.0;
  gpaReal m_A_out = 0.0;
  gpaReal m_A_in_pipe = 0.0;
  gpaReal m_A_out_pipe = 0.0;
  gpaReal m_alpha_in_pipe = 0.0;
  gpaReal m_alpha_out_pipe = 0.0;

  // GAS (газовая)
  gpaReal m_R_gas = 1.0;
  gpaReal m_A_in_gas = 0.0;
  gpaReal m_A_out_gas = 0.0;
  gpaReal m_alpha_in_gas = 0.0;
  gpaReal m_alpha_out_gas = 0.0;
  gpaReal m_wall_diamet1;
  gpaReal m_wall_diamet2;
  gpaReal m_wall_diamet3;
  gpaReal m_hydro_coeff;
  gpaReal m_diametr;
  gpaReal m_wall_conductive1;
  gpaReal m_wall_conductive2;

  // Порты ступеней
  const gpaMixPort *inlet_oil;
  const gpaMixPort *out_oil;

  // Для межтрубного пространства CC используется модель трубы с оребрением 
  myPipeRib_EOH oilChannel;

  // Начальная средняя температура пучка ТЭНов
  gpaReal TEMP_TEH_bundle_INIT;
  // Средняя температура пучка ТЭНов
  gpaReal temp_TEH_bundle;

  // Удельный коэффициент теплоотдачи, кВт/(м^2*К) 
  gpaReal alpha_oil;

  // Масса пучка ТЭНов, кг
  gpaReal mass_TEH_bundle;

  // Масса ТЭН
  gpaReal mass_TEH;

  // Электричкаская мощность пучка ТЭНов, кВт
  gpaReal TEH_bundle_Power = 180;

  //Геометрия

  //кол-во ТЭНов  
  gpaReal TEH_amount = 45;  
  //Длина зоны теплоотдачи 
  gpaReal len_HE_zone = 2.7;
  //Длина ТЭН 
  gpaReal len_TEH;

  //Кол-во секций пучка труб
  gpaReal amount_of_sections = 14;

  //Длина секции пучка труб
  gpaReal len_of_section;
  
  //Внутренний диаметр обечайки 
  gpaReal d_inner_oil_ch = 0.236;

  //Кол-во рядов труб
  gpaReal TEH_Row = 11;

  //Продольное расстояние между трубами
  gpaReal s1 = 0.023;

  //Поперечное расстояние между трубами
  gpaReal s2 = 0.020;

  //Внешний диаметр ТЭН 
  gpaReal d_TEH = 0.012;

  //Площадь теплообмена, м^2 
  gpaReal HE_area;

  // Теплообмен

  // Средняя теплоемкость материалов тена, кДж/(кг*К) 
  gpaReal cp_TEH_bundle = 0.75;

  //Тепловая мощность снимаемая маслом с поверхности пучка ТЭНов, кВт
  gpaReal Q_from_TEH_bundle_to_oil;

  //Коэффициент коррекции теплообмена
  gpaReal k_delta_H;

  //Коэффициент коррекции перепала давления
  gpaReal k_delta_DP;

  // Изменение энтальпии масла Дж/моль
  gpaReal Delta_H_oil; 

  // Свойства потоков
  gpaReal P_in_oil;
  gpaReal P_out_oil;

  // Перепад давлений по маслу
  gpaReal delta_P_oil;



  // коэффициент задвижки
  gpaReal coef_deltaP_Valve = 1;

  // Массовый расход входящего масла, кг/c
  gpaReal m_dot_oil;

  // Мольные расходы масла, кмоль/с
  gpaReal G_in_oil;
  gpaReal G_out_oil;

  // Темпераутра масла
  gpaReal T_in_oil;
  gpaReal T_out_oil;

  // Medium
  gpaMedium *m_medium_oil;

  // Old
  gpaReal m_temperature = 0.0;
  gpaReal m_gasEnthalpy = 0.0;
  gpaReal m_liquidEnthalpy = 0.0;
  gpaReal m_liquidFlowRate = 0.0;

public:
  static const gpaString &getDeviceTypeName();
  static const gpaString &getDeviceDescription();

private:
  static const gpaString m_typeName;
  static const gpaString m_description;
  static const gpaSensorInfoVector m_sensors;
};
#endif
