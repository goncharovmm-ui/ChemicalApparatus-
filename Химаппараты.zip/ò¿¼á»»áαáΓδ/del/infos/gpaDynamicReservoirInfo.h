/*!
 *  \file      gpaDynamicReservoirInfo.h
 *  \brief     Метакласс описания односекционного сепаратора для библиотеки элементов
 *  \author    Мельников Роман
 *  \date      2025
 */
#ifndef GPA_DYNAMIC_RESERVOIR_INFO_H
#define GPA_DYNAMIC_RESERVOIR_INFO_H

#include "gpaInclude.h"
#include "gpaDeviceInfo.h"

/*!
 * \class gpaDynamicReservoirInfo
 * \brief Метакласс описания односекционного сепаратора для библиотеки элементов
 */
class gpaDynamicReservoirInfo : public gpaDeviceInfo
{
public:
    /*!
     * Конструктор по умолчанию
     */
    gpaDynamicReservoirInfo();
    /*!
     * Деструктор по умолчанию
     */
    virtual ~gpaDynamicReservoirInfo() override = default;
    /*!
     * Получить количество материальных контуров элемента
     * \return количество материальных контуров элемента
     */
    virtual gpaUInt getNumMixCircuits() const override;
    /*!
     * Получить минимальное количество материальных портов аппарата
     * \return минимальное количество материальных портов аппарата
     */
    virtual gpaUInt getMinNumMixPorts(gpaUInt index) const override;
    /*!
     * Получить максимальное количество материальных портов аппарата
     * \return максимальное количество материальных портов аппарата
     */
    virtual gpaUInt getMaxNumMixPorts(gpaUInt index) const override;
    /*!
     * Получить название материального контура элемента
     * \param index индекс контура
     * \return название материального контура элемента
     */
    virtual const gpaString *getMixCircuitName(gpaUInt index) const override;
    /*!
     * Получить название материального порта элемента в заданном контуре
     * \param circIdx индекс контура
     * \param portIdx индекс порта в контуре
     * \return название материального порта элемента в заданном контуре
     */
    virtual const gpaString *getMixPortName(gpaUInt circIdx, gpaUInt portIdx) const override;
    /*!
     * Создать аппарат
     * \param [in] interfaces интерфейсы интегратора
     * \param [in] pairDevice ссылка на соответствующий аппарат в интеграторе
     * \param model описание параметров аппарата и его подмоделей
     * \return ссылка на аппарат
     */
    virtual gpaElement *createDevice(const gpaCoreInterfaces *interfaces, gpaCoreReference pairDevice,
                                     const gpaExtObjectModel *model) const override;
};

#endif
