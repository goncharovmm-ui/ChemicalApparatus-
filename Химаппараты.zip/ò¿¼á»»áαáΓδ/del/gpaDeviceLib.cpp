#include "gpaDeviceLib.h"
#include "gpaLibraryVersion.h"

#include "gpaDynamicReservoirInfo.h"
#include "gpaFillingRiserInfo.h"
#include "gpaVolumeVaporatorInfo.h"

#include "gpaGasFilterInfo.h"
#include "gpaLiquidFilterInfo.h"
#include "gpaNitrogenTankInfo.h"
#include "gpaReboilerInfo.h"
#include "gpaTurboExpanderInfo.h"
#include "gpaVaporatorInfo.h"
#include "gpaIncineratorInfo.h"
#include "gpaFlareSystemInfo.h"

#include "gpaConvectiveHeatExchangerInfo.h"
#include "gpaFurnaceHeatExchangerInfo.h"
#include "gpaGBVER2Info.h"
#include "gpaHeatRecoveryUnitInfo.h"
#include "gpaTDBaseVerSimpleInfo.h"
#include "gpaEOHInfo.h"


#ifdef NDEBUG
const gpaString debugPostfix = "";
#else
const gpaString debugPostfix = ", DEBUG";
#endif

const gpaString gpaDeviceLib::m_name = DEL_DEVICES_NAME;
const gpaString gpaDeviceLib::m_version =
    gpaString(DEL_DEVICES_VERSION) + " (Build: " + GPA_PROJECT_FULL_VERSION +
    debugPostfix + ")";
const gpaString gpaDeviceLib::m_description = DEL_DEVICES_DESCRIPTION;

gpaGeneralDeviceLib *createLibrary(const gpaCoreInterfaces *interfaces) {
  return new gpaDeviceLib(interfaces);
}

gpaDeviceLib::gpaDeviceLib(const gpaCoreInterfaces *interfaces)
    : gpaGeneralDeviceLib(interfaces) {
  setDevices({

      new gpaDynamicReservoirInfo(),
      new gpaVolumeVaporatorInfo(),
      new gpaVaporatorInfo(),
      new gpaTurboExpanderInfo(),
      new gpaGasFilterInfo(),
      new gpaLiquidFilterInfo(),
      new gpaNitrogenTankInfo(),
      // new gpaFIreOilHeaterInfo(),
      // new gpaFurnaceInfo(),
      // new gpaSeparatorInfo(),
      // new gpaAbsorberInfo(),copy
      new gpaReboilerInfo(),
      //    new gpaStanderInfo(),
      //  new gpaSimpleSepInfo(),
      new gpaFillingRiserInfo(),

      // GMM
      new gpaFurnaceHeatExchangerInfo(),
      new gpaHeatRecoveryUnitInfo(),
      new gpaConvectiveHeatExchangerInfo(),
      new gpaEOHInfo(),
      new gpaTDBaseVerSimpleInfo(),
      new gpaGBVER2Info(),
      new gpaIncineratorInfo(),
      new gpaFlareSystemInfo(),
  });
}
