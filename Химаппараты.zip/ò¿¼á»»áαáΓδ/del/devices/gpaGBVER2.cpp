#include "gpaGBVER2.h"
#include <iostream>

constexpr gpaUInt NUM_CIRCUITS          = 1;

constexpr gpaUInt ID_CIRCUIT = 0;

constexpr gpaUInt ID_PORT_GAS_INLET = 0;
constexpr gpaUInt ID_PORT_GAS_OUTLET = 1;

constexpr gpaUInt NUM_PORTS          = 2;

// Перечень параметров для расчета
constexpr gpaUInt ID_PARAM_EM_Power       = 0;
constexpr gpaUInt ID_PARAM_k_delta_H_CS   = 1;
constexpr gpaUInt ID_PARAM_omegaInit      = 2;
constexpr gpaUInt ID_PARAM_I_shaft        = 3;

constexpr gpaUInt ID_PARAM_numb_calc_delta_P_regime        = 4;

constexpr gpaUInt ID_PARAM_mdot_1        = 5;
constexpr gpaUInt ID_PARAM_mdot_2        = 6;
constexpr gpaUInt ID_PARAM_mdot_3        = 7;

constexpr gpaUInt ID_PARAM_P_1        = 8;
constexpr gpaUInt ID_PARAM_P_2        = 9;
constexpr gpaUInt ID_PARAM_P_3        = 10;

constexpr gpaUInt ID_PARAM_P_Const        = 11;
constexpr gpaUInt ID_PARAM_mdot_type        = 12;
constexpr gpaUInt ID_PARAM_GB_type        = 13;

constexpr gpaUInt ID_PARAM_nom_omega        = 14;

constexpr gpaUInt ID_PARAM_coef_deltaP_Valve        = 15;

// sensors
constexpr gpaUInt ID_SENSOR_OMEGA           = 0;
constexpr gpaUInt ID_SENSOR_CS_IN_TEMP      = 1;
constexpr gpaUInt ID_SENSOR_CS_OUT_TEMP     = 2;
constexpr gpaUInt ID_SENSOR_Delta_H_CS      = 3;
constexpr gpaUInt ID_SENSOR_deltaP_CS       = 4;
constexpr gpaUInt ID_SENSOR_k_CS            = 5;
constexpr gpaUInt ID_SENSOR_n_CS            = 6;
constexpr gpaUInt ID_SENSOR_Q_CS            = 7;
constexpr gpaUInt ID_SENSOR_momentCS        = 8;

const gpaString gpaGBVER2::m_typeName      = "GB-VER-2";
const gpaString gpaGBVER2::m_description   = "Газодувка (ver 2)";

const gpaStringVector gpaGBVER2::m_circuitNames =
{
    "Воздуходувка",
};

const gpaStringVector gpaGBVER2::m_portNames =
{
    "Вход",
    "Выход",
};



const gpaParameterInfoVector gpaGBVER2::m_parameters =
{
    realParam("EM_Power",           "Мощность электродвигателя, кВт",             GPA_DIMLESS_UNIT,     true, 1.0),
    realParam("k_delta_H_CS",       "Адиабатический КПД",                         GPA_DIMLESS_UNIT,     false, 1.0),

    realParam("omegaInit",          "Частота вращения вала, об/мин",              GPA_DIMLESS_UNIT,     false,  9000.0),
    realParam("I_shaft",            "Момент инерции вала, кг*м^2",                GPA_DIMLESS_UNIT,     false, 10000),

    realParam("numb_calc_delta_P_regime", "Вариант ввода напорной кривой (0 - соглавно ОЛ, 1 - ручной ввод)",    GPA_DIMLESS_UNIT,     false, 0),

    realParam("mdot_1",       "Расход 1",                         GPA_DIMLESS_UNIT,     false, 1.0),
    realParam("mdot_2",       "Расход 2",                         GPA_DIMLESS_UNIT,     false, 1.0),
    realParam("mdot_3",       "Расход 3",                         GPA_DIMLESS_UNIT,     false, 1.0),

    realParam("P_1",       "Давление 1, кПа",                         GPA_DIMLESS_UNIT,     false, 1.0),
    realParam("P_2",       "Давление 2, кПа",                         GPA_DIMLESS_UNIT,     false, 1.0),
    realParam("P_3",       "Давление 3, кПа",                         GPA_DIMLESS_UNIT,     false, 1.0),

    realParam("P_Const",       "Давление на фикс. порту, кПа",                         GPA_PRESSURE_UNIT,     false, 1.0),
    realParam("mdot_type",       "0 - массовый расход, тыс. кг/ч.  1 - объемный расход м^3/мин. ",     GPA_DIMLESS_UNIT,     false, 1),
    realParam("GB_type",       "0 - M0-74C01, 1 - G1-64C01",                         GPA_DIMLESS_UNIT,     false, 0),
    realParam("nom_omega",       "Номинальная частота, об/мин",                         GPA_DIMLESS_UNIT,     false, 0),

    realParam("coef_deltaP_Valve",       "Коэффициент местного сопротивление арматуры",                         GPA_DIMLESS_UNIT,     true, 1),


};


const gpaSensorInfoVector gpaGBVER2::m_sensors =
{
    //6
    scalarSensor("OMEGA",      "Частота вращения вала, об/мин",                 GPA_DIMLESS_UNIT),
    scalarSensor("CS_IN_TEMP",      "Температура газа на входе",               GPA_TEMPERATURE_UNIT),
    scalarSensor("CS_OUT_TEMP",     "Температура газа на выходе",              GPA_TEMPERATURE_UNIT),

    scalarSensor("Delta_H_CS",     "Изменение энтальпии газа, кДж/кмоль", NAN),

    scalarSensor("deltaP_CS",      "Перепад давлений, КПа",             GPA_DIMLESS_UNIT),
    scalarSensor("k_out_cs",       "Показатель адиабаты газа на выходе",             GPA_DIMLESS_UNIT),
    scalarSensor("n_out_cs",      "Показатель политропы газа на выходе",             GPA_DIMLESS_UNIT),

    scalarSensor("Q_CS",      "Изменение энергии газа, кВт",             GPA_DIMLESS_UNIT),

    scalarSensor("momentCS",      "Момент газа, Н*м",             GPA_DIMLESS_UNIT),

};

gpaGBVER2::gpaGBVER2(const gpaCoreInterfaces* interfaces, gpaCoreReference importRef) :
    gpaExportSystem (interfaces, importRef),
    m_heatPipes      (asParent())
{
}

gpaResult gpaGBVER2::calcSensors(gpaVector& sensors) const
{

    setSensorValue(sensors, ID_SENSOR_OMEGA,      m_heatPipes.omega*60); //
    setSensorValue(sensors, ID_SENSOR_CS_IN_TEMP,      m_heatPipes.T_in_CS - 273.15);//T_in_oil - 273.15
    setSensorValue(sensors, ID_SENSOR_CS_OUT_TEMP,     m_heatPipes.T_out_CS - 273.15);//T_out_oil - 273.15

    setSensorValue(sensors, ID_SENSOR_Delta_H_CS,    m_heatPipes.Delta_H_CS);

    setSensorValue(sensors, ID_SENSOR_deltaP_CS,         -m_heatPipes.deltaP_CS);//

    setSensorValue(sensors, ID_SENSOR_k_CS,         m_heatPipes.k_out_cs);//
    setSensorValue(sensors, ID_SENSOR_n_CS,         m_heatPipes.n_out_cs);//

    setSensorValue(sensors, ID_SENSOR_Q_CS,         m_heatPipes.Q_CS/1000);//

    setSensorValue(sensors, ID_SENSOR_momentCS,         m_heatPipes.momentCS/1000);//

    return GPA_RESULT_OK;
}
gpaResult gpaGBVER2::checkParamValues(const gpaExtParameter *values) const
{
    (void)values;
    return GPA_RESULT_OK;
}

void gpaGBVER2::setNames()
{
    m_heatPipes.setName("pipes");
}

gpaResult gpaGBVER2::initMixtureFlow(const gpaExtParameter *values)
{
    // Назначаем параметры проточных элементов
    bool good = true;
    return GPA_RESULT_OK;
}

gpaResult gpaGBVER2::setParamValues(const gpaExtParameter *values, bool checkNeeded)
{
    //Передача введенных параметров
    m_heatPipes.k_delta_H_CS = values[ID_PARAM_k_delta_H_CS].value.realValue;
    m_heatPipes.EM_Power = values[ID_PARAM_EM_Power].value.realValue;
    m_heatPipes.omegaInit = values[ID_PARAM_omegaInit].value.realValue;
    m_heatPipes.I_shaft   = values[ID_PARAM_I_shaft]  .value.realValue;
    m_heatPipes.numb_calc_delta_P_regime = values[ID_PARAM_numb_calc_delta_P_regime]  .value.realValue;
    m_heatPipes.coef_deltaP_Valve = values[ID_PARAM_coef_deltaP_Valve]  .value.realValue;
    m_heatPipes.mdot_type = values[ID_PARAM_mdot_type].value.realValue;
    m_heatPipes.gb_channel.GB_type = values[ID_PARAM_GB_type].value.realValue;

    if(m_heatPipes.numb_calc_delta_P_regime == 1)
    {
        m_heatPipes.gb_channel.m_Dot_Points[0]  = values[ID_PARAM_mdot_1].value.realValue;
        m_heatPipes.gb_channel.m_Dot_Points[1]  = values[ID_PARAM_mdot_2].value.realValue;
        m_heatPipes.gb_channel.m_Dot_Points[2]  = values[ID_PARAM_mdot_3].value.realValue;

        m_heatPipes.gb_channel.pressure_Points[0] = values[ID_PARAM_P_1].value.realValue;
        m_heatPipes.gb_channel.pressure_Points[1] = values[ID_PARAM_P_2].value.realValue;
        m_heatPipes.gb_channel.pressure_Points[2] = values[ID_PARAM_P_3].value.realValue;

        m_heatPipes.gb_channel.const_pressure_on_one_port = values[ID_PARAM_P_Const].value.realValue;

        m_heatPipes.gb_channel.nom_omega = values[ID_PARAM_nom_omega].value.realValue;
    }

    // Проверка параметров, если требуется
    if (checkNeeded)
    {
        gpaResult res = checkParamValues(values);
        if (res != GPA_RESULT_OK)
            return res;
    }
    // Даем названия элементам и потокам
    setNames();
    // Инициализируются элементы с потоком смеси
    gpaResult res = initMixtureFlow(values);
    if (res != GPA_RESULT_OK)
        return res;
    // Обновляем параметры воздуха на входе
    return res;
}

gpaResult gpaGBVER2::buildDevice()
{
    bool good = true;
    // Соединяем поток смеси по трубам с граничными потоками смеси системы
    good = good && m_heatPipes.connectMixStream(GPA_ELEM_CIRCUIT_0, ID_PORT_GAS_INLET,  getEdgeMixStream(ID_CIRCUIT,   ID_PORT_GAS_INLET),  GPA_STREAM_INLET);
    good = good && m_heatPipes.connectMixStream(GPA_ELEM_CIRCUIT_0, ID_PORT_GAS_OUTLET, getEdgeMixStream(ID_CIRCUIT,   ID_PORT_GAS_OUTLET), GPA_STREAM_OUTLET);
    if (!good)
        return GPA_ERROR_WRONG_ARGS;
    // Добавляем в систему все элементы и потоки
    setElements({&m_heatPipes});
    setStreams({});
    return GPA_RESULT_OK;
}

gpaResult gpaGBVER2::initialize()
{
    // Подключить экспортируемый элемент к потокам в интеграторе
    gpaResult res = linkToCoreStreams();
    if (res != GPA_RESULT_OK)
        return res;
    // Соединяем все элементы друг с другом
    res = buildDevice();
    if (res != GPA_RESULT_OK)
        return res;
    // Создаем схемы течений (нужны соединенные элементы)
    if (!createSimStructures({}, {getOuterEntrance(ID_CIRCUIT, ID_PORT_GAS_INLET)}))
        return GPA_ERROR_WRONG_ARGS;
    // Инициализируем систему
    return gpaExportSystem::initialize();
}

gpaResult gpaGBVER2::setSignals(const gpaConstVector &signals)
{
    gpaReal value;
    bool good = true;

    if (getSignalValue(signals, ID_PARAM_EM_Power, value))
    m_heatPipes.EM_Power               = value;

    if (getSignalValue(signals, ID_PARAM_coef_deltaP_Valve, value))
    m_heatPipes.coef_deltaP_Valve =   value;

    return GPA_RESULT_OK;
}
const gpaString* gpaGBVER2::getDeviceMixCircuitName(gpaUInt index)
{
    return index < NUM_CIRCUITS ? &m_circuitNames[index] : NULL;
}
const gpaString* gpaGBVER2::getDeviceMixPortName(gpaUInt circIdx, gpaUInt portIdx)
{
    if (circIdx == ID_CIRCUIT)
         return portIdx < NUM_PORTS ? &m_portNames[portIdx] : NULL;
    return NULL;
}





