#include "gpaLiquidFilter.h"
#include "gpaLogMeanTempDifference.h"
#include "gpaThinWall.h"
#include "gpaZeroRadiation.h"
#include <iostream>
#include <numbers>

constexpr gpaUInt ID_CIRCUIT_INNER = 0;
constexpr gpaUInt NUM_CIRCUITS = 1;

constexpr gpaUInt ID_CIRCUIT = 0;

constexpr gpaUInt ID_PORT_INLET = 0;
constexpr gpaUInt ID_PORT_OUTLET = 1;
constexpr gpaUInt NUM_PORTS = 2;

constexpr gpaUInt ID_PARAM_NUM = 0x00;
constexpr gpaUInt ID_PARAM_RADIUS = 0x01;
constexpr gpaUInt ID_PARAM_RADIUS_FILTER = 0x02;
constexpr gpaUInt ID_PARAM_HEIGHT = 0x03;
constexpr gpaUInt ID_PARAM_LENTGH = 0x04;
constexpr gpaUInt ID_PARAM_WALL_THICKNESS = 0x05;
constexpr gpaUInt ID_PARAM_INSULATION_THICKNESS = 0x06;
constexpr gpaUInt ID_PARAM_ELEMENT_DIAMETER = 0x07;
constexpr gpaUInt ID_PARAM_ALPHA_IN = 0x08;
constexpr gpaUInt ID_PARAM_ALPHA_OUT = 0x09;
constexpr gpaUInt ID_PARAM_INSULATION_HEAT_COEF = 0x0A;
constexpr gpaUInt ID_PARAM_WALL_HEAT_COEF = 0x0B;
constexpr gpaUInt ID_PARAM_LAMBDA = 0x0C;
constexpr gpaUInt ID_PARAM_POROSITY = 0x0D;
constexpr gpaUInt ID_PARAM_ENV_TEMP = 0x0E;

constexpr gpaUInt ID_SENSOR_HEAT_FLOW = 0x00;
constexpr gpaUInt ID_SENSOR_PRESSURE_DROP = 0x01;
constexpr gpaUInt ID_SENSOR_TEMP_DROP = 0x02;
constexpr gpaUInt ID_SENSOR_PERMEABILITY = 0x03;

const gpaString gpaLiquidFilter::m_typeName = "liquid-filter";
const gpaString gpaLiquidFilter::m_description = "Фильтр";

const gpaStringVector gpaLiquidFilter::m_circuitNames = {
    "Контрур",
};

const gpaStringVector gpaLiquidFilter::m_portNames = {
    "Вход",
    "Выход",
};

const gpaParameterInfoVector gpaLiquidFilter::m_parameters = {
    intParam("m", "Количество фильтрующих элементов", 5),
    realParam("r", " Внутренний радиус корпуса фильтра", GPA_LENGTH_UNIT, false,
              5),
    realParam("rf", "Радиус фильтрующего элемента", GPA_LENGTH_UNIT, false, 5),
    realParam("h", "Высота фильтра", GPA_LENGTH_UNIT, false, 5),
    realParam("l", "Длина фильтрующего элемента", GPA_LENGTH_UNIT, false, 5),
    realParam("dw", "Толщина металлической стенки корпуса", GPA_LENGTH_UNIT,
              false, 5),
    realParam("di", "Толщина теплоизоляции", GPA_LENGTH_UNIT, false, 5),
    realParam("d", " Размер твердых частиц", GPA_LENGTH_UNIT, false, 5),
    realParam("a-in", "Коэффициент внутренней теплоотдачи",
              GPA_HEATTRANS_COEF_UNIT, false, 5),
    realParam("a-out", "Коэффициент внешней теплоотдачи",
              GPA_HEATTRANS_COEF_UNIT, false, 5),
    realParam("ki", "Теплопроводность материала теплоизоляции",
              GPA_CONDUCTIVITY_UNIT, false, 5),
    realParam("kw", "Теплопроводность материала стенки", GPA_CONDUCTIVITY_UNIT,
              false, 5),
    realParam("lambda", "Эмпирический коэффициент засорения", GPA_DIMLESS_UNIT,
              false, 1),
    realParam("epsilon", "Пористость", GPA_DIMLESS_UNIT, false, 4e-1),
    realParam("T-env", "Температура окружающей среды", GPA_TEMPERATURE_UNIT,
              true, 20),
};

const gpaSensorInfoVector gpaLiquidFilter::m_sensors = {
    scalarSensor("heat-flow", "Тепловой поток", GPA_HEAT_RATE_UNIT),
    scalarSensor("pressure-drop", "Перепад давления в фильтре",
                 GPA_PRES_DIFFER_UNIT),
    scalarSensor("temperature-drop", "Перепад температуры в фильтре",
                 GPA_TEMP_DIFFER_UNIT),
    scalarSensor("permeability", "Коэффициент проницаемости", GPA_AREA_UNIT)};

gpaLiquidFilter::gpaLiquidFilter(const gpaCoreInterfaces *interfaces,
                                 gpaCoreReference importRef)
    : gpaExportSystem(interfaces, importRef), m_filter(asParent()) {}

gpaResult gpaLiquidFilter::calcSensors(gpaVector &sensors) const {
  setSensorValue(sensors, ID_SENSOR_HEAT_FLOW, m_filter.getHeatRate());
  setSensorValue(sensors, ID_SENSOR_PRESSURE_DROP,
                 m_filter.getMixPort(ID_CIRCUIT_INNER, ID_PORT_OUTLET)
                         ->getStreamPressure() -
                     m_filter.getMixPort(ID_CIRCUIT_INNER, ID_PORT_INLET)
                         ->getStreamPressure());
  setSensorValue(sensors, ID_SENSOR_TEMP_DROP,
                 m_filter.getMixPort(ID_CIRCUIT_INNER, ID_PORT_OUTLET)
                         ->getStreamTemperature() -
                     m_filter.getMixPort(ID_CIRCUIT_INNER, ID_PORT_INLET)
                         ->getStreamTemperature());
  setSensorValue(sensors, ID_SENSOR_PERMEABILITY,
                 m_filter.getPermeabilityCoef());

  return GPA_RESULT_OK;
}
gpaResult
gpaLiquidFilter::checkParamValues(const gpaExtParameter *values) const {
  (void)values;
  return GPA_RESULT_OK;
}

void gpaLiquidFilter::setNames() { m_filter.setName("filter"); }

gpaResult gpaLiquidFilter::setParamValues(const gpaExtParameter *values,
                                          bool checkNeeded) {
  // Проверка параметров, если требуется
  if (checkNeeded) {
    gpaResult res = checkParamValues(values);
    if (res != GPA_RESULT_OK)
      return res;
  }
  // Даем названия элементам и потокам
  setNames();
  // Инициализируются элементы с потоком смеси
  m_filter.setFilterParameter(values[ID_PARAM_LENTGH].value.realValue,
                              values[ID_PARAM_RADIUS_FILTER].value.realValue,
                              values[ID_PARAM_NUM].value.intValue,
                              values[ID_PARAM_ELEMENT_DIAMETER].value.realValue,
                              values[ID_PARAM_POROSITY].value.realValue,
                              values[ID_PARAM_LAMBDA].value.realValue);
  gpaReal r = values[ID_PARAM_RADIUS].value.realValue;
  gpaReal h = values[ID_PARAM_HEIGHT].value.realValue;
  gpaReal wall_thickness = values[ID_PARAM_WALL_THICKNESS].value.realValue;
  gpaReal insulation_thickness =
      values[ID_PARAM_INSULATION_THICKNESS].value.realValue;
  gpaReal Ain = 2 * std::numbers::pi * r * h;
  gpaReal Aout =
      2 * std::numbers::pi * (r + wall_thickness + insulation_thickness) * h;
  gpaReal Rmat = 1 /
                     (2 * std::numbers::pi * h *
                      values[ID_PARAM_WALL_HEAT_COEF].value.realValue) *
                     log(1 + wall_thickness / r) +
                 1 /
                     (2 * std::numbers::pi * h *
                      values[ID_PARAM_INSULATION_HEAT_COEF].value.realValue) *
                     log(1 + insulation_thickness / (r + wall_thickness));
  gpaReal R = Rmat + 1 / values[ID_PARAM_ALPHA_IN].value.realValue / Ain +
              1 / values[ID_PARAM_ALPHA_OUT].value.realValue / Aout;
  m_filter.setHeatTransferModel(std::make_unique<LMTDHeatTransfer>(
      R, values[ID_PARAM_ENV_TEMP].value.realValue + GPA_CELCIUS_TO_KELVIN));

  return GPA_RESULT_OK;
}

gpaResult gpaLiquidFilter::buildDevice() {
  bool good = true;
  // Соединяем поток смеси по трубам с граничными потоками смеси системы
  good = good &&
         m_filter.connectMixStream(GPA_ELEM_CIRCUIT_0, ID_PORT_INLET,
                                   getEdgeMixStream(ID_CIRCUIT, ID_PORT_INLET),
                                   GPA_STREAM_INLET);
  good = good &&
         m_filter.connectMixStream(GPA_ELEM_CIRCUIT_0, ID_PORT_OUTLET,
                                   getEdgeMixStream(ID_CIRCUIT, ID_PORT_OUTLET),
                                   GPA_STREAM_OUTLET);
  if (!good)
    return GPA_ERROR_WRONG_ARGS;
  // Добавляем в систему все элементы и потоки
  setElements({&m_filter});
  setStreams({});
  return GPA_RESULT_OK;
}

gpaResult gpaLiquidFilter::initialize() {
  // Подключить экспортируемый элемент к потокам в интеграторе
  gpaResult res = linkToCoreStreams();
  if (res != GPA_RESULT_OK)
    return res;
  // Соединяем все элементы друг с другом
  res = buildDevice();
  if (res != GPA_RESULT_OK)
    return res;
  // Создаем схемы течений (нужны соединенные элементы)
  if (!createSimStructures({}, {getOuterEntrance(ID_CIRCUIT, ID_PORT_INLET)}))
    return GPA_ERROR_WRONG_ARGS;
  // Инициализируем систему
  return gpaExportSystem::initialize();
}

gpaResult gpaLiquidFilter::setSignals(const gpaConstVector &signals) {
  return GPA_RESULT_OK;
}
const gpaString *gpaLiquidFilter::getDeviceMixCircuitName(gpaUInt index) {
  return index < NUM_CIRCUITS ? &m_circuitNames[index] : NULL;
}
const gpaString *gpaLiquidFilter::getDeviceMixPortName(gpaUInt circIdx,
                                                       gpaUInt portIdx) {
  if (circIdx == ID_CIRCUIT)
    return portIdx < NUM_PORTS ? &m_portNames[portIdx] : NULL;
  return NULL;
}
