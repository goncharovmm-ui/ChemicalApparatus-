#include "gpaPipePrm.h"
#include <iostream>
#include <numbers>

constexpr gpaUInt LENGTH_PARAM_IDX = 0;
constexpr gpaUInt LEN_1 = 1;
constexpr gpaUInt LEN_2 = 2;
constexpr gpaUInt LEN_3 = 3;

// gpaReal calcRaynolds(gpaReal viscosity, gpaReal dencity, gpaReal D,gpaReal
// Q){
//     gpaReal V=Q/(std::numbers::pi*D^2/4);
//     gpaReal Re=dencity*abs(V)*D/viscosity;
// }
// a
double sigmoid(double x) { return 1.0 / (1.0 + exp(-x)); }
gpaReal calcFriction(gpaReal Re, gpaReal eps) {
  // Calculate f values
  gpaReal f1, f2, f3;
  f1 = 16.0 * Re;
  f3 = 0.07716 * pow(Re, 2) /
       pow(log10(6.9 / (Re + 1e-9) + pow(eps / (3.7 * D), 1.11)), 2);

  if (Re <= 2300) {
    f2 = f1;
  } else if (Re >= 4000) {
    f2 = f3;
  } else {
    f2 = f1 + (Re - 2300) / 1700 * (f3 - f1);
  }

  // Calculate x values
  gpaReal x1 = (Re - 2300) / 300;
  gpaReal x2 = (Re - 4000) / 300;

  // Calculate friction factor
  gpaReal f = (f1 * (1 - sigmoid(x1)) + f2 * sigmoid(x1)) * (1 - sigmoid(x2)) +
              f3 * sigmoid(x2);

  // Calculate pressure drop
  gpaReal friction_dp =
      f * pow(viscosity, 2) * length / (2 * density * pow(D, 3));

  return friction_dp;
}

const gpaString lengthErrorStr = "Pipe length must be positive";

const gpaString gpaPipePrm::m_typeName = "pipe-prm";
const gpaString gpaPipePrm::m_description = "Труба труба";

const gpaModelNameInfoVector gpaPipePrm::m_modelNames = {
    {"geometry", "Модель геометрии"},
    {"friction", "Модель сопротивления"},
    {"heatCoef", "Модель коэффициента теплопередачи"}};

const gpaParameterInfoVector gpaPipePrm::m_parameters = {
    realParam("length", "Длина", GPA_LENGTH_UNIT, false, 1.)};

gpaPipePrm::gpaPipePrm(const gpaParentLink *link)
    : gpaLongFlow(link), m_length(1.0), m_power(10.0), m_geometry(NULL),
      m_heatCoef(NULL), m_friction(NULL), m_medium_1(NULL), m_medium_2(NULL),
      m_medium_3(NULL), m_length1(0), m_length2(0), m_length3(0) {}

gpaPipePrm::gpaPipePrm(const gpaPipePrm &pipe)
    : gpaLongFlow(pipe), m_length(pipe.m_length), m_power(pipe.m_power),
      m_geometry(pipe.m_geometry ? pipe.m_geometry->copy() : NULL),
      m_friction(pipe.m_friction ? pipe.m_friction->copy() : NULL),
      m_heatCoef(pipe.m_heatCoef ? pipe.m_heatCoef->copy() : NULL),
      m_medium_1(pipe.m_medium_1 ? pipe.m_medium_1->copy() : NULL),
      m_medium_2(pipe.m_medium_2 ? pipe.m_medium_2->copy() : NULL),
      m_medium_3(pipe.m_medium_3 ? pipe.m_medium_3->copy() : NULL),
      m_length1(0), m_length2(0), m_length3(0) {}

gpaPipePrm::~gpaPipePrm() {
  clearGeometry();
  clearFriction();
  clearHeatCoef();
}

void gpaPipePrm::clearGeometry() {
  if (m_geometry)
    delete m_geometry;
  m_geometry = NULL;
}

void gpaPipePrm::clearFriction() {
  if (m_friction)
    delete m_friction;
  m_friction = NULL;
}

void gpaPipePrm::clearHeatCoef() {
  if (m_heatCoef != NULL)
    delete m_heatCoef;
  m_heatCoef = NULL;
}

gpaPipePrm *gpaPipePrm::copy() const { return new gpaPipePrm(*this); }

gpaReal gpaPipePrm::getHeatArea() const {
  if (m_friction && m_geometry)
    return m_geometry->getNumStrokes() * m_geometry->getNumPipes() *
           std::numbers::pi * getDiameter() * m_length;
  return 0;
}

gpaReal gpaPipePrm::getDiameter() const {
  return m_friction ? m_friction->getDiameter() : 0.0;
}

gpaReal gpaPipePrm::getCrossArea() const {
  return (m_friction && m_geometry)
             ? m_friction->getArea() * m_geometry->getNumPipes()
             : 0.0;
}

gpaReal gpaPipePrm::getVolume() const { return getCrossArea() * m_length; }

bool gpaPipePrm::setPower(gpaReal power) {
  m_power = power;
  return true;
}
bool gpaPipePrm::setAlphaCoef(gpaReal alpha) {
  m_alphaCoef = alpha;
  return true;
}

bool gpaPipePrm::setLength(gpaReal length) {
  bool good = 0.0 < length;
  if (good)
    m_length = length;
  else
    pushParametrError(lengthErrorStr, this);
  return good;
}

void gpaPipePrm::setGeometry(gpaPipesGeometry *geometry) {
  clearGeometry();
  m_geometry = geometry;
}

void gpaPipePrm::setFriction(gpaPipeFriction *friction) {
  clearFriction();
  m_friction = friction;
}

void gpaPipePrm::setHeatCoefficient(gpaFlowHeatCoef *heatCoef) {
  clearHeatCoef();
  m_heatCoef = heatCoef;
}

gpaReal gpaPipePrm::getHeatTransferCoef() const {
  if (!m_heatCoef)
    return 0.0;
  gpaReal diameter = getDiameter();
  gpaReal reynolds = calcReynoldsNumber(diameter);
  return m_heatCoef->getHeatTransferCoef(reynolds, getPrandtlNumber(),
                                         getConductivity(), diameter);
}

gpaMixPort *gpaPipePrm::connectCircuitStream(gpaUInt index,
                                             gpaMixStream *stream,
                                             gpaReal orientation) {
  if (index == GPA_FLOW_INLET) {
    m_medium_1 = stream->getMedium()->copy();
    m_medium_2 = stream->getMedium()->copy();
    m_medium_3 = stream->getMedium()->copy();
  }
  return connectMixStream(0, index, stream, orientation);
}

gpaResult gpaPipePrm::initialize() {
  if (!m_geometry || !m_friction)
    return GPA_ERROR_WRONG_STATE;
  return GPA_RESULT_OK;
}

gpaReal gpaPipePrm::calcHeatFricCoef() const {
  return 2.0 * (getInletTemperature() - getOutletTemperature()) /
         (getInletTemperature() + getOutletTemperature());
}

gpaReal gpaPipePrm::calcFrictionFunc(gpaReal deltaPres, gpaReal rate) const {
  gpaReal velocity = getMolarMass() * rate / getCrossArea() / getDensity();

  gpaReal dens = getDensity();
  gpaReal re = calcReynoldsNumber();
  gpaReal friction_dp = calcFrictionFunc();
  gpaReal dp = 9.81 * delta_h * dencity + friction_dp * sign(V);

  return dp;
  // gpaReal reynolds = calcReynoldsNumber(m_ten_diametr);

  gpaReal flowCoef = getDensity() * vmAbs(velocity) * velocity / 2.0;
  gpaReal fricLosses =
      m_geometry->getNumStrokes() * m_length *
      m_friction->calcSpecificPressLoss(velocity, getViscosity(), getDensity());
  gpaReal otherLosses =
      (m_geometry->calcResistCoef(velocity) + calcHeatFricCoef()) * flowCoef;
  return deltaPres - (fricLosses + otherLosses) / GPA_KILOPASCAL_TO_PASCAL -
         calcStaticPressure();
}

gpaSubModel *gpaPipePrm::getSubModel(gpaUInt index) const {
  gpaTypeVector<gpaSubModel *> models = {m_geometry, m_friction, m_heatCoef};
  return index < getNumSubModels() ? models[index] : NULL;
}

bool gpaPipePrm::checkParameterValues(gpaReal length) const {
  bool good = 0.0 < length;
  if (!good)
    pushParametrError(lengthErrorStr, this);
  return good;
}

bool gpaPipePrm::setParameterValues(gpaReal length, bool checkNeeded) {
  if (checkNeeded && !checkParameterValues(length))
    return false;
  m_length = length;
  return true;
}

gpaResult gpaPipePrm::checkParamValues(const gpaExtParameter *values) const {
  bool good = checkParameterValues(values[LENGTH_PARAM_IDX].value.realValue);
  return good ? GPA_RESULT_OK : GPA_ERROR_WRONG_ARGS;
}

gpaResult gpaPipePrm::setParamValues(const gpaExtParameter *values,
                                     bool checkNeeded) {
  bool good =
      setParameterValues(values[LENGTH_PARAM_IDX].value.realValue, checkNeeded);
  return good ? GPA_RESULT_OK : GPA_ERROR_WRONG_ARGS;
}

gpaResult gpaPipePrm::calcFuncValues(const gpaConstVector &,
                                     const gpaConstVector &variables,
                                     gpaVector &values) {
  gpaReal deltaPres = getInletPort()->getStreamPressure() -
                      getOutletPort()->getStreamPressure();
  gpaReal inletPress = 0.5 * (getInletPort()->getStreamPressure() +
                              getOutletPort()->getStreamPressure());
  gpaReal inletRate = getInletPort()->getIncomingFlowRate();
  gpaReal outletRate = getOutletPort()->getIncomingFlowRate();

  gpaReal l1 = vmAbs(variables[LEN_1]);
  gpaReal l2 = vmAbs(variables[LEN_2]);
  gpaReal l3 = vmAbs(variables[LEN_3]);

  gpaResult res =
      m_medium_2->calcFlashPV(inletPress, 0, m_medium_2->getFractions());
  res = m_medium_3->calcFlashPV(inletPress, 1, m_medium_3->getFractions());
  gpaReal G = inletRate;
  if (G < 0) {
    G = 0;
  }

  gpaReal q_heat = (m_medium_2->getEnthalpy() -
                    getInletPort()->getStreamMedium()->getEnthalpy()) *
                   G;
  gpaReal q_phase_transition =
      (m_medium_3->getEnthalpy() - m_medium_2->getEnthalpy()) * G;

  gpaReal q_1 = m_power * l1 / m_length;
  gpaReal q_2 = m_power * l2 / m_length;
  gpaReal q_3 = m_power * l3 / m_length;
  gpaMedium *media_out = m_medium_3;
  std::cout << "q1 " << q_heat << " " << "q_phase_transition "
            << q_phase_transition << "m_port " << m_power << " " << m_length
            << "\n";

  values[0] = inletRate + outletRate;
  values[1] = calcFrictionFunc(variables[0], 0.5 * (inletRate - outletRate));
  values[2] = variables[0] - deltaPres;
  if (q_heat < m_power) {
    values[3] = q_1 - q_heat;
  } else {
    values[3] = l1 - m_length;
    // media_out = m_medium_1;
  }

  if (q_heat <= 0) {
    values[3] = l1;
    q_heat = 0;
  }

  if (q_heat + q_phase_transition < m_power) {
    values[4] = q_2 - q_phase_transition;
    values[5] = l1 + l2 + l3 - m_length;
  } else {
    values[4] = l3;
    values[5] = l1 + l2 - m_length;
    // media_out = m_medium_2;
  }
  gpaReal v1 = variables[0];
  gpaReal v2 = variables[1];
  setLength1(l1);
  setLength2(l2);
  setLength3(l3);
  t1 = m_medium_1->getTemperature() + m_power * l1 / m_length / m_alphaCoef;
  t2 = m_medium_2->getTemperature() + m_power * l2 / m_length / m_alphaCoef;
  t3 = m_medium_3->getTemperature() + m_power * l3 / m_length / m_alphaCoef;
  std::cout << calcReynoldsNumber(m_length) << "\n";

  std::cout << "inlet rate " << inletRate << "\n ";
  return GPA_RESULT_OK;
}
gpaResult gpaPipePrm::calcEnthalpyFuncValueAt(gpaUInt circIdx, gpaUInt portIdx,
                                              gpaReal enthalpy,
                                              gpaReal &funcValue) const {
  if (circIdx != GPA_ELEM_CIRCUIT_0)
    return GPA_ERROR_WRONG_ARGS;
  const gpaMixPort *oppPort = getOppositePort(portIdx);
  if (!oppPort)
    return GPA_ERROR_WRONG_ARGS;
  gpaReal G = vmAbs(oppPort->getIncomingFlowRate());
  if (G < 1.e-6) {
    funcValue = enthalpy - oppPort->getStreamEnthalpy();
  } else {
    funcValue = (enthalpy - oppPort->getStreamEnthalpy()) * G - m_power;
  }
  return GPA_RESULT_OK;
}
gpaResult gpaPipePrm::initVariables(gpaVector &variables) const {
  variables[0] = 0;
  variables[1] = m_length;
  variables[2] = 0;
  variables[3] = 0;
  return GPA_RESULT_OK;
}

gpaReal gpaPipePrm::getTenHeatTransferCoef() const {
  if (!m_heatCoef)
    return 0.0;
  return 0;
  // gpaReal reynolds = calcReynoldsNumber(m_ten_diametr);
  // return m_heatCoef->getHeatTransferCoef(reynolds, getPrandtlNumber(),
  // getConductivity(), diameter);
}
gpaReal gpaPipePrm::getPresureDelta() const {
  if (!m_heatCoef)
    return 0.0;
  gpaReal dens = getDensity();
  gpaReal re = calcReynoldsNumber();
  gpaReal friction_dp = calcFrictionFunc();
  gpaReal dp = 9.81 * delta_h * dencity + friction_dp * sign(V);

  return dp;
  // gpaReal reynolds = calcReynoldsNumber(m_ten_diametr);
  // return m_heatCoef->getHeatTransferCoef(reynolds, getPrandtlNumber(),
  // getConductivity(), diameter);
}
