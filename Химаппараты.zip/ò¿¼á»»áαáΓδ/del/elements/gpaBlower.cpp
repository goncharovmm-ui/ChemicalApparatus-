#include "gpaBlower.h"
#include "spline.h"
#include <cassert>

namespace {
void scalarMultiply(std::vector<gpaReal> &vector, gpaReal scalar) {
  for (auto &element : vector) {
    element *= scalar;
  }
}
} // namespace

constexpr gpaUInt ID_PORT_INLET = 0;
constexpr gpaUInt ID_PORT_OUTLET = 1;

const gpaString initPresErrorStr = "Initial volume pressure must be positive";
const gpaString initTempErrorStr =
    "Initial volume temperature must be positive";
const gpaString initFractErrorStr =
    "Initial mole fractions must be in range [0,1] and their sum is less or "
    "equal to 1.0";
const gpaString liqHeatTransCoefErrorStr =
    "Gas-wall heat transfer coefficient must be non-negative";
const gpaString gasHeatTransCoefErrorStr =
    "Liquid-wall heat transfer coefficient must be non-negative";

const gpaString gpaBlower::m_typeName = "blower";
const gpaString gpaBlower::m_description = "Однослойный объем";

gpaBlower::gpaBlower(const gpaParentLink *link) {
  m_dP_curve = {0, 13.3, 32.9, 52.5, 72.1, 101.5, 1e9};
  m_V_curve = {4.1, 4.016666, 3.96666, 3.916666, 3.86666, 3.8166666, 1.6666e-4};
  m_tau = 20000;
  m_w_set = 1743;
  m_w_curve = 743;
  m_w_init = 5; // [начальная скорость вращения турбины, об/с]
  m_h_KS = 0;
}

gpaBlower::gpaBlower(const gpaBlower &expander) {}

gpaBlower::~gpaBlower() {}

gpaBlower *gpaBlower::copy() const { return new gpaBlower(*this); }

bool gpaBlower::setInitialRPM(gpaReal omega) {
  m_w_init = omega;
  return true;
}

bool gpaBlower::setProcessEfficiency(gpaReal eta) {
  m_eta = eta;
  return true;
}

bool gpaBlower::setParameters(gpaReal omega_curve, gpaReal omega_target,
                                 gpaReal tau) {
  m_tau = tau;
  m_w_set = omega_target;
  m_w_curve = omega_curve;
  return true;
}

bool gpaBlower::setVolumeRateCurve(std::vector<double> deltaPres,
                                      std::vector<double> VFR) {
  if (std::all_of(deltaPres.begin(), deltaPres.end(),
                  [](double n) { return n == .0; }) &&
      std::all_of(VFR.begin(), VFR.end(), [](double n) { return n == .0; }))
    return true;
  m_dP_curve = deltaPres;
  m_V_curve = VFR;
  return true;
}

gpaReal gpaBlower::getRPM() const { return m_w; }

gpaReal gpaBlower::getPower() const { return m_power; }

gpaUInt gpaBlower::getMinNumMixPorts(gpaUInt index) const {
  return index == GPA_ELEM_CIRCUIT_0 ? 2 : 0;
}

gpaUInt gpaBlower::getMaxNumMixPorts(gpaUInt index) const {
  return index == GPA_ELEM_CIRCUIT_0 ? 2 : 0;
}

gpaUInt gpaBlower::getNumVariables() const { return 1; }

gpaResult gpaBlower::initialize() {
  const gpaMedium *medium = getCircuitMediumAt(GPA_ELEM_CIRCUIT_0);
  if (!medium)
    return GPA_ERROR_WRONG_ARGS;
  if (!medium->supportsFlash(PS_FLASH) || !medium->supportsFlash(PH_FLASH))
    return GPA_ERROR_UNSUPPORTED;
  return GPA_RESULT_OK;
}

void gpaBlower::fillVarNames(gpaStringVector &varNames) const {
  varNames[0] = "Hz";
  // varNames[1] = getName() + GPA_VAR_POINTER + "Hz";
}

gpaResult gpaBlower::initVariables(gpaVector &variables) const {
  variables[0] = m_w_init;
  // variables[1] = 1;
  return GPA_RESULT_OK;
}

gpaResult gpaBlower::fillMassMatrix(gpaUInt refRow, gpaUInt refCol) const {
  gpaResult res = setMassMatrCoef(refRow, refCol, 1.0);
  if (res != GPA_RESULT_OK)
    return res;
  return GPA_RESULT_OK;
}

gpaResult gpaBlower::calcProcess(std::pair<gpaReal, gpaReal> &res) {
  gpaMixPort *port = getMixPort(GPA_ELEM_CIRCUIT_0, ID_PORT_INLET);
  gpaMedium *medium = port->getStreamMedium()->copyTo(asOwner());
  gpaReal p_in = port->getStreamPressure();
  gpaReal p_out =
      getMixPort(GPA_ELEM_CIRCUIT_0, ID_PORT_OUTLET)->getStreamPressure();
  gpaReal entropy = medium->getEntropy();
  gpaResult result =
      medium->calcFlashPS(p_out, entropy, medium->getFractions());
  if (result != GPA_RESULT_OK)
    return result;
  gpaReal ro2_ideal = medium->getDensity();
  gpaReal enthalpy = medium->getEnthalpy();
  gpaReal ro2_actual =
      getMixPort(GPA_ELEM_CIRCUIT_0, ID_PORT_OUTLET)->getStreamDensity();
  gpaReal h_out = enthalpy;
  gpaReal ro_in = port->getStreamDensity();
  gpaReal n = (log(p_out / p_in) + 1e-12) / (log(ro2_actual / ro_in) + 1e-12) +
              1e-12; // Polytropic Exponent
  gpaReal k = (log(p_out / p_in) + 1e-12) / (log(ro2_ideal / ro_in) + 1e-12) +
              1e-12; // Isentropic Exponent (Cp/Cv)
  // Пропорциональность между коэффициентами политропным и адиабатным кпд
  gpaReal k_prop =
      ((vmPower(p_out / p_in, ((n - 1) / n)) - 1) * (n / (n - 1)) *
       ((k - 1) / k) / ((vmPower(p_out / p_in, ((k - 1) / k)) - 1) + 1e-12));
  delete medium;
  res = {h_out, k_prop};
  return result;
}

gpaResult gpaBlower::calcFuncValues(const gpaConstVector &,
                                    const gpaConstVector &variables,
                                    gpaVector &values,
                                    const gpaSetOfEquations &eqIds) {
  m_w = vmMax(0., variables[0]);
  // gpaReal dP = variables[1];

  gpaReal dP_ks =
      getMixPort(GPA_ELEM_CIRCUIT_0, ID_PORT_OUTLET)->getStreamPressure() -
      getMixPort(GPA_ELEM_CIRCUIT_0, ID_PORT_INLET)->getStreamPressure();

  std::vector<gpaReal> G_curve(m_V_curve);
  scalarMultiply(
      G_curve,
      getMixPort(GPA_ELEM_CIRCUIT_0, ID_PORT_OUTLET)->getStreamDensity());

  std::vector<gpaReal> dP_Curve(m_dP_curve);
  scalarMultiply(G_curve, (m_w + 1) / m_w_curve);
  scalarMultiply(dP_Curve, (m_w + 1) * (m_w + 1) / m_w_curve / m_w_curve);

  gpaReal G_KS = tk::spline(dP_Curve, G_curve, tk::spline::linear)(dP_ks);

  std::pair<gpaReal, gpaReal> a;
  gpaResult res = calcProcess(a);
  if (res != GPA_RESULT_OK)
    return GPA_ERROR_MIX_STATE;

  auto [h_out_ks, k_prop] = a;

  gpaReal eta_KS = m_eta / k_prop;
  m_h_KS =
      getMixPort(GPA_ELEM_CIRCUIT_0, ID_PORT_INLET)->getStreamEnthalpy() +
      (h_out_ks -
       getMixPort(GPA_ELEM_CIRCUIT_0, ID_PORT_INLET)->getStreamEnthalpy()) /
          eta_KS;
  m_power = G_KS * dP_ks * eta_KS;

  values(0) = (m_w_set - m_w) / m_tau;

  gpaElementMixCircuit *circuit = getMixCircuit(GPA_ELEM_CIRCUIT_0);
  values(1) = circuit->getPort(ID_PORT_INLET)->getIncomingMassRate() +
              circuit->getPort(ID_PORT_OUTLET)->getIncomingMassRate();
  values(2) = circuit->getPort(ID_PORT_INLET)->getIncomingMassRate() - G_KS;
  // values(3) = 0.0363 * 1e-3 * vmPower(w, 2) - dP;
  return GPA_RESULT_OK;
}

gpaResult gpaBlower::calcEnthalpyFuncValueAt(gpaUInt circIdx, gpaUInt portIdx,
                                             gpaReal enthalpy,
                                             gpaReal &funcValue) const {

  gpaMixPort *oppPort = getMixCircuit(circIdx)->getPort(1 - portIdx);
  gpaReal portEnthalpy = oppPort->getStreamEnthalpy();
  funcValue = enthalpy - m_h_KS;
  // funcValue = enthalpy - portEnthalpy;

  return GPA_RESULT_OK;
}

gpaResult gpaBlower::calcFractionsFuncValuesAt(gpaUInt circIdx, gpaUInt portIdx,
                                               const gpaConstVector &fractions,
                                               gpaVector &funcValues) const {

  gpaMixPort *oppPort = getMixCircuit(circIdx)->getPort(1 - portIdx);
  gpaDataVector portFractions = oppPort->getStreamFractions();
  for (gpaUInt i = 0; i < funcValues.size(); i++) {
    funcValues[i] = fractions[i] - portFractions[i];
  }

  return GPA_RESULT_OK;
}
