/*!
 *  \file      gpaNitrogenTank.h
 *  \brief     Класс, описывающий простейший однокамерный сепаратор
 *  \author    Фролов Алексей
 *  \date      2024
 */
#ifndef GPA_NITROGEN_TANK_H
#define GPA_NITROGEN_TANK_H

#include "gpaInclude.h"
#include "gpaExportSystem.h"
#include "gpaEnthalpyMixStream.h"
// #include "gpaReservoirVolume.h"
#include "gpaInstantTransfer.h"
#include "gpaEnvironment.h"
#include "gpaTankVolume.h"

constexpr gpaUInt GPA_NITROGEN_TANK_NUM_PORTS = 6;

/*!
 * \class gpaNitrogenTank
 * \brief Класс, реализующий простейший однокамерный сепаратор
 */
class gpaNitrogenTank : public gpaExportSystem
{
public:
    /*!
     * Конструктор с параметрами
     * \param interfaces интерфейсы интегратора
     * \param importRef ссылка на парный аппарат в интеграторе
     */
    gpaNitrogenTank(const gpaCoreInterfaces *interfaces, gpaCoreReference importRef);
    /*!
     * Конструктор копирования
     * \param separator ссылка на простейший сепаратор
     */
    gpaNitrogenTank(const gpaNitrogenTank &separator) = delete;
    /*!
     * Деструктор по умолчанию
     */
    virtual ~gpaNitrogenTank() override;
    /*!
     * Функция копирования однокамерного сепаратора
     * \return скопированный однокамерный сепаратор
     */
    virtual gpaNitrogenTank *copy() const override { return NULL; }
    /*!
     * Получить имя типа аппарата
     * \return имя типа аппарата
     */
    virtual const gpaString &getTypeName() const override { return getDeviceTypeName(); }
    /*!
     * Получить описание аппарата
     * \return описание аппарата
     */
    virtual const gpaString &getDescription() const override { return getDeviceDescription(); }
    /*!
     * Функция получения количества материальных контуров элемента
     * \return количество материальных контуров элемента
     */
    virtual gpaUInt getNumMixCircuits() const override { return getDeviceNumMixCircuits(); }
    /*!
     * Функция получения минимального количества портов в материальном контуре элемента
     * \param index индекс контура
     * \return минимальное количество портов
     */
    virtual gpaUInt getMinNumMixPorts(gpaUInt index) const override { return getDeviceMinNumMixPorts(index); }
    /*!
     * Функция получения максимального количества портов в материальном контуре элемента
     * \param index индекс контура
     * \return максимальное количество портов
     */
    virtual gpaUInt getMaxNumMixPorts(gpaUInt index) const override { return getDeviceMaxNumMixPorts(index); }
    /*!
     * Получить минимальное количество подключенных материальных потоков
     * \return минимальное количество подключенных материальных потоков
     */
    static gpaUInt getDeviceMinNumMixPorts() { return GPA_NITROGEN_TANK_NUM_PORTS; }
    /*!
     * Получить максимальное количество подключенных материальных потоков
     * \return максимальное количество подключенных материальных потоков
     */
    static gpaUInt getDeviceMaxNumMixPorts() { return GPA_NITROGEN_TANK_NUM_PORTS; }
    /*!
     * Инициализировать аппарат
     * \return код операции
     */
    virtual gpaResult initialize() override;
    /*!
     * Установить значения сигналов
     * \param [out] signals значения сигналов
     * \return код операции
     */
    virtual gpaResult setSignals(const gpaConstVector &signals) override;
    /*!
     * Рассчитать значения сенсоров
     * \param [out] sensors вектор сенсоров
     * \return код операции
     */
    virtual gpaResult calcSensors(gpaVector &sensors) const override;

protected:
    /*!
     * Функция получения вектора с описаниями параметров аппарата
     * \return вектор с описаниями параметров аппарата
     */
    virtual const gpaParameterInfoVector *getParamsInfo() const override { return getParametersInfo(); }
    /*!
     * Функция получения вектора с описаниями сенсоров модели аппарата
     * \return вектор с описаниями сенсоров модели аппарата
     */
    virtual const gpaSensorInfoVector *getSensesInfo() const override { return getSensorsInfo(); }
    /*!
     * Функция проверки значений параметров модели аппарата
     * \param values вектор параметров модели аппарата
     * \return код операции
     */
    virtual gpaResult checkParamValues(const gpaExtParameter *values) const override;
    /*!
     * Функция назначения параметров модели аппарата
     * \param values вектор параметров модели аппарата
     * \param checkNeeded флаг о необходимости проверить параметры
     * \return код операции
     */
    virtual gpaResult setParamValues(const gpaExtParameter *values, bool checkNeeded = true) override;

private:
    //! Сепарационная камера
    gpaTankVolume m_volume;
    //! Окружающая среда
    gpaEnvironment m_environment;
    //! Теплопередача через стенки объема
    gpaInstantTransferVector m_heatTransfers;
    /*!
     * Назначить имена аппаратам и потокам
     */
    void setNames();
    /*!
     * Инициализировать сепарационную камеру
     * \param values вектор параметров модели аппарата
     * \return результат операции
     */
    gpaResult initVolumes(const gpaExtParameter *values);
    /*!
     * Назначить параметры портов
     * \param values вектор параметров модели аппарата
     * \return результат ыоперации
     */
    gpaResult initPortParameters(const gpaExtParameter *values);
    /*!
     * Инициализировать теплопередачу со стенками
     * \param values вектор параметров модели аппарата
     * \return результат операции
     */
    gpaResult initHeatTransfers(const gpaExtParameter *values);
    /*!
     * Соединить аппараты и потоки в аппарате
     */
    gpaResult buildDevice();

public:
    /*!
     * Получить название типа аппарата
     * \return название типа аппарата
     */
    static const gpaString &getDeviceTypeName() { return m_typeName; }
    /*!
     * Получить описание аппарата
     * \return описание аппарата
     */
    static const gpaString &getDeviceDescription() { return m_description; }
    /*!
     * Получить количество материальных контуров элемента
     * \return количество материальных контуров элемента
     */
    static gpaUInt getDeviceNumMixCircuits();
    /*!
     * Получить минимальное количество подключенных материальных потоков
     * \param index индекс материального контура
     * \return минимальное количество подключенных материальных потоков
     */
    static gpaUInt getDeviceMinNumMixPorts(gpaUInt index);
    /*!
     * Получить максимальное количество подключенных материальных потоков
     * \param index индекс материального контура
     * \return максимальное количество подключенных материальных потоков
     */
    static gpaUInt getDeviceMaxNumMixPorts(gpaUInt index);
    /*!
     * Получить вектор описаний параметров аппарата
     * \return вектор описаний параметров аппарата
     */
    static const gpaParameterInfoVector *getParametersInfo() { return &m_parameters; }
    /*!
     * Получить вектор описаний сенсоров модели
     * \return вектор описаний сенсоров модели
     */
    static const gpaSensorInfoVector *getSensorsInfo() { return &m_sensors; }
    /*!
     * Функция получения названия материального контура элемента
     * \param index индекс контура
     * \return название материального контура элемента
     */
    virtual const gpaString *getMixCircuitName(gpaUInt index) const override { return getDeviceMixCircuitName(index); }
    /*!
     * Функция получения названия порта в материальном контуре элемента
     * \param circIdx индекс контура
     * \param portIdx индекс порта
     * \return название порта
     */
    virtual const gpaString *getMixPortName(gpaUInt circIdx, gpaUInt portIdx) const override { return getDeviceMixPortName(circIdx, portIdx); }
    /*!
     * Получить название материального порта элемента
     * \param index индекс контура
     * \return название материального порта элемента
     */
    static const gpaString *getDeviceMixCircuitName(gpaUInt index);

    /*!
     * Получить название материального порта элемента
     * \param index индекс контура
     * \return название материального порта элемента
     */
    static const gpaString *getDeviceMixPortName(gpaUInt circIdx, gpaUInt portIdx);

private:
    //! Название аппарата
    static const gpaString m_typeName;
    //! Описание аппарата
    static const gpaString m_description;
    //! Вектор описаний параметров аппарата
    static const gpaParameterInfoVector m_parameters;
    //! Вектор описаний сенсоров модели
    static const gpaSensorInfoVector m_sensors;
    //! Массив названий портов элемента
    static const gpaStringVector m_portNames;
    //! Массив названий контуров элемента
    static const gpaStringVector m_circuitNames;
};

#endif
