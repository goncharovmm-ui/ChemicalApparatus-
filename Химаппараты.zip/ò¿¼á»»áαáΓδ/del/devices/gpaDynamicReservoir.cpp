#include "gpaDynamicReservoir.h"
#include "gpaDefinitions.h"
#include "gpaInclude.h"
#include "gpaLogMeanTempDifference.h"
#include "gpaThinWall.h"
#include "gpaVerticalCylinder.h"
#include "gpaZeroRadiation.h"
#include <iostream>

constexpr gpaUInt ID_CIRCUIT = 0;
constexpr gpaUInt NUM_CIRCUITS = 1;

constexpr gpaUInt GPA_N01_INLET = 0;
constexpr gpaUInt GPA_N02_INLET = 1;
constexpr gpaUInt GPA_N03_INLET = 2;
constexpr gpaUInt GPA_N04_INLET = 3;
constexpr gpaUInt GPA_N05_INLET = 4;
constexpr gpaUInt GPA_N06_INLET = 5;
constexpr gpaUInt GPA_N07_OUTLET = 6;
constexpr gpaUInt GPA_N12_OUTLET = 7;
constexpr gpaUInt GPA_N13_OUTLET = 8;
constexpr gpaUInt GPA_N15_OUTLET = 9;
constexpr gpaUInt GPA_N18_INLET = 10;
constexpr gpaUInt NUM_PORTS = 11;

constexpr gpaUInt ID_PARAM_PRES0 = 0x00;
constexpr gpaUInt ID_PARAM_TEMP0 = 0x01;
constexpr gpaUInt ID_PARAM_GAS_FRACTIONS = 0x02;
constexpr gpaUInt ID_PARAM_LIQ_FRACTIONS = 0x02;

constexpr gpaUInt ID_PARAM_D = 0x03;
constexpr gpaUInt ID_PARAM_Y = 0x04;
constexpr gpaUInt ID_PARAM_H = 0x05;
constexpr gpaUInt ID_PARAM_H_PORTS = 0x06;
constexpr gpaUInt ID_PARAM_ALPHA_OUT = 0x07;
constexpr gpaUInt ID_PARAM_BETA_OUT = 0x08;
constexpr gpaUInt ID_PARAM_RHO_OUT = 0x09;
constexpr gpaUInt ID_PARAM_ETA_OUT = 0x0A;
constexpr gpaUInt ID_PARAM_CP_OUT = 0x0B;
constexpr gpaUInt ID_PARAM_K_OUT = 0x0C;
constexpr gpaUInt ID_PARAM_V_IN = 0x0D;
constexpr gpaUInt ID_PARAM_V_OUT = 0x0E;
constexpr gpaUInt ID_PARAM_D_LAYERS = 0x0f;
constexpr gpaUInt ID_PARAM_K_LAYERS = 0x10;
constexpr gpaUInt ID_PARAM_T_ENV = 0x11;
constexpr gpaUInt ID_PARAM_PHI = 0x12;
constexpr gpaUInt ID_PARAM_PORT_R01 = 0x13;
constexpr gpaUInt ID_PARAM_PORT_R02 = 0x14;
constexpr gpaUInt ID_PARAM_PORT_R03 = 0x15;
constexpr gpaUInt ID_PARAM_PORT_R04 = 0x16;
constexpr gpaUInt ID_PARAM_PORT_R05 = 0x17;
constexpr gpaUInt ID_PARAM_PORT_R06 = 0x18;
constexpr gpaUInt ID_PARAM_PORT_R07 = 0x19;
constexpr gpaUInt ID_PARAM_PORT_R12 = 0x1a;
constexpr gpaUInt ID_PARAM_PORT_R13 = 0x1b;
constexpr gpaUInt ID_PARAM_PORT_R15 = 0x1c;
constexpr gpaUInt ID_PARAM_PORT_R18 = 0x1d;
constexpr gpaUInt ID_PARAM_EXT_VOL = 0x1e;

constexpr gpaUInt ID_SENSOR_PRESSURE = 0x00;
constexpr gpaUInt ID_SENSOR_LIQ_TEMPERATURE = 0x01;
constexpr gpaUInt ID_SENSOR_GAS_TEMPERATURE = 0x02;
constexpr gpaUInt ID_SENSOR_INLET_PRES = 0x03;
constexpr gpaUInt ID_SENSOR_OUT_LIQ_PRES = 0x04;
constexpr gpaUInt ID_SENSOR_LIQUID_LEVEL = 0x05;
constexpr gpaUInt ID_SENSOR_LEV_FULLNESS = 0x06;
constexpr gpaUInt ID_SENSOR_VOL_FULLNESS = 0x07;
constexpr gpaUInt ID_SENSOR_ENTHALPY = 0x08;
constexpr gpaUInt ID_SENSOR_MOLES = 0x09;
constexpr gpaUInt ID_SENSOR_FRACTION0 = 0x0c;
constexpr gpaUInt ID_SENSOR_FRACTION1 = 0x11;
constexpr gpaUInt ID_SENSOR_FRACTION2 = 0x12;
constexpr gpaUInt ID_SENSOR_FRACTION3 = 0x13;
constexpr gpaUInt ID_SENSOR_FRACTION4 = 0x14;
constexpr gpaUInt ID_SENSOR_FRACTION5 = 0x15;
constexpr gpaUInt ID_SENSOR_N15_VAPOR = 0x1d;

const gpaString gpaDynamicReservoir::m_typeName = "dynamic-reservoir3";
const gpaString gpaDynamicReservoir::m_description =
    "Изотермический резервуар с фазовым переходом";

const gpaParameterInfoVector gpaDynamicReservoir::m_parameters = {
    realParam("initial-pressure", "Начальное давление в резервуаре",
              GPA_PRESSURE_UNIT, false, 1e+2),
    realParam("initial-temp", "Начальная температура в резервуаре",
              GPA_TEMPERATURE_UNIT, false, 20.0),
    realVecFracsParam("liq_fractions",
                      "Начальные мольные доли жидких компонентов",
                      GPA_DIMLESS_UNIT, false, 0),
    realParam("d", "Рабочий внутренний диаметр аппарата", GPA_LENGTH_UNIT,
              false, 1.2),
    realParam("y", "Высота подъема шаровой части аппарата", GPA_LENGTH_UNIT,
              false, 0.6),
    realParam("H", "Высота цилиндрической рабочей части аппарата",
              GPA_LENGTH_UNIT, false, 2.3),
    realParam("H-ports", "Высоты патрубков подключения (от дна), набор",
              GPA_LENGTH_UNIT, false, 0.0),
    realParam("alpha-out", "Коэффициент внешней теплоотдачи",
              GPA_HEATTRANS_COEF_UNIT, true, 6.0),
    realParam("beta-out", "Коэффициент теплового расширения",
              GPA_TEMP_DIFFER_UNIT, false, 0.003),
    realParam("rho-out", "Плотность окружающей среды", GPA_MASS_UNIT, false,
              1.225),
    realParam("eta-out", "Динамическая вязкость окружающей среды",
              GPA_PRESSURE_UNIT, false, 1.8e-5),
    realParam("cp-out", "Теплоёмкость окружающей среды", GPA_HEAT_CAPACITY_UNIT,
              false, 1.0),
    realParam("k-out", "Теплопроводность окружающей среды",
              GPA_CONDUCTIVITY_UNIT, false, 0.03),
    realParam("v-in", "Скорость движения технологической среды",
              GPA_VELOCITY_UNIT, false, 0.0),
    realParam("v-out", "Скорость движения окружающей среды", GPA_VELOCITY_UNIT,
              false, 0.0),
    realParam("d-layers", "Диаметры границ слоев боковых стенок",
              GPA_LENGTH_UNIT, false, 0.0),
    realParam("k-layers", "Теплопроводности материалов слоев стенки",
              GPA_CONDUCTIVITY_UNIT, false, 0.0),
    realParam("T-env", "Температура окружающей среды", GPA_TEMPERATURE_UNIT,
              true, 20.0),
    realParam("phi", "Начальная доля жидкости", GPA_DIMLESS_UNIT, true, 0.1),
    realParam("r01", "Внутренни диаметр на порту 01", GPA_LENGTH_UNIT, true,
              0.3),
    realParam("r02", "Внутренни диаметр на порту 02", GPA_LENGTH_UNIT, true,
              0.7),
    realParam("r03", "Внутренни диаметр на порту 03", GPA_LENGTH_UNIT, true,
              0.5),
    realParam("r04", "Внутренни диаметр на порту 04", GPA_LENGTH_UNIT, true,
              0.2),
    realParam("r05", "Внутренни диаметр на порту 05", GPA_LENGTH_UNIT, true,
              0.05),
    realParam("r06", "Внутренни диаметр на порту 06", GPA_LENGTH_UNIT, true,
              0.2),
    realParam("r07", "Внутренни диаметр на порту 07", GPA_LENGTH_UNIT, true,
              0.6),
    realParam("r12", "Внутренни диаметр на порту 12", GPA_LENGTH_UNIT, true,
              0.05),
    realParam("r13", "Внутренни диаметр на порту 13", GPA_LENGTH_UNIT, true,
              0.08),
    realParam("r15", "Внутренни диаметр на порту 15", GPA_LENGTH_UNIT, true,
              0.4),
    realParam("r18", "Внутренни диаметр на порту 18", GPA_LENGTH_UNIT, true,
              0.1),
    realParam("ext-vol", "Объекм внешнего резервуара", GPA_VOLUME_UNIT, true,
              1),
};

const gpaSensorInfoVector gpaDynamicReservoir::m_sensors = {
    scalarSensor("pressure", "Давление в резервуаре", GPA_PRESSURE_UNIT),
    scalarSensor("gas-temperature", "Температура газа", GPA_TEMPERATURE_UNIT),
    scalarSensor("liq-temperature", "Температура жидкости",
                 GPA_TEMPERATURE_UNIT),
    scalarSensor("mix-pressure", "Давление на входе в резервуар",
                 GPA_PRESSURE_UNIT),
    scalarSensor("liq-pressure", "Давление жидкости на выходе из резервуара",
                 GPA_PRESSURE_UNIT),
    scalarSensor("liquid-level", "Уровень жидкости в резервуаре",
                 GPA_LENGTH_UNIT),
    scalarSensor("lev-fullness", "Заполненность по уровню жидкости",
                 GPA_DIMLESS_UNIT),
    scalarSensor("vol-fullness", "Заполненность по объему", GPA_DIMLESS_UNIT),
    scalarSensor("enthalpy", "Сумма энтальпии газа и жидкости",
                 GPA_ENERGY_UNIT),
    scalarSensor("moles", "Сумма количества вещества газа и жидкости",
                 GPA_AMOUNT_UNIT),
    scalarSensor("vel_1", "скорость 1", GPA_DIMLESS_UNIT),
    scalarSensor("vel_2", "скорость 2", GPA_DIMLESS_UNIT),
    scalarSensor("fraction0", "Доля компонента 1 жидкости", GPA_DIMLESS_UNIT),
    scalarSensor("fraction1", "Доля компонента 2 жидкости", GPA_DIMLESS_UNIT),
    scalarSensor("fraction2", "Доля компонента 3 жидкости", GPA_DIMLESS_UNIT),
    scalarSensor("fraction3", "Доля компонента 4 жидкости", GPA_DIMLESS_UNIT),
    scalarSensor("fraction4", "Доля компонента 5 жидкости", GPA_DIMLESS_UNIT),
    scalarSensor("fraction5", "Доля компонента 6 жидкости", GPA_DIMLESS_UNIT),
    scalarSensor("N15_vapor", "Доля пара на порту N15", GPA_DIMLESS_UNIT)};

gpaDynamicReservoir::gpaDynamicReservoir(const gpaCoreInterfaces *interfaces,
                                         gpaCoreReference importRef)
    : gpaExportSystem(interfaces, importRef), m_volume(asParent()),
      m_environment(asParent()) {}

gpaDynamicReservoir::~gpaDynamicReservoir() {}

const gpaStringVector gpaDynamicReservoir::m_circuitNames = {"Circuit"};

const gpaStringVector gpaDynamicReservoir::m_portNames = {
    "N01 Вход (нижняя загрузка)",
    "N02 Вход (верхняя загрузка)",
    "N03 Вход (отпарной газ ПФ с судна)",
    "N04 Вход (от установки термостатирования)",
    "N05 Вход (штуцер подачи под слой)",
    "N06 Вход (азот низкого давления)",
    "N07 Выход (отпарной газ на установку термостатирования)",
    "N12 Выход (пилотный газ)",
    "N13 Выход (сброс на факел НД)",
    "N15 Выход продукта из насосов откачки",
    "N18 Вход (сбросы и дренажи пропановой фракции)"};

gpaUInt gpaDynamicReservoir::getDeviceNumMixCircuits() { return NUM_CIRCUITS; }

gpaUInt gpaDynamicReservoir::getDeviceMinNumMixPorts(gpaUInt index) {
  return index < NUM_CIRCUITS ? NUM_PORTS : 0;
}

gpaUInt gpaDynamicReservoir::getDeviceMaxNumMixPorts(gpaUInt index) {
  return index < NUM_CIRCUITS ? NUM_PORTS : 0;
}

const gpaString *gpaDynamicReservoir::getDeviceMixCircuitName(gpaUInt index) {
  return index < NUM_CIRCUITS ? &m_circuitNames[index] : NULL;
}

const gpaString *gpaDynamicReservoir::getDeviceMixPortName(gpaUInt circIdx,
                                                           gpaUInt portIdx) {
  return portIdx < NUM_PORTS ? &m_portNames[portIdx] : NULL;
}

gpaResult
gpaDynamicReservoir::checkParamValues(const gpaExtParameter *values) const {
  (void)values;
  return GPA_RESULT_OK;
}

void gpaDynamicReservoir::setNames() {
  m_volume.setName("Vol");
  m_environment.setName("Env");
}

gpaResult gpaDynamicReservoir::initVolumes(const gpaExtParameter *values) {
  // Формируем вектор начальных мольных долей в резервуаре
  // gpaVector gasFractions(values[ID_PARAM_GAS_FRACTIONS].value.realVector,
  //                       values[ID_PARAM_GAS_FRACTIONS].size);
  gpaVector fractions(values[ID_PARAM_LIQ_FRACTIONS].value.realVector,
                      values[ID_PARAM_LIQ_FRACTIONS].size);
  // Назначаем параметры сепрационной секции
  bool good = true;
  gpaVerticalCylinder *shape = new gpaVerticalCylinder(&m_volume);
  good &= shape->setDiameter(values[ID_PARAM_D].value.realValue);
  good &= shape->setHeight(values[ID_PARAM_H].value.realValue);
  if (!good)
    return GPA_ERROR_WRONG_ARGS;
  m_volume.setShape(shape);
  good &= m_volume.setInitFractions(fractions);
  good &= m_volume.setInitPressure(values[ID_PARAM_PRES0].value.realValue);
  good &= m_volume.setInitTemperature(
      values[ID_PARAM_TEMP0].value.realValue + GPA_CELCIUS_TO_KELVIN);
  good &= m_volume.setHeatTransferParams(2, 6);
  good &= m_volume.setMiddleLayerCoeff(6);
  good &= m_volume.setWallLayer({0.05, 7800, 60, 500});
  good &= m_volume.addIsolationLayer({0.1, 1.25, 1, 20});
  good &= m_volume.addIsolationLayer({0.2, 7800, 60, 500});
  good &= m_volume.setOuterLayerCoeff(
      values[ID_PARAM_ALPHA_OUT].value.realValue);
  good &= m_volume.setEvaporationTimeConstant(1e2);
  good &= m_volume.setVaporizationTimeConstant(1e3);
  good &= m_volume.setEvaporationThreshold(1e-3);
  good &= m_volume.setInitLiqVolumeFraction(
      values[ID_PARAM_PHI].value.realValue);
  good &= m_volume.setAmbientTemperature(
      values[ID_PARAM_T_ENV].value.realValue + GPA_CELCIUS_TO_KELVIN);

  good &=
      m_volume.setExternalVolume(values[ID_PARAM_EXT_VOL].value.realValue);
  if (!good)
    return GPA_ERROR_WRONG_ARGS;
  return GPA_RESULT_OK;
}

gpaResult
gpaDynamicReservoir::initPortParameters(const gpaExtParameter *values) {
  bool good = true;
  // Создаем отверсие для входа смеси и назначаем его характеристики
  gpaVolumeFittingData *port = NULL;
  port = new gpaVolumeFittingData(&m_volume);
  good &= port->setVolumeBottom(values[ID_PARAM_PORT_R01].value.realValue);
  good &= m_volume.setFittingPortData(GPA_N01_INLET, port);
  // Создаем отверсие для выхода газа и назначаем его характеристики
  port = new gpaVolumeFittingData(&m_volume);
  good &= port->setVolumeTop(values[ID_PARAM_PORT_R02].value.realValue);
  good &= m_volume.setFittingPortData(GPA_N02_INLET, port);
  // Создаем отверсие для выхода жидкости и назначаем его характеристики
  port = new gpaVolumeFittingData(&m_volume);
  good &= port->setVolumeTop(values[ID_PARAM_PORT_R03].value.realValue);
  good &= m_volume.setFittingPortData(GPA_N03_INLET, port);
  //
  port = new gpaVolumeFittingData(&m_volume);
  good &= port->setVolumeTop(values[ID_PARAM_PORT_R04].value.realValue);
  good &= m_volume.setFittingPortData(GPA_N04_INLET, port);
  //
  port = new gpaVolumeFittingData(&m_volume);
  good &= port->setVolumeBottom(values[ID_PARAM_PORT_R05].value.realValue);
  good &= m_volume.setFittingPortData(GPA_N05_INLET, port);
  //
  port = new gpaVolumeFittingData(&m_volume);
  good &= port->setVolumeTop(values[ID_PARAM_PORT_R06].value.realValue);
  good &= m_volume.setFittingPortData(GPA_N06_INLET, port);

  port = new gpaVolumeFittingData(&m_volume);
  good &= port->setVolumeTop(values[ID_PARAM_PORT_R07].value.realValue);
  good &= m_volume.setFittingPortData(GPA_N07_OUTLET, port);
  //
  port = new gpaVolumeFittingData(&m_volume);
  good &= port->setVolumeTop(values[ID_PARAM_PORT_R12].value.realValue);
  good &= m_volume.setFittingPortData(GPA_N12_OUTLET, port);

  port = new gpaVolumeFittingData(&m_volume);
  good &= port->setVolumeTop(values[ID_PARAM_PORT_R13].value.realValue);
  good &= m_volume.setFittingPortData(GPA_N13_OUTLET, port);

  port = new gpaVolumeFittingData(&m_volume);
  good &= port->setVolumeBottom(values[ID_PARAM_PORT_R15].value.realValue);
  good &= m_volume.setFittingPortData(GPA_N15_OUTLET, port);

  port = new gpaVolumeFittingData(&m_volume);
  good &= port->setVolumeTop(values[ID_PARAM_PORT_R18].value.realValue);
  good &= m_volume.setFittingPortData(GPA_N18_INLET, port);
  if (!good)
    return GPA_ERROR_WRONG_ARGS;
  return GPA_RESULT_OK;
}

gpaResult gpaDynamicReservoir::setParamValues(const gpaExtParameter *values,
                                              bool checkNeeded) {
  // Проверка параметров, если требуется
  if (checkNeeded) {
    gpaResult res = checkParamValues(values);
    if (res != GPA_RESULT_OK)
      return res;
  }
  // Даем названия элементам и потокам
  setNames();
  // Инициализируем резервуар
  gpaResult res = initVolumes(values);
  if (res != GPA_RESULT_OK)
    return res;
  // Назначаем параметры портов
  res = initPortParameters(values);
  if (res != GPA_RESULT_OK)
    return res;
  // Инициализируем внешнюю среду
  return updateEnvironment(values);
}

gpaResult gpaDynamicReservoir::buildDevice() {
  bool good = true;
  // Соединяем резервуар с граничными потоками смеси системы
  good = good &&
         m_volume.connectMixStream(GPA_ELEM_CIRCUIT_0, GPA_N01_INLET,
                                   getEdgeMixStream(ID_CIRCUIT, GPA_N01_INLET),
                                   GPA_STREAM_INLET);
  good = good &&
         m_volume.connectMixStream(GPA_ELEM_CIRCUIT_0, GPA_N02_INLET,
                                   getEdgeMixStream(ID_CIRCUIT, GPA_N02_INLET),
                                   GPA_STREAM_INLET);
  good = good &&
         m_volume.connectMixStream(GPA_ELEM_CIRCUIT_0, GPA_N03_INLET,
                                   getEdgeMixStream(ID_CIRCUIT, GPA_N03_INLET),
                                   GPA_STREAM_INLET);
  good = good &&
         m_volume.connectMixStream(GPA_ELEM_CIRCUIT_0, GPA_N04_INLET,
                                   getEdgeMixStream(ID_CIRCUIT, GPA_N04_INLET),
                                   GPA_STREAM_INLET);
  good = good &&
         m_volume.connectMixStream(GPA_ELEM_CIRCUIT_0, GPA_N05_INLET,
                                   getEdgeMixStream(ID_CIRCUIT, GPA_N05_INLET),
                                   GPA_STREAM_INLET);
  good = good &&
         m_volume.connectMixStream(GPA_ELEM_CIRCUIT_0, GPA_N06_INLET,
                                   getEdgeMixStream(ID_CIRCUIT, GPA_N06_INLET),
                                   GPA_STREAM_INLET);
  good = good &&
         m_volume.connectMixStream(GPA_ELEM_CIRCUIT_0, GPA_N18_INLET,
                                   getEdgeMixStream(ID_CIRCUIT, GPA_N18_INLET),
                                   GPA_STREAM_INLET);
  //  outlet section
  good = good &&
         m_volume.connectMixStream(GPA_ELEM_CIRCUIT_0, GPA_N07_OUTLET,
                                   getEdgeMixStream(ID_CIRCUIT, GPA_N07_OUTLET),
                                   GPA_STREAM_OUTLET);
  good = good &&
         m_volume.connectMixStream(GPA_ELEM_CIRCUIT_0, GPA_N12_OUTLET,
                                   getEdgeMixStream(ID_CIRCUIT, GPA_N12_OUTLET),
                                   GPA_STREAM_OUTLET);
  good = good &&
         m_volume.connectMixStream(GPA_ELEM_CIRCUIT_0, GPA_N13_OUTLET,
                                   getEdgeMixStream(ID_CIRCUIT, GPA_N13_OUTLET),
                                   GPA_STREAM_OUTLET);
  good = good &&
         m_volume.connectMixStream(GPA_ELEM_CIRCUIT_0, GPA_N15_OUTLET,
                                   getEdgeMixStream(ID_CIRCUIT, GPA_N15_OUTLET),
                                   GPA_STREAM_OUTLET);
  if (!good)
    return GPA_ERROR_WRONG_ARGS;
  // Добавляем в систему все элементы и потоки
  setElements({&m_volume});
  setStreams({});
  return GPA_RESULT_OK;
}

gpaResult gpaDynamicReservoir::initialize() {
  // Подключить экспортируемый элемент к потокам в интеграторе
  gpaResult res = linkToCoreStreams();
  if (res != GPA_RESULT_OK)
    return res;
  // Соединяем все элементы друг с другом
  res = buildDevice();
  if (res != GPA_RESULT_OK)
    return res;
  // Создаем схемы течений (нужны соединенные элементы)
  if (!createSimStructures(
          {},
          {
              {getOuterEntrance(ID_CIRCUIT, GPA_N01_INLET)},
              // {getEdgeMixStream(GPA_N02_INLET), getMediumAt(GPA_N02_INLET)},
              //{getEdgeMixStream(GPA_N03_INLET), getMediumAt(GPA_N03_INLET)},
              // {getEdgeMixStream(GPA_N04_INLET), getMediumAt(GPA_N04_INLET)},
              // {getEdgeMixStream(GPA_N05_INLET), getMediumAt(GPA_N05_INLET)},
              // {getEdgeMixStream(GPA_N06_INLET), getMediumAt(GPA_N06_INLET)},
              // {getEdgeMixStream(GPA_N18_INLET), getMediumAt(GPA_N18_INLET)},
          }))
    return GPA_ERROR_WRONG_ARGS;
  // Инициализируем систему
  return gpaExportSystem::initialize();
}

gpaResult
gpaDynamicReservoir::updateEnvironment(const gpaExtParameter *values) {
  // Обновление параметров окружающей среды
  bool good = true;
  good &= m_environment.setTemperature(22. + GPA_CELCIUS_TO_KELVIN);
  good &= m_environment.setHeatTransferCoef(2.54);
  if (!good)
    return GPA_ERROR_WRONG_ARGS;
  return GPA_RESULT_OK;
}

gpaResult gpaDynamicReservoir::setSignals(const gpaConstVector &signals) {
  // gpaReal value;
  // bool good = true;
  // if (getSignalValue(signals, ID_PARAM_EXT_TEMP, value))
  //     good &= m_environment.setTemperature(value + GPA_CELCIUS_TO_KELVIN);
  // if (!good)
  //     return GPA_ERROR_WRONG_ARGS;
  return GPA_RESULT_OK;
}

gpaResult gpaDynamicReservoir::calcSensors(gpaVector &sensors) const {
  setSensorValue(sensors, ID_SENSOR_PRESSURE,
                 m_volume.getLiquidLevelPressure());
  setSensorValue(sensors, ID_SENSOR_LIQ_TEMPERATURE,
                 m_volume.getMedium()->getTemperature() -
                     GPA_CELCIUS_TO_KELVIN);
  setSensorValue(sensors, ID_SENSOR_GAS_TEMPERATURE,
                 m_volume.getMedium()->getTemperature() -
                     GPA_CELCIUS_TO_KELVIN);
  setSensorValue(sensors, ID_SENSOR_INLET_PRES,
                 m_volume.getFittingData(GPA_N01_INLET)->getPressure());
  // setSensorValue(sensors, ID_SENSOR_OUT_GAS_PRES,
  //                m_volume.getFittingData(GPA_N02_INLET)->getPressure());
  setSensorValue(sensors, ID_SENSOR_OUT_LIQ_PRES,
                 m_volume.getFittingData(GPA_N15_OUTLET)->getPressure());
  setSensorValue(sensors, ID_SENSOR_LIQUID_LEVEL, m_volume.getLiquidLevel());
  setSensorValue(sensors, ID_SENSOR_LEV_FULLNESS,
                 m_volume.getLiquidLevel() / m_volume.getShape()->getHeight());
  setSensorValue(sensors, ID_SENSOR_VOL_FULLNESS,
                 m_volume.getLiquidVolume() / m_volume.getShape()->getVolume());
  setSensorValue(sensors, ID_SENSOR_ENTHALPY, m_volume.getMixEnergy());
  setSensorValue(sensors, ID_SENSOR_MOLES, m_volume.getMixMoles());
  setSensorValue(sensors, ID_SENSOR_MOLES + 1, m_volume.m_vel_1);
  setSensorValue(sensors, ID_SENSOR_MOLES + 2, m_volume.m_vel_2);
  gpaConstVector fractions = m_volume.getInitFraction();
  for (gpaUInt i = 0; i < fractions.size(); ++i) {
    setSensorValue(sensors, i + ID_SENSOR_FRACTION0, fractions[i]);
  }

  setSensorValue(
      sensors, ID_SENSOR_N15_VAPOR,
      m_volume.getFittingData(GPA_N15_OUTLET)->getGasVolumeFraction());
  return GPA_RESULT_OK;
}
