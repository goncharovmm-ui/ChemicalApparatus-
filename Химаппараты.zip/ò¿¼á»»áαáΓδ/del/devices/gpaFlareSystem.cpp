#include "gpaFlareSystem.h"
#include "gpaThinWall.h"
#include "gpaZeroRadiation.h"
#include <gpaLogMeanTempDifference.h>
#include <iostream>

constexpr gpaUInt ID_CIRCUIT_INNER = 0;
constexpr gpaUInt NUM_CIRCUITS = 1;

constexpr gpaUInt ID_PORT_INLET = 0;
constexpr gpaUInt ID_PORT_OUTLET = 1;
constexpr gpaUInt NUM_PORTS = 2;

// Gas Blower Parameters IDs
constexpr gpaUInt ID_PARAM_RADLOSS = 0x00;
constexpr gpaUInt ID_PARAM_K_CO_2 = 0x01;
constexpr gpaUInt ID_PARAM_K_NO_2 = 0x02;
constexpr gpaUInt ID_PARAM_ENVIRONMENT_TEMP = 0x03;
constexpr gpaUInt ID_PARAM_PIPE_DIAM = 0x04;
constexpr gpaUInt ID_PARAM_PIPE_LEN = 0x05;
constexpr gpaUInt ID_PARAM_EXCESS_OXYGEN = 0x06;
constexpr gpaUInt ID_PARAM_NUM_BURNER = 0x07;
constexpr gpaUInt ID_PARAM_BURNER1_SWITCH = 0x08;
constexpr gpaUInt ID_PARAM_BURNER2_SWITCH = 0x09;
constexpr gpaUInt ID_PARAM_BURNER3_SWITCH = 0x0a;
constexpr gpaUInt ID_PARAM_BURNER4_SWITCH = 0x0b;
constexpr gpaUInt ID_PARAM_BURNER5_SWITCH = 0x0c;

constexpr gpaUInt ID_SENSOR_PRESSURE_DIFF = 0x00;
constexpr gpaUInt ID_SENSOR_TEMPERATURE_DIFF = 0x01;
// constexpr gpaUInt ID_SENSOR_NR_FLOWRATE = 0x02;
//  constexpr gpaUInt ID_SENSOR_OVERAGE_COEF = 0x03;
constexpr gpaUInt ID_SENSOR_Q_REACTION = 0x02;
constexpr gpaUInt ID_SENSOR_BURNER1_T = 0x03;
constexpr gpaUInt ID_SENSOR_BURNER2_T = 0x04;
constexpr gpaUInt ID_SENSOR_BURNER3_T = 0x05;
constexpr gpaUInt ID_SENSOR_Q_STREAM = 0x06;
constexpr gpaUInt ID_SENSOR_NO_OUT = 0x07;
constexpr gpaUInt ID_SENSOR_NO2_OUT = 0x08;
constexpr gpaUInt ID_SENSOR_BURNER4_T = 0x09;
constexpr gpaUInt ID_SENSOR_BURNER5_T = 0x0a;

const gpaString gpaFlareSystem::m_typeName = "flare-system";
const gpaString gpaFlareSystem::m_description = "Факельная система";

const gpaStringVector gpaFlareSystem::m_circuitNames = {"Flare circuit"};

const gpaStringVector gpaFlareSystem::m_portNames = {
    "Вход смеси", "Дымовые газы"
    // "122-065",
    // "122-077"
};

const gpaParameterInfoVector gpaFlareSystem::m_parameters = {
    realParam("radiation-loss", "Доля тепловых потерь в виде излучения",
              GPA_DIMLESS_UNIT, false, 0.1),
    realParam("k_CO_2", "Доля углерода, окисляющегося до CO2", GPA_DIMLESS_UNIT,
              true, 1.0),
    realParam("k_NO_2", "Доля азота, превращающегося в NO2", GPA_DIMLESS_UNIT,
              true, 0.2),
    realParam("env_temp", "Температура окружающей среды", GPA_TEMPERATURE_UNIT,
              false, 21.0),
    realParam("pipe_diam", "Диаметр дымовой трубы", GPA_LENGTH_UNIT, false,
              2.2),
    realParam("pipe_len", "Длина дымовой трубы", GPA_LENGTH_UNIT, false, 20.0),
    realParam("excess_oxygen", "Мольная доля кислорода в выходящем потоке",
              GPA_DIMLESS_UNIT, true, 1.0),
    realParam("number_of_burners", "Число горелок", GPA_DIMLESS_UNIT, false,
              2.0),
    realParam("burner1_switch", "Активность горелки 1", GPA_DIMLESS_UNIT, true,
              true),
    realParam("burner2_switch", "Активность горелки 2", GPA_DIMLESS_UNIT, true,
              true),
    realParam("burner3_switch", "Активность горелки 3", GPA_DIMLESS_UNIT, true,
              true),
    realParam("burner4_switch", "Активность горелки 4", GPA_DIMLESS_UNIT, true,
              true),
    realParam("burner5_switch", "Активность горелки 5", GPA_DIMLESS_UNIT, true,
              true),
};

const gpaSensorInfoVector gpaFlareSystem::m_sensors = {
    scalarSensor("pressure-diff", "Перепад давления", GPA_PRES_DIFFER_UNIT),
    scalarSensor("temperature-diff", "Перепад температуры",
                 GPA_TEMP_DIFFER_UNIT),
    scalarSensor("q-reaction", "Удельная теплота сгорания газо-воздушной смеси",
                 GPA_DIMLESS_UNIT),
    scalarSensor("burner1_temp", "Температура горелки 1", GPA_DIMLESS_UNIT),
    scalarSensor("burner2_temp", "Температура горелки 2", GPA_DIMLESS_UNIT),
    scalarSensor("burner3_temp", "Температура горелки 3", GPA_DIMLESS_UNIT),
    scalarSensor("q-stream", "Интенсивность горения", GPA_HEAT_RATE_UNIT),
    scalarSensor("no-out", "Мольная доля NO вы выходящем потоке",
                 GPA_HEAT_RATE_UNIT),
    scalarSensor("no2-out", "Мольная доля NO2 вы выходящем потоке",
                 GPA_HEAT_RATE_UNIT),
    scalarSensor("burner4_temp", "Температура горелки 4", GPA_DIMLESS_UNIT),
    scalarSensor("burner5_temp", "Температура горелки 5", GPA_DIMLESS_UNIT),

};

gpaFlareSystem::gpaFlareSystem(const gpaCoreInterfaces *interfaces,
                               gpaCoreReference importRef)
    : gpaExportSystem(interfaces, importRef), m_incinerator(asParent()),
      m_environment(asParent()) {}

gpaUInt gpaFlareSystem::getDeviceNumMixCircuits() { return NUM_CIRCUITS; }

gpaUInt gpaFlareSystem::getDeviceMinNumMixPorts(gpaUInt index) {
  return index < NUM_CIRCUITS ? NUM_PORTS : 0;
}

gpaUInt gpaFlareSystem::getDeviceMaxNumMixPorts(gpaUInt index) {
  return index < NUM_CIRCUITS ? NUM_PORTS : 0;
}

gpaResult gpaFlareSystem::checkParamValues(const gpaExtParameter *) const {
  return GPA_RESULT_OK;
}

const gpaString *gpaFlareSystem::getDeviceMixCircuitName(gpaUInt index) {
  return index < NUM_CIRCUITS ? &m_circuitNames[index] : NULL;
}

const gpaString *gpaFlareSystem::getDeviceMixPortName(gpaUInt circIdx,
                                                      gpaUInt portIdx) {
  return portIdx < NUM_PORTS ? &m_portNames[portIdx + circIdx * 2] : NULL;
}

void gpaFlareSystem::setNames() {
  m_incinerator.setName("flare");
  m_environment.setName("env");
}

gpaResult gpaFlareSystem::setParamValues(const gpaExtParameter *values,
                                         bool checkNeeded) {
  m_incinerator.setPressureModel(std::make_unique<PressureGradientModel>(
      1e-4, values[ID_PARAM_PIPE_LEN].value.realValue,
      values[ID_PARAM_PIPE_DIAM].value.realValue,
      values[ID_PARAM_PIPE_LEN].value.realValue, 0));
  m_incinerator.setRadiationLossCoef(values[ID_PARAM_RADLOSS].value.realValue);
  m_incinerator.setGeometry(values[ID_PARAM_PIPE_DIAM].value.realValue,
                            values[ID_PARAM_PIPE_LEN].value.realValue);
  m_incinerator.setOxidationCoef(values[ID_PARAM_K_CO_2].value.realValue,
                                 values[ID_PARAM_K_NO_2].value.realValue);
  m_incinerator.setHeatTransferCoef(1);
  m_environment.setTemperature(
      GPA_CELCIUS_TO_KELVIN +
      values[ID_PARAM_ENVIRONMENT_TEMP].value.realValue);
  m_environment.setHeatTransferCoef(2);

  m_convection.setCounterFlow(true);
  m_convection.setConvectLossCoef(0.1);

  gpaLogMeanTempDifference *tempDiff = new gpaLogMeanTempDifference();
  m_convection.setConvTempDiff(tempDiff);
  m_convection.setRadiation(new gpaZeroRadiation());
  m_incinerator.setExcessOxygen(values[ID_PARAM_EXCESS_OXYGEN].value.realValue);
  m_incinerator.setNumBurner(values[ID_PARAM_NUM_BURNER].value.realValue);
  m_incinerator.setBurner1Switch(
      values[ID_PARAM_BURNER1_SWITCH].value.realValue);
  m_incinerator.setBurner2Switch(
      values[ID_PARAM_BURNER2_SWITCH].value.realValue);
  m_incinerator.setBurner3Switch(
      values[ID_PARAM_BURNER3_SWITCH].value.realValue);
  m_incinerator.setBurner4Switch(
      values[ID_PARAM_BURNER4_SWITCH].value.realValue);
  m_incinerator.setBurner5Switch(
      values[ID_PARAM_BURNER5_SWITCH].value.realValue);
  m_incinerator.m_ari_temp =
      values[ID_PARAM_ENVIRONMENT_TEMP].value.realValue + GPA_CELCIUS_TO_KELVIN;
  gpaThinWall *wall = new gpaThinWall();
  wall->setFinningFactor(2.25 / 2);
  wall->calcPipeHeatCoef(1, 2, 2.25);
  m_convection.setWallModel(wall);
  return GPA_RESULT_OK;
}

gpaResult gpaFlareSystem::buildDevice() {
  bool good = true;

  good = good && m_incinerator.connectMixStream(
                     GPA_ELEM_CIRCUIT_0, ID_PORT_INLET,
                     getEdgeMixStream(ID_CIRCUIT_INNER, ID_PORT_INLET),
                     GPA_STREAM_INLET);
  good = good && m_incinerator.connectMixStream(
                     GPA_ELEM_CIRCUIT_0, ID_PORT_OUTLET,
                     getEdgeMixStream(ID_CIRCUIT_INNER, ID_PORT_OUTLET),
                     GPA_STREAM_OUTLET);
  good = good &&
         m_incinerator.connectHeatStream(0, &m_convection, GPA_STREAM_INLET);
  good = good &&
         m_environment.connectHeatStream(0, &m_convection, GPA_STREAM_OUTLET);
  // Добавляем в систему все элементы и потоки
  setElements({&m_incinerator});
  setStreams({&m_convection});
  return GPA_RESULT_OK;
}

gpaResult gpaFlareSystem::initialize() {
  // Подключить экспортируемый элемент к потокам в интеграторе
  gpaResult res = linkToCoreStreams();
  if (res != GPA_RESULT_OK)
    return res;
  // Соединяем все элементы друг с другом
  res = buildDevice();
  if (res != GPA_RESULT_OK)
    return res;
  // Создаем схемы течений (нужны соединенные элементы)
  auto oe1 = getOuterEntrance(ID_CIRCUIT_INNER, ID_PORT_INLET);
  auto oe2 = getOuterEntrance(ID_CIRCUIT_INNER, ID_PORT_OUTLET);
  auto ret = createSimStructures({}, {oe1});
  if (!ret)
    return GPA_ERROR_WRONG_ARGS;
  // Инициализируем систему
  return gpaExportSystem::initialize();
}

gpaResult gpaFlareSystem::calcSensors(gpaVector &sensors) const {
  setSensorValue(sensors, ID_SENSOR_PRESSURE_DIFF,
                 m_incinerator.getMixPort(ID_CIRCUIT_INNER, ID_PORT_OUTLET)
                         ->getStreamPressure() -
                     m_incinerator.getMixPort(ID_CIRCUIT_INNER, ID_PORT_INLET)
                         ->getStreamPressure());
  setSensorValue(sensors, ID_SENSOR_TEMPERATURE_DIFF,
                 m_incinerator.getMixPort(ID_CIRCUIT_INNER, ID_PORT_OUTLET)
                         ->getStreamTemperature() -
                     m_incinerator.getMixPort(ID_CIRCUIT_INNER, ID_PORT_INLET)
                         ->getStreamTemperature());
  // setSensorValue(sensors, ID_SENSOR_NR_FLOWRATE, 0);

  setSensorValue(sensors, ID_SENSOR_Q_REACTION, m_incinerator.m_Q_reaction);
  setSensorValue(sensors, ID_SENSOR_BURNER1_T,
                 m_incinerator.m_burner1_temp - GPA_CELCIUS_TO_KELVIN);
  setSensorValue(sensors, ID_SENSOR_BURNER2_T,
                 m_incinerator.m_burner2_temp - GPA_CELCIUS_TO_KELVIN);
  setSensorValue(sensors, ID_SENSOR_BURNER3_T,
                 m_incinerator.m_burner3_temp - GPA_CELCIUS_TO_KELVIN);
  setSensorValue(sensors, ID_SENSOR_BURNER4_T,
                 m_incinerator.m_burner3_temp - GPA_CELCIUS_TO_KELVIN);
  setSensorValue(sensors, ID_SENSOR_BURNER5_T,
                 m_incinerator.m_burner3_temp - GPA_CELCIUS_TO_KELVIN);

  setSensorValue(sensors, ID_SENSOR_Q_STREAM, m_incinerator.m_q_stream);
  setSensorValue(sensors, ID_SENSOR_NO_OUT, m_incinerator.m_NO_out);
  setSensorValue(sensors, ID_SENSOR_NO2_OUT, m_incinerator.m_NO2_out);
  return GPA_RESULT_OK;
}

gpaResult gpaFlareSystem::setSignals(const gpaConstVector &signals) {
  gpaReal value;
  bool good = true;
  if (getSignalValue(signals, ID_PARAM_BURNER1_SWITCH, value))
    good &= m_incinerator.setBurner1Switch(value);

  if (getSignalValue(signals, ID_PARAM_BURNER2_SWITCH, value))
    good &= m_incinerator.setBurner2Switch(value);

  if (getSignalValue(signals, ID_PARAM_BURNER3_SWITCH, value))
    good &= m_incinerator.setBurner3Switch(value);
  if (getSignalValue(signals, ID_PARAM_BURNER4_SWITCH, value))
    good &= m_incinerator.setBurner4Switch(value);
  if (getSignalValue(signals, ID_PARAM_BURNER5_SWITCH, value))
    good &= m_incinerator.setBurner5Switch(value);

  if (getSignalValue(signals, ID_PARAM_EXCESS_OXYGEN, value))
    good &= m_incinerator.setExcessOxygen(value);

  if (getSignalValue(signals, ID_PARAM_K_CO_2, value))
    good &= m_incinerator.setCoefCO2(value);
  if (getSignalValue(signals, ID_PARAM_K_NO_2, value))
    good &= m_incinerator.setCoefNO(value);

  //  // if (!good)
  //  //     return GPA_ERROR_WRONG_ARGS;
  return GPA_RESULT_OK;
}
