#include "gpaEOHInfo.h"
#include "gpaEOH.h"



gpaEOHInfo::gpaEOHInfo() :
    gpaDeviceInfo  (gpaEOH::getDeviceTypeName(),
                    gpaEOH::getDeviceDescription())
{
    setParameters(gpaEOH::getParametersInfo());
    setSensors(gpaEOH::getSensorsInfo());
}

gpaUInt gpaEOHInfo::getNumMixCircuits() const
{
    return gpaEOH::getDeviceNumMixCircuits();
}

gpaUInt gpaEOHInfo::getMinNumMixPorts(gpaUInt index) const
{
    return gpaEOH::getDeviceMinNumMixPorts(index);
}

gpaUInt gpaEOHInfo::getMaxNumMixPorts(gpaUInt index) const
{
    return gpaEOH::getDeviceMaxNumMixPorts(index);
}
const gpaString *gpaEOHInfo::getMixPortName(gpaUInt circIdx, gpaUInt portIdx) const
{
    return gpaEOH::getDeviceMixPortName(circIdx, portIdx);
}

const gpaString *gpaEOHInfo::getMixCircuitName(gpaUInt index) const
{
    return gpaEOH::getDeviceMixCircuitName(index);
}



gpaElement* gpaEOHInfo::createDevice(const gpaCoreInterfaces* interfaces, gpaCoreReference pairDevice,
                                             const gpaExtObjectModel* model) const
{
    gpaEOH* cooler = new gpaEOH(interfaces, pairDevice);
    gpaResult res = cooler->specifyModel(model);
    if (res == GPA_RESULT_OK)
        return cooler;
    delete cooler;
    return NULL;
}
