#include "gpaVaporatorPipe.h"
#include <cassert>
#include <iostream>
#include <numbers>

double sigmoid(double x) { return 1.0 / (1.0 + exp(-x)); }

gpaReal calcFrictionCoeff(gpaReal Re, gpaReal eps, gpaReal D) {
  // Calculate f values
  gpaReal f1, f2, f3;
  f1 = 16.0 * Re;
  f3 = 0.07716 * pow(Re, 2) /
       pow(log10(6.9 / (Re + 1e-9) + pow(eps / (3.7 * D), 1.11)), 2);

  if (Re <= 2300) {
    f2 = f1;
  } else if (Re >= 4000) {
    f2 = f3;
  } else {
    f2 = f1 + (Re - 2300) / 1700 * (f3 - f1);
  }

  // Calculate x values
  gpaReal x1 = (Re - 2300) / 300;
  gpaReal x2 = (Re - 4000) / 300;

  // Calculate friction factor
  gpaReal f = (f1 * (1 - sigmoid(x1)) + f2 * sigmoid(x1)) * (1 - sigmoid(x2)) +
              f3 * sigmoid(x2);

  // Calculate pressure drop
  gpaReal friction_dp = f;

  return friction_dp;
}

constexpr gpaUInt LENGTH_PARAM_IDX = 0;
constexpr gpaUInt LEN_1 = 1;
constexpr gpaUInt LEN_2 = 2;
constexpr gpaUInt LEN_3 = 3;

const gpaString lengthErrorStr = "Pipe length must be positive";

const gpaString gpaVaporatorPipe::m_typeName = "vaporator-pipe";
const gpaString gpaVaporatorPipe::m_description = "Труба испарителя";

const gpaModelNameInfoVector gpaVaporatorPipe::m_modelNames = {
    {"geometry", "Модель геометрии"},
    {"friction", "Модель сопротивления"},
    {"heatCoef", "Модель коэффициента теплопередачи"}};

const gpaParameterInfoVector gpaVaporatorPipe::m_parameters = {
    realParam("length", "Длина", GPA_LENGTH_UNIT, false, 1.)};

gpaVaporatorPipe::gpaVaporatorPipe(const gpaParentLink *link)
    : gpaLongFlow(link), m_length(1.0), m_eps(1.0), m_diametr(1.0),
      m_power(10.0), m_power_nominal(10), m_power_coeff(1.0), m_geometry(NULL),
      m_friction(NULL), m_heatCoef(NULL), m_heatCoef1(NULL), m_heatCoef2(NULL),
      m_medium_1(NULL), m_medium_2(NULL), m_medium_3(NULL), m_length1(0),
      m_length2(0), m_length3(0), m_hydro_coeff(1), m_external_q(1) {}

gpaVaporatorPipe::gpaVaporatorPipe(const gpaVaporatorPipe &pipe)
    : gpaLongFlow(pipe), m_length(pipe.m_length), m_eps(5e-5),
      m_diametr(pipe.m_diametr), m_power(pipe.m_power),
      m_power_nominal(pipe.m_power_nominal), m_power_coeff(pipe.m_power_coeff),
      m_geometry(pipe.m_geometry ? pipe.m_geometry->copyTo(asOwner()) : NULL),
      m_friction(pipe.m_friction ? pipe.m_friction->copyTo(asOwner()) : NULL),
      m_heatCoef(pipe.m_heatCoef ? pipe.m_heatCoef->copyTo(asOwner()) : NULL),
      m_heatCoef1(NULL), m_heatCoef2(NULL),
      m_medium_1(pipe.m_medium_1 ? pipe.m_medium_1->copyTo(asOwner()) : NULL),
      m_medium_2(pipe.m_medium_2 ? pipe.m_medium_2->copyTo(asOwner()) : NULL),
      m_medium_3(pipe.m_medium_3 ? pipe.m_medium_3->copyTo(asOwner()) : NULL),
      m_length1(0), m_length2(0), m_length3(0),
      m_hydro_coeff(pipe.m_hydro_coeff), m_external_q(pipe.m_external_q),
      m_wall_diamet1(pipe.m_wall_diamet1), m_wall_diamet2(pipe.m_wall_diamet2),
      m_wall_diamet3(pipe.m_wall_diamet3),
      m_wall_conductive1(pipe.m_wall_conductive1),
      m_wall_conductive2(pipe.m_wall_conductive2),
      m_wall_conductive3(pipe.m_wall_conductive3) {}

gpaVaporatorPipe::~gpaVaporatorPipe() {
  clearGeometry();
  //   clearFriction();
  //   clearHeatCoef();
}

void gpaVaporatorPipe::clearGeometry() {
  if (m_geometry)
    delete m_geometry;
  m_geometry = NULL;
}

void gpaVaporatorPipe::clearFriction() {
  if (m_friction)
    delete m_friction;
  m_friction = NULL;
}

void gpaVaporatorPipe::clearHeatCoef() {
  if (m_heatCoef != NULL)
    delete m_heatCoef;
  m_heatCoef = NULL;
}

gpaVaporatorPipe *gpaVaporatorPipe::copy() const {
  return new gpaVaporatorPipe(*this);
}

bool gpaVaporatorPipe::calcValuesPerLength() { return true; }

gpaReal gpaVaporatorPipe::getHeatArea() const {
  if (m_friction && m_geometry)
    return m_geometry->getNumStrokes() * m_geometry->getNumPipes() *
           std::numbers::pi * getDiameter() * m_length;
  return 0;
}

gpaReal gpaVaporatorPipe::getDiameter() const {
  return m_friction ? m_friction->getPipeDiameter() : 0.0;
}

gpaReal gpaVaporatorPipe::getCrossArea() const {
  return (m_friction && m_geometry)
             ? m_friction->getArea() * m_geometry->getNumPipes()
             : 0.0;
}

gpaReal gpaVaporatorPipe::getVolume() const {
  return getCrossArea() * m_length;
}

bool gpaVaporatorPipe::setPower(gpaReal power) {
  m_power_nominal = power;
  m_power = m_power_nominal * m_power_coeff;
  return true;
}
bool gpaVaporatorPipe::setPowerCoeff(gpaReal power) {
  m_power_coeff = power;
  m_power = m_power_nominal * m_power_coeff;
  return true;
}
bool gpaVaporatorPipe::setAlphaCoef(gpaReal alpha) {
  m_alphaCoef = alpha;
  return true;
}

bool gpaVaporatorPipe::setLength(gpaReal length) {
  bool good = 0.0 < length;
  if (good)
    m_length = length;
  else
    pushParameterError(lengthErrorStr, this);
  return good;
}

void gpaVaporatorPipe::setGeometry(gpaPipesGeometry *geometry) {
  clearGeometry();
  m_geometry = geometry;
}

void gpaVaporatorPipe::setFriction(gpaPipeFriction *friction) {
  clearFriction();
  m_friction = friction;
}

void gpaVaporatorPipe::setHeatCoefficient(gpaFlowHeatCoef *heatCoef) {
  clearHeatCoef();
  m_heatCoef = heatCoef;
}

gpaReal gpaVaporatorPipe::getHeatTransferCoef() const {
  if (!m_heatCoef)
    return 0.0;
  gpaReal diameter = getDiameter();
  gpaReal reynolds = calcReynoldsNumber(diameter);
  return m_heatCoef->getHeatTransferCoef(reynolds, getPrandtlNumber(),
                                         getConductivity(), diameter);
}

gpaMixPort *gpaVaporatorPipe::connectCircuitStream(gpaUInt index,
                                                   gpaMixStream *stream,
                                                   gpaReal orientation) {
  if (index == GPA_FLOW_INLET) {
    m_medium_1 = stream->getMedium()->copyTo(asOwner());
    m_medium_2 = stream->getMedium()->copyTo(asOwner());
    m_medium_3 = stream->getMedium()->copyTo(asOwner());
  }
  return connectMixStream(0, index, stream, orientation);
}

gpaResult gpaVaporatorPipe::initialize() {
  if (!m_geometry || !m_friction)
    return GPA_ERROR_WRONG_STATE;
  return GPA_RESULT_OK;
}

gpaReal gpaVaporatorPipe::calcHeatFricCoef() const {
  return 2.0 * (getInletTemperature() - getOutletTemperature()) /
         (getInletTemperature() + getOutletTemperature());
}

gpaReal gpaVaporatorPipe::calcFrictionFunc(gpaReal deltaPres,
                                           gpaReal rate) const {
  gpaReal velocity = getMolarMass() * rate / getCrossArea() / getDensity();
  gpaReal flowCoef = getDensity() * vmAbs(velocity) * velocity / 2.0;

  gpaReal re = calcReynoldsNumber(m_diametr);
  gpaReal friction_coeff = calcFrictionCoeff(re, m_eps, m_diametr);

  gpaReal friction_dp = friction_coeff * pow(getViscosity(), 2) * m_length /
                        (2 * getDensity() * pow(m_diametr, 3));
  gpaReal dp = friction_dp * vmSign(velocity);
  return deltaPres - m_hydro_coeff * dp - calcStaticPressure();
}

gpaSubModel *gpaVaporatorPipe::getSubModel(gpaUInt index) const {
  std::vector<gpaSubModel *> models = {m_geometry, m_friction, m_heatCoef};
  return index < getNumSubModels() ? models[index] : NULL;
}

bool gpaVaporatorPipe::checkParameterValues(gpaReal length) const {
  bool good = 0.0 < length;
  if (!good)
    pushParameterError(lengthErrorStr, this);
  return good;
}

bool gpaVaporatorPipe::setParameterValues(gpaReal length, bool checkNeeded) {
  if (checkNeeded && !checkParameterValues(length))
    return false;
  m_length = length;
  return true;
}

gpaResult
gpaVaporatorPipe::checkParamValues(const gpaExtParameter *values) const {
  bool good = checkParameterValues(values[LENGTH_PARAM_IDX].value.realValue);
  return good ? GPA_RESULT_OK : GPA_ERROR_WRONG_ARGS;
}

gpaResult gpaVaporatorPipe::setParamValues(const gpaExtParameter *values,
                                           bool checkNeeded) {
  bool good =
      setParameterValues(values[LENGTH_PARAM_IDX].value.realValue, checkNeeded);
  return good ? GPA_RESULT_OK : GPA_ERROR_WRONG_ARGS;
}

gpaResult gpaVaporatorPipe::calcFuncValues(const gpaConstVector &,
                                           const gpaConstVector &variables,
                                           gpaVector &values,
                                           const gpaSetOfEquations &eqIds) {
  gpaReal deltaPres = getInletPort()->getStreamPressure() -
                      getOutletPort()->getStreamPressure();
  gpaReal inletPress = 0.5 * (getInletPort()->getStreamPressure() +
                              getOutletPort()->getStreamPressure());
  gpaReal inletRate = getInletPort()->getIncomingFlowRate();
  gpaReal outletRate = getOutletPort()->getIncomingFlowRate();

  gpaReal l1 = vmAbs(variables[LEN_1]);
  gpaReal l2 = vmAbs(variables[LEN_2]);
  gpaReal l3 = vmAbs(variables[LEN_3]);

  // t1out = m_medium_1->getTemperature()+q_1_out/calcRmat(l1);
  // t2out = m_medium_2->getTemperature()+q_2_out/calcRmat(l2);
  // t3out = m_medium_3->getTemperature()+q_3_out/calcRmat(l3);
  gpaReal t1out = 0; // variables[4];
  gpaReal t2out = 0; // variables[5];
  gpaReal t3out = 0; // variables[6];

  gpaDataVector fractions = getInletPort()->getStreamFractions();
  gpaResult res = m_medium_2->calcFlashPV(inletPress, 0, fractions);
  res = m_medium_3->calcFlashPV(inletPress, 1, fractions);
  gpaReal G = inletRate;
  if (G < 0) {
    G = 0;
  }
  gpaHeatCoeffPrm hc = *m_heatCoef1;

  gpaReal q_heat = (m_medium_2->getEnthalpy() -
                    getInletPort()->getStreamMedium()->getEnthalpy()) *
                   G;
  gpaReal q_phase_transition =
      (m_medium_3->getEnthalpy() - m_medium_2->getEnthalpy()) * G;

  gpaReal q_1_out = variables[4];
  gpaReal q_2_out = variables[5];
  gpaReal q_3_out = variables[6];
  m_external_q = q_1_out + q_2_out + q_3_out;
  gpaReal q_1 = m_power * l1 / m_length - q_1_out;
  gpaReal q_2 = m_power * l2 / m_length - q_2_out;
  gpaReal q_3 = m_power * l3 / m_length - q_3_out;
  gpaReal q_total = q_1 + q_2 + q_3;
  gpaMedium *media_out = m_medium_3;

  values[0] = inletRate + outletRate;
  values[1] = deltaPres - variables[0];
  values[2] = -calcFrictionFunc(variables[0], 0.5 * (inletRate - outletRate));
  if (m_power < 1e-6) {
    values[3] = l1 / m_length - 1;
    values[4] = l2;
    values[5] = l3;
    values[6] = q_1_out;
    values[7] = q_2_out;
    values[8] = q_3_out;
  } else {
    if (q_heat <= 0) {
      values[3] = l1 / m_length;
      q_heat = 0;
    } else if (q_heat + q_1_out < m_power) {
      values[3] = (q_1 - q_heat) / m_power;
    } else {
      values[3] = l1 / m_length - 1;
      // media_out = m_medium_1;
    }

    if (q_phase_transition < 0) {
      values[4] = l2 / m_length;
    } else if (q_heat + q_phase_transition - q_1_out - q_2_out < m_power) {
      values[4] = (q_2 - q_phase_transition) / m_power;
    } else {
      values[4] = (l1 + l2) / m_length - 1;
      //       media_out = m_medium_2;
    }
    // values[1]= variables[0]-1;
    // media_out = m_medium_2;
    values[5] = (l1 + l2 + l3) / m_length - 1;
    gpaReal rmat = calcRmat();

    res = m_medium_3->calcFlashPH(getOutletPort()->getStreamPressure(),
                                  getOutletPort()->getStreamEnthalpy(),
                                  fractions);

    values[6] =
        q_1_out +
        l1 * (m_heatCoef1->Tsr - m_medium_1->getTemperature()) * calcRmat();
    values[7] =
        q_2_out +
        l2 * (m_heatCoef1->Tsr - m_medium_2->getTemperature()) * calcRmat();
    values[8] =
        q_3_out +
        l3 * (m_heatCoef1->Tsr - m_medium_3->getTemperature()) * calcRmat();
  }
  //   }else{
  //   values[6]  =  t1out - m_medium_1->getTemperature()+q_1_out/calcRmat();
  //   values[7]  =  t2out - m_medium_2->getTemperature()+q_2_out/calcRmat();
  //   values[8]  =  t3out - m_medium_3->getTemperature()+q_3_out/calcRmat();

  //   values[6]  =   m_medium_1->getTemperature() -t1out;
  //   values[7]  =  m_medium_2->getTemperature() - t2out;
  // values[8]  =  getOutletPort()->getStreamTemperature()- t3out ;

  //   }

  setLength1(l1);
  setLength2(l2);
  setLength3(l3);

  if (l1 > 0) {
    t1 = m_medium_1->getTemperature() + q_1 / m_alphaCoef / l1;
  }
  if (l2 > 0) {
    t2 = m_medium_2->getTemperature() + q_2 / m_alphaCoef / l2;
  } else {
    t2 = t1;
  }
  if (l3 > 0) {
    t3 = getOutletPort()->getStreamTemperature() + q_3 / m_alphaCoef / l3;
  } else {
    t3 = t2;
  }

  return GPA_RESULT_OK;
}
gpaResult gpaVaporatorPipe::calcEnthalpyFuncValueAt(gpaUInt circIdx,
                                                    gpaUInt portIdx,
                                                    gpaReal enthalpy,
                                                    gpaReal &funcValue) const {
  if (circIdx != GPA_ELEM_CIRCUIT_0)
    return GPA_ERROR_WRONG_ARGS;
  const gpaMixPort *oppPort = getOppositePort(portIdx);
  if (!oppPort)
    return GPA_ERROR_WRONG_ARGS;
  gpaReal G = vmAbs(oppPort->getIncomingFlowRate());
  if (G < 1.e-6) {
    funcValue = enthalpy - oppPort->getStreamEnthalpy();
  } else {
    funcValue = (enthalpy - oppPort->getStreamEnthalpy()) * G -
                (m_power - m_external_q);
  }
  return GPA_RESULT_OK;
}
gpaResult gpaVaporatorPipe::initVariables(gpaVector &variables) const {
  variables[0] = 0.01;
  variables[1] = m_length / 2;
  variables[2] = m_length / 2;
  variables[3] = 0;
  variables[4] = 0;
  variables[5] = 0;
  variables[6] = 0;
  //  variables[7] = 0;
  return GPA_RESULT_OK;
}

gpaReal gpaVaporatorPipe::getTenHeatTransferCoef() const {
  if (!m_heatCoef)
    return 0.0;
  return 0;
  // gpaReal reynolds = calcReynoldsNumber(m_ten_diametr);
  // return m_heatCoef->getHeatTransferCoef(reynolds, getPrandtlNumber(),
  // getConductivity(), diameter);
}
gpaReal gpaVaporatorPipe::calcRmat() {
  m_Ain = std::numbers::pi * m_wall_diamet1;
  m_Aout = std::numbers::pi * m_wall_diamet3;
  gpaReal rMat = 0;
  rMat += std::log(m_wall_diamet2 / m_wall_diamet1) /
          (2 * std::numbers::pi * m_wall_conductive1);
  rMat += std::log(m_wall_diamet3 / m_wall_diamet2) /
          (2 * std::numbers::pi * m_wall_conductive2);
  return rMat;
}
void gpaVaporatorPipe::fillVarNames(gpaStringVector &varNames) const {
  varNames[0] = "p";
  varNames[1] = "l_liquid_zone";
  varNames[2] = "l_boling_zone";
  varNames[3] = "l_vapor";
  varNames[4] = "q_liquid_zone";
  varNames[5] = "q_boling_zone";
  varNames[6] = "q_vapor";
}
