#include "gpaInclude.h"
#include "gpaFireOilHeaterElement.h"

const gpaString gpaFireOilHeaterElement::m_typeName     = "fire-oilheater";
const gpaString gpaFireOilHeaterElement::m_description  = "Идеальное ";