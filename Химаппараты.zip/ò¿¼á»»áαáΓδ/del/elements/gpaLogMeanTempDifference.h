/*!
 *  \file      gpaLogMeanTempDifference.h
 *  \brief     Класс, описывающий среднелогарифмический температурный напор
 *  \author    Колосков Александр
 *  \date      2025
 */
#ifndef GPA_LOG_MEAN_TEMP_DIFFERENCE_H
#define GPA_LOG_MEAN_TEMP_DIFFERENCE_H

#include "gpaInclude.h"
#include "gpaConvectionTempDifference.h"

/*!
 * \class gpaLogMeanTempDifference
 * \brief Класс, описывающий среднелогарифмический температурный напор
 */
class gpaLogMeanTempDifference : public gpaConvectionTempDifference
{
public:
    /*!
     * Конструктор по умолчанию
     * \param link ссылки на владельцев
     */
    gpaLogMeanTempDifference(const gpaOwnerLink* link = NULL);
    /*!
     * Конструктор копирования
     * \param difference температурный напор для копирования
     * \param link ссылки на владельцев
     */
    gpaLogMeanTempDifference(const gpaLogMeanTempDifference& difference, const gpaOwnerLink* link = NULL);
    /*!
     * Деструктор по умолчанию
     */
    virtual ~gpaLogMeanTempDifference() override = default;
    /*!
     * Функция копирования температурного напора
     * \param link ссылки на владельцев
     * \return скопированный температурный напор
     */
    virtual gpaLogMeanTempDifference* copyTo(const gpaOwnerLink* link = NULL) const override;
    /*!
     * Получить название типа модели
     * \return название типа модели
     */
    virtual const gpaString& getTypeName() const override { return getObjectTypeName(); }
    /*!
     * Получить описание модели
     * \return описание модели
     */
    virtual const gpaString& getDescription() const override { return getObjectDescription(); }
    /*!
     * Определить значение температурного напора
     * \param leftDeltaTemp левая разность температур
     * \param rightDeltaTemp правая разность температур
     * \return значение температурного напора
     */
    virtual gpaReal calcTemperatureDiff(gpaReal leftDeltaTemp, gpaReal rightDeltaTemp) const override;

public:
    /*!
     * Получить название типа модели
     * \return название типа модели
     */
    static const gpaString& getObjectTypeName() { return m_modelName; }
    /*!
     * Получить описание модели
     * \return описание модели
     */
    static const gpaString& getObjectDescription() { return m_modelDescr; }

private:
    //! Название типа модели
    static const gpaString                  m_modelName;
    //! Описание модели
    static const gpaString                  m_modelDescr;
};

#endif
