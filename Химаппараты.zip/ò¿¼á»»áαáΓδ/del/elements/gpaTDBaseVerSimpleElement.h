#ifndef GPA_TD_BaseVerSimpleElement_H
#define GPA_TD_BaseVerSimpleElement_H
#include "gpaFlowElement.h"
#include "gpaHeatLayer.h"
#include "gpaInclude.h"
#include <fstream>
#include <iostream>
#include <numbers>
using namespace std;

#include <stdexcept>
#include <vector>

#include <algorithm>
#include <cstdlib>
#include <filesystem>
#include <iomanip>
#include <sstream>
#include <string>

#include <limits>
#include <map>
#include <queue>
#include <set>

using namespace std;
namespace fs = std::filesystem;

const gpaUInt GPA_ELEM_CIRCUIT_1 = 1;

// Структура для представления точки в 3D
struct Point3D {
  double x, y, z;
  int id; // Идентификатор точки

  Point3D(double x = 0, double y = 0, double z = 0, int id = -1)
      : x(x), y(y), z(z), id(id) {}

  void print() const {
    cout << "(" << x << ", " << y << ", " << z << ")";
    if (id >= 0)
      cout << "[id=" << id << "]";
  }

  // Расстояние до другой точки (только по x,y для 2D)
  double distance2DTo(const Point3D &other) const {
    double dx = x - other.x;
    double dy = y - other.y;
    return sqrt(dx * dx + dy * dy);
  }

  // Квадрат расстояния (только по x,y)
  double distance2DSqTo(const Point3D &other) const {
    double dx = x - other.x;
    double dy = y - other.y;
    return dx * dx + dy * dy;
  }
};

// Структура для представления треугольника в 3D
struct Triangle3D {
  Point3D p1, p2, p3;
  vector<int> indices; // Индексы вершин

  Triangle3D(const Point3D &a, const Point3D &b, const Point3D &c)
      : p1(a), p2(b), p3(c) {
    indices = {a.id, b.id, c.id};
    sort(indices.begin(), indices.end()); // Для уникальности
  }

  // Вычисление центра треугольника (центроид)
  Point3D center() const {
    return Point3D((p1.x + p2.x + p3.x) / 3.0, (p1.y + p2.y + p3.y) / 3.0,
                   (p1.z + p2.z + p3.z) / 3.0);
  }

  // Проверка, является ли треугольник вырожденным в проекции на плоскость XY
  bool isDegenerate2D(double eps = 1e-10) const {
    double area = abs(signedArea2D());
    return area < eps;
  }

  // Вычисление знаковой площади проекции на плоскость XY
  double signedArea2D() const {
    return (p2.x - p1.x) * (p3.y - p1.y) - (p3.x - p1.x) * (p2.y - p1.y);
  }

  // Вычисление площади проекции на плоскость XY
  double area2D() const { return abs(signedArea2D()) / 2.0; }

  // Интерполяция значения z по точке внутри треугольника
  double interpolateZ(const Point3D &p) const {
    // Барицентрические координаты
    double areaABC = this->area2D() * 2;
    double areaPBC = abs(signedArea2DWithPoint(p, p2, p3));
    double areaAPC = abs(signedArea2DWithPoint(p1, p, p3));
    double areaABP = abs(signedArea2DWithPoint(p1, p2, p));

    double u = areaPBC / areaABC;
    double v = areaAPC / areaABC;
    double w = areaABP / areaABC;

    return u * p1.z + v * p2.z + w * p3.z;
  }

  // Вспомогательная функция для вычисления знаковой площади с точкой
  static double signedArea2DWithPoint(const Point3D &a, const Point3D &b,
                                      const Point3D &c) {
    return (b.x - a.x) * (c.y - a.y) - (c.x - a.x) * (b.y - a.y);
  }

  void print() const {
    cout << "Треугольник с вершинами: ";
    p1.print();
    cout << ", ";
    p2.print();
    cout << ", ";
    p3.print();
  }

  // Оператор для использования в set/map
  bool operator<(const Triangle3D &other) const {
    return indices < other.indices;
  }
};

// ================== АЛГОРИТМЫ ТРИАНГУЛЯЦИИ ==================

// Класс для триангуляции Делоне
class DelaunayTriangulation {
private:
  vector<Point3D> points;
  vector<Triangle3D> triangles;

  // Проверка условия Делоне для ребра
  bool isDelaunay(const Point3D &p1, const Point3D &p2, const Point3D &p3,
                  const Point3D &p4) const {
    // Проверяем, находится ли точка p4 внутри окружности, описанной вокруг
    // треугольника p1,p2,p3
    double ax = p1.x - p4.x;
    double ay = p1.y - p4.y;
    double bx = p2.x - p4.x;
    double by = p2.y - p4.y;
    double cx = p3.x - p4.x;
    double cy = p3.y - p4.y;

    double det = (ax * ax + ay * ay) * (bx * cy - cx * by) -
                 (bx * bx + by * by) * (ax * cy - cx * ay) +
                 (cx * cx + cy * cy) * (ax * by - bx * ay);

    return det > 1e-12; // Положительное значение - точка внутри окружности
  }

  // Проверка, являются ли два треугольника соседними по ребру
  bool shareEdge(const Triangle3D &t1, const Triangle3D &t2,
                 pair<int, int> &edge) const {
    vector<int> common;
    for (int i : t1.indices) {
      for (int j : t2.indices) {
        if (i == j) {
          common.push_back(i);
        }
      }
    }

    if (common.size() == 2) {
      edge = {common[0], common[1]};
      return true;
    }
    return false;
  }

  // Флип ребра между двумя треугольниками
  void flipEdge(Triangle3D &t1, Triangle3D &t2, const pair<int, int> &edge) {
    // Находим вершины, не входящие в общее ребро
    int v1 = -1, v2 = -1;
    for (int i : t1.indices) {
      if (i != edge.first && i != edge.second) {
        v1 = i;
        break;
      }
    }
    for (int i : t2.indices) {
      if (i != edge.first && i != edge.second) {
        v2 = i;
        break;
      }
    }

    if (v1 != -1 && v2 != -1) {
      // Создаем новые треугольники
      Triangle3D newT1(points[edge.first], points[v1], points[v2]);
      Triangle3D newT2(points[edge.second], points[v1], points[v2]);

      // Заменяем старые треугольники новыми
      t1 = newT1;
      t2 = newT2;
    }
  }

public:
  DelaunayTriangulation(const vector<Point3D> &pts) : points(pts) {}

  // Алгоритм триангуляции Делоне (инкрементальный метод)
  vector<Triangle3D> triangulate() {
    triangles.clear();

    if (points.size() < 3) {
      return triangles;
    }

    // Создаем супер-треугольник, покрывающий все точки
    double minX = points[0].x, maxX = points[0].x;
    double minY = points[0].y, maxY = points[0].y;

    for (const auto &p : points) {
      minX = min(minX, p.x);
      maxX = max(maxX, p.x);
      minY = min(minY, p.y);
      maxY = max(maxY, p.y);
    }

    double dx = maxX - minX;
    double dy = maxY - minY;
    double margin = max(dx, dy) * 2;

    Point3D superP1(minX - margin, minY - margin, 0, -1);
    Point3D superP2(maxX + margin, minY - margin, 0, -2);
    Point3D superP3(minX - margin, maxY + margin, 0, -3);

    // Добавляем супер-треугольник
    triangles.push_back(Triangle3D(superP1, superP2, superP3));

    // Добавляем точки по одной
    for (const auto &point : points) {
      if (point.id < 0)
        continue; // Пропускаем точки без id

      vector<Triangle3D> badTriangles;

      // Находим все треугольники, содержащие точку в описанной окружности
      for (const auto &tri : triangles) {
        if (isPointInCircumcircle(point, tri)) {
          badTriangles.push_back(tri);
        }
      }

      // Находим границу многоугольника (все ребра, принадлежащие только одному
      // плохому треугольнику)
      map<pair<int, int>, int> edgeCount;

      for (const auto &tri : badTriangles) {
        vector<pair<int, int>> edges = {{tri.indices[0], tri.indices[1]},
                                        {tri.indices[1], tri.indices[2]},
                                        {tri.indices[2], tri.indices[0]}};

        for (auto &e : edges) {
          if (e.first > e.second)
            swap(e.first, e.second);
          edgeCount[e]++;
        }
      }

      // Удаляем плохие треугольники
      vector<Triangle3D> newTriangles;
      for (const auto &tri : triangles) {
        bool isBad = false;
        for (const auto &bad : badTriangles) {
          if (tri.indices == bad.indices) {
            isBad = true;
            break;
          }
        }
        if (!isBad) {
          newTriangles.push_back(tri);
        }
      }

      // Добавляем новые треугольники (соединяем точку с каждым ребром границы)
      for (const auto &edge : edgeCount) {
        if (edge.second ==
            1) { // Ребро принадлежит только одному плохому треугольнику
          int i1 = edge.first.first;
          int i2 = edge.first.second;

          // Получаем точки по индексам
          Point3D p1 = (i1 >= 0)    ? points[i1]
                       : (i1 == -1) ? superP1
                       : (i1 == -2) ? superP2
                                    : superP3;
          Point3D p2 = (i2 >= 0)    ? points[i2]
                       : (i2 == -1) ? superP1
                       : (i2 == -2) ? superP2
                                    : superP3;

          Triangle3D newTri(p1, p2, point);
          if (!newTri.isDegenerate2D()) {
            newTriangles.push_back(newTri);
          }
        }
      }

      triangles = newTriangles;
    }

    // Удаляем треугольники, использующие супер-точки
    vector<Triangle3D> result;
    for (const auto &tri : triangles) {
      bool hasSuperPoint = false;
      for (int idx : tri.indices) {
        if (idx < 0) {
          hasSuperPoint = true;
          break;
        }
      }
      if (!hasSuperPoint) {
        result.push_back(tri);
      }
    }

    return result;
  }

  // Проверка, находится ли точка внутри описанной окружности треугольника
  bool isPointInCircumcircle(const Point3D &p, const Triangle3D &tri) const {
    // Вычисляем описанную окружность треугольника
    double ax = tri.p1.x, ay = tri.p1.y;
    double bx = tri.p2.x, by = tri.p2.y;
    double cx = tri.p3.x, cy = tri.p3.y;

    double d = 2 * (ax * (by - cy) + bx * (cy - ay) + cx * (ay - by));
    if (abs(d) < 1e-12)
      return false; // Точки коллинеарны

    double ux =
        ((ax * ax + ay * ay) * (by - cy) + (bx * bx + by * by) * (cy - ay) +
         (cx * cx + cy * cy) * (ay - by)) /
        d;
    double uy =
        ((ax * ax + ay * ay) * (cx - bx) + (bx * bx + by * by) * (ax - cx) +
         (cx * cx + cy * cy) * (bx - ax)) /
        d;

    double radius = sqrt((ax - ux) * (ax - ux) + (ay - uy) * (ay - uy));
    double dist = sqrt((p.x - ux) * (p.x - ux) + (p.y - uy) * (p.y - uy));

    return dist < radius - 1e-10;
  }
};

class delanayInterpolator {

public:
  vector<Point3D> points;

  gpaString name_case;
  bool isHandEnter;

  vector<gpaReal> m_dot = {0, 0, 0, 0, 0, 0, 0, 0, 0};
  vector<gpaReal> pressure = {0, 0, 0, 0, 0, 0, 0, 0, 0};
  vector<gpaReal> omega = {0, 0, 0, 0, 0, 0, 0, 0, 0};

  Triangle3D *resultTriangle = nullptr;
  Point3D *resultPoint = nullptr;

  vector<Triangle3D> allTriangles;

  // ================== ГЕОМЕТРИЧЕСКИЕ ФУНКЦИИ ==================

  // Вычисление знаковой площади треугольника (проекция на XY)
  double signedArea2D(const Point3D &a, const Point3D &b, const Point3D &c) {
    return (b.x - a.x) * (c.y - a.y) - (c.x - a.x) * (b.y - a.y);
  }

  // Проверка, находится ли точка p внутри треугольника abc (проекция на XY)
  bool isPointInTriangle2D(const Point3D &p, const Point3D &a, const Point3D &b,
                           const Point3D &c, double eps = 1e-9) {
    double areaABC = abs(signedArea2D(a, b, c));
    double areaPBC = abs(signedArea2D(p, b, c));
    double areaAPC = abs(signedArea2D(a, p, c));
    double areaABP = abs(signedArea2D(a, b, p));

    // Сумма площадей маленьких треугольников должна равняться площади большого
    return abs(areaPBC + areaAPC + areaABP - areaABC) < eps;
  }

  // Расстояние от точки до отрезка (проекция на XY)
  double distanceToSegment2D(const Point3D &p, const Point3D &a,
                             const Point3D &b) {
    double dx = b.x - a.x;
    double dy = b.y - a.y;

    if (dx == 0 && dy == 0) {
      return p.distance2DTo(a);
    }

    double t = ((p.x - a.x) * dx + (p.y - a.y) * dy) / (dx * dx + dy * dy);

    if (t < 0)
      t = 0;
    if (t > 1)
      t = 1;

    Point3D projection(a.x + t * dx, a.y + t * dy);
    return p.distance2DTo(projection);
  }

  // Расстояние от точки до треугольника (проекция на XY)
  double distanceToTriangle2D(const Point3D &p, const Triangle3D &tri) {
    if (isPointInTriangle2D(p, tri.p1, tri.p2, tri.p3)) {
      return 0.0;
    }

    double d1 = distanceToSegment2D(p, tri.p1, tri.p2);
    double d2 = distanceToSegment2D(p, tri.p2, tri.p3);
    double d3 = distanceToSegment2D(p, tri.p3, tri.p1);

    return min({d1, d2, d3});
  }

  // ================== ФУНКЦИИ ПОИСКА ==================

  // Поиск треугольника, содержащего точку (поиск по всем треугольникам)
  Triangle3D *findTriangleContainingPoint(const vector<Triangle3D> &triangles,
                                          const Point3D &target) {
    for (const auto &tri : triangles) {
      if (isPointInTriangle2D(target, tri.p1, tri.p2, tri.p3)) {
        return const_cast<Triangle3D *>(&tri);
      }
    }
    return nullptr;
  }

  // Поиск ближайшей точки из массива
  Point3D findClosestPoint(const vector<Point3D> &points,
                           const Point3D &target) {
    if (points.empty()) {
      return Point3D();
    }

    int closestIdx = 0;
    double minDistSq = target.distance2DSqTo(points[0]);

    for (size_t i = 1; i < points.size(); i++) {
      double distSq = target.distance2DSqTo(points[i]);
      if (distSq < minDistSq) {
        minDistSq = distSq;
        closestIdx = i;
      }
    }

    return points[closestIdx];
  }

  // Поиск ближайшего треугольника
  Triangle3D findClosestTriangle(const vector<Triangle3D> &triangles,
                                 const Point3D &target) {
    if (triangles.empty()) {
      throw runtime_error("Нет треугольников для поиска");
    }

    double minDist = numeric_limits<double>::max();
    int bestIdx = 0;

    for (size_t i = 0; i < triangles.size(); i++) {
      double dist = distanceToTriangle2D(target, triangles[i]);
      if (dist < minDist) {
        minDist = dist;
        bestIdx = i;
      }
    }

    return triangles[bestIdx];
  }

  // ================== ОСНОВНАЯ ФУНКЦИЯ ==================

  // Основная функция: выполняет триангуляцию и находит треугольник, содержащий
  // точку
  void processPoint(double x0, double y0) {

    // Создаем целевую точку
    Point3D target(x0, y0, 0, -1);

    // Ищем треугольник, содержащий точку
    resultTriangle = findTriangleContainingPoint(allTriangles, target);

    if (resultTriangle != nullptr) {
      // Нашли треугольник
      resultPoint = nullptr;
    } else {
      // Ищем ближайшую точку
      Point3D closest = findClosestPoint(points, target);
      resultPoint = new Point3D(closest);
    }
  }

  // Вывод результатов
  gpaReal getInterpolatedValueByPoint(gpaReal x0, gpaReal y0) {

    Point3D target(x0, y0, 0);
    double z_interp;

    if (resultTriangle != nullptr) {
      // Интерполируем значение z

      z_interp = resultTriangle->interpolateZ(target);
      return z_interp;

    } else {
      Point3D closestPoint = findClosestPoint(points, target);
      z_interp = closestPoint.z;
      return z_interp;
    }
  }

  // Генерация тестовых данных

  void setPoutVSmdotAndomegaPointsAndDoDelTriang() {

    if (isHandEnter == 0) {
      vector<gpaReal> omega = {11500, 11000, 10000, 9200};
      vector<vector<vector<gpaReal>>> pOutVSmdotTES = {
          {{284.217, 2.19395},
           {289.087, 2.21513},
           {296.087, 2.2605},
           {302.783, 2.29176},
           {313.536, 2.33714},
           {324.899, 2.3916},
           {337.986, 2.45311},
           {350.362, 2.50353},
           {364.058, 2.55496},
           {378.261, 2.60336},
           {392.362, 2.66487},
           {406.565, 2.70924},
           {423., 2.75765},
           {436.391, 2.79597},
           {449.275, 2.83429},
           {461.957, 2.87059}},
          {{257.926, 2.13189}, {261.79, 2.17029},  {266.169, 2.22662},
           {270.548, 2.2599},  {275.184, 2.31623}, {279.821, 2.35464},
           {285.745, 2.3956},  {293.473, 2.43145}, {298.882, 2.45961},
           {305.321, 2.49546}, {313.049, 2.53642}, {321.291, 2.57483},
           {327.731, 2.60555}, {335.716, 2.6414},  {344.731, 2.68748},
           {355.55, 2.72589},  {368.944, 2.78478}, {381.823, 2.82574},
           {393.414, 2.86415}, {404.748, 2.90511}, {416.081, 2.92303},
           {428.188, 2.97424}, {438.748, 2.99984}, {449.309, 3.02545},
           {456.264, 3.04849}},
          {{197.137, 1.90487}, {199.713, 1.94071}, {202.289, 1.97912},
           {206.668, 2.03545}, {210.016, 2.08665}, {215.168, 2.14554},
           {220.835, 2.21211}, {225.471, 2.28124}, {231.653, 2.35549},
           {237.32, 2.4195},   {242.729, 2.48863}, {250.199, 2.57568},
           {257.154, 2.64737}, {263.078, 2.7037},  {269.002, 2.75746},
           {276.73, 2.84196},  {289.351, 2.91621}, {296.821, 2.95717},
           {307.124, 3.0135},  {317.428, 3.06471}, {329.534, 3.12103},
           {339.58, 3.14408},  {351.686, 3.19272}, {363.535, 3.22345},
           {375.126, 3.27209}, {385.687, 3.30026}, {396.505, 3.33866},
           {409.642, 3.36939}, {420.203, 3.40011}, {432.566, 3.44364},
           {443.127, 3.46924}},
          {{182.713, 2.22321}, {185.804, 2.27185}, {189.925, 2.33586},
           {194.304, 2.40755}, {198.425, 2.47156}, {205.122, 2.56373},
           {210.274, 2.65078}, {215.168, 2.71991}, {220.32, 2.78904},
           {225.214, 2.86841}, {231.653, 2.93242}, {237.578, 3.01947},
           {243.76, 3.09116},  {248.911, 3.15261}, {257.926, 3.22686},
           {265.911, 3.29343}, {274.154, 3.35744}, {284.715, 3.40353},
           {296.821, 3.46497}, {309.185, 3.50082}, {320.003, 3.54435},
           {331.595, 3.57507}, {344.989, 3.61347}, {357.868, 3.65188},
           {369.974, 3.69029}, {383.884, 3.72613}, {394.96, 3.76966},
           {409.899, 3.81062}}};

      // if(name_case == "100")
      // {

      // }

      gpaReal scale = 11500;
      gpaReal scale2 = 500;

      for (size_t i = 0; i < omega.size(); i++) {
        for (size_t j = 0; j < pOutVSmdotTES[i].size(); j++) {
          points.push_back(Point3D(omega[i], pOutVSmdotTES[i][j][0],
                                   pOutVSmdotTES[i][j][1], points.size()));
        }
      }

      for (size_t i = 0; i < omega.size(); i++) {
        for (size_t j = 0; j < pOutVSmdotTES[i].size(); j++) {
          points.push_back(Point3D(omega[i] + 1, pOutVSmdotTES[i][j][0],
                                   pOutVSmdotTES[i][j][1], points.size()));
        }
      }

      for (size_t i = 0; i < omega.size(); i++) {
        for (size_t j = 0; j < pOutVSmdotTES[i].size(); j++) {
          points.push_back(Point3D(omega[i], pOutVSmdotTES[i][j][0] - 1,
                                   pOutVSmdotTES[i][j][1], points.size()));
        }
      }

      // points.push_back(Point3D(15000, 500, 5, points.size()));
      // points.push_back(Point3D(15000, 100, 1, points.size()));
      // points.push_back(Point3D(8000, 250, 4, points.size()));

    } else {
      for (size_t i = 0; i < m_dot.size(); i++) {
        points.push_back(
            Point3D(omega[i], m_dot[i], pressure[i], points.size()));

        // нужно, чтобы участвовали все начальные точки
        //  points.push_back(Point3D(omega[i]+1, m_dot[i] , pressure[i],
        //  points.size())); points.push_back(Point3D(omega[i], m_dot[i]+1 ,
        //  pressure[i], points.size()));
        points.push_back(
            Point3D(omega[i] - 1, m_dot[i], pressure[i], points.size()));
        points.push_back(
            Point3D(omega[i], m_dot[i] - 1, pressure[i], points.size()));
      }

      // points.push_back(Point3D(15000, 500, 5, points.size()));
      // points.push_back(Point3D(15000, 100, 1, points.size()));
      // points.push_back(Point3D(8000, 250, 4, points.size()));
    }

    // points.push_back(Point3D(12000/12000, 350/350, 4, points.size()));
    // points.push_back(Point3D(11400/12000, 310/350, 5, points.size()));
    // points.push_back(Point3D(10000/12000, 360/350, 1, points.size()));
    // points.push_back(Point3D(11600/12000, 300/350, 2, points.size()));

    // points.push_back(Point3D(11600/12000, 300/350, 3, points.size()));
    // points.push_back(Point3D(12200/12000, 360/350, 4, points.size()));
    // points.push_back(Point3D(11440/12000, 310/350, 5, points.size()));
    // points.push_back(Point3D(10000/12000, 360/350, 1, points.size()));
    // points.push_back(Point3D(11200/12000, 310/350, 2, points.size()));

    // Выполняем триангуляцию Делоне
    DelaunayTriangulation delaunay(points);
    allTriangles = delaunay.triangulate();
  }

  gpaReal getPoutValueByCurrentOmegaAndMdot(gpaReal omegaNeed,
                                            gpaReal mdotNeed) {

    processPoint(omegaNeed, mdotNeed);

    gpaReal res = getInterpolatedValueByPoint(omegaNeed, mdotNeed);
    // for (size_t i = 0; i < allTriangles1.size(); i++)
    // {
    //     allTriangles1[i].print();
    // }

    delete resultPoint;

    return res;
  };
};

class PolynomialLeastSquares {
private:
  // Решение системы линейных уравнений методом Гаусса
  std::vector<double> gaussElimination(std::vector<std::vector<double>> &A,
                                       std::vector<double> &B) {
    int n = B.size();

    // Прямой ход
    for (int i = 0; i < n; i++) {
      // Поиск максимального элемента в столбце
      double maxEl = fabs(A[i][i]);
      int maxRow = i;
      for (int k = i + 1; k < n; k++) {
        if (fabs(A[k][i]) > maxEl) {
          maxEl = fabs(A[k][i]);
          maxRow = k;
        }
      }

      // Перестановка строк
      for (int k = i; k < n; k++) {
        std::swap(A[maxRow][k], A[i][k]);
      }
      std::swap(B[maxRow], B[i]);

      // Приведение к треугольному виду
      for (int k = i + 1; k < n; k++) {
        double c = -A[k][i] / A[i][i];
        for (int j = i; j < n; j++) {
          if (i == j) {
            A[k][j] = 0;
          } else {
            A[k][j] += c * A[i][j];
          }
        }
        B[k] += c * B[i];
      }
    }

    // Обратный ход
    std::vector<double> x(n);
    for (int i = n - 1; i >= 0; i--) {
      x[i] = B[i] / A[i][i];
      for (int k = i - 1; k >= 0; k--) {
        B[k] -= A[k][i] * x[i];
      }
    }

    return x;
  }

public:
  int degree;

  std::vector<double> coefficients; // Коэффициенты полинома

  void fit(const std::vector<double> &x, const std::vector<double> &y) {
    if (x.size() != y.size() || x.empty()) {
      throw std::invalid_argument("Invalid input data");
    }

    int n = x.size();
    int m = degree + 1;

    // Создание матрицы системы уравнений
    std::vector<std::vector<double>> A(m, std::vector<double>(m, 0.0));
    std::vector<double> B(m, 0.0);

    // Заполнение матрицы A и вектора B
    for (int k = 0; k < m; k++) {
      for (int j = 0; j < m; j++) {
        double sum = 0.0;
        for (int i = 0; i < n; i++) {
          sum += pow(x[i], j + k);
        }
        A[j][k] = sum;
      }

      double sum = 0.0;
      for (int i = 0; i < n; i++) {
        sum += y[i] * pow(x[i], k);
      }
      B[k] = sum;
    }

    // Решение системы уравнений
    coefficients = gaussElimination(A, B);
  }

  double predict(double x) const {
    double result = 0.0;
    for (int i = 0; i <= degree; i++) {
      result += coefficients[i] * pow(x, i);
    }
    return result;
  }

  void printCoefficients() const {
    std::cout << "y = ";
    for (int i = degree; i >= 0; i--) {
      if (i == degree) {
        std::cout << coefficients[i] << " * x^" << i;
      } else if (i > 0) {
        std::cout << " + " << coefficients[i] << " * x^" << i;
      } else {
        std::cout << " + " << coefficients[i];
      }
    }
    std::cout << std::endl;
  }

  double getRMSE(const std::vector<double> &x, const std::vector<double> &y) {
    // Расчет среднеквадратичной ошибки
    double rmse = 0.0;
    for (size_t i = 0; i < x.size(); i++) {
      double error = 100 * (predict(x[i]) - y[i]) / y[i];
      rmse += error * error;
    }
    rmse = 2 * pow(rmse / x.size(), 0.5);
    return rmse;
  }

  const std::vector<double> &getCoefficients() const { return coefficients; }
};

class GBChannel {

public:
  //----- Параметры из конфигурации режима необходимые для описания функции

  // Номинальная частота вращения, об/мин
  gpaReal nom_omega = 0;
  gpaReal nom_m_dot = 0;
  gpaReal omega_coef_A = 0;
  gpaReal omega_coef_B = 0;
  vector<gpaReal> delta_P_Points = {0, 0, 0, 0, 0};
  vector<gpaReal> coef_approx;

  // Точки для ручного ввода напорной хар-ки
  vector<gpaReal> m_Dot_Points = {0, 0, 0, 0, 0};
  vector<gpaReal> pressure_Points = {0, 0, 0, 0, 0};

  gpaReal const_pressure_on_one_port = 0.0;

  //++++ Вспомогательные функции

  // Находит максимум
  gpaReal max(vector<double> x) {
    gpaReal max = 0;
    for (size_t i = 0; i < x.size(); i++) {
      if (x[i] > max) {
        max = x[i];
      }
    }

    return max;
  }

  // Находит минимум
  gpaReal min(vector<double> x) {
    gpaReal min = 1000;
    for (size_t i = 0; i < x.size(); i++) {
      if (x[i] < min) {
        min = x[i];
      }
    }

    return min;
  }

  // Функция округления
  gpaReal myRound(gpaReal x, gpaReal n) {
    return round(x * pow(10, n)) / pow(10, n);
  }

  //++++ Вспомогательные функции

  //+++++++++++++ Модификация данных режимов

  // Функция сигмойда
  gpaReal sigmoid(gpaReal x) { return 1.0 / (1.0 + std::exp(-x)); }

  // Расчет перепада давления
  void get_Approx_DeltaP_VS_m_Dot() {

    // Очистка матриц коэффиентов
    coef_approx.clear();

    calc_deltaP_points();

    // Аппроксимация полиномом 2-й степени левой части кривых
    PolynomialLeastSquares plsL;
    plsL.degree = 3;
    // апрроксимация
    plsL.fit(m_Dot_Points, delta_P_Points);
    coef_approx = plsL.coefficients;
  }

  gpaReal buildPolinom(vector<vector<gpaReal>> cM, gpaReal fr, gpaReal mf,
                       gpaReal m, gpaReal n) {
    gpaReal sum = 0;
    for (size_t i = 0; i < cM.size(); i++) {
      for (size_t j = 0; j < cM[0].size(); j++) {
        sum += cM[i][j] * pow(fr, j + m) * pow(mf, i + n);
      }
    }
    return sum;
  }

  gpaReal buildPolinomOneVar(vector<gpaReal> cM, gpaReal x) {
    gpaReal sum = 0;
    for (size_t i = 0; i < cM.size(); i++) {
      sum += cM[i] * pow(x, i);
    }
    return sum;
  }

  void calc_deltaP_points() {
    for (size_t i = 0; i < pressure_Points.size(); i++) {
      delta_P_Points[i] = const_pressure_on_one_port - pressure_Points[i];
    }
  }

  gpaReal getDeltaP(gpaReal omega, gpaReal mf) {
    // mf = volflow
    gpaReal relOmega = (omega - nom_omega) / nom_omega;
    return buildPolinomOneVar(coef_approx, mf) *
           (1 + omega_coef_A * relOmega + omega_coef_B * pow(relOmega, 2));
  }
};

class regimeParametricCurve {

public:
  // Режим
  string regime_name;
  // Ордината функции (давление или мощность)
  string regime_Par;
  // Ступень
  string regime_stage;

  // Директория базы данных
  string dbWay;
  // Директория матриц аппроксимации функции
  string wayCaseFiles;

  //----- Параметры из конфигурации режима необходимые для описания функции

  // Номинальная частота вращения
  gpaReal nomOmega;
  // Номинальный расход ступени
  gpaReal m_dot_Nom;
  gpaReal A_omega;
  gpaReal B_omega;
  // Значении функции на входе в ступень для расчета разницы функции
  gpaReal fun_In_exp;
  double omegaDown;
  double omegaUp;
  double mfSplitOmegaDown;
  double mfSplitOmegaUp;

  vector<vector<double>> cMCustomCase_Omega_L;
  vector<vector<double>> cMCustomCase_Omega_R;

  //----- Параметры из конфигурации режима необходимые для описания функции

  // Набор переменных для добавления новых режимов
  vector<vector<double>> dbCaseCurvePoints;
  vector<double> omegaCurves;
  vector<double> mfSplit;
  vector<vector<double>> cMCustomCase_L;
  vector<vector<double>> cMCustomCase_R;
  vector<double> db_case_MDot_L;
  vector<double> db_case_POut_L;
  vector<double> db_case_MDot_R;
  vector<double> db_case_POut_R;
  vector<double> coefListApproxByMF;
  int amountOmega;
  // Набор переменных для добавления новых режимов

  //++++ Работа с файлами

  // Функция загрузки матриц из csv файла
  vector<vector<double>> loadMatrixFromcsvFile(string way, string nameFile) {
    vector<vector<double>> fileMatrix;
    ifstream file; // A CLASS OF THE ifstream LIB ALLOWING FILES TO BE READ

    file.open(way + nameFile); // OPEN THE CSV FILE
    string line;

    //  Чтение файла построчно
    while (getline(file, line)) {
      vector<double> row;
      stringstream ss(line);
      string cell;

      // Разбиваем строку на ячейки по запятой
      while (getline(ss, cell, ',')) {
        row.push_back(stod(cell));
      }

      if (!row.empty()) {
        fileMatrix.push_back(row);
      }
    }

    file.close();

    return fileMatrix;
  }

  // Запись матрицы в CSV файл
  bool writeMatrixToCSV(const vector<vector<double>> &matrix,
                        const string &filename, char delimiter = ',',
                        int precision = 3, bool includeHeaders = false,
                        const vector<string> &rowHeaders = {},
                        const vector<string> &colHeaders = {}) {

    ofstream file(filename);

    if (!file.is_open()) {
      cerr << "Ошибка: не удалось открыть файл " << filename << " для записи"
           << endl;
      return false;
    }

    // Устанавливаем точность вывода
    file << scientific << setprecision(precision);

    int rows = matrix.size();
    if (rows == 0) {
      cerr << "Ошибка: пустая матрица" << endl;
      file.close();
      return false;
    }

    int cols = matrix[0].size();

    // Проверка корректности матрицы (все строки одинаковой длины)
    for (int i = 1; i < rows; i++) {
      if (matrix[i].size() != static_cast<size_t>(cols)) {
        cerr << "Ошибка: строки матрицы имеют разную длину" << endl;
        file.close();
        return false;
      }
    }

    // Записываем заголовки столбцов (если нужно)
    if (includeHeaders && !colHeaders.empty()) {
      // Если есть заголовки строк, первая ячейка пустая
      if (!rowHeaders.empty()) {
        file << delimiter;
      }

      // Записываем заголовки столбцов
      for (int j = 0; j < cols; j++) {
        if (j < static_cast<int>(colHeaders.size())) {
          // Если в заголовках есть запятые, заключаем в кавычки
          if (colHeaders[j].find(delimiter) != string::npos) {
            file << "\"" << colHeaders[j] << "\"";
          } else {
            file << colHeaders[j];
          }
        } else {
          file << "Column_" << (j + 1);
        }

        if (j < cols - 1) {
          file << delimiter;
        }
      }
      file << endl;
    }

    // Записываем данные матрицы
    for (int i = 0; i < rows; i++) {
      // Заголовок строки (если есть)
      if (includeHeaders && !rowHeaders.empty()) {
        if (i < static_cast<int>(rowHeaders.size())) {
          // Если в заголовках есть запятые, заключаем в кавычки
          if (rowHeaders[i].find(delimiter) != string::npos) {
            file << "\"" << rowHeaders[i] << "\"";
          } else {
            file << rowHeaders[i];
          }
        } else {
          file << "Row_" << (i + 1);
        }
        file << delimiter;
      }

      // Элементы строки матрицы
      for (int j = 0; j < cols; j++) {
        file << matrix[i][j];
        if (j < cols - 1) {
          file << delimiter;
        }
      }
      file << endl;
    }

    file.close();

    if (file.fail()) {
      cerr << "Ошибка при записи в файл" << endl;
      return false;
    }

    return true;
  }

  // Проверка существования директории (кросс-платформенная)
  bool directoryExists(const string &path) {
    return fs::exists(path) && fs::is_directory(path);
  }

  // Создание директории (кросс-платформенная)
  bool createDirectory(const string &path) {
    try {
      return fs::create_directory(path);
    } catch (const fs::filesystem_error &e) {
      cerr << "Ошибка при создании директории: " << e.what() << endl;
      return false;
    }
  }

  //++++ Работа с файлами

  //++++ Вспомогательные функции

  // Находит максимум
  gpaReal max(vector<double> x) {
    gpaReal max = 0;
    for (size_t i = 0; i < x.size(); i++) {
      if (x[i] > max) {
        max = x[i];
      }
    }

    return max;
  }

  // Находит минимум
  gpaReal min(vector<double> x) {
    gpaReal min = 1000;
    for (size_t i = 0; i < x.size(); i++) {
      if (x[i] < min) {
        min = x[i];
      }
    }

    return min;
  }

  // Функция округления
  gpaReal myRound(gpaReal x, gpaReal n) {
    return round(x * pow(10, n)) / pow(10, n);
  }

  // Функция, собирающая полиномиальную функцию от двух аргументов и выдающая
  // значение ее в соответсвующей точке
  gpaReal predictFun(vector<vector<double>> cM, gpaReal fr, gpaReal mf) {
    gpaReal sum = 0;
    for (size_t i = 0; i < cM.size(); i++) {
      for (size_t j = 0; j < cM[i].size(); j++) {
        sum += cM[i][j] * pow(fr, j) * pow(mf, i);
      }
    }
    return sum;
  }

  //++++ Вспомогательные функции

  //+++++++++++++ Загрузка данных режимов

  void loadCaseCoefFromPCMemory() {

    vector<gpaReal> db_case_pars = {0, 0, 0, 0, 0, 0, 0, 0, 0};

    if (regime_name == "100") {

      db_case_pars = {7.99,
                      2.595,
                      107.24331308607495,
                      149.36737319981313,
                      176.1066615621627,
                      -214.9678768745072,
                      0.05649092344119973,
                      -151.25224940805083,
                      0.059774796106287845};

      if (regime_stage == "TES") {
        cMCustomCase_Omega_L = {{5.232e+01, -1.156e-02, 6.101e-07},
                                {-9.708e-02, 3.419e-05, -2.164e-09},
                                {-6.286e-05, -1.124e-08, 1.389e-12}};
        cMCustomCase_Omega_R = {{5.095e+00, -2.039e-04, -8.806e-09},
                                {1.981e-02, -3.071e-06, 1.382e-10}};
      } else {
        cMCustomCase_Omega_L = {{5.169e+01, -1.197e-02, 6.435e-07},
                                {-5.480e-02, 2.439e-05, -1.619e-09},
                                {-6.999e-05, -1.375e-09, 5.840e-13}};
        cMCustomCase_Omega_R = {{8.863e+00, -9.008e-04, 2.961e-08},
                                {1.478e-03, 3.485e-07, -3.389e-11}};
      }
    }

    if (regime_stage == "TES") {
      fun_In_exp = db_case_pars[0];
      m_dot_Nom = db_case_pars[2];
      nomOmega = db_case_pars[4];
      A_omega = db_case_pars[5];
      B_omega = db_case_pars[6];
    } else {
      fun_In_exp = db_case_pars[1];
      m_dot_Nom = db_case_pars[3];
      nomOmega = db_case_pars[4];
      A_omega = db_case_pars[7];
      B_omega = db_case_pars[8];
    }
  }

  // Загрузить матрицы коэффициентов для одной области
  std::vector<std::vector<double>> loadCaseCoef(string side) {
    wayCaseFiles = dbWay + regime_name + "\\";
    gpaString nameImport_CM = "case" + regime_name + "Coef" + regime_Par +
                              regime_stage + side + ".csv";

    return loadMatrixFromcsvFile(wayCaseFiles, nameImport_CM);
  }

  // Загрузить матрицы коэффициентов для обоих областей
  void loadCaseCoefALL() {
    cMCustomCase_Omega_L = loadCaseCoef("L");
    cMCustomCase_Omega_R = loadCaseCoef("R");
  }

  // Загрузить точки кривых, соотвестветсвующих разным частотам
  void loadDBCaseCurvePoints() {
    string nameFileWithPoints = "db" + regime_name + "CaseCurvePoints" +
                                regime_Par + regime_stage + ".csv";

    dbCaseCurvePoints = loadMatrixFromcsvFile(dbWay, nameFileWithPoints);
  }

  //+++++++++++++ Загрузка данных режимов

  //+++++++++++++ Модификация данных режимов

  // Вычисление расходов, по которым разделяются кривые
  void getmfSplit() {
    mfSplit.clear();
    for (int omegaI = 0; omegaI < amountOmega; omegaI++) {
      mfSplit.push_back(0);
    }

    mfSplit[0] = mfSplitOmegaDown;
    mfSplit[amountOmega - 1] = mfSplitOmegaUp;

    for (int omegaI = 1; omegaI < amountOmega - 1; omegaI++) {

      mfSplit[omegaI] =
          mfSplitOmegaUp + (omegaUp - omegaCurves[omegaI]) /
                               (omegaUp - omegaDown) *
                               (mfSplitOmegaDown - mfSplitOmegaUp);
    }
  }

  // Вывод расходов, по которым разделяются кривые
  void showSplitPoints() {
    int amountOmega = omegaCurves.size();
    for (int omegaI = 0; omegaI < amountOmega; omegaI++) {
      std::cout << "Omega -> " << omegaCurves[omegaI] << " | "
                << mfSplit[omegaI] << std::endl;
    }
  }

  void getApproximationFunOfMF() {
    // Очистка матриц коэффиентов
    cMCustomCase_R.clear();
    cMCustomCase_L.clear();

    for (size_t omegaI = 0; omegaI < 4; omegaI++) {
      // Очистка векторов координат кривой
      db_case_MDot_L.clear();
      db_case_POut_L.clear();

      // взял точки в левой области текущей кривой
      for (size_t iPs = 0; iPs < dbCaseCurvePoints[2 * omegaI + 1].size();
           iPs++) {
        double mfCur = dbCaseCurvePoints[2 * omegaI + 1][iPs];
        if (mfCur < mfSplit[omegaI]) {
          db_case_MDot_L.push_back(mfCur);
          db_case_POut_L.push_back(dbCaseCurvePoints[2 * (omegaI + 1)][iPs]);
        }
      }

      // Аппроксимация полиномом 2-й степени левой части кривых
      PolynomialLeastSquares plsL;
      plsL.degree = 2;
      // апрроксимация
      plsL.fit(db_case_MDot_L, db_case_POut_L);
      cMCustomCase_L.push_back(plsL.coefficients);
    }

    for (size_t omegaI = 0; omegaI < 4; omegaI++) {
      // Очистка векторов координат кривой
      db_case_MDot_R.clear();
      db_case_POut_R.clear();

      // Аппроксимация полиномом 1-й степени правых частей функций
      PolynomialLeastSquares plsR;
      plsR.degree = 1;

      // взял точки в правой области текущей кривой
      for (size_t iPs = 0; iPs < dbCaseCurvePoints[2 * omegaI + 1].size();
           iPs++) {
        double mfCur = dbCaseCurvePoints[2 * omegaI + 1][iPs];
        if (mfCur >= mfSplit[omegaI]) {
          db_case_MDot_R.push_back(mfCur);
          db_case_POut_R.push_back(dbCaseCurvePoints[2 * (omegaI + 1)][iPs]);
        }
      }

      // апрроксимация
      plsR.fit(db_case_MDot_R, db_case_POut_R);
      cMCustomCase_R.push_back(plsR.coefficients);
    }
  }

  void getApproximationCoefFunOfOmega() {

    // Очистка матрицы коэффициентов аппроксимации
    cMCustomCase_Omega_L.clear();
    cMCustomCase_Omega_R.clear();

    // Аппроксимация полиномом 2-й степени
    PolynomialLeastSquares plsOmega(2);

    // рассмтариваем поочереди зависимости коэффициентов в слогаемых  с массовым
    // расходом в стпени coefI
    for (size_t coefI = 0; coefI < 3; coefI++) {
      // очистка вектора значений коэффициента конкретного слогаемого с массовым
      // расходом
      coefListApproxByMF.clear();

      // получение вектора значений коэффициента конкретного слогаемого с
      // массовым расходом
      for (size_t omegaI = 0; omegaI < 4; omegaI++) {
        coefListApproxByMF.push_back(cMCustomCase_L[omegaI][coefI]);
      }

      // аппроксимация
      plsOmega.fit(omegaCurves, coefListApproxByMF);
      cMCustomCase_Omega_L.push_back(plsOmega.coefficients);
    }

    for (size_t coefI = 0; coefI < 2; coefI++) {
      coefListApproxByMF.clear();

      for (size_t omegaI = 0; omegaI < 4; omegaI++) {
        coefListApproxByMF.push_back(cMCustomCase_R[omegaI][coefI]);
      }

      plsOmega.fit(omegaCurves, coefListApproxByMF);
      cMCustomCase_Omega_R.push_back(plsOmega.coefficients);
    }
  }

  gpaReal getErrorFullFun() {
    gpaReal summ = 0;
    gpaReal nPoints = 0;
    for (size_t omegaI = 0; omegaI < 4; omegaI++) {
      for (size_t iPs = 0; iPs < dbCaseCurvePoints[2 * omegaI + 1].size();
           iPs++) {
        double mfCur = dbCaseCurvePoints[2 * omegaI + 1][iPs];
        double poutCur = dbCaseCurvePoints[2 * (omegaI + 1)][iPs];

        summ +=
            pow(100 * (poutCur - predictFunFull(omegaCurves[omegaI], mfCur)) /
                    poutCur,
                2);
        nPoints += 1;
      }
    }
    return 2 * pow(summ / nPoints, 0.5);
  }

  void getApproxNewCase() {
    omegaCurves = dbCaseCurvePoints[0];
    amountOmega = omegaCurves.size();
    omegaDown = omegaCurves[0];
    omegaUp = omegaCurves[amountOmega - 1];

    double bc1 = min(dbCaseCurvePoints[1]);
    double bc2 = max(dbCaseCurvePoints[1]);
    double bc3 = min(dbCaseCurvePoints[dbCaseCurvePoints.size() - 2]);
    double bc4 = max(dbCaseCurvePoints[dbCaseCurvePoints.size() - 2]);

    double mdotDown_opt_split_Start = (bc1 + bc2) / 2; // 441.9;
    double mdotUp_opt_split_Start = (bc3 + bc4) / 2;   // 306;
    double partDelta = 0.8;
    double nStepDown = 20;
    double nStepUp = 20;

    double mdotDown_opt_split;
    double mdotUp_opt_split;

    double error_opt_split = 100;

    double rangeDownL_Lim =
        mdotDown_opt_split_Start - partDelta * (bc2 - bc1) / 2;
    double rangeDownR_Lim =
        mdotDown_opt_split_Start + partDelta * (bc2 - bc1) / 2;
    double stepDown = partDelta * (bc2 - bc1) / nStepDown;

    double rangeUpL_Lim = mdotUp_opt_split_Start - partDelta * (bc4 - bc3) / 2;
    double rangeUpR_Lim = mdotUp_opt_split_Start + partDelta * (bc4 - bc3) / 2;
    double stepUp = partDelta * (bc4 - bc3) / nStepUp;

    double rangeDownL = rangeDownL_Lim;
    double rangeDownR = rangeDownR_Lim;
    double rangeUpL = rangeUpL_Lim;
    double rangeUpR = rangeUpR_Lim;

    vector<double> errorEpoch;

    for (mfSplitOmegaDown = rangeDownL; mfSplitOmegaDown < rangeDownR;
         mfSplitOmegaDown += stepDown) {
      for (mfSplitOmegaUp = rangeUpL; mfSplitOmegaUp < rangeUpR;
           mfSplitOmegaUp += stepUp) {

        getmfSplit();
        getApproximationFunOfMF();
        // showcMCustomCase();
        getApproximationCoefFunOfOmega();
        // showcMCustomCase_Omega();

        gpaReal curErr = getErrorFullFun();

        if (curErr < error_opt_split) {
          mdotDown_opt_split = mfSplitOmegaDown;
          mdotUp_opt_split = mfSplitOmegaUp;
          error_opt_split = curErr;

          errorEpoch.push_back(curErr);
        }
      }
    }

    // for (size_t epoch = 0; epoch < 3; epoch++)
    // {

    //     //Уменьшили зону расчета вокруг нового центра, а также шаг изменения
    //     расходо, по которыи делим partDelta /= 2; stepDown  /= 2; stepUp /=
    //     2;

    //     //Вычисление границ новой области параметров
    //     rangeDownL = mdotDown_opt_split-partDelta*(bc2-bc1)/2;
    //     rangeDownR = mdotDown_opt_split+partDelta*(bc2-bc1)/2;
    //     rangeUpL = mdotUp_opt_split-partDelta*(bc4-bc3)/2;
    //     rangeUpR = mdotUp_opt_split+partDelta*(bc4-bc3)/2;

    //     // Коррекция области, чтобы были точки в правой и левых областях при
    //     делении rangeDownL = rangeDownL<rangeDownL_Lim?
    //     rangeDownL_Lim:rangeDownL; rangeDownR = rangeDownR>rangeDownR_Lim?
    //     rangeDownR_Lim:rangeDownR; rangeUpL = rangeUpL<rangeUpL_Lim?
    //     rangeUpL_Lim:rangeUpL; rangeUpR = rangeUpR>rangeUpR_Lim?
    //     rangeUpR_Lim:rangeUpR;
    // }

    B_omega = (mdotDown_opt_split - mdotUp_opt_split) / (omegaDown - omegaUp);
    A_omega = mdotUp_opt_split - omegaUp * B_omega;

    // vector <double> coefs_pls_Split_mf_VS_omega;

    // // Аппроксимация линии разделения точек 1-й степени
    // PolynomialLeastSquares pls_Split_mf_VS_omega(1);
    // pls_Split_mf_VS_omega.fit(omegaCurves, mfSplit);
    // coefs_pls_Split_mf_VS_omega = pls_Split_mf_VS_omega.coefficients;
  }

  void doApproxCurvesOfNewRegime() {

    wayCaseFiles = dbWay + regime_name + "\\";

    if (!directoryExists(wayCaseFiles)) {
      createDirectory(wayCaseFiles);
    }

    loadDBCaseCurvePoints();
    getApproxNewCase();
    exportMatrixCoef(cMCustomCase_Omega_L, "L");
    exportMatrixCoef(cMCustomCase_Omega_R, "R");
  }

  void exportMatrixCoef(vector<vector<double>> cM, string regime_side) {
    gpaString nameExport_CM = "case" + regime_name + "Coef" + regime_Par +
                              regime_stage + regime_side + ".csv";
  }

  //+++++++++++++ Модификация данных режимов

  // Функция сигмойда
  gpaReal sigmoid(gpaReal x) { return 1.0 / (1.0 + std::exp(-x)); }

  // Вычисляет значение функции, которая аппроксимрует набор кривых
  gpaReal predictFunFull(gpaReal omega, gpaReal mf) {
    gpaReal msplit = A_omega + B_omega * omega;

    gpaReal smFactor = sigmoid(1 * (msplit - mf));
    gpaReal lFun = predictFun(cMCustomCase_Omega_L, omega, mf);
    gpaReal rFun = predictFun(cMCustomCase_Omega_R, omega, mf);

    return lFun * smFactor + (1 - smFactor) * rFun;
  }
};

class gpaTDBaseVerSimpleElement : public gpaFlowElement {
public:
  // не убирать
  gpaTDBaseVerSimpleElement(const gpaParentLink *link)
      : m_gasEnthalpy(0), m_liquidEnthalpy(0), m_liquidFlowRate(0),
        m_temperature(0) {

    setMixCircuit(new gpaElementMixCircuit(this, GPA_ELEM_CIRCUIT_1));
    m_d = 0.5;
    m_l = 2.0;
    m_dh = 0.3;
    m_nBends = 2;
    m_eps = 0.0001;
    m_Tenv = 293.15;
    m_heatLayers.push_back(gpaHeatLayer{0.02, 7800, 16.0, 460});
    m_alpha_in_pipe = m_alpha_out_pipe = m_alpha_in_gas = m_alpha_out_gas =
        100.0;
    calcThermalParams();
  }
  gpaTDBaseVerSimpleElement(const gpaTDBaseVerSimpleElement &m_heatPipes) {
    m_gasEnthalpy = m_heatPipes.m_gasEnthalpy;
    m_liquidEnthalpy = m_heatPipes.m_liquidEnthalpy;
    m_liquidFlowRate = m_heatPipes.m_liquidFlowRate;
    m_temperature = m_heatPipes.m_temperature;
    m_d = m_heatPipes.m_d;
    m_l = m_heatPipes.m_l;
    m_dh = m_heatPipes.m_dh;
    m_nBends = m_heatPipes.m_nBends;
    m_eps = m_heatPipes.m_eps;
    m_Tenv = m_heatPipes.m_Tenv;
    m_heatLayers = m_heatPipes.m_heatLayers;

    m_alpha_in_pipe = m_heatPipes.m_alpha_in_pipe;
    m_alpha_out_pipe = m_heatPipes.m_alpha_out_pipe;
    m_alpha_in_gas = m_heatPipes.m_alpha_in_gas;
    m_alpha_out_gas = m_heatPipes.m_alpha_out_gas;
    calcThermalParams();
  }
  virtual gpaTDBaseVerSimpleElement *copy() const override {
    return new gpaTDBaseVerSimpleElement(*this);
  }
  // не убирать

  virtual gpaUInt getMinNumMixPorts(gpaUInt index) const override {
    return getDeviceMinNumMixPorts(index);
  }
  static gpaUInt getDeviceMinNumMixPorts(gpaUInt index) {
    if (index == GPA_ELEM_CIRCUIT_0) {
      return 2;
    }
    if (index == GPA_ELEM_CIRCUIT_1) {
      return 2;
    }
    return 0;
  }
  static gpaUInt getDeviceNumMixCircuits() { return 2; }
  virtual gpaUInt getNumMixCircuits() const override { return 2; }
  virtual gpaUInt getMaxNumMixPorts(gpaUInt index) const override {
    return getDeviceMaxNumMixPorts(index);
  }
  static gpaUInt getDeviceMaxNumMixPorts(gpaUInt index) {
    if (index == GPA_ELEM_CIRCUIT_0) {
      return 2;
    }
    if (index == GPA_ELEM_CIRCUIT_1) {
      return 2;
    }
    return 0;
  }

  //+++++++++++ Инициализация переменных

  // Кол-во переменных
  gpaUInt getNumVariables() const override { return 1; }

  // Нумирация переменных
  enum {
    OMEGA = 0,
  };

  void fillVarNames(gpaStringVector &varNames) const override {}

  // Задаем начальные условия для переменнных
  gpaResult initVariables(gpaVector &variables) const override {
    variables[OMEGA] = omegaInit / 60; //;

    return GPA_RESULT_OK;
  }

  //++++++++++++ Инициализация переменных

  //+++++++++++++ Инициализация остального

  // Установка параметров режима из файла
  void setCasePars(gpaString name_case) {
    gpaReal db_case_pars[9];
    gpaInt i = 0;
    ifstream dataPars; // A CLASS OF THE ifstream LIB ALLOWING FILES TO BE READ
    dataPars.open(dataBaseWay + "case" + name_case +
                  "Pars.csv"); // OPEN THE CSV FILE
    while (dataPars.good()) {  // WHILE SOMETHING IS IN THE FILE KEEP READING IT
      string line;             // DEFINE A STRING
      getline(dataPars, line, ','); // GRAB THE ELEMENT UNTIL THE TEXT SEES A COMMA
      db_case_pars[i] = stod(line);
      i += 1;
    }

    curve_Pout_TES.fun_In_exp = db_case_pars[0];
    curve_Pout_CS.fun_In_exp = db_case_pars[1];
    curve_Pout_TES.m_dot_Nom = db_case_pars[2];
    curve_Pout_CS.m_dot_Nom = db_case_pars[3];
    curve_Pout_TES.nomOmega = db_case_pars[4];
    curve_Pout_CS.nomOmega = db_case_pars[4];
    curve_Pout_TES.A_omega = db_case_pars[5];
    curve_Pout_TES.B_omega = db_case_pars[6];
    curve_Pout_CS.A_omega = db_case_pars[7];
    curve_Pout_CS.B_omega = db_case_pars[8];
  }

  //+++++++++++++ Функции для работы с файлами

  //+++++++++++++ Функции для работы с файлами

  void testIni() {
    curve_Pout_TES.loadCaseCoefFromPCMemory();
    curve_Pout_CS.loadCaseCoefFromPCMemory();

    gpaReal pOut_TES = curve_Pout_TES.predictFunFull(10500, 350);
    gpaReal pOut_CS = curve_Pout_CS.predictFunFull(10500, 350);

    curve_Pout_TES.doApproxCurvesOfNewRegime();
    curve_Pout_CS.doApproxCurvesOfNewRegime();

    pOut_TES = curve_Pout_TES.predictFunFull(10500, 350);
    pOut_CS = curve_Pout_CS.predictFunFull(10500, 350);

    // delInt_TES.isHandEnter = delInt_CS.isHandEnter= 1;
    // delInt_TES.setPoutVSmdotAndomegaPointsAndDoDelTriang();
    // delInt_CS.setPoutVSmdotAndomegaPointsAndDoDelTriang();

    while (1 > 0) {
      /* code */
    }
  }

  // Главная функция инициалзации
  gpaResult initialize() override {

    dataBaseWay = fs::current_path().string() + "\\libs\\dbTDA\\";

    initFlows();
    initMedium();

    // exportCurrentBiblProps(dataBaseWay);

    curve_Pout_TES.m_dot_Nom = 373 * 1000 / 3600; // one for all

    curve_Pout_TES.dbWay = curve_Pout_CS.dbWay = dataBaseWay;
    curve_Pout_TES.regime_name = curve_Pout_CS.regime_name = name_case;
    curve_Pout_TES.regime_Par = curve_Pout_CS.regime_Par = "Pout";
    curve_Pout_TES.regime_stage = "TES";
    curve_Pout_CS.regime_stage = "CS";

    // isNeedApproxGDC=1;
    delInt_TES.name_case = delInt_CS.name_case = name_case;

    // testIni();

    // load  curves from memory
    if (isNeedApproxCurvesNewRegime == 1) {
      curve_Pout_TES.loadCaseCoefFromPCMemory();
      curve_Pout_CS.loadCaseCoefFromPCMemory();
    }

    // load user points and approx use one curve with omega nom
    if (isNeedApproxCurvesNewRegime == 2) {

      p_curve_TES.get_Approx_DeltaP_VS_m_Dot();
      p_curve_CS.get_Approx_DeltaP_VS_m_Dot();
    }

    if (isNeedApproxCurvesNewRegime == 3) {
      delInt_TES.isHandEnter = delInt_CS.isHandEnter = 1;
      delInt_TES.setPoutVSmdotAndomegaPointsAndDoDelTriang();
      delInt_CS.setPoutVSmdotAndomegaPointsAndDoDelTriang();

      delInt_TES.getPoutValueByCurrentOmegaAndMdot(9200, 305);
      delInt_TES.getPoutValueByCurrentOmegaAndMdot(10000, 347);
      delInt_TES.getPoutValueByCurrentOmegaAndMdot(11000, 401);
      delInt_TES.getPoutValueByCurrentOmegaAndMdot(11500, 433);

      delInt_CS.getPoutValueByCurrentOmegaAndMdot(9200, 400);
      delInt_CS.getPoutValueByCurrentOmegaAndMdot(10000, 450);
      delInt_CS.getPoutValueByCurrentOmegaAndMdot(11000, 500);
      delInt_CS.getPoutValueByCurrentOmegaAndMdot(11500, 535);

      delInt_CS.getPoutValueByCurrentOmegaAndMdot(9200, 500);
      delInt_CS.getPoutValueByCurrentOmegaAndMdot(10000, 500);
      delInt_CS.getPoutValueByCurrentOmegaAndMdot(11000, 500);
      delInt_CS.getPoutValueByCurrentOmegaAndMdot(11500, 535);
    }

    // load test points and approx
    if (isNeedApproxCurvesNewRegime == 4) {
      delInt_TES.isHandEnter = delInt_CS.isHandEnter = 0;
      delInt_TES.setPoutVSmdotAndomegaPointsAndDoDelTriang();
      delInt_CS.setPoutVSmdotAndomegaPointsAndDoDelTriang();

      delInt_TES.getPoutValueByCurrentOmegaAndMdot(9200, 305);
      delInt_TES.getPoutValueByCurrentOmegaAndMdot(10000, 347);
      delInt_TES.getPoutValueByCurrentOmegaAndMdot(11000, 401);
      delInt_TES.getPoutValueByCurrentOmegaAndMdot(11500, 433);

      delInt_CS.getPoutValueByCurrentOmegaAndMdot(9200, 400);
      delInt_CS.getPoutValueByCurrentOmegaAndMdot(10000, 450);
      delInt_CS.getPoutValueByCurrentOmegaAndMdot(11000, 500);
      delInt_CS.getPoutValueByCurrentOmegaAndMdot(11500, 535);

      delInt_CS.getPoutValueByCurrentOmegaAndMdot(9200, 500);
      delInt_CS.getPoutValueByCurrentOmegaAndMdot(10000, 500);
      delInt_CS.getPoutValueByCurrentOmegaAndMdot(11000, 500);
      delInt_CS.getPoutValueByCurrentOmegaAndMdot(11500, 535);
    }

    if (isNeedApproxCurvesNewRegime == 5) {
      setCasePars(name_case);
      curve_Pout_TES.doApproxCurvesOfNewRegime();
      curve_Pout_CS.doApproxCurvesOfNewRegime();
    }

    //  while (1>0)
    //     {
    //         /* code */
    //     }
    // if(isNeedApproxCurvesNewRegime==5)
    // {
    //     setCasePars(name_case);
    //     curve_Pout_TES.loadCaseCoefALL(0);
    //     curve_Pout_CS.loadCaseCoefALL(0);
    // }

    return GPA_RESULT_OK;
  }

  gpaResult fillMassMatrix(gpaUInt refRow, gpaUInt refCol) const override {
    gpaResult res = setMassMatrCoef(refRow, refCol, 1.0);
    if (res != GPA_RESULT_OK)
      return res;
    return GPA_RESULT_OK;
  }

  // Инициализация среды
  void initMedium() {
    m_medium_TES = inlet_TES->getStreamMedium()->copyTo(asOwner());
    m_medium_CS = inlet_CS->getStreamMedium()->copyTo(asOwner());
  }

  // Запись матрицы в CSV файл
  bool writeMatrixToCSV(const vector<vector<double>> &matrix,
                        const string &filename, char delimiter = ',',
                        int precision = 3, bool includeHeaders = false,
                        const vector<string> &rowHeaders = {},
                        const vector<string> &colHeaders = {}) {

    ofstream file(filename);

    if (!file.is_open()) {
      cerr << "Ошибка: не удалось открыть файл " << filename << " для записи"
           << endl;
      return false;
    }

    // Устанавливаем точность вывода
    file << scientific << setprecision(precision);

    int rows = matrix.size();
    if (rows == 0) {
      cerr << "Ошибка: пустая матрица" << endl;
      file.close();
      return false;
    }

    int cols = matrix[0].size();

    // Проверка корректности матрицы (все строки одинаковой длины)
    for (int i = 1; i < rows; i++) {
      if (matrix[i].size() != static_cast<size_t>(cols)) {
        cerr << "Ошибка: строки матрицы имеют разную длину" << endl;
        file.close();
        return false;
      }
    }

    // Записываем заголовки столбцов (если нужно)
    if (includeHeaders && !colHeaders.empty()) {
      // Если есть заголовки строк, первая ячейка пустая
      if (!rowHeaders.empty()) {
        file << delimiter;
      }

      // Записываем заголовки столбцов
      for (int j = 0; j < cols; j++) {
        if (j < static_cast<int>(colHeaders.size())) {
          // Если в заголовках есть запятые, заключаем в кавычки
          if (colHeaders[j].find(delimiter) != string::npos) {
            file << "\"" << colHeaders[j] << "\"";
          } else {
            file << colHeaders[j];
          }
        } else {
          file << "Column_" << (j + 1);
        }

        if (j < cols - 1) {
          file << delimiter;
        }
      }
      file << endl;
    }

    // Записываем данные матрицы
    for (int i = 0; i < rows; i++) {
      // Заголовок строки (если есть)
      if (includeHeaders && !rowHeaders.empty()) {
        if (i < static_cast<int>(rowHeaders.size())) {
          // Если в заголовках есть запятые, заключаем в кавычки
          if (rowHeaders[i].find(delimiter) != string::npos) {
            file << "\"" << rowHeaders[i] << "\"";
          } else {
            file << rowHeaders[i];
          }
        } else {
          file << "Row_" << (i + 1);
        }
        file << delimiter;
      }

      // Элементы строки матрицы
      for (int j = 0; j < cols; j++) {
        file << matrix[i][j];
        if (j < cols - 1) {
          file << delimiter;
        }
      }
      file << endl;
    }

    file.close();

    if (file.fail()) {
      cerr << "Ошибка при записи в файл" << endl;
      return false;
    }

    return true;
  }

  void exportStageBiblProps(string way, string name, vector<double> tR,
                            vector<double> pR, gpaMedium *medium) {
    vector<vector<gpaReal>> parsVST;
    for (gpaReal temp = tR[0]; temp < tR[1]; temp = temp + tR[2]) {
      for (gpaReal pressure = pR[0]; pressure < pR[1];
           pressure = pressure + pR[2]) {
        vector<gpaReal> pars = {0, 0, 0, 0, 0, 0, 0};
        medium->calcFlashPT(pressure, temp, medium->getFractions());
        pars[0] = temp;
        pars[1] = pressure;
        pars[2] = medium->getConductivity();
        pars[3] = medium->getDensity();
        pars[4] = medium->getViscosity();
        pars[5] = medium->getHeatCapacity() / medium->getMolarMass();
        pars[6] = medium->getMolarMass();
        parsVST.push_back(pars);
      }
    }

    gpaString nameExport = way + name + " .csv";
  }

  void exportCurrentBiblProps(string way) {
    vector<vector<double>> testTR = {{-64.63 + 273.15, -4.88 + 273.15, 1},
                                     {16.13 + 273.15, 44.7 + 273.15, 1}};
    vector<vector<double>> testPR = {{2940, 8300, 100}, {2591, 3558, 100}};

    exportStageBiblProps(way, name_case + "_TES", testTR[0], testPR[0],
                         m_medium_TES);
    exportStageBiblProps(way, name_case + "_CS", testTR[1], testPR[1],
                         m_medium_CS);
  }

  // Инициализация потоков
  void initFlows() {
    circuit_TES = getMixCircuit(GPA_ELEM_CIRCUIT_0);
    circuit_CS = getMixCircuit(GPA_ELEM_CIRCUIT_1);

    inlet_TES = circuit_TES->getPort(0);
    out_TES = circuit_TES->getPort(1);
    inlet_CS = circuit_CS->getPort(0);
    out_CS = circuit_CS->getPort(1);
  }

  //+++++++++++++++++ Инициализация остального

  //+++++++++++++++++ Функции, которые будут использоваться на каждой итерации

  //+++ Расчет свойств потоков
  void calcFlowProperties() {

    T_in_TES = inlet_TES->getStreamTemperature();
    T_in_CS = inlet_CS->getStreamTemperature();

    T_out_TES = out_TES->getStreamTemperature();
    T_out_CS = out_CS->getStreamTemperature();

    // Get G&P
    G_in_TES = inlet_TES->getIncomingFlowRate();
    P_in_TES = inlet_TES->getStreamPressure();
    G_in_CS = inlet_CS->getIncomingFlowRate();
    P_in_CS = inlet_CS->getStreamPressure();

    G_out_TES = out_TES->getIncomingFlowRate();
    G_out_CS = out_CS->getIncomingFlowRate();
    P_out_TES = out_TES->getStreamPressure();
    P_out_CS = out_CS->getStreamPressure();

    m_dot_TES = inlet_TES->getIncomingMassRate();
    m_dot_CS = inlet_CS->getIncomingMassRate();
  }
  //+++ Расчет свойств потоков

  //+++ Расчет теплообмена

  // Функция сигмойда
  gpaReal sigmoid(gpaReal x) { return 1.0 / (1.0 + std::exp(-x)); }

  gpaReal buildPolinom3(gpaReal cM[3][3], gpaReal fr, gpaReal mf, gpaReal m,
                        gpaReal n) {
    gpaReal sum = 0;
    for (size_t i = 0; i < 3; i++) {
      for (size_t j = 0; j < 3; j++) {
        sum += cM[i][j] * pow(fr, j + m) * pow(mf, i + n);
      }
    }
    return sum;
  }

  gpaReal buildPolinom2(gpaReal cM[2][3], gpaReal fr, gpaReal mf, gpaReal m,
                        gpaReal n) {
    gpaReal sum = 0;
    for (size_t i = 0; i < 2; i++) {
      for (size_t j = 0; j < 3; j++) {
        sum += cM[i][j] * pow(fr, j + m) * pow(mf, i + n);
      }
    }
    return sum;
  }

  // Расчет перепада давления
  void calcDeltaPress() {
    // omega = m_dot_TES>1?119.83 + 0.338142*m_dot_TES +
    // 0.00557742*pow(m_dot_TES,2) - 0.0000322672*pow(m_dot_TES,3):130;//good

    omegaTarget = 200; // need for work
    gpaReal cM_Omega_By_m_dot_TES[4] = {0.65304, 0.344189, 0.0922534,
                                        -0.0691466};

    if (name_case == "150") {
      omegaTarget = 10930 / 60; // need for work
    }
    if (m_dot_TES > 1) {
      omegaTarget = 0;
      for (size_t i = 0; i < 4; i++) {
        omegaTarget += curve_Pout_TES.nomOmega *
                       (cM_Omega_By_m_dot_TES[i] *
                        pow(m_dot_TES / curve_Pout_TES.m_dot_Nom, i));
      }
    }

    gpaReal fr = omega * 60;
    gpaReal mf = 0;
    gpaReal smFactor = 0;

    gpaReal pOut_TES;
    gpaReal pOut_CS;
    mf = m_dot_TES / 1000 * 3600; // ton/h

    // load  curves from memory
    if (isNeedApproxCurvesNewRegime == 1 || isNeedApproxCurvesNewRegime == 5) {
      pOut_TES = curve_Pout_TES.predictFunFull(fr, mf);
    }

    // load user points and approx//load test points and approx
    if (isNeedApproxCurvesNewRegime == 3 || isNeedApproxCurvesNewRegime == 4) {
      pOut_TES = delInt_TES.getPoutValueByCurrentOmegaAndMdot(fr, mf);
    }

    if (isNeedApproxCurvesNewRegime == 2) {
      deltaP_TES = (10000 - mf + fr) / 100000 * (1 - sigmoid(mf - 10)) +
                   sigmoid(mf - 10) * 1000 * p_curve_TES.getDeltaP(fr, mf);
    } else {
      deltaP_TES = 1000 * (curve_Pout_TES.fun_In_exp - pOut_TES);
    }

    mf = m_dot_CS / 1000 * 3600; // ton/h

    // load  curves from memory
    if (isNeedApproxCurvesNewRegime == 1 || isNeedApproxCurvesNewRegime == 5) {
      pOut_CS = curve_Pout_CS.predictFunFull(fr, mf);
    }

    // load user points and approx//load test points and approx
    if (isNeedApproxCurvesNewRegime == 3 || isNeedApproxCurvesNewRegime == 4) {
      pOut_CS = delInt_CS.getPoutValueByCurrentOmegaAndMdot(fr, mf);
    }

    if (isNeedApproxCurvesNewRegime == 2) {
      deltaP_CS = -(10000 - fr + mf) / 100000 * (1 - sigmoid(mf - 10)) +
                  sigmoid(mf - 10) * 1000 * p_curve_CS.getDeltaP(fr, mf);
    } else {
      deltaP_CS = 1000 * (curve_Pout_CS.fun_In_exp - pOut_CS);
    }
  }

  void calcQ() {
    gpaReal h_in_TES = inlet_TES->getStreamEnthalpy();
    m_medium_TES->calcFlashPT(P_in_TES, T_in_TES, m_medium_TES->getFractions());
    gpaReal S_in_TES = m_medium_TES->getEntropy();
    m_medium_TES->calcFlashPS(P_out_TES, S_in_TES,
                              m_medium_TES->getFractions());
    gpaReal h_tilda_out_TES = m_medium_TES->getEnthalpy();

    gpaReal h_in_CS = inlet_CS->getStreamEnthalpy();
    m_medium_CS->calcFlashPT(P_in_CS, T_in_CS, m_medium_CS->getFractions());
    gpaReal S_in_CS = m_medium_CS->getEntropy();
    m_medium_CS->calcFlashPS(P_out_CS, S_in_CS, m_medium_CS->getFractions());
    gpaReal h_tilda_out_CS = m_medium_CS->getEnthalpy();
    gpaReal rho_tilda_out_CS = m_medium_CS->getDensity();
    gpaReal rho_out_CS = out_CS->getStreamDensity();
    gpaReal rho_in_CS = inlet_CS->getStreamDensity();
    k_out_cs =
        log(P_out_CS / P_in_CS) / log(rho_tilda_out_CS / rho_in_CS); // good
    n_out_cs = log(P_out_CS / P_in_CS) / log(rho_out_CS / rho_in_CS);

    gpaReal polit_eta_CS = 0; // good
    gpaReal polit_eta_CS_coef[4] = {0.55998, 0.585759, -0.119405, -0.233282};

    for (size_t i = 0; i < 4; i++) {
      gpaReal nom_m_dot = isNeedApproxCurvesNewRegime == 1
                              ? curve_Pout_CS.m_dot_Nom
                              : p_curve_CS.nom_m_dot;
      polit_eta_CS += polit_eta_CS_coef[i] * pow(m_dot_TES / nom_m_dot, i);
    }

    gpaReal adiab_eta_CS =
        polit_eta_CS *
        (pow(P_out_CS / P_in_CS, (k_out_cs - 1) / k_out_cs) - 1) /
        (pow(P_out_CS / P_in_CS, (n_out_cs - 1) / n_out_cs) - 1) *
        ((n_out_cs - 1) / n_out_cs) * (k_out_cs / (k_out_cs - 1));

    gpaReal adiab_eta_TES_coef[4] = {0.0755062, 1.70686, -0.992089, 0.0993642};
    gpaReal adiab_eta_TES = 0;

    for (size_t i = 0; i < 4; i++) {
      gpaReal nom_m_dot = isNeedApproxCurvesNewRegime == 1
                              ? curve_Pout_TES.m_dot_Nom
                              : p_curve_TES.nom_m_dot;
      adiab_eta_TES += adiab_eta_TES_coef[i] * pow(m_dot_TES / nom_m_dot, i);
    }

    // Теплообмен
    Delta_H_TES =
        G_in_TES > 0.1
            ? k_delta_H_TES * (h_tilda_out_TES - h_in_TES) * (adiab_eta_TES)
            : 0.1;
    Delta_H_CS = G_in_CS > 0.1 ? k_delta_H_CS * (h_tilda_out_CS - h_in_CS) /
                                     (adiab_eta_CS)
                               : 0.1;

    // Расчет моментов вращения
    Q_TES = G_in_TES * Delta_H_TES * 1000;
    Q_CS = G_in_CS * Delta_H_CS * 1000;

    // Расчет моментов вращения
    momentTES = Q_TES / (omega + 0.001);
    momentCS = Q_CS / (omega + 0.001);
  }

  // Главная функция: полный набор уравнений для "стрелок" и фазового равновесия
  gpaResult calcFuncValues(const gpaConstVector &,
                           const gpaConstVector &variables, gpaVector &values,
                           const gpaSetOfEquations &eqIds) override {

    calcFlowProperties();

    // Переименовал для удобства неизвестые перемеые. Можно потом убрать для
    // ускорения
    omega = variables[OMEGA];
    //++ Пересчет различных переменных

    // Расчет теплообмена

    calcDeltaPress();
    calcQ();

    // Delta_H_CS = -Delta_H_TES;
    //++ Пересчет различных переменных

    //++ Формирование уравнений для невязок

    values[0] = (momentTES + momentCS) / I_shaft;

    // values[0] = -(variables[OMEGA]-omegaTarget)/I_shaft;
    values[1] = P_in_TES - P_out_TES - deltaP_TES;
    values[2] = G_in_TES + G_out_TES;
    values[3] = P_in_CS - P_out_CS - deltaP_CS;
    values[4] = G_in_CS + G_out_CS;

    //++ Формирование уравнений для невязок

    return GPA_RESULT_OK;
  }

  // Невязка по энтальпии
  gpaResult calcEnthalpyFuncValueAt(gpaUInt circIdx, gpaUInt portIdx,
                                    gpaReal enthalpy,
                                    gpaReal &funcValue) const override {
    if (circIdx == GPA_ELEM_CIRCUIT_0) {
      const gpaMixPort *oppPort = getMixPort(GPA_ELEM_CIRCUIT_0, 1 - portIdx);
      if (!oppPort)
        return GPA_ERROR_WRONG_ARGS;
      funcValue =
          enthalpy - oppPort->getStreamMedium()->getEnthalpy() - Delta_H_TES;
      // printf("Enthalpy %d: %f\n", portIdx, funcValue);
      return GPA_RESULT_OK;
    }
    if (circIdx == GPA_ELEM_CIRCUIT_1) {
      const gpaMixPort *oppPort2 = getMixPort(GPA_ELEM_CIRCUIT_1, 1 - portIdx);
      if (!oppPort2)
        return GPA_ERROR_WRONG_ARGS;
      funcValue =
          enthalpy - oppPort2->getStreamMedium()->getEnthalpy() - Delta_H_CS;
      // printf("Enthalpy %d: %f\n", portIdx, funcValue);
      return GPA_RESULT_OK;
    }
    return GPA_ERROR_WRONG_ARGS;
  }

  // Невязка по компонентам — для выходных портов сравниваем с переменными
  // разделителя
  gpaResult calcFractionsFuncValuesAt(gpaUInt circIdx, gpaUInt portIdx,
                                      const gpaConstVector &fractions,
                                      gpaVector &funcValues) const override {
    if (circIdx == GPA_ELEM_CIRCUIT_0) {

      const gpaMixPort *oppPort = getMixCircuit(circIdx)->getPort(1 - portIdx);
      if (!oppPort)
        return GPA_ERROR_WRONG_ARGS;
      const gpaConstVector calcFractions =
          oppPort->getStreamMedium()->getFractions();
      for (gpaUInt i = 0; i < funcValues.size(); ++i)
        funcValues[i] = fractions[i] - calcFractions[i];
      // printf("Fractions %d\n", portIdx);
      //  for (gpaUInt i = 0; i < funcValues.size(); ++i)
      //      printf("%f--", funcValues[i]);
      // printf("\n");
      return GPA_RESULT_OK;
    }

    if (circIdx == GPA_ELEM_CIRCUIT_1) {

      const gpaMixPort *oppPort2 = getMixCircuit(circIdx)->getPort(1 - portIdx);
      ;
      if (!oppPort2)
        return GPA_ERROR_WRONG_ARGS;
      const gpaConstVector calcFractions2 =
          oppPort2->getStreamMedium()->getFractions();
      for (gpaUInt i = 0; i < funcValues.size(); ++i)
        funcValues[i] = fractions[i] - calcFractions2[i];
      // printf("Fractions %d\n", portIdx);
      //  for (gpaUInt i = 0; i < funcValues.size(); ++i)
      //      printf("%f--", funcValues[i]);
      // printf("\n");
      return GPA_RESULT_OK;
    }

    return GPA_ERROR_WRONG_ARGS;
  }

  virtual const gpaString &getTypeName() const override {
    return getDeviceTypeName();
  }
  virtual const gpaString &getDescription() const override {
    return getDeviceDescription();
  }

private:
  gpaElementMixCircuit *circuit_TES;
  gpaElementMixCircuit *circuit_CS;

  void calcThermalParams() {
    gpaReal d = m_d;
    gpaReal l = m_l;
    // PIPE (основная труба)
    m_R_pipe = 0;
    m_A_in_pipe = std::numbers::pi * d * l;
    gpaReal radius_inner = d / 2.0;
    for (const auto &layer : m_heatLayers) {
      gpaReal r1 = radius_inner;
      gpaReal r2 = r1 + layer.thickness;
      m_R_pipe += std::log(r2 / r1) /
                  (2 * std::numbers::pi * layer.heatConductivity * l);
      radius_inner = r2;
    }
    m_A_out_pipe = std::numbers::pi * (2 * radius_inner) * l;

    // GAS (газовая сторона, пусть конструкция аналогична)
    m_R_gas = m_R_pipe;
    m_A_in_gas = m_A_in_pipe;
    m_A_out_gas = m_A_out_pipe;
  }

public:
  delanayInterpolator delInt_TES, delInt_CS;
  GBChannel p_curve_TES, p_curve_CS;

  // Переключатель библиотек
  gpaReal flagMixBibl = 0.0;

  // Параметры геометрии:
  gpaReal m_d = 0.0;       // внутренний диаметр (м)
  gpaReal m_l = 0.0;       // длина аппарата (м)
  gpaReal m_dh = 0.0;      // гидростат. напор (м)
  gpaReal m_nBends = 0.0;  // число колен
  gpaReal m_eps = 0.0;     // шероховатость (м)
  gpaReal m_Tenv = 298.15; // температура окружающей среды (К)

  gpaHeatLayerVector m_heatLayers;

  // PIPE (общая труба)
  gpaReal m_R_pipe = 1.0;
  gpaReal m_A_in = 0.0;
  gpaReal m_A_out = 0.0;
  gpaReal m_A_in_pipe = 0.0;
  gpaReal m_A_out_pipe = 0.0;
  gpaReal m_alpha_in_pipe = 0.0;
  gpaReal m_alpha_out_pipe = 0.0;

  // GAS (газовая)
  gpaReal m_R_gas = 1.0;
  gpaReal m_A_in_gas = 0.0;
  gpaReal m_A_out_gas = 0.0;
  gpaReal m_alpha_in_gas = 0.0;
  gpaReal m_alpha_out_gas = 0.0;
  gpaReal m_wall_diamet1;
  gpaReal m_wall_diamet2;
  gpaReal m_wall_diamet3;
  gpaReal m_hydro_coeff;
  gpaReal m_diametr;
  gpaReal m_wall_conductive1;
  gpaReal m_wall_conductive2;

  // Порты ступеней
  const gpaMixPort *inlet_TES;
  const gpaMixPort *out_TES;
  const gpaMixPort *inlet_CS;
  const gpaMixPort *out_CS;

  gpaReal cM_TES_L[3][3];
  gpaReal cM_TES_R[2][3];
  gpaReal cM_CS_L[3][3];
  gpaReal cM_CS_R[2][3];

  // Частота вращения начальная
  gpaReal omegaInit;
  // Частота вращения текущая
  gpaReal omega;
  // Частота вращения целевая
  gpaReal omegaTarget;

  // Момент инерции вала
  gpaReal I_shaft;

  // Момент ТДС
  gpaReal momentTES;
  // Момент КС
  gpaReal momentCS;

  // Название режима
  gpaString name_case = "100";

  // Теплообмен
  gpaReal k_delta_H_TES;
  gpaReal k_delta_H_CS;
  gpaReal Delta_H_TES; //
  gpaReal Delta_H_CS;  //
  gpaReal Q_TES;
  gpaReal Q_CS;

  // Свойства потоков
  gpaReal P_in_TES;
  gpaReal P_out_TES;
  gpaReal P_in_CS;
  gpaReal P_out_CS;

  // Путь к файлам с параметрами режимов
  string wayCaseFiles;
  gpaString dataBaseWay = "C:\\Users\\workstation777\\Desktop\\MMA\\lib_"
                          "tester\\win64\\libs\\dbTDA\\";

  // 1 - use coefs for approx GDC, 2 - use user points, 3 - use big set of
  // points GDC case 100
  gpaInt isNeedApproxCurvesNewRegime;

  regimeParametricCurve curve_Pout_TES;
  regimeParametricCurve curve_Pout_CS;

  // Показатель адиабаты газа на выходе из канала КС
  gpaReal k_out_cs;
  // Показатель политропы газа на выходе из канала КС
  gpaReal n_out_cs;

  // Перепад давлений по ТДС
  gpaReal deltaP_TES;
  // Перепад давлений по КС
  gpaReal deltaP_CS;

  // Массовый расход газа в ТДС
  gpaReal m_dot_TES;
  // Массовый расход входящего в КС
  gpaReal m_dot_CS;

  // Мольные расходы
  gpaReal G_in_TES;
  gpaReal G_out_TES;
  gpaReal G_in_CS;
  gpaReal G_out_CS;

  // Temperature
  gpaReal T_in_TES;
  gpaReal T_out_TES;
  gpaReal T_in_CS;
  gpaReal T_out_CS;

  // Medium
  gpaMedium *m_medium_TES;
  gpaMedium *m_medium_CS;

  // Old
  gpaReal m_temperature = 0.0;
  gpaReal m_gasEnthalpy = 0.0;
  gpaReal m_liquidEnthalpy = 0.0;
  gpaReal m_liquidFlowRate = 0.0;

public:
  static const gpaString &getDeviceTypeName() { return m_typeName; }
  static const gpaString &getDeviceDescription() { return m_description; }

private:
  static const gpaString m_typeName;
  static const gpaString m_description;
  static const gpaSensorInfoVector m_sensors;
};
#endif
