#include "gpaTankVolume.h"
#include <cassert>

const gpaString initPresErrorStr = "Initial volume pressure must be positive";
const gpaString initTempErrorStr =
    "Initial volume temperature must be positive";
const gpaString initFractErrorStr =
    "Initial mole fractions must be in range [0,1] and their sum is less or "
    "equal to 1.0";
const gpaString liqHeatTransCoefErrorStr =
    "Gas-wall heat transfer coefficient must be non-negative";
const gpaString gasHeatTransCoefErrorStr =
    "Liquid-wall heat transfer coefficient must be non-negative";

const gpaString gpaTankVolume::m_typeName = "reservoir-volume";
const gpaString gpaTankVolume::m_description = "Однослойный объем";

gpaTankVolume::gpaTankVolume(const gpaParentLink *link)
    : gpaVolumeElement(link), m_medium(NULL), m_mixEnergy(0.0), m_mixMoles(0.0),
      m_initPressure(0.0), m_initTemperature(0.0), m_initFractions(0),
      m_liquidLevel(0.0), m_liqHeatTransCoef(0.0), m_gasHeatTransCoef(0.0),
      m_savedVariables(0) {
  for (gpaUInt i = 0; i < GPA_VOLUME_NUM_FACES; ++i)
    setHeatPortData(i, new gpaVolumeHeatData(this, i));
}

gpaTankVolume::gpaTankVolume(const gpaTankVolume &volume)
    : gpaVolumeElement(volume), m_medium(volume.m_medium->copyTo(asOwner())),
      m_mixEnergy(volume.m_mixEnergy), m_mixMoles(volume.m_mixMoles),
      m_initPressure(volume.m_initPressure),
      m_initTemperature(volume.m_initTemperature),
      m_initFractions(volume.m_initFractions),
      m_liquidLevel(volume.m_liquidLevel),
      m_liqHeatTransCoef(volume.m_liqHeatTransCoef),
      m_gasHeatTransCoef(volume.m_gasHeatTransCoef),
      m_savedVariables(volume.m_savedVariables) {
  for (gpaUInt i = 0; i < GPA_VOLUME_NUM_FACES; ++i)
    setHeatPortData(i, new gpaVolumeHeatData(this, i));
}

gpaTankVolume::~gpaTankVolume() { finalizeMedium(); }

gpaTankVolume *gpaTankVolume::copy() const { return new gpaTankVolume(*this); }

void gpaTankVolume::finalizeMedium() {
  if (m_medium)
    delete m_medium;
  m_medium = NULL;
}

bool gpaTankVolume::setInitPressure(gpaReal initPressure) {
  bool good = 0.0 < initPressure;
  if (good)
    m_initPressure = initPressure;
  else
    pushParameterError(initPresErrorStr, this);
  return good;
}

bool gpaTankVolume::setInitTemperature(gpaReal initTemperature) {
  bool good = 0.0 < initTemperature;
  if (good)
    m_initTemperature = initTemperature;
  else
    pushParameterError(initTempErrorStr, this);
  return good;
}

bool gpaTankVolume::setInitFractions(const gpaConstVector &fractions) {
  bool good = true;
  good &= gpaMedium::checkInitFractions(fractions);
  if (!good)
    pushParameterError(initFractErrorStr, this);
  m_initFractions.resize(fractions.size());
  m_initFractions = fractions;
  good &= gpaMedium::prepareInitFractions(m_initFractions);
  return good;
}

bool gpaTankVolume::setLiqHeatTransCoef(gpaReal liqHeatTransCoef) {
  bool good = 0.0 <= liqHeatTransCoef;
  if (good)
    m_liqHeatTransCoef = liqHeatTransCoef;
  else
    pushParameterError(liqHeatTransCoefErrorStr, this);
  return good;
}

bool gpaTankVolume::setGasHeatTransCoef(gpaReal gasHeatTransCoef) {
  bool good = 0.0 <= gasHeatTransCoef;
  if (good)
    m_gasHeatTransCoef = gasHeatTransCoef;
  else
    pushParameterError(gasHeatTransCoefErrorStr, this);
  return good;
}

bool gpaTankVolume::aboveLiquidSurface(gpaReal level) const {
  return m_liquidLevel <= level;
}

gpaReal gpaTankVolume::getPressureAt(gpaReal level) const {
  gpaReal gasDensity = m_medium->getGasDensity();
  gpaReal gasColumn = gasDensity * (getShape()->getHeight() - m_liquidLevel);
  gpaReal upGasColumn = level > m_liquidLevel
                            ? gasDensity * (getShape()->getHeight() - level)
                            : gasColumn;
  gpaReal liqColumn =
      m_medium->getLiquidDensity() * vmMax(0.0, m_liquidLevel - level);
  gpaReal column = upGasColumn + liqColumn;
  return m_medium->getPressure() +
         GPA_GRAVITY_ACCELERATION * column / GPA_KILOPASCAL_TO_PASCAL;
}

gpaReal gpaTankVolume::getTemperatureAt(gpaReal) const {
  return m_medium->getTemperature();
}

gpaReal gpaTankVolume::getMolarMassFor(gpaReal gasVolumeFraction) const {
  if (gasVolumeFraction == 1)
    return m_medium->getGasMolarMass();
  if (gasVolumeFraction == 0)
    return m_medium->getLiquidMolarMass();
  return vmAffine(m_medium->getGasMolarMass(), m_medium->getLiquidMolarMass(),
                  m_medium->calcGasMolarFraction(gasVolumeFraction));
}

gpaReal gpaTankVolume::getEnthalpyFor(gpaReal gasVolumeFraction) const {
  if (gasVolumeFraction == 1)
    return m_medium->getGasEnthalpy();
  if (gasVolumeFraction == 0)
    return m_medium->getLiquidEnthalpy();
  return vmAffine(m_medium->getGasEnthalpy(), m_medium->getLiquidEnthalpy(),
                  m_medium->calcGasMolarFraction(gasVolumeFraction));
}

gpaReal gpaTankVolume::getDensityFor(gpaReal gasVolumeFraction) const {
  if (gasVolumeFraction == 1)
    return m_medium->getGasDensity();
  if (gasVolumeFraction == 0)
    return m_medium->getLiquidDensity();
  return vmAffine(m_medium->getGasDensity(), m_medium->getLiquidDensity(),
                  gasVolumeFraction);
}

gpaReal gpaTankVolume::getViscosityFor(gpaReal gasVolumeFraction) const {
  if (gasVolumeFraction == 1)
    return m_medium->getGasViscosity();
  if (gasVolumeFraction == 0)
    return m_medium->getLiquidViscosity();
  return vmAffine(m_medium->getGasViscosity(), m_medium->getLiquidViscosity(),
                  gasVolumeFraction);
}

void gpaTankVolume::getFractionsFor(gpaDataVector &fractions,
                                    gpaReal gasVolumeFraction) const {
  if (gasVolumeFraction == 1)
    fractions = m_medium->getGasFractions();
  else if (gasVolumeFraction == 0)
    fractions = m_medium->getLiquidFractions();
  else {
    gpaReal molarFraction = m_medium->calcGasMolarFraction(gasVolumeFraction);
    const gpaConstVector &gasFracs = m_medium->getGasFractions();
    const gpaConstVector &liqFracs = m_medium->getLiquidFractions();
    for (gpaUInt i = 0; i < fractions.size(); ++i)
      fractions[i] = vmAffine(gasFracs[i], liqFracs[i], molarFraction);
  }
}

gpaReal gpaTankVolume::getTransitionLevel(gpaReal level, gpaReal radius) const {
  gpaReal transLevel = level;
  if (level == 0.0)
    transLevel = radius / 4.0;
  if (level == getShape()->getHeight())
    transLevel = getShape()->getHeight() - radius / 4.0;
  return transLevel;
}

gpaReal gpaTankVolume::getTransitionRadius(gpaReal level,
                                           gpaReal radius) const {
  gpaReal transRadius = radius;
  if (level == 0.0 || level == getShape()->getHeight())
    transRadius = radius / 4.0;
  return transRadius;
}

void gpaTankVolume::updateLiquidLevel(gpaReal mixMoles) {
  gpaReal steamContent = m_medium->getSteamContent();
  m_liquidLevel = getShape()->getLevelFor((1.0 - steamContent) * mixMoles *
                                          m_medium->getLiquidMolarVolume());
  m_liquidLevel = vmMin(vmMax(m_liquidLevel, 0.0), getShape()->getHeight());
}

gpaReal gpaTankVolume::getLiquidVolume() const {
  return getShape()->getVolumeAt(m_liquidLevel);
}

gpaUInt gpaTankVolume::getNumVariables() const {
  return m_medium->getNumComponents() + 1;
}

gpaResult gpaTankVolume::initialize() {
  const gpaMedium *medium = getCircuitMedium();
  if (!medium)
    return GPA_ERROR_WRONG_ARGS;
  if (!medium->supportsFlash(Uv_FLASH) || !medium->supportsFlash(PT_FLASH))
    return GPA_ERROR_UNSUPPORTED;
  if (m_initFractions.size() != medium->getNumComponents())
    return GPA_ERROR_WRONG_ARGS;
  finalizeMedium();
  m_medium = medium->copyTo(asOwner());
  m_savedVariables.resize(getNumVariables());
  m_savedVariables = -1;
  gpaResult res = gpaVolumeElement::initialize();
  if (res != GPA_RESULT_OK)
    return res;
  res =
      m_medium->calcFlashPT(m_initPressure, m_initTemperature, m_initFractions);
  if (res != GPA_RESULT_OK)
    return res;
  updateLiquidLevel(getShape()->getVolume() / m_medium->getMolarVolume());
  return GPA_RESULT_OK;
}

void gpaTankVolume::fillVarNames(gpaStringVector &varNames) const {
  varNames[0] = "U";
  for (gpaUInt i = 0; i < m_initFractions.size(); i++)
    varNames[i + 1] = "N" + gpaToString(i);
}

gpaResult gpaTankVolume::initVariables(gpaVector &variables) const {
  assert(variables.size() == m_initFractions.size() + 1);
  gpaReal moles = getShape()->getVolume() / m_medium->getMolarVolume();
  variables[0] = moles * m_medium->getEnergy();
  for (gpaUInt i = 0; i < m_initFractions.size(); i++)
    variables[i + 1] = moles * m_initFractions[i];
  return GPA_RESULT_OK;
}

gpaResult gpaTankVolume::fillMassMatrix(gpaUInt refRow, gpaUInt refCol) const {
  for (gpaUInt i = 0; i < getNumVariables(); i++) {
    gpaResult res =
        setMassMatrCoef(refRow + getNumMixPorts() + i, refCol + i, 1.0);
    if (res != GPA_RESULT_OK)
      return res;
  }
  return GPA_RESULT_OK;
}

gpaResult gpaTankVolume::calcFuncValues(const gpaConstVector &,
                                        const gpaConstVector &variables,
                                        gpaVector &values,
                                        const gpaSetOfEquations &eqIds) {
  assert(variables.size() == m_initFractions.size() + 1);
  if (variables != m_savedVariables) {
    m_mixEnergy = variables[0];
    m_mixMoles = variables[1];
    gpaResult res = m_medium->prepareMolesTol(
        m_initFractions, variables(1, variables.size()), &m_mixMoles);
    if (res != GPA_RESULT_OK)
      return res;
    res = m_medium->calcFlashUv(m_mixEnergy / m_mixMoles,
                                getShape()->getVolume() / m_mixMoles,
                                m_initFractions);
    if (res != GPA_RESULT_OK)
      return res;
    updateLiquidLevel(m_mixMoles);
    m_savedVariables = variables;
  }

  gpaElementMixCircuit *circuit = getMixCircuit(GPA_ELEM_CIRCUIT_0);
  gpaUInt numPorts = circuit->getNumPorts();
  values = 0.0;
  values[0 + numPorts] = getHeatCircuit()->getIncomingHeatRate();
  gpaUInt i = 0;
  for (auto iter = circuit->firstPortIter(); iter != circuit->lastPortIter();
       ++iter) {
    const gpaMixPort *port = iter->second;
    values[i++] =
        port->getStreamPressure() - getFittingData(iter->first)->getPressure();
    gpaReal flowRate = port->getIncomingFlowRate();
    values[0 + numPorts] += flowRate * port->getStreamEnthalpy();
    gpaConstVector fracs = port->getStreamFractions();
    for (gpaUInt j = 0; j < fracs.size(); j++)
      values[j + 1 + numPorts] += flowRate * fracs[j];
  }
  return GPA_RESULT_OK;
}

gpaResult gpaTankVolume::calcEnthalpyFuncValueAt(gpaUInt circIdx,
                                                 gpaUInt portIdx,
                                                 gpaReal enthalpy,
                                                 gpaReal &funcValue) const {
  if (circIdx != GPA_ELEM_CIRCUIT_0)
    return GPA_ERROR_WRONG_ARGS;
  const gpaVolumeFittingData *data = getFittingData(portIdx);
  if (!data)
    return GPA_ERROR_WRONG_ARGS;

  gpaReal x = (data->getLevel() - m_liquidLevel) / 1e-3;
  gpaReal Y = 1 / (1 + exp(-x));
  funcValue = enthalpy - m_medium->getGasEnthalpy() * Y -
              m_medium->getLiquidEnthalpy() * (1 - Y);

  return GPA_RESULT_OK;
}

gpaResult
gpaTankVolume::calcFractionsFuncValuesAt(gpaUInt circIdx, gpaUInt portIdx,
                                         const gpaConstVector &fractions,
                                         gpaVector &funcValues) const {
  if (circIdx != GPA_ELEM_CIRCUIT_0)
    return GPA_ERROR_WRONG_ARGS;
  const gpaVolumeFittingData *data = getFittingData(portIdx);
  if (!data)
    return GPA_ERROR_WRONG_ARGS;

  gpaReal x = (data->getLevel() - m_liquidLevel) / 1e-3;
  gpaReal Y = 1 / (1 + exp(-x));

  gpaConstVector gasFractions = m_medium->getGasFractions();
  gpaConstVector liquidFractions = m_medium->getLiquidFractions();
  for (gpaUInt i = 0; i < funcValues.size(); i++) {
    funcValues[i] =
        fractions[i] - gasFractions[i] * Y - liquidFractions[i] * (1 - Y);
  }

  return GPA_RESULT_OK;
}
