#ifndef GPA_HRU_E_H
#define GPA_HRU_E_H
#include "gpaInclude.h"
#include "gpaFlowElement.h"
#include "gpaHeatLayer.h"
#include <iostream>
#include <fstream> 
#include <numbers>
using namespace std;


#include <vector>
#include <stdexcept>

#include <sstream>
#include <string>
#include <iomanip>
#include <filesystem>
#include <cstdlib>
#include <algorithm>

namespace fs = std::filesystem;

const gpaUInt GPA_ELEM_CIRCUIT_Oil            = 1;

class myPipe_HRU
{

    public:
    
    gpaString pipe_Name;
    gpaString fluid;
    gpaMedium* medium;

    gpaReal flag=0.0;
    gpaReal meanTemp = 300.0;
    gpaReal meanPressure = 101.0;

    gpaReal n_ch    = 1.0;
    gpaReal epsilon = 1.0;
    gpaReal d_char  = 1.0;
    gpaReal l_ch    = 1.0;
    gpaReal deltaH  = 1.0;
   
    gpaReal density   = 1.0;
    gpaReal viscosity = 1.0;
    gpaReal mu        = 1.0;
    gpaReal cp = 1.0;
    gpaReal lambda = 1.0;

    gpaReal v  = 1.0;
    gpaReal Re = 1.0;

    gpaReal coefFrick = 1.0;
    gpaReal DP_Frick  = 1.0;
    gpaReal DP_DH     = 1.0;
    gpaReal DP        = 1.0;


    gpaReal F1 = 1.0;
    gpaReal F2 = 1.0;
    gpaReal F3 = 1.0;
    gpaReal X1 = 1.0;
    gpaReal X2 = 1.0;


    gpaReal ReJoin1 = 2300.0;
    gpaReal ReJoin2 = 4000.0;
    gpaReal deltaRe = 30.0;

    gpaReal sigm = 0.2;
    gpaReal crossArea = 0.2;
    gpaReal volume =0;

    gpaReal Pr = 1.0;
    gpaReal Nu = 1.0;
    gpaReal alpha_conv=0.1;




    // Запись матрицы в CSV файл
    bool writeMatrixToCSV(const vector<vector<double>>& matrix, 
                        const string& filename, 
                        char delimiter = ',',
                        int precision = 3,
                        bool includeHeaders = false,
                        const vector<string>& rowHeaders = {},
                        const vector<string>& colHeaders = {}) {
        
        ofstream file(filename);
        
        if (!file.is_open()) {
            cerr << "Ошибка: не удалось открыть файл " << filename << " для записи" << endl;
            return false;
        }
        
        // Устанавливаем точность вывода
        file << scientific << setprecision(precision);
        
        int rows = matrix.size();
        if (rows == 0) {
            cerr << "Ошибка: пустая матрица" << endl;
            file.close();
            return false;
        }
        
        int cols = matrix[0].size();
        
        // Проверка корректности матрицы (все строки одинаковой длины)
        for (int i = 1; i < rows; i++) {
            if (matrix[i].size() != static_cast<size_t>(cols)) {
                cerr << "Ошибка: строки матрицы имеют разную длину" << endl;
                file.close();
                return false;
            }
        }
        
        // Записываем заголовки столбцов (если нужно)
        if (includeHeaders && !colHeaders.empty()) {
            // Если есть заголовки строк, первая ячейка пустая
            if (!rowHeaders.empty()) {
                file << delimiter;
            }
            
            // Записываем заголовки столбцов
            for (int j = 0; j < cols; j++) {
                if (j < static_cast<int>(colHeaders.size())) {
                    // Если в заголовках есть запятые, заключаем в кавычки
                    if (colHeaders[j].find(delimiter) != string::npos) {
                        file << "\"" << colHeaders[j] << "\"";
                    } else {
                        file << colHeaders[j];
                    }
                } else {
                    file << "Column_" << (j + 1);
                }
                
                if (j < cols - 1) {
                    file << delimiter;
                }
            }
            file << endl;
        }
        
        // Записываем данные матрицы
        for (int i = 0; i < rows; i++) {
            // Заголовок строки (если есть)
            if (includeHeaders && !rowHeaders.empty()) {
                if (i < static_cast<int>(rowHeaders.size())) {
                    // Если в заголовках есть запятые, заключаем в кавычки
                    if (rowHeaders[i].find(delimiter) != string::npos) {
                        file << "\"" << rowHeaders[i] << "\"";
                    } else {
                        file << rowHeaders[i];
                    }
                } else {
                    file << "Row_" << (i + 1);
                }
                file << delimiter;
            }
            
            // Элементы строки матрицы
            for (int j = 0; j < cols; j++) {
                file << matrix[i][j];
                if (j < cols - 1) {
                    file << delimiter;
                }
            }
            file << endl;
        }
        
        file.close();
        
        if (file.fail()) {
            cerr << "Ошибка при записи в файл" << endl;
            return false;
        }
        
        return true;
    }


    // Проверка существования директории (кросс-платформенная)
    bool directoryExists(const string& path) {
        return fs::exists(path) && fs::is_directory(path);
    }

    // Создание директории (кросс-платформенная)
    bool createDirectory(const string& path) {
        try {
            return fs::create_directory(path);
        } catch (const fs::filesystem_error& e) {
            cerr << "Ошибка при создании директории: " << e.what() << endl;
            return false;
        }
    }

   void exportCurrentBiblProps(string way, gpaReal tempStart, gpaReal tempEnd, gpaReal deltaTemp, gpaDataVector fractions)
    {  
        
        cout << "  cp_gas = f(T)   " << " | " <<"\n";

        vector <vector<gpaReal>> parsVST;
        vector<gpaReal> pars={0,0,0,0,0,0};
        for (gpaReal temp = tempStart; temp < tempEnd; temp = temp + deltaTemp)
        {
            //cout<<temp <<endl;
            medium->calcFlashPT(meanPressure, temp, fractions); 

            pars[0] = temp;
            pars[1] = medium->getConductivity();
            pars[2] = medium->getDensity();
            pars[3] = medium->getViscosity();
            pars[4] = medium->getHeatCapacity()/medium->getMolarMass();
            pars[5] = medium->getMolarMass();

            parsVST.push_back(pars);
        }

        gpaString nameExport_CM = pipe_Name + " " + fluid + " " + to_string(meanPressure) + " .csv";
        cout << "--> export "<< " | "  << nameExport_CM << " " << writeMatrixToCSV(parsVST, way + nameExport_CM) <<endl;

        std::cout << "  ---------   " <<"\n"; 
    
        
    }

    void calcVolume()
    {
        volume = n_ch*crossArea*l_ch;
    }

    // Функция, выдающая свойства ГМ. Функции получены интерполяцией табличных зависимостей терминола 66
    gpaReal getOilProp(gpaString par, gpaReal T)
    {
        if(par == "rho"){
           return   1236.69 - 0.745665*T;//kg/m^3
        }
        if(par == "cp"){
           return   (0.5211052170945513 + 0.0035340139549585384*T);//kJ/kg/K
        }
        if(par == "lambda"){
           return   (0.15395 - 0.000103468*T)/1000;//kW/K/m
        }  
        if(par == "eta"){
           return   21.834/pow(T-273,1.912);//Pa*s
        }
        if(par == "mu"){
           return   252.0;//kg/kmol
        }
    }

    // Функция, выдающая свойства ГС и ДГ. Для простоты взяты табличные зависимости воздуха при 1 атм 
    gpaReal getGasProp(gpaString par, gpaReal T)
    {
        if(par == "rho"){
           return   365.863/T;
        }
        if(par == "cp"){
           return   (-229.668 + 463.18*pow(T,0.168614))/1000.0;
        }
        if(par == "lambda"){
           return   (0.00396343 + 0.0000706675*T)/1000.0;
        }  
        if(par == "eta"){
           return   -2.96295*pow(10.0,-6.0) + 3.65048*pow(10.0,-7.0)*pow(T,0.696601);
        }
        if(par == "mu"){
           return   29.0;
        }
    }

   //Получить теплопроводность, плотность, динамическую вязкость,теплоемкость, молярную массу
    void getStandartPackProp(gpaDataVector fractions)
    {
         if(flag == 0)
        {
            
            density   = fluid =="gas"? getGasProp("rho",   meanTemp):getOilProp("rho",   meanTemp);
            viscosity = fluid =="gas"? getGasProp("eta",   meanTemp):getOilProp("eta",   meanTemp);
            mu        = fluid =="gas"? getGasProp("mu" ,   meanTemp):getOilProp("mu",   meanTemp);
            cp        = fluid =="gas"? getGasProp("cp" ,   meanTemp):getOilProp("cp",   meanTemp);        
            lambda    = fluid =="gas"? getGasProp("lambda",meanTemp):getOilProp("lambda",   meanTemp);

        }
        else
        {
        
            medium->calcFlashPT(meanPressure, meanTemp, fractions);// !!! без изменения состава b P_in_gas
            //std::cout << " gas | is good calcFlash | "<< res<< "\n";
            lambda     = medium->getConductivity();
            density    = medium->getDensity();
            viscosity  = medium->getViscosity();
            cp         = medium->getHeatCapacity()/medium->getMolarMass();
            mu         = medium->getMolarMass();
        }

    }

    //Функция сигмойда
    gpaReal sigmoid(gpaReal x)
    {
        return 1.0 / (1.0 + std::exp(-x));
    }

    //Выдает сглаженное значение кусочно-заданной функции по числу Рейнолдса
    gpaReal smFun(gpaReal fL,gpaReal fR, gpaReal ReStar, gpaReal ReDelta)
    {
        gpaReal ReDim = (Re - ReStar) / ReDelta;
        return fL * (1.0 - sigmoid(ReDim)) + fR * sigmoid(ReDim);
    } 

    //Выдвет Nu для турбулетного режима согласно закону Диттуса-Болтера
    gpaReal getNuByDBLaw(gpaReal Re,gpaReal Pr)
    {
        return 0.023*pow(Re,0.8)*pow(Pr,0.3);
    }
    
    //Выдает значение линейной функции, сшивающей два закона в переходной зоне  
    gpaReal getLineTransFunByRe(gpaReal reS,gpaReal reE, gpaReal yS, gpaReal yE)
    {
        return yS+(yE-yS)*(Re-reS)/(reE-reS);
    }

    gpaReal getNu(bool imShow)
    {

        gpaReal ReTrZSt = 2300;
        gpaReal ReTrZEnd = 105000;
        gpaReal deltaReForNuLaw = 100;
        gpaReal nuLam    = 3.657;
        gpaReal nuTrZEnd = getNuByDBLaw(ReTrZEnd, Pr);
        gpaReal nuTurb   = getNuByDBLaw(Re,Pr);
        gpaReal nuTr     = getLineTransFunByRe(ReTrZSt, ReTrZEnd, nuLam, nuTrZEnd);
        gpaReal NuSM     = smFun(nuLam, nuTr, ReTrZSt, deltaReForNuLaw);
                      Nu = smFun(NuSM, nuTurb, ReTrZEnd, deltaReForNuLaw);
        return Nu;

        if(imShow==1)
        {
            std::cout << "  nuTrZEnd | nuTurb  | nuTr "   <<"\n"; 
            std::cout  <<" | " << nuTrZEnd << " | " << nuTurb << " | " << nuTr << " | "   <<"\n"; 
            std::cout << "  Re | NuSM1 | NuSM2 " <<"\n";
            std::cout << Re << " | " << NuSM << Nu << " | "   <<"\n";

            cout << "G"<< " | " << " v "<< " | " << "Re" << " | "  << "coefFrick"<<endl;
            cout << 0<< " | " << v << " | " << Re   << " | "  << coefFrick<<endl;  
        }

        //trustNuFun()
    }

    // Выводит зависимость Nu = f(Re)
    void trustNuFun(){
        
        //test nu fun
        for (size_t ReTest = 0; ReTest < 30000; ReTest=ReTest+1000)
        {
            Re=ReTest;
            std::cout << " | " << ReTest << " | " << getNu(0) << " | "   <<"\n"; 
        }
    }

    void calcMyPipeHeatTransherProp(bool imshow)
    {
        Pr = viscosity*cp/lambda;
        Nu = getNu(imshow);
        alpha_conv = Nu*lambda/d_char;
    }
    
    void calcMyPipeMeanFlowProp2(bool isShow, gpaReal G)
    {
        //G  = (G * mu > 3 ? G: 3 / mu );//flowCond
      
        v  = G * mu / n_ch / density / crossArea;

        Re = v * density * d_char / viscosity;


        F1 = 64*Re;

        F3 =  1 / pow(1.8, 2.0) * pow(Re, 2.0) / pow(log10(6.9 / (Re + 1e-9) + pow(epsilon / 3.7 / d_char, 1.11)), 2.0);

        F2 = F1 + (Re - ReJoin1) / (ReJoin2 - ReJoin1) * (F3 - F1);

        X1 = (Re - ReJoin1) / deltaRe;
        X2 = (Re - ReJoin2) / deltaRe;
        
        sigm = 1.0/(1.0 + exp(-1.0*X1));
        coefFrick =  F1 * (1.0 - sigm) + F2 * sigm;
        
        sigm = 1.0/(1.0 + exp(-1.0*X2));
        coefFrick =  coefFrick * (1.0 - sigm) + F3 * sigm;
        
        
        
        DP_Frick = coefFrick * pow(viscosity, 2.0) * l_ch/2.0/density/pow(d_char,3.0) /1000;//flowCond 
        
   
        DP_DH = density*9.8*deltaH/1000;


   
        

        DP =  DP_Frick + DP_DH;

    }

};

class myPipeRib_HRU
{

    public:
    
    gpaString pipe_Name;
    gpaString fluid;
    gpaMedium* medium;

    gpaReal flag = 0.0;
    gpaReal meanPressure = 101.0;
    gpaReal meanTemp = 300.0;

    gpaReal n_ch    = 1.0;

    //gpaReal l_ch    = 1.0;
    gpaReal deltaH  = 1.0;
   
    gpaReal density   = 1.0;
    gpaReal viscosity = 1.0;
    gpaReal mu        = 1.0;
    gpaReal cp = 1.0;
    gpaReal lambda = 1.0;

    gpaReal v  = 1.0;
    gpaReal Re = 1.0;
    gpaReal volume =0.0;

    gpaReal DP        = 1.0;

    gpaReal crossArea = 0.2;

    gpaReal Pr = 1.0;
    gpaReal Nu = 1.0;
    gpaReal alpha_conv=0.1;

    gpaReal c;
    gpaReal n;
    gpaReal m;

    //Перечень входных геометрических параметров КК (СC - convection chamber)
    gpaReal deltaRib=0.0012;
    gpaReal hRib=0.015;
    gpaReal sRib=1;
    gpaReal psiRib = 4;
    gpaReal lambdaRib = 0.1;// kWt/m/k

    gpaReal d_equal;
    gpaReal l_char;
    gpaReal nRow;
    gpaReal zeta_0_R;

    // Запись матрицы в CSV файл
    bool writeMatrixToCSV(const vector<vector<double>>& matrix, 
                        const string& filename, 
                        char delimiter = ',',
                        int precision = 3,
                        bool includeHeaders = false,
                        const vector<string>& rowHeaders = {},
                        const vector<string>& colHeaders = {}) {
        
        ofstream file(filename);
        
        if (!file.is_open()) {
            cerr << "Ошибка: не удалось открыть файл " << filename << " для записи" << endl;
            return false;
        }
        
        // Устанавливаем точность вывода
        file << scientific << setprecision(precision);
        
        int rows = matrix.size();
        if (rows == 0) {
            cerr << "Ошибка: пустая матрица" << endl;
            file.close();
            return false;
        }
        
        int cols = matrix[0].size();
        
        // Проверка корректности матрицы (все строки одинаковой длины)
        for (int i = 1; i < rows; i++) {
            if (matrix[i].size() != static_cast<size_t>(cols)) {
                cerr << "Ошибка: строки матрицы имеют разную длину" << endl;
                file.close();
                return false;
            }
        }
        
        // Записываем заголовки столбцов (если нужно)
        if (includeHeaders && !colHeaders.empty()) {
            // Если есть заголовки строк, первая ячейка пустая
            if (!rowHeaders.empty()) {
                file << delimiter;
            }
            
            // Записываем заголовки столбцов
            for (int j = 0; j < cols; j++) {
                if (j < static_cast<int>(colHeaders.size())) {
                    // Если в заголовках есть запятые, заключаем в кавычки
                    if (colHeaders[j].find(delimiter) != string::npos) {
                        file << "\"" << colHeaders[j] << "\"";
                    } else {
                        file << colHeaders[j];
                    }
                } else {
                    file << "Column_" << (j + 1);
                }
                
                if (j < cols - 1) {
                    file << delimiter;
                }
            }
            file << endl;
        }
        
        // Записываем данные матрицы
        for (int i = 0; i < rows; i++) {
            // Заголовок строки (если есть)
            if (includeHeaders && !rowHeaders.empty()) {
                if (i < static_cast<int>(rowHeaders.size())) {
                    // Если в заголовках есть запятые, заключаем в кавычки
                    if (rowHeaders[i].find(delimiter) != string::npos) {
                        file << "\"" << rowHeaders[i] << "\"";
                    } else {
                        file << rowHeaders[i];
                    }
                } else {
                    file << "Row_" << (i + 1);
                }
                file << delimiter;
            }
            
            // Элементы строки матрицы
            for (int j = 0; j < cols; j++) {
                file << matrix[i][j];
                if (j < cols - 1) {
                    file << delimiter;
                }
            }
            file << endl;
        }
        
        file.close();
        
        if (file.fail()) {
            cerr << "Ошибка при записи в файл" << endl;
            return false;
        }
        
        return true;
    }


    // Проверка существования директории (кросс-платформенная)
    bool directoryExists(const string& path) {
        return fs::exists(path) && fs::is_directory(path);
    }

    // Создание директории (кросс-платформенная)
    bool createDirectory(const string& path) {
        try {
            return fs::create_directory(path);
        } catch (const fs::filesystem_error& e) {
            cerr << "Ошибка при создании директории: " << e.what() << endl;
            return false;
        }
    }

    void exportCurrentBiblProps(string way, gpaReal tempStart, gpaReal tempEnd, gpaReal deltaTemp, gpaDataVector fractions)
    {  
        
        cout << "  cp_gas = f(T)   " << " | " <<"\n";

        vector <vector<gpaReal>> parsVST;
        vector<gpaReal> pars={0,0,0,0,0,0};
        for (gpaReal temp = tempStart; temp < tempEnd; temp = temp + deltaTemp)
        {
            //cout<<temp <<endl;
            medium->calcFlashPT(meanPressure, temp, fractions); 

            pars[0] = temp;
            pars[1] = medium->getConductivity();
            pars[2] = medium->getDensity();
            pars[3] = medium->getViscosity();
            pars[4] = medium->getHeatCapacity()/medium->getMolarMass();
            pars[5] = medium->getMolarMass();

            parsVST.push_back(pars);
        }

        gpaString nameExport_CM = pipe_Name + " " + fluid + " " + to_string(meanPressure) + " .csv";
        cout << "--> export "<< " | "  << nameExport_CM << " " << writeMatrixToCSV(parsVST, way + nameExport_CM) <<endl;

        std::cout << "  ---------   " <<"\n"; 
    
        
    }

    // Функция, выдающая свойства ГМ. Функции получены интерполяцией табличных зависимостей терминола 66
    gpaReal getOilProp(gpaString par, gpaReal T)
    {
        if(par == "rho"){
           return   1236.69 - 0.745665*T;//kg/m^3
        }
        if(par == "cp"){
           return   (0.5211052170945513 + 0.0035340139549585384*T);//kJ/kg/K
        }
        if(par == "lambda"){
           return   (0.15395 - 0.000103468*T)/1000;//kW/K/m
        }  
        if(par == "eta"){
           return   21.834/pow(T-273,1.912);//Pa*s
        }
        if(par == "mu"){
           return   252.0;//kg/kmol
        }
    }

    // Функция, выдающая свойства ГС и ДГ. Для простоты взяты табличные зависимости воздуха при 1 атм 
    gpaReal getGasProp(gpaString par, gpaReal T)
    {
        if(par == "rho"){
           return   365.863/T;
        }
        if(par == "cp"){
           return   (-229.668 + 463.18*pow(T,0.168614))/1000.0;
        }
        if(par == "lambda"){
           return   (0.00396343 + 0.0000706675*T)/1000.0;
        }  
        if(par == "eta"){
           return   -2.96295*pow(10.0,-6.0) + 3.65048*pow(10.0,-7.0)*pow(T,0.696601);
        }
        if(par == "mu"){
           return   29.0;
        }
    }

    //Получить теплопроводность, плотность, динамическую вязкость,теплоемкость, молярную массу
    void getStandartPackProp(gpaDataVector fractions)
    {
         if(flag == 0)
        {
            
            density   = fluid =="gas"? getGasProp("rho",   meanTemp):getOilProp("rho",   meanTemp);
            viscosity = fluid =="gas"? getGasProp("eta",   meanTemp):getOilProp("eta",   meanTemp);
            mu        = fluid =="gas"? getGasProp("mu" ,   meanTemp):getOilProp("mu",   meanTemp);
            cp        = fluid =="gas"? getGasProp("cp" ,   meanTemp):getOilProp("cp",   meanTemp);        
            lambda    = fluid =="gas"? getGasProp("lambda",meanTemp):getOilProp("lambda",   meanTemp);

        }
        else
        {
        
            medium->calcFlashPT(meanPressure, meanTemp, fractions);
            //std::cout << " gas | is good calcFlash | "<< res<< "\n";
            lambda     = medium->getConductivity();
            density    = medium->getDensity();
            viscosity  = medium->getViscosity();
            cp         = medium->getHeatCapacity()/medium->getMolarMass();
            mu         = medium->getMolarMass();
        }

    }

   //Функция сигмойда
    gpaReal sigmoid(gpaReal x)
    {
        return 1.0 / (1.0 + std::exp(-x));
    }

    //Выдает сглаженное значение кусочно-заданной функции по числу Рейнолдса
    gpaReal smFun(gpaReal fL,gpaReal fR, gpaReal ReStar, gpaReal ReDelta)
    {
        gpaReal ReDim = (Re - ReStar) / ReDelta;
        return fL * (1.0 - sigmoid(ReDim)) + fR * sigmoid(ReDim);
    } 
    
    void calcMyPipeHeatTransherProp(bool imShow,  gpaReal G)
    {

        v  = (G) * mu / n_ch / density / crossArea;
        Re = v * density * l_char / viscosity;

        Pr = viscosity*cp/lambda;
        Nu = smFun(1, c * pow(abs(Re), n) * pow(Pr, m) , 100, 10);

        if(imShow==1)
        {
            std::cout << "  Re | NuSM1 | NuSM2 " <<"\n";
            std::cout << Re << " | " <<  Nu << " | "   <<"\n";
            std::cout << c << " | " <<  n << " | " << m  <<"\n";
        }

        gpaReal alphaEG   = Nu*lambda/l_char;
        gpaReal mRib      = pow(2*alphaEG*lambdaRib/deltaRib, 0.5);
        gpaReal eff       = tanh(mRib*(hRib + deltaRib/2.0))/(mRib*(hRib + deltaRib/2.0));
        gpaReal psiE      = 1.0 - 0.058*mRib*hRib;
        gpaReal eta       = 1.0 - (1.0 - psiE*eff)*(1.0 - 1.0/psiRib*(1.0 - deltaRib/sRib));
        alpha_conv = alphaEG*psiRib*eta;

    }
    
    void getZeta0R()
    {
        zeta_0_R = 0.26*pow(l_char/d_equal,0.3);
    }

    gpaReal getZeta(gpaReal Re)
    {

        gpaReal zeta, zeta_0;
        
        gpaReal ReZero = 1000;

        gpaReal zeta_star= (5.4 * l_char) / d_equal * pow(ReZero, -0.25);

        gpaReal zeta_mid = Re<0.8*ReZero?(5.4 * l_char) / d_equal * pow(0.8*ReZero, -0.25):(5.4 * l_char) / d_equal * pow(Re, -0.25); 

        gpaReal zetaMid = smFun(7, zeta_mid, ReZero, 10);

        
        zeta_0 = smFun(zetaMid,zeta_0_R, 1.5e5, 100);

        zeta     =  zeta_0 * nRow;

        return zeta;
    }



    void calcMyPipeMeanFlowProp3(bool isShow,  gpaReal G)
    {
        v  = (G) * mu / n_ch / density / crossArea;
        Re = v * density * l_char / viscosity;


        DP     = smFun(0, 2/1.75* getZeta(Re) * density * v*abs(v) / 2 / 1000, 0 ,10);//kPa
    }

};

class gpaHeatRecoveryUnitElement : public gpaFlowElement
{
public:

    // не убирать 
    gpaHeatRecoveryUnitElement(const gpaParentLink *link);
    gpaHeatRecoveryUnitElement(const gpaHeatRecoveryUnitElement &m_heatPipes);
    virtual gpaHeatRecoveryUnitElement *copy() const override;
    // не убирать

    virtual gpaUInt getMinNumMixPorts(gpaUInt index) const override;
    static  gpaUInt getDeviceMinNumMixPorts(gpaUInt index);
    static  gpaUInt getDeviceNumMixCircuits();
    virtual gpaUInt getNumMixCircuits() const;
    virtual gpaUInt getMaxNumMixPorts(gpaUInt index) const override;
    static  gpaUInt getDeviceMaxNumMixPorts(gpaUInt index);

    //+++++++++++ Инициализация переменных  

    // Кол-во переменных 
    gpaUInt getNumVariables() const override;

    // Нумирация переменных
    enum
    {
        //VOL_OIL = 2,
    };

    void fillVarNames(gpaStringVector &varNames) const override;

    // Задаем начальные условия для переменнных
    gpaResult initVariables(gpaVector &variables) const override;
    
    //++++++++++++ Инициализация переменных 

    //+++++++++++++ Инициализация остального
    // Главная функция инициалзации 
    gpaResult initialize() override;

    // параметры для расчета тепломассопереноса в межтрубном пространстве СС
    void calcGeomPars();

    //для расчета тепломассопереноса в межтрубном пространстве RС  
    void calcGeomParsGasPipeline();

    //Расчет площади внешней поверхности, с которой тепло уходит в окр среду, с учетом слоя утеплителя  

    // параметры геометрии трубопровода с ГМ
    void calcGeomParsHotOilPipeline();

    // Инициализация среды 
    void initMedium();

    void exportBiblProps(string way);

    
    void updateAllPipeProperties();

    // Инициализация потоков 
    void initFlows();
    
    //+++++++++++++++++ Инициализация остального

    //+++++++++++++++++ Библиотека смесей для тестирования 

    // Функция, выдающая свойства ГМ. Функции получены интерполяцией табличных зависимостей терминола 66
    gpaReal getOilProp(gpaString par, gpaReal T);

    // Функция, выдающая свойства ГС и ДГ. Для простоты взяты табличные зависимости воздуха при 1 атм 
    gpaReal getGasProp(gpaString par, gpaReal T);

    //+++++++++++++++++ Библиотека смесей для тестирования 


    //+++++++++++++++++ Функции, которые будут использоваться на каждой итерации 

    //+++ Расчет перепадов давлений 
    void calcDeltaP(bool isShow);
    //+++ Расчет перепадов давлений 

    //+++ Расчет свойств потоков
    void calcFlowProperties();
    //+++ Расчет свойств потоков

    //+++ Расчет теплообмена

    //Расчет кол-ва тепла, которое уходит в окр среду с внешней поеврхности установки
    void calcQInAtm(bool isShow);


    //Расчет средних температур в каналах
    void calcMeanTemp(bool isShow);

    //Расчет средних значений давлений в каналах
    void calcMeanPressure();

    
    gpaReal myRound(gpaReal x, gpaReal n);

    gpaReal build_polinom(vector <gpaReal>  coef_List, gpaReal x);
   
    //Функция сигмойда
    gpaReal sigmoid(gpaReal x);

    //Получить средне-логарифмический перепад температур 0 -  соноправленное течение, 1 - противонаправленное течение
    gpaResult getLMTD(bool isShow,gpaReal T_in_1, gpaReal T_out_1, gpaReal T_in_2, gpaReal T_out_2, gpaUInt i_Flow_Scheme);

    //Расчитывает поправочные коэффициенты
    void setCurrentHTPars(bool isShow);

    //Расчет теплообмена
    void calcHeatEchange(bool isShow);

    //+++ Расчет теплообмена


    // Главная функция: полный набор уравнений для "стрелок" и фазового равновесия
    gpaResult calcFuncValues(const gpaConstVector &, const gpaConstVector &variables, gpaVector &values,const gpaSetOfEquations &eqIds) override;


    void getProps(bool imShow);


    //Расчет свойств промежуточных точек трактов (г* и м*) 
    void getCpOnPorts();
  
    

    void trustCpAndQBalance(bool isNeedShowCpVST);

    
    //Невязка по энтальпии
    gpaResult calcEnthalpyFuncValueAt(gpaUInt circIdx, gpaUInt portIdx, gpaReal enthalpy, gpaReal &funcValue) const override;

    // Невязка по компонентам — для выходных портов сравниваем с переменными разделителя
    gpaResult calcFractionsFuncValuesAt(gpaUInt circIdx, gpaUInt portIdx, const gpaConstVector &fractions, gpaVector &funcValues) const override;
    
    virtual const gpaString &getTypeName() const override;
    virtual const gpaString &getDescription() const override;

private:

gpaElementMixCircuit *circuit_Gas;
gpaElementMixCircuit *circuit_Oil;

    void calcThermalParams();

public:

    // Переключатель библиотек
    gpaReal flagMixBibl = 1.0;
    gpaReal setParsMethodFlag = 1.0;

    // Параметры геометрии:
    gpaReal m_d = 0.0;       // внутренний диаметр (м)
    gpaReal m_l = 0.0;       // длина аппарата (м)
    gpaReal m_dh = 0.0;      // гидростат. напор (м)
    gpaReal m_nBends = 0.0;  // число колен
    gpaReal m_eps = 0.0;     // шероховатость (м)
    gpaReal m_Tenv = 298.15; // температура окружающей среды (К)

    gpaHeatLayerVector m_heatLayers;

    // PIPE (общая труба)
    gpaReal m_R_pipe = 1.0;
    gpaReal m_A_in = 0.0;
    gpaReal m_A_out = 0.0;
    gpaReal m_A_in_pipe = 0.0;
    gpaReal m_A_out_pipe = 0.0;
    gpaReal m_alpha_in_pipe = 0.0;
    gpaReal m_alpha_out_pipe = 0.0;

    // GAS (газовая)
    gpaReal m_R_gas = 1.0;
    gpaReal m_A_in_gas = 0.0;
    gpaReal m_A_out_gas = 0.0;
    gpaReal m_alpha_in_gas = 0.0;
    gpaReal m_alpha_out_gas = 0.0;
    gpaReal m_wall_diamet1;
    gpaReal m_wall_diamet2;
    gpaReal m_wall_diamet3;
    gpaReal m_hydro_coeff;
    gpaReal m_diametr;
    gpaReal m_wall_conductive1;
    gpaReal m_wall_conductive2;


    //gpaHeatCoeffPrm m_hydro_coeff;

    // Проcтые трубы
    myPipe_HRU oilPipeCC;

    // Для межтрубного пространства CC используется модель трубы с оребрением 
    myPipeRib_HRU gasPipeCC;

    const gpaMixPort *gasInlet;
    const gpaMixPort *gasOut;
    const gpaMixPort *oilInlet;
    const gpaMixPort *oilOut;


    gpaReal vol_oil; 
    gpaReal deltaVolume = 10;
    gpaReal total_volume_oil; 
    gpaReal vol_Switcher = -10;
    gpaReal timeCalc; 
    gpaReal volumeOilChannel; 

    gpaReal m;
    gpaReal cConst;
    gpaReal nConst;
    gpaReal c;
    gpaReal n;

    gpaReal sLSRC;
    gpaReal dGasRC;
    gpaReal DPipeRC;
    gpaReal pWetRC;

    //

    gpaReal mGasCC;
    gpaReal sStar;
    gpaReal sMS;
    gpaReal velGasCC;   
    gpaReal reEG;

    gpaReal sRib;
    gpaReal sRibStar;
    gpaReal nPipeСС;
    gpaReal DPipeCC;
    gpaReal DpCC;
    gpaReal lChar;
    gpaReal dEqual;
    gpaReal rhoGasCC;
    gpaReal etaGasCC;

    //Перечень входных геометрических параметров КК (СC - convection chamber)
    gpaReal nChannelsCC;
    gpaReal nPipeCC =10;
    gpaReal lPipeCC=6.7;
    gpaReal dPipeCC=0.102;

    gpaReal nRowsCC=5;

    gpaReal h_dist_BW_oil_ports;
    gpaReal l_out_CC=0;
    gpaReal aCC = 1.0;
    gpaReal bCC = 6.0;

    gpaReal nPipeSmСС=5.0;
    gpaReal nPipeCorСС=18.0;
    gpaReal deltaPipeCC=0.006;
    gpaReal epsilonСС=0.0001;
    gpaReal kRib=167.0;
    gpaReal deltaRib=0.0012;
    gpaReal hRib=0.015;
    gpaReal s1=0.2;
    gpaReal s2=0.086;
    gpaReal s3=0.2;

    //Перечень параметров окружающей установку среды+


    // Общий коэффицент прочих местных потерь 
    gpaReal total_local_frick_coef_CC;

    //Коэффициент теплоотдачи от поверхности стенки КК
    gpaReal alphaAtmCC = 10.0;
    //Коэффициент теплопроводности стенки изоляции КК
    gpaReal lambdaAtmCC = 0.15;
    //Толщина изоляции КР
    gpaReal dIsoCC = 0.150; 
    //Температура окружающей среды
    gpaReal TAirAtm = 300.0;

    // Площадь контакта СС с окружающей средой
    gpaReal sAtmSideCC;
    // Тепло от CC в  окружающую среду
    gpaReal QAtmCC;

    // Поправочные коэффициенты
    //Коэффициент для теплоемкости ДГ
    gpaReal c_fix_cp_EG = 1;
    //Коэффициент для теплоотдачи
    gpaReal c_fix_HE = 1;
    //Коэффициент для вычисления температуры ДГ после УТ
    gpaReal c_fix_temp_mix=1;


    //Теплообмен

    gpaReal pr_CC_gas;
    gpaReal nu_CC_gas;
    gpaReal alphaEG;
    gpaReal mRib;
    gpaReal eta;
    gpaReal psiRib;
    gpaReal kQCC;
    gpaReal kQRC;
    gpaReal alphaRC;
    gpaReal alphaCC;
    gpaReal sSideCC;
    gpaReal sSideRC;
    gpaReal LMTDRC;
    gpaReal LMTDCC;

    //Теплопроводность ребра
    gpaReal lambdaRib;

    gpaReal Delta_H_Gas_Fixed;// 
    gpaReal Delta_H_Oil_Fixed;// 

    //Перешедшее от газа к маслу тепло
    gpaReal Q;
    //Изменение энтальпии ТС 
    gpaReal Delta_H_Gas;
    //Изменение энтальпии ГМ
    gpaReal Delta_H_Oil;
    
    gpaReal P_in_gas;
    gpaReal P_out_gas;
    gpaReal P_in_oil;
    gpaReal P_out_oil;

    // Перепад давлений по маслу
    gpaReal deltaP_oil;
    // Перепад давлений по газу
    gpaReal deltaP_gas;

    // Коэффициент пропускания ДГ
    gpaReal part_flow_for_HE;

    // Массовый расход входящей ТС
    gpaReal m_dot_gas;
    // Массовый расход входящего ГМ
    gpaReal m_dot_oil;

    //Мольные расходы 
    gpaReal G_in_gas;
    gpaReal G_out_gas;
    gpaReal G_in_oil;
    gpaReal G_out_oil;

    //Массовые теплоемкости 
    gpaReal Cp_M_out_oil;
    gpaReal Cp_M_in_gas;
    gpaReal Cp_M_out_gas;
    gpaReal Cp_M_in_oil;    

    // Temperature
    gpaReal T_in_gas;
    gpaReal T_out_gas;

    gpaReal T_in_oil;
    gpaReal T_out_oil;

    gpaReal T_EG_after_HE;

    // Medium
    gpaMedium *m_medium_Gas;
    gpaMedium *m_medium_Oil;


    // Old
    gpaReal m_temperature = 0.0;
    gpaReal m_gasEnthalpy = 0.0;
    gpaReal m_liquidEnthalpy = 0.0;
    gpaReal m_liquidFlowRate = 0.0;

    //Показывает разницу консентраций компонент смеси на выходе и на входе
    // gpaDataVector delta_gas_fraction = {0.000740068, 0.164894, -0.0745216, 0.0804703, -0.171582};
    // // ("-" - сожгли метан и кислород, "+" - появилась вода и угл газ, доля озота поти неизменна)

    gpaDataVector delta_gas_fraction = {-0.0745216, 0.0804703, 0.164894, 0.000740068, -0.171582};
    // ("-" - сожгли метан и кислород, "+" - появилась вода и угл газ, доля озота поти неизменна)

public:
    static const gpaString &getDeviceTypeName();
    static const gpaString &getDeviceDescription();

private:
    static const gpaString m_typeName;
    static const gpaString m_description;
    static const gpaSensorInfoVector m_sensors;
};
#endif
