
#include "gpaInclude.h"
#include <gpaMedium.h>

#ifndef HEATTRANSFER_MODEL_H
#define HEATTRANSFER_MODEL_H

class DirectWallHeatTransfer
{
public:
    DirectWallHeatTransfer(gpaReal wall_resistance,
                          gpaReal inner_area,
                          gpaReal inner_htc,
                          gpaReal outer_area,
                          gpaReal outer_htc,
                          gpaReal environment_temp)
        : m_wall_resistance(wall_resistance),
          m_inner_area(inner_area),
          m_inner_htc(inner_htc),
          m_outer_area(outer_area),
          m_outer_htc(outer_htc),
          m_environment_temp(environment_temp)
    {
    }

    // Update environmental temperature
    void setEnvironmentTemperature(gpaReal environment_temp)
    {
        m_environment_temp = environment_temp;
    }

    // Calculate heat transfer rate (W), given inner temperature
    gpaReal calcQ(gpaReal inner_temp) const
    {
        gpaReal total_resistance = m_wall_resistance + 1.0 / (m_inner_htc * m_inner_area) + 1.0 / (m_outer_htc * m_outer_area);
        return (inner_temp - m_environment_temp) / total_resistance;
    }

private:
    gpaReal m_wall_resistance;  // Wall (solid) resistance
    gpaReal m_inner_area;       // Inner surface area
    gpaReal m_inner_htc;        // Inner heat transfer coefficient
    gpaReal m_outer_area;       // Outer surface area
    gpaReal m_outer_htc;        // Outer heat transfer coefficient
    gpaReal m_environment_temp; // Ambient/environmental temperature
};

class ArbitraryHeatTransfer
{
public:
ArbitraryHeatTransfer(gpaReal area, gpaReal htc)
        : m_area(area), m_htc(htc)
    {
    }

    // Calculate heat transfer rate (W), given inner temperature
    gpaReal calcQ(gpaReal inner_temp, gpaReal outer_temp) const
    {
        return m_area*m_htc*(inner_temp - outer_temp);
    }

private:
    gpaReal m_area;
    gpaReal m_htc;
};

class IntermediateWallHeatTransfer
{
public:
    IntermediateWallHeatTransfer(gpaReal inner_area,
                             gpaReal inner_htc,
                             gpaReal outer_area,
                             gpaReal outer_htc)
        : m_inner_area(inner_area),
          m_inner_htc(inner_htc),
          m_outer_area(outer_area),
          m_outer_htc(outer_htc)
    {
    }

    // Q (W): from inner medium through material (in)
    gpaReal calcQ_fromInner(gpaReal inner_temp, gpaReal material_temp) const
    {
        return m_inner_area * m_inner_htc * (inner_temp - material_temp);
    }

    // Q (W): from material through outer medium (out)
    gpaReal calcQ_fromMaterial(gpaReal material_temp, gpaReal outer_temp) const
    {
        return m_outer_area * m_outer_htc * (material_temp - outer_temp);
    }

private:
    gpaReal m_inner_area; // Area between "inner" medium and material
    gpaReal m_inner_htc;  // HTC between inner medium and material
    gpaReal m_outer_area; // Area between material and outside/outer medium
    gpaReal m_outer_htc;  // HTC between material and outer medium
};

class LMTDHeatTransfer
{
public:
    LMTDHeatTransfer(gpaReal resistance,
                      gpaReal environment_temp)
        : m_resistance(resistance),
          m_environment_temp(environment_temp)
    {
    }

    void setEnvironmentTemperature(gpaReal environment_temp)
    {
        m_environment_temp = environment_temp;
    }

    // Calculate Q using LMTD (W)
    // Th_in: hot fluid inlet temperature
    // Th_out: hot fluid outlet temperature
    // Tc_out: cold fluid outlet temperature (Tc_in is m_environment_temp)
    gpaReal calcQ(gpaReal hot_inlet_temp, gpaReal hot_outlet_temp) const
    {
        gpaReal cold_inlet_temp = m_environment_temp;
        gpaReal cold_outlet_temp = m_environment_temp;
        gpaReal deltaT1 = hot_inlet_temp - cold_outlet_temp;
        gpaReal deltaT2 = hot_outlet_temp - cold_inlet_temp;
        gpaReal lmtd = lmtd_calc(deltaT1, deltaT2);
        return lmtd/m_resistance;
    }

private:
    static gpaReal lmtd_calc(gpaReal deltaT1, gpaReal deltaT2)
    {
        if (std::abs(deltaT1 - deltaT2) < 1e-6)
            return deltaT1; // or deltaT2
        return (deltaT1 - deltaT2) / std::log(deltaT1 / deltaT2);
    }

    gpaReal m_resistance;      // Overall heat transfer coefficient (U)
    gpaReal m_environment_temp; // Environmental temp (cold fluid inlet)
};

#endif