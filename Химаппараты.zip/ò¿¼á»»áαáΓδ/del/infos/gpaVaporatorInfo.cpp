#include "gpaVaporatorInfo.h"
#include "gpaVaporator.h"

gpaVaporatorInfo::gpaVaporatorInfo() :
    gpaDeviceInfo  (gpaVaporator::getDeviceTypeName(),
                    gpaVaporator::getDeviceDescription())
{
    setParameters(gpaVaporator::getParametersInfo());
    setSensors(gpaVaporator::getSensorsInfo());
}

gpaUInt gpaVaporatorInfo::getNumMixCircuits() const
{
    return gpaVaporator::getDeviceNumMixCircuits();
}

gpaUInt gpaVaporatorInfo::getMinNumMixPorts(gpaUInt index) const
{
    return gpaVaporator::getDeviceMinNumMixPorts(index);
}

gpaUInt gpaVaporatorInfo::getMaxNumMixPorts(gpaUInt index) const
{
    return gpaVaporator::getDeviceMaxNumMixPorts(index);
}



const gpaString* gpaVaporatorInfo::getMixPortName(gpaUInt circIdx, gpaUInt portIdx) const
{
    return gpaVaporator::getDeviceMixPortName(circIdx, portIdx);
}

const gpaString* gpaVaporatorInfo::getMixCircuitName(gpaUInt index) const
{
    return gpaVaporator::getDeviceMixCircuitName(index);
}
gpaElement* gpaVaporatorInfo::createDevice(const gpaCoreInterfaces* interfaces, gpaCoreReference pairDevice,
                                             const gpaExtObjectModel* model) const
{
    gpaVaporator* cooler = new gpaVaporator(interfaces, pairDevice);
    gpaResult res = cooler->specifyModel(model);
    if (res == GPA_RESULT_OK)
        return cooler;
    delete cooler;
    return NULL;
}
