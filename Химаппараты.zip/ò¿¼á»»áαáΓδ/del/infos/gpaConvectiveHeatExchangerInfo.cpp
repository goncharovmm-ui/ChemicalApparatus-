#include "gpaConvectiveHeatExchangerInfo.h"
#include "gpaConvectiveHeatExchanger.h"


gpaConvectiveHeatExchangerInfo::gpaConvectiveHeatExchangerInfo() :
    gpaDeviceInfo  (gpaConvectiveHeatExchanger::getDeviceTypeName(),
                    gpaConvectiveHeatExchanger::getDeviceDescription())
{
    setParameters(gpaConvectiveHeatExchanger::getParametersInfo());
    setSensors(gpaConvectiveHeatExchanger::getSensorsInfo());
}

gpaUInt gpaConvectiveHeatExchangerInfo::getNumMixCircuits() const
{
    return gpaConvectiveHeatExchanger::getDeviceNumMixCircuits();
}

gpaUInt gpaConvectiveHeatExchangerInfo::getMinNumMixPorts(gpaUInt index) const
{
    return gpaConvectiveHeatExchanger::getDeviceMinNumMixPorts(index);
}

gpaUInt gpaConvectiveHeatExchangerInfo::getMaxNumMixPorts(gpaUInt index) const
{
    return gpaConvectiveHeatExchanger::getDeviceMaxNumMixPorts(index);
}
const gpaString *gpaConvectiveHeatExchangerInfo::getMixPortName(gpaUInt circIdx, gpaUInt portIdx) const
{
    return gpaConvectiveHeatExchanger::getDeviceMixPortName(circIdx, portIdx);
}

const gpaString *gpaConvectiveHeatExchangerInfo::getMixCircuitName(gpaUInt index) const
{
    return gpaConvectiveHeatExchanger::getDeviceMixCircuitName(index);
}



gpaElement* gpaConvectiveHeatExchangerInfo::createDevice(const gpaCoreInterfaces* interfaces, gpaCoreReference pairDevice,
                                             const gpaExtObjectModel* model) const
{
    gpaConvectiveHeatExchanger* cooler = new gpaConvectiveHeatExchanger(interfaces, pairDevice);
    gpaResult res = cooler->specifyModel(model);
    if (res == GPA_RESULT_OK)
        return cooler;
    delete cooler;
    return NULL;
}
