#include "gpaInclude.h"
#include "gpaVolumeShape.h"
#include <numbers>

constexpr gpaReal TOL = 1e-6;
constexpr int MAX_ITER = 100;

class gpaEllipseVerticalCylinder : public gpaVolumeShape {
public:
  gpaEllipseVerticalCylinder(const gpaVolumeElement *volume, gpaReal diameter,
                             gpaReal cylinderHeight, gpaReal headHeight)
      : gpaVolumeShape(volume), m_d(diameter), m_h(cylinderHeight),
        m_y(headHeight) {
    if (diameter <= 0 || cylinderHeight <= 0 || headHeight <= 0) {
    }
    m_R = vmSqrt(vmPower(m_y, 2) + vmPower(m_d, 2) / 2 +
                 vmPower(m_d, 4) / 16 / vmPower(m_y, 2)) /
          2;
  }

  gpaVolumeShape *copy() const override {
    return new gpaEllipseVerticalCylinder(*this);
  }

  gpaReal getHeight() const override { return m_h + 2 * m_y; }

  gpaReal getTotalArea() const override {
    return getBottomArea() + getTopArea() + getSideArea();
  }

  gpaReal getBottomArea() const override {
    return std::numbers::pi * vmPower(m_d / 2, 2);
  }

  gpaReal getTopArea() const override {
    return std::numbers::pi * vmPower(m_d / 2, 2);
  }

  gpaReal getSideArea() const override {
    gpaReal R = (vmPower(m_y, 2) + vmPower(m_d / 2, 2)) / (2 * m_y);
    gpaReal headArea = 2 * std::numbers::pi * R * m_y;
    gpaReal cylinderArea = std::numbers::pi * m_d * m_h;
    return cylinderArea + 2 * headArea;
  }

  bool checkHeight(gpaReal height) const {
    return (height > 0) && (height < getHeight());
  }

  gpaReal getPerimeterAt(gpaReal height) const override {
    if (!checkHeight(height))
      return 0;

    if (height <= m_y) {
      gpaReal a = (m_d / 2) * std::sqrt(1 - vmPower(height / m_y, 2));
      return 2 * std::numbers::pi * a;
    } else if (height <= m_y + m_h) {
      return std::numbers::pi * m_d;
    } else {
      gpaReal h_upper = getHeight() - height;
      gpaReal a = (m_d / 2) * std::sqrt(1 - vmPower(h_upper / m_y, 2));
      return 2 * std::numbers::pi * a;
    }
  }

  gpaReal getSliceAreaAt(gpaReal height) const override {
    if (!checkHeight(height))
      return 0;

    if (height <= m_y) {
      gpaReal a = (m_d / 2) * std::sqrt(1 - vmPower(height / m_y, 2));
      return std::numbers::pi * a * a;
    } else if (height <= m_y + m_h) {
      return std::numbers::pi * vmPower(m_d / 2, 2);
    } else {
      gpaReal h_upper = getHeight() - height;
      gpaReal a = (m_d / 2) * std::sqrt(1 - vmPower(h_upper / m_y, 2));
      return std::numbers::pi * a * a;
    }
  }

  gpaReal getSideAreaAt(gpaReal height) const override {
    if (!checkHeight(height))
      return 0;

    if (height <= m_y) {
      return 2 * std::numbers::pi * m_R * height;
    } else if (height <= m_y + m_h) {
      gpaReal headArea = 2 * std::numbers::pi * m_R * m_y;
      gpaReal cylinderArea = std::numbers::pi * m_d * (height - m_y);
      return headArea + cylinderArea;
    } else {
      gpaReal headArea = 2 * std::numbers::pi * m_R * m_y;
      gpaReal cylinderArea = std::numbers::pi * m_d * m_h;
      gpaReal h_upper = getHeight() - height;
      gpaReal upperHeadArea = 2 * std::numbers::pi * m_R * h_upper;
      return headArea + cylinderArea + upperHeadArea;
    }
  }

  gpaReal getVolume() const override {
    gpaReal V_cyl = std::numbers::pi * vmPower(m_d, 2) * m_h / 4.0;
    gpaReal V_head = std::numbers::pi * vmPower(m_y, 2) * (m_R - m_y / 3);
    return V_cyl + 2 * V_head;
  }

  gpaReal getVolumeAt(gpaReal height) const override {
    if (!checkHeight(height))
      return 0;

    if (height <= m_y) {
      return (std::numbers::pi * vmPower(m_d, 2) * vmPower(height, 2) *
              (3 * m_y - height)) /
             (12 * vmPower(m_y, 2));
    } else if (height <= m_y + m_h) {
      gpaReal V_head = std::numbers::pi * vmPower(m_y, 2) * (m_R - m_y / 3);
      gpaReal V_cyl_part =
          std::numbers::pi * vmPower(m_d, 2) * (height - m_y) / 4.0;
      return V_head + V_cyl_part;
    } else {
      gpaReal V_head = std::numbers::pi * vmPower(m_y, 2) * (m_R - m_y / 3);
      gpaReal V_cyl = std::numbers::pi * vmPower(m_d, 2) * m_h / 4.0;
      gpaReal h_upper = getHeight() - height;
      gpaReal V_upper_head = (std::numbers::pi * vmPower(m_d, 2) *
                              vmPower(h_upper, 2) * (3 * m_y - h_upper)) /
                             (12 * vmPower(m_y, 2));
      return V_head + V_cyl + V_upper_head;
    }
  }

  gpaReal getLevelFor(gpaReal volume) const override {
    if (volume == getVolume())
      return getHeight();
    if (!checkVolume(volume))
      return 0;

    gpaReal V_head_full = std::numbers::pi * vmPower(m_y, 2) * (m_R - m_y / 3);
    gpaReal V_cyl_full = std::numbers::pi * vmPower(m_d, 2) * m_h / 4.0;
    gpaReal V_total = V_head_full + V_cyl_full + V_head_full;

    if (volume <= V_head_full) {
      return solveCubicVolume(volume, m_y);
    } else if (volume <= V_head_full + V_cyl_full) {
      return m_y + (volume - V_head_full) /
                       (std::numbers::pi * vmPower(m_d, 2) / 4.0);
    } else if (volume <= V_total) {
      gpaReal h_upper =
          solveCubicVolume(volume - V_head_full - V_cyl_full, m_y);
      return m_y + m_h + h_upper;
    } else {
      return getHeight();
    }
  }

private:
  gpaReal solveCubicVolume(gpaReal volume, gpaReal y) const {
    gpaReal K =
        (12 * vmPower(y, 2) * volume) / (std::numbers::pi * vmPower(m_d, 2));
    gpaReal h =
        y * std::cbrt(volume / (std::numbers::pi * vmPower(m_d, 2) * y / 6.0));

    for (int i = 0; i < MAX_ITER; ++i) {
      gpaReal f = 3 * y * vmPower(h, 2) - vmPower(h, 3) - K;
      if (std::abs(f) < TOL)
        break;

      gpaReal df = 6 * y * h - 3 * vmPower(h, 2);
      if (std::abs(df) < TOL)
        break;

      gpaReal delta = f / df;
      h -= delta;

      if (h < 0)
        h = 0;
      if (h > y)
        h = y;
    }
    return h;
  }

  gpaReal m_d; // Внутренний диаметр (м)
  gpaReal m_h; // Высота цилиндрической части (м)
  gpaReal m_y; // Высота днища (м)
  gpaReal m_R; //  (м)
};
