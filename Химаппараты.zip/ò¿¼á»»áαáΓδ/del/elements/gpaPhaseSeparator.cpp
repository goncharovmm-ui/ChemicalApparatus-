#include "gpaInclude.h"
#include "gpaPhaseSeparator.h"

const gpaString gpaPhaseSeparator::m_typeName     = "flow-separator";
const gpaString gpaPhaseSeparator::m_description  = "Идеальное ";