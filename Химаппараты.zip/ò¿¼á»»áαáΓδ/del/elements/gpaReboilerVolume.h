/*!
 *  \file      gpaReboilerVolume.h
 *  \brief     Класс для описания однослойного объемного элемента
 *  \author    Мельников Роман
 *  \date      2025
 */
#ifndef GPA_REBOILER_VOLUME_H
#define GPA_REBOILER_VOLUME_H

#include "gpaHeatLayer.h"
#include "gpaInclude.h"
#include "gpaMedium.h"
#include "gpaVolumeElement.h"
#include <memory>

/*!
 * \class gpaReboilerVolume
 * \brief Класс, реализующий однослойный объемный элемента
 */
class gpaReboilerVolume : public gpaVolumeElement {
public:
  /*!
   * Конструктор по умолчанию
   * \param link ссылки на родительские контейнеры
   */
  gpaReboilerVolume(const gpaParentLink *link = NULL);
  /*!
   * Конструктор копирования
   * \param volume объемный элемент для копирования
   */
  gpaReboilerVolume(const gpaReboilerVolume &volume);
  /*!
   * Деструктор по умолчанию
   */
  virtual ~gpaReboilerVolume() override;
  /*!
   * Функция копирования объемного элемента
   * \return скопированный объемный элемент
   */
  virtual gpaReboilerVolume *copy() const override;
  /*!
   * Получить название типа элемента
   * \return название типа элемента
   */
  virtual const gpaString &getTypeName() const override {
    return getDeviceTypeName();
  }
  /*!
   * Получить описание элемента
   * \return описание элемента
   */
  virtual const gpaString &getDescription() const override {
    return getDeviceDescription();
  }
  /*!
   * Функция получения минимального количества портов в материальном контуре
   * элемента
   * \param index индекс контура
   * \return минимальное количество портов
   */
  virtual gpaUInt getMinNumMixPorts(gpaUInt index) const override;
  /*!
   * Функция получения максимального количества портов в материальном контуре
   * элемента
   * \param index индекс контура
   * \return максимальное количество портов
   */
  virtual gpaUInt getMaxNumMixPorts(gpaUInt index) const override;
  /*!
   * Задать начальное значение давления
   * \param initPressure начальное значение давления
   * \return флаг успеха назначения параметра
   */
  bool setInitPressure(gpaReal initPressure);
  /*!
   * Задать начальную объёмную долю жидкости
   * \param volumeFraction начальное значение объёмной доли жидкости
   * \return флаг успеха назначения параметра
   */
  bool setInitLiqVolumeFraction(gpaReal volumeFraction);
  /*!
   * Задать начальное значение температуры
   * \param initTemperature начальное значение температуры
   * \return флаг успеха назначения параметра
   */
  bool setInitTemperature(gpaReal initTemperature);
  /*!
   * Задать начальные значения мольных долей компонентов смеси
   * \param fractions начальные значения мольных долей компонентов смеси
   * \return флаг успеха назначения параметра
   */
  bool setInitFractions(const gpaConstVector &fractions);
  /*!
   * Получить значение давления на определенном уровне [кПа]
   * \param level уровень (высота)
   * \return значение давления на определенном уровне [кПа]
   */
  virtual gpaReal getPressureAt(gpaReal level) const override;
  /*!
   * Получить значение температуры на определенном уровне [К]
   * \param level уровень (высота)
   * \return значение температуры на определенном уровне [К]
   */
  virtual gpaReal getTemperatureAt(gpaReal level) const override;
  /*!
   * Получить значение молярной массы для линейной комбинации равновесных фаз
   * для заданной объемной доли газа [кг/кмоль]
   * \param gasVolumeFraction заданная объемная доля газа в среде
   * \return значение молярной массы для линейной комбинации равновесных фаз для
   * заданной объемной доли газа [кг/кмоль]
   */
  virtual gpaReal getMolarMassFor(gpaReal gasVolumeFraction) const override;
  /*!
   * Получить значение удельной мольной энтальпии для линейной комбинации
   * равновесных фаз для заданной объемной доли газа [кДж/кмоль]
   * \param gasVolumeFraction заданная объемная доля газа в среде
   * \return значение удельной мольной энтальпии для линейной комбинации
   * равновесных фаз для заданной объемной доли газа [кДж/кмоль]
   */
  virtual gpaReal getEnthalpyFor(gpaReal gasVolumeFraction) const override;
  /*!
   * Получить значение плотности для линейной комбинации равновесных фаз для
   * заданной объемной доли газа [кг/м3]
   * \param gasVolumeFraction заданная объемная доля газа в среде
   * \return значение плотности для линейной комбинации равновесных фаз для
   * заданной объемной доли газа [кг/м3]
   */
  virtual gpaReal getDensityFor(gpaReal gasVolumeFraction) const override;
  /*!
   * Получить значение вязкости для линейной комбинации равновесных фаз для
   * заданной объемной доли газа [Па*с]
   * \param gasVolumeFraction заданная объемная доля газа в среде
   * \return значение вязкости для линейной комбинации равновесных фаз для
   * заданной объемной доли газа [Па*с]
   */
  virtual gpaReal getViscosityFor(gpaReal gasVolumeFraction) const override;
  /*!
   * Получить значение коэффициента теплопередачи для жидкости [Вт/(м^2*K)]
   * \return значение коэффициента теплопередачи для жидкости [Вт/(м^2*K)]
   */
  virtual gpaReal getLiquidHeatTransferCoef() const override {
    return m_alpha_first_liq;
  }
  /*!
   * Получить значение коэффициента теплопередачи для газа [Вт/(м^2*K)]
   * \return значение коэффициента теплопередачи для газа [Вт/(м^2*K)]
   */
  virtual gpaReal getGasHeatTransferCoef() const override {
    return m_alpha_first_gas;
  }
  /*!
   * Получить значения мольных долей на выходе
   * \param fractions мольные доли на выходе
   * \param gasVolumeFraction объемная доля газа в смеси
   * \return значение мольных долей на выходе
   */
  virtual void getFractionsFor(gpaDataVector &fractions,
                               gpaReal gasVolumeFraction) const override;
  /*!
   * Получить значение уровня жидкости
   * \return значение уровня жидкости
   */
  virtual gpaReal getLiquidLevel() const override { return m_firstLiquidLevel; }

  virtual gpaReal getLiquidVolume() const override;

  virtual const gpaMedium *getMedium() const override { return m_firstMedium; };

  virtual const gpaMedium *getLiquidMedium() const { return m_firstMedium; };

  virtual const gpaMedium *getGasMedium() const { return m_secondMedium; };

  virtual gpaReal getTransitionLevel(gpaReal level,
                                     gpaReal radius) const override;

  virtual gpaReal getTransitionRadius(gpaReal level,
                                      gpaReal radius) const override;

  /*!
   * Получить значение EnthalpySum
   * \return значение EnthalpySum
   */
  gpaReal getEnthalpySum() const;
  /*!
   * Получить значение MolesSum
   * \return значение MolesSum
   */
  gpaReal getMolesSum() const;
  /*!
   * Получить значение PartitionFlowRate
   * \return значение PartitionFlowRate
   */
  gpaReal getPartitionFlowRate() const;
  /*!
   * Получить значение размерности
   * \return значение размерности
   */
  virtual gpaUInt getNumVariables() const override;
  bool calcHeatTransferProperties();
  /*!
   * Заполнить названия неизвестных
   * \param [out] varNames названия неизвестных
   */
  virtual void fillVarNames(gpaStringVector &varNames) const override;
  /*!
   * Инициализировать камеру и ее параметры для расчета
   * \return код операции
   */
  virtual gpaResult initialize() override;
  /*!
   * Заполнить матрицу масс камеры
   * \param refRow первая строка подматрицы
   * \param refCol первый столбец подматрицы
   * \return код ошибки
   */
  virtual gpaResult fillMassMatrix(gpaUInt refRow,
                                   gpaUInt refCol) const override;
  /*!
   * Инициализировать решение заданным вектором
   * \param [out] variables вектор неизвестных
   * \return код ошибки
   */
  virtual gpaResult initVariables(gpaVector &variables) const override;
  /*!
   * Рассчитать значения функций правых частей
   * \param [in] states вектор состояний
   * \param [in] variables вектор неизвестных
   * \param [out] values вектор значений функций правых частей
   * \return код операции
   */
  virtual gpaResult calcFuncValues(const gpaConstVector &states,
                                   const gpaConstVector &variables,
                                   gpaVector &values,
                                   const gpaSetOfEquations &eqIds) override;
  bool isFirstSectionPort(gpaUInt portID) const;
  gpaReal calcPressureGradient(gpaReal Q, gpaMedium *medium);
  std::pair<gpaDataVector, gpaReal> calcFlowsInterphase(gpaReal firstMoles,
                                                        gpaReal secondMoles);
  /*!
   * Получить невязку уравнения для удельной мольной энтальпии для заданного
   * порта материального потока
   * \param circIdx индекс материального контура
   * \param portIdx индекс порта материального потока
   * \param enthalpy текущее значение энтальпии (относительно которого требуется
   * невязка)
   * \param [out] funcValue значение невязки уравнения для удельной мольной
   * энтальпии для заданного порта материального потока
   * \param код операции
   */
  virtual gpaResult calcEnthalpyFuncValueAt(gpaUInt circIdx, gpaUInt portIdx,
                                            gpaReal enthalpy,
                                            gpaReal &funcValue) const override;
  /*!
   * Получить невязки уравнений для мольных долей компонентов смеси для
   * заданного порта материального потока
   * \param circIdx индекс материального контура
   * \param portIdx индекс порта материального потока
   * \param fractions текущие значения мольных долей компонентов (относительно
   * которых требуется невязка)
   * \param [out] funcValues вектор невязок уравнений для мольных долей
   * компонентов смеси для заданного порта материального потока
   * \param код операции
   */
  virtual gpaResult
  calcFractionsFuncValuesAt(gpaUInt circIdx, gpaUInt portIdx,
                            const gpaConstVector &fractions,
                            gpaVector &funcValues) const override;

  bool setPartitionProperties(gpaReal partitionHeight, gpaReal tauDiff,
                                 gpaReal tauLiq, gpaReal tauLiqDiff,
                                 gpaReal liqDiffFlowrate);

  bool addIsolationLayer(gpaHeatLayer layer);

  bool setGasHeatTransferCoeff(gpaReal alpha_in_gas);

  bool setLiquidHeatTransferCoeff(gpaReal alpha_in_liq);

  bool setWallParameters(gpaReal heatCapacity, gpaReal density);

  bool setAmbientTemperature(gpaReal T_out);

  bool setMixHeatTransferParams(gpaReal alpha_in_gas, gpaReal alpha_in_liq);

  bool setShellMixHeatTransferParams(gpaReal alpha_in_shell,
                                        gpaReal alpha_in_gas,
                                        gpaReal alpha_in_liq);

  bool setShellParameters(gpaReal roughness, gpaReal minHeight,
                             gpaReal maxHeight, gpaReal diameter,
                             gpaReal heightDiff, gpaReal thickness,
                             gpaReal length, gpaUInt numPipes);

  bool setGeometryParameters(gpaReal cylynderLength, gpaReal cylynderHeight,
                                gpaReal minorCylynderLength,
                                gpaReal minorCylynderHeight, gpaReal thickness);

  bool setInitSecondFractions(const gpaConstVector &fractions);

  bool setInitFirstFractions(const gpaConstVector &fractions);

  virtual gpaUInt getNumMixCircuits() const override { return 2; }

protected:
  /*!
   * Освободить текущую среду
   */
  void finalizeMedium();
  /*!
   * Рассчитать внутренний параметры камеры
   */
  void updateLiquidLevel(gpaReal mixMoles);

  bool aboveLiquidSurface(gpaReal level) const;

private:
  //! Флаг отсчет гидростатики от крышки
  bool m_topHydroStatic;
  //! Заданная среда
  gpaMedium *m_firstMedium;
  gpaMedium *m_secondMedium;
  //! Внутренняя энергия
  gpaReal m_secondEnthalpy;
  //! Внутренняя энергия
  gpaReal m_firstEnthalpy;
  //! Количество вещества
  gpaReal m_secondMoles;
  //! Количество вещества
  gpaReal m_firstMoles;
  //! расход испарения
  gpaReal m_partitionFlowRate;
  //! Начальное давление
  gpaReal m_initPressure;
  //! Начальная температура
  gpaReal m_initTemperature;
  //! Начальные мольные доли
  gpaDataVector m_firstFractions;
  gpaDataVector m_secondFractions;
  //! Уровень жидкости
  gpaReal m_firstLiquidLevel;
  gpaReal m_secondLiquidLevel;
  //! Вектор сохраненных неизвестных
  gpaDataVector m_savedVariables;
  //! начальное отношение объёма жидкости к газу
  gpaReal m_initLiqVolumeFraction;

  gpaReal m_tauDiff;         // Характерное время диффузии газа, с
  gpaReal m_tauLiq;          // Характерное время перелива жидкости, с
  gpaReal m_tauLiqDiff;      // Характерное время диффузии жидкости, с
  gpaReal m_liqDiffFlowrate; // Диффузионный поток жидкости, моль/с
  gpaReal m_partitionHeight;
  gpaReal m_Cm_wall;
  gpaReal m_Cm_shell;
  gpaHeatLayerVector m_isolationLayers;
  gpaHeatLayer m_wallLayer;
  // =========
  gpaReal m_shellRoughness;
  gpaReal m_shellMinHeight;
  gpaReal m_shellMaxHeight;
  gpaReal m_shellDiameter;
  gpaReal m_shellHeightDiff;
  gpaReal m_shellThickness;
  gpaReal m_shellLength;
  gpaUInt m_shellNumPipes;
  // =========
  gpaReal m_thickness;
  gpaReal m_minorCylynderHeight;
  gpaReal m_cylynderHeight;
  gpaReal m_cylynderLength;
  gpaReal m_minorCylynderLength;
  // =========
  gpaReal m_density;
  gpaReal m_heatCapacity; // Wall heat capacity
  gpaReal m_A_in_shell;   // Inner heat transfer area
  gpaReal m_A_out_shell;  // Inner heat transfer area
  gpaReal m_A_in_first;
  gpaReal m_A_in_second;
  gpaReal m_A_out_first;
  gpaReal m_A_out_second;
  gpaReal m_alpha_first_gas;  // Gas heat transfer coeff
  gpaReal m_alpha_second_gas; // Gas heat transfer coeff
  gpaReal m_alpha_first_liq;  // Liquid heat transfer coeff
  gpaReal m_alpha_second_liq; // Liquid heat transfer coeff
  gpaReal m_alpha_shell_gas;  // Gas heat transfer coeff
  gpaReal m_alpha_shell_liq;  // Gas heat transfer coeff
  gpaReal m_alpha_out_shell_gas;
  gpaReal m_alpha_out_shell_liq;
  gpaReal m_alpha_in_shell;
  gpaReal m_T_env; // Ambient temperature
  gpaByte m_portLocation;

  struct Indices {
    const vmUInt n; // Number of components

    // Variable indices
    const vmUInt PRESSURE;
    const vmUInt FIRST_ENTHALPY;
    const vmUInt FIRST_FRAC_START;
    const vmUInt SECOND_ENTHALPY;
    const vmUInt SECOND_FRAC_START;
    const vmUInt WALL_TEMP;
    const vmUInt SHELL_TEMP;
    const vmUInt DELTA_PRES;
    const vmUInt NUM_VARS;

    // Equation indices
    const vmUInt VOLUME_BALANCE;
    const vmUInt FIRST_ENTHALPY_EQ;
    const vmUInt FIRST_COMP_START;
    const vmUInt SECOND_ENTHALPY_EQ;
    const vmUInt SECOND_COMP_START;
    const vmUInt WALL_TEMP_EQ;
    const vmUInt SHELL_TEMP_EQ;
    const vmUInt FLOWRATE_EQ;
    const vmUInt PRESSURE_EQ;
    const vmUInt DELTA_PRES_EQ;
    const vmUInt NUM_EQNS;

    Indices(vmUInt numComponents)
        : n(numComponents),
          // Variable indices
          PRESSURE(0), FIRST_ENTHALPY(1), FIRST_FRAC_START(2),
          SECOND_ENTHALPY(FIRST_FRAC_START + n),
          SECOND_FRAC_START(SECOND_ENTHALPY + 1),
          WALL_TEMP(SECOND_FRAC_START + n), SHELL_TEMP(WALL_TEMP + 1),
          DELTA_PRES(SHELL_TEMP + 1), NUM_VARS(DELTA_PRES + 1),
          // Equation indices
          VOLUME_BALANCE(0), FIRST_ENTHALPY_EQ(1), FIRST_COMP_START(2),
          SECOND_ENTHALPY_EQ(FIRST_COMP_START + n),
          SECOND_COMP_START(SECOND_ENTHALPY_EQ + 1),
          WALL_TEMP_EQ(SECOND_COMP_START + n), SHELL_TEMP_EQ(WALL_TEMP_EQ + 1),
          FLOWRATE_EQ(SHELL_TEMP_EQ + 1), PRESSURE_EQ(FLOWRATE_EQ + 1),
          DELTA_PRES_EQ(PRESSURE_EQ + 1), NUM_EQNS(DELTA_PRES_EQ + 1) {}
  };

  mutable std::unique_ptr<Indices> idx;

  const Indices &getIndices() const {
    if (!idx) {
      gpaUInt numFractions = m_firstFractions.size();
      idx = std::make_unique<Indices>(numFractions);
    }
    return *idx;
  }

public:
  /*!
   * Получить название типа элемента
   * \return название типа элемента
   */
  static const gpaString &getDeviceTypeName() { return m_typeName; }
  /*!
   * Получить описание элемента
   * \return описание элемента
   */
  static const gpaString &getDeviceDescription() { return m_description; }

  static gpaUInt getDeviceNumMixCircuits() { return 2; }

private:
  //! Название элемента
  static const gpaString m_typeName;
  //! Описание элемента
  static const gpaString m_description;
};

#endif
