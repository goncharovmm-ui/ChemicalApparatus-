
#ifndef GPA_PHASE_SEPARATOR_H
#define GPA_PHASE_SEPARATOR_H
#include "gpaFlowElement.h"
#include "gpaFlowHeatCoef.h"
#include "gpaHeatCoeffPrm.h"
#include "gpaHeatLayer.h"
#include "gpaInclude.h"
#include <iostream>
#include <numbers>

class gpaPhaseSeparator : public gpaFlowElement {
public:
  gpaPhaseSeparator(const gpaParentLink *link)
      : m_gasEnthalpy(0), m_liquidEnthalpy(0), m_liquidFlowRate(0),
        m_temperature(0) {
    m_d = 0.5;
    m_l = 2.0;
    m_dh = 0.3;
    m_nBends = 2;
    m_eps = 0.0001;
    m_Tenv = 293.15;
    m_heatLayers.push_back(gpaHeatLayer{0.02, 7800, 16.0, 460});
    m_alpha_in_pipe = m_alpha_out_pipe = m_alpha_in_gas = m_alpha_out_gas =
        100.0;
    calcThermalParams();
  }

  gpaPhaseSeparator(const gpaPhaseSeparator &separator) {
    m_gasEnthalpy = separator.m_gasEnthalpy;
    m_liquidEnthalpy = separator.m_liquidEnthalpy;
    m_liquidFlowRate = separator.m_liquidFlowRate;
    m_temperature = separator.m_temperature;
    m_d = separator.m_d;
    m_l = separator.m_l;
    m_dh = separator.m_dh;
    m_nBends = separator.m_nBends;
    m_eps = separator.m_eps;
    m_Tenv = separator.m_Tenv;
    m_heatLayers = separator.m_heatLayers;

    m_alpha_in_pipe = separator.m_alpha_in_pipe;
    m_alpha_out_pipe = separator.m_alpha_out_pipe;
    m_alpha_in_gas = separator.m_alpha_in_gas;
    m_alpha_out_gas = separator.m_alpha_out_gas;
    calcThermalParams();
  }

  virtual gpaPhaseSeparator *copy() const override {
    return new gpaPhaseSeparator(*this);
  }

  enum {
    DELTA_PRES_PIPE = 0,
    DELTA_PRES_GAS = 1,
    TEMPERATURE_IN_PIPE = 2,
    TEMPERATURE_OUT_PIPE = 3,
    TEMPERATURE_IN_GAS = 4,
    TEMPERATURE_OUT_GAS = 5
  };

  virtual gpaUInt getMinNumMixPorts(gpaUInt index) const override {
    return getDeviceMinNumMixPorts(index);
  }
  static gpaUInt getDeviceMinNumMixPorts(gpaUInt index) {
    return index == GPA_ELEM_CIRCUIT_0 ? 2 : 0;
  }

  virtual gpaUInt getMaxNumMixPorts(gpaUInt index) const override {
    return getDeviceMaxNumMixPorts(index);
  }
  static gpaUInt getDeviceMaxNumMixPorts(gpaUInt index) {
    return index == GPA_ELEM_CIRCUIT_0 ? 2 : 0;
  }

  gpaUInt getNumVariables() const override { return 1; }

  gpaResult initialize() override {
    const gpaMedium *medium = getCircuitMedium();
    if (!medium)
      return GPA_ERROR_WRONG_ARGS;

    m_medium = medium->copyTo(asOwner());
    m_temperature = medium->getTemperature();
    m_gasEnthalpy = medium->getGasEnthalpy();
    m_liquidEnthalpy = medium->getLiquidEnthalpy();
    m_liquidFlowRate = 0;
    m_gasFractions.assign(medium->getGasFractions());
    m_liquidFractions.assign(medium->getLiquidFractions());
    return GPA_RESULT_OK;
  }

  void fillVarNames(gpaStringVector &varNames) const override {
    //    varNames[DELTA_PRES_PIPE] = getName() + GPA_VAR_POINTER + "p_pipe";
    //       varNames[DELTA_PRES_GAS] = getName() + GPA_VAR_POINTER + "p_gas";
    //      varNames[TEMPERATURE_IN_PIPE] = getName() + GPA_VAR_POINTER +
    //      "T_in_pipe"; varNames[TEMPERATURE_OUT_PIPE] = getName() +
    //      GPA_VAR_POINTER + "T_out_pipe"; varNames[TEMPERATURE_IN_GAS] =
    //      getName() + GPA_VAR_POINTER + "T_in_gas";
    //      varNames[TEMPERATURE_OUT_GAS] = getName() + GPA_VAR_POINTER +
    //      "T_out_gas";
  }

  gpaResult initVariables(gpaVector &variables) const override {
    variables[DELTA_PRES_PIPE] = 0.00;
    //       variables[DELTA_PRES_GAS] = 1;
    //       variables[TEMPERATURE_IN_PIPE] = m_temperature;
    //        variables[TEMPERATURE_OUT_PIPE] = m_temperature;
    //       variables[TEMPERATURE_IN_GAS] = m_temperature;
    //      variables[TEMPERATURE_OUT_GAS] = m_temperature;

    return GPA_RESULT_OK;
  }

  // Невязка по энергии
  //    gpaResult calcEnthalpyFuncValueAt(gpaUInt, gpaUInt portIdx, gpaReal
  //    enthalpy, gpaReal &funcValue) const override
  //   {
  //        switch (portIdx)
  //        {
  //        case 1:
  //            funcValue = m_gasEnthalpy - enthalpy;
  //            break; // gas out
  //        case 2:
  //            funcValue = m_liquidEnthalpy - enthalpy;
  //            break; // liquid out
  //        default:
  //            funcValue = 0.0;
  //        }
  //        printf("Enthalpy %d: %f\n", portIdx, funcValue);
  //        return GPA_RESULT_OK;
  //    }

  // Невязка по компонентам — для выходных портов сравниваем с переменными
  // разделителя
  //    gpaResult calcFractionsFuncValuesAt(gpaUInt, gpaUInt portIdx, const
  //    gpaConstVector &fractions, gpaVector &funcValues) const override
  //    {
  //        const gpaUInt n = m_gasFractions.size();
  //        switch (portIdx)
  //        {
  //        case 1: // Газ
  //            for (gpaUInt i = 0; i < n; ++i)
  //                funcValues[i] = m_gasFractions[i] - fractions[i];
  //            break;
  //        case 2: // Жидкость
  //            for (gpaUInt i = 0; i < n; ++i)
  //                funcValues[i] = m_liquidFractions[i] - fractions[i];
  //            break;
  //        default:
  //            for (gpaUInt i = 0; i < n; ++i)
  //                funcValues[i] = 0;
  //        }
  //        printf("Fractions %d\n", portIdx);
  //        for (gpaUInt i = 0; i < n; ++i)
  //            printf("%f--", funcValues[i]);
  //        printf("\n");
  //        return GPA_RESULT_OK;
  //    }
  // Главная функция: полный набор уравнений для "стрелок" и фазового равновесия
  gpaReal calcPressureGradient0(gpaReal Q, gpaMedium *medium) {
    gpaReal density = medium->getDensity();
    gpaReal viscosity = medium->getViscosity();
    gpaReal V = Q / (std::numbers::pi * std::numbers::pi * m_d / 4.0);
    gpaReal Re = density * std::abs(V) * m_d / viscosity;

    gpaReal F1 = 16 * Re;
    gpaReal F3 = 0.07716 * Re * Re /
                 std::pow(std::log10(6.9 / (Re + 1e-9) +
                                     vmPower(m_eps / 3.7 / m_d, 1.11)),
                          2);

    gpaReal F2 = F1 + (Re - 2300.0) / 1700.0 * (F3 - F1);

    gpaReal X1 = (Re - 2300.0) / 300.0;
    gpaReal X2 = (Re - 4000.0) / 300.0;

    gpaReal f =
        (F1 * (1 - sigmoid(X1)) + F2 * sigmoid(X1)) * (1 - sigmoid(X2)) +
        F3 * sigmoid(X2);

    gpaReal length = m_l;

    gpaReal friction_dp =
        f * viscosity * viscosity * length / 2.0 / density / std::pow(m_d, 3);

    gpaReal dp =
        GPA_GRAVITY_ACCELERATION * m_dh * density / GPA_KILOPASCAL_TO_PASCAL +
        friction_dp * ((V > 0) ? 1 : ((V < 0) ? -1 : 0));

    gpaReal dp_bends = 1 * 0.04 * density * vmPower(V, 2) / 2;

    return dp + dp_bends;
  }

  gpaResult calcFuncValues(const gpaConstVector &,
                           const gpaConstVector &variables, gpaVector &values,
                           const gpaSetOfEquations &eqIds) override {

    auto *circuit = getMixCircuit(GPA_ELEM_CIRCUIT_0);
    const gpaMixPort *inlet = circuit->getPort(0);
    const gpaMixPort *gasOut = circuit->getPort(1);
    m_medium = inlet->getStreamMedium()->copyTo(asOwner());
    gpaReal steamContent = inlet->getStreamMedium()->getSteamContent();

    gpaResult res = m_medium->calcFlashPT(gasOut->getStreamPressure(),
                                          inlet->getStreamTemperature(),
                                          m_medium->getGasFractions());
    gpaReal G_in = inlet->getIncomingFlowRate();
    gpaReal G_out = gasOut->getIncomingFlowRate();
    gpaReal liquidFlowRate =
        G_in * (1 - inlet->getStreamMedium()->getSteamContent());
    m_liquidFlowRate = liquidFlowRate > 0 ? liquidFlowRate : 0;

    gpaReal volFlowRate = G_in * inlet->getIncomingVolRate();
    gpaReal dp_calc_pipe = calcPressureGradient(inlet->getIncomingVolRate(),
                                                inlet->getStreamMedium());
    gpaReal dp_calc_gas = calcPressureGradient(
        inlet->getIncomingVolRate() * steamContent, m_medium);
    //  gpaReal liquidFlowRate = G_in * 0.5;

    gpaReal deltaPres =
        inlet->getStreamPressure() - gasOut->getStreamPressure();
    //   values[0]= variables[DELTA_PRES_PIPE]-dp_calc_pipe;
    m_Qout = variables[0];
    values[0] = G_in + G_out - m_liquidFlowRate;
    values[1] = deltaPres - dp_calc_pipe - dp_calc_gas;
    values[2] = variables[0] -
                (m_heatCoef1->Tsr - inlet->getStreamTemperature()) * calcRmat();
    return GPA_RESULT_OK;
  }

  gpaResult calcEnthalpyFuncValueAt(gpaUInt circIdx, gpaUInt portIdx,
                                    gpaReal enthalpy,
                                    gpaReal &funcValue) const override {
    if (circIdx != GPA_ELEM_CIRCUIT_0)
      return GPA_ERROR_WRONG_ARGS;
    const gpaMixPort *oppPort = getOppositePort(portIdx);
    if (!oppPort)
      return GPA_ERROR_WRONG_ARGS;
    gpaReal G = vmAbs(oppPort->getIncomingFlowRate());
    if (G < 1.e-6) {
      funcValue = enthalpy - oppPort->getStreamMedium()->getGasEnthalpy();
    } else {
      funcValue =
          (enthalpy - oppPort->getStreamMedium()->getGasEnthalpy()) * G -
          m_Qout;
    }

    // funcValue = enthalpy -
    // oppPort->getStreamMedium()->getGasEnthalpy()-m_Qout/;
    printf("Enthalpy %d: %f\n", portIdx, funcValue);
    return GPA_RESULT_OK;
  }

  // Невязка по компонентам — для выходных портов сравниваем с переменными
  // разделителя
  gpaResult calcFractionsFuncValuesAt(gpaUInt circIdx, gpaUInt portIdx,
                                      const gpaConstVector &fractions,
                                      gpaVector &funcValues) const override {
    if (circIdx != GPA_ELEM_CIRCUIT_0)
      return GPA_ERROR_WRONG_ARGS;
    const gpaMixPort *oppPort = getOppositePort(portIdx);
    if (!oppPort)
      return GPA_ERROR_WRONG_ARGS;
    const gpaConstVector calcFractions =
        oppPort->getStreamMedium()->getGasFractions();
    for (gpaUInt i = 0; i < funcValues.size(); ++i)
      funcValues[i] = fractions[i] - calcFractions[i];
    printf("Fractions %d\n", portIdx);
    for (gpaUInt i = 0; i < funcValues.size(); ++i)
      printf("%f--", funcValues[i]);
    printf("\n");
    return GPA_RESULT_OK;
  }

  //    gpaResult calcFuncValues(const gpaConstVector &, const gpaConstVector
  //    &variables, gpaVector &values) override
  //    {
  //        gpaUInt n = m_gasFractions.size();
  //
  //        gpaReal dp_pipe = variables[DELTA_PRES_PIPE];
  //       // gpaReal dp_gas = variables[DELTA_PRES_GAS];
  //        gpaReal T_in_pipe = variables[TEMPERATURE_IN_PIPE];
  //        gpaReal T_out_pipe = variables[TEMPERATURE_OUT_PIPE];
  //        gpaReal T_in_gas = variables[TEMPERATURE_IN_GAS];
  //        gpaReal T_out_gas = variables[TEMPERATURE_OUT_GAS];
  //
  //        gpaReal Q_pipe = (T_in_pipe - T_out_pipe) / m_R_pipe;
  //        gpaReal Q_gas = (T_in_gas - T_out_gas) / m_R_gas;
  //
  //        auto *circuit = getMixCircuit(GPA_ELEM_CIRCUIT_0);
  //        const gpaMixPort *inlet = circuit->getPort(0);
  //        const gpaMixPort *gasOut = circuit->getPort(1);
  //
  //        gpaReal G_in = inlet->getIncomingFlowRate();
  //        gpaReal G_out = gasOut->getIncomingFlowRate();
  //
  //        gpaReal p_pipe = inlet->getStreamPressure() - dp_pipe;
  //        m_liquidEnthalpy = inlet->getStreamEnthalpy() - (G_in != .0 ? Q_pipe
  //        / (G_in) : .0);
  //
  //        const gpaMedium *inletMedium = inlet->getStreamMedium();
  //        gpaConstVector inlet_gasFractions = inletMedium->getGasFractions();
  //        gpaConstVector liqFractions = inletMedium->getLiquidFractions();
  //
  //        gpaResult res = m_medium->calcFlashPHCur(p_pipe, m_liquidEnthalpy,
  //        inletMedium->getFractions()); if (res != GPA_RESULT_OK)
  //            return res;
  //        gpaReal T_eq_pipe = m_medium->getTemperature();
  //
  //        gpaReal gasFlowRate = G_in * m_medium->getSteamContent();
  //        gpaReal liquidFlowRate = G_in * (1 - m_medium->getSteamContent());
  //
  //        if (m_medium->getSteamContent() == .0)
  //        {
  //            m_gasFractions.assign(m_medium->getFractions());
  //            m_liquidFractions.assign(m_gasFractions);
  //        }
  //        else
  //        {
  //            m_gasFractions.assign(m_medium->getGasFractions());
  //            m_liquidFractions.assign(m_medium->getLiquidFractions());
  //            m_liquidEnthalpy = m_medium->getLiquidEnthalpy();
  //        }
  //
  //        gpaReal volFlowRate = G_in * m_medium->getMolarMass() /
  //        m_medium->getDensity();
  //
  //        res = m_medium->calcFlashMiddle(inlet->getStreamMedium(), m_medium);
  //        if (res != GPA_RESULT_OK)
  //            return res;
  //        gpaReal T_pipe = m_medium->getTemperature();
  //
  //        gpaReal dp_calc_pipe = calcPressureGradient((volFlowRate +
  //        inlet->getIncomingVolRate()) / 2, m_medium);
  //
  //        m_gasEnthalpy = m_liquidEnthalpy - (G_in != .0 ? Q_gas / (G_in) :
  //        .0);
  //
  //        res = m_medium->calcFlashPT(p_pipe, T_eq_pipe, m_gasFractions);
  //
  //        res = m_medium->calcFlashMiddle(m_medium,
  //        gasOut->getStreamMedium()); if (res != GPA_RESULT_OK)
  //            return res;
  //        gpaReal T_gas = m_medium->getTemperature();
  //
  //        gpaReal dp_calc_gas = calcPressureGradient((gasFlowRate *
  //        m_medium->getMolarMass() / m_medium->getDensity() +
  //        gasOut->getIncomingVolRate()) / 2, m_medium);
  //
  //
  //        //values[0] = Q_pipe - m_alpha_in_pipe * m_A_in_pipe * (T_pipe -
  //        T_in_pipe);
  //        //values[1] = Q_pipe - m_alpha_out_pipe * m_A_out_pipe * (T_out_pipe
  //        - m_Tenv);
  //        //values[2] = Q_gas - m_alpha_in_gas * m_A_in_gas * (T_gas -
  //        T_in_gas);
  //        //values[3] = Q_gas - m_alpha_out_gas * m_A_out_gas * (T_out_gas -
  //        m_Tenv);
  //
  //        //values[4] = dp_calc_pipe - dp_pipe;
  //        //values[5] = dp_calc_gas - dp_gas;
  //
  //        values[0] = G_in +G_out -liquidFlowRate ;
  //        values[1] =( inlet->getStreamPressure()- gasOut->getStreamPressure()
  //        )+ p_pipe; values[2]= p_pipe-dp_calc_pipe;
  //
  //        //values[6] = gasOut->getStreamPressure() -
  //        inlet->getStreamPressure() + dp_gas + dp_pipe;
  //        // p_pipe = inlet->getStreamPressure() - dp_pipe
  //        //values[7] = gasOut->getStreamPressure() - p_pipe + dp_gas;
  //
  //        return GPA_RESULT_OK;
  //    }

  gpaReal sigmoid(gpaReal x) { return 1.0 / (1.0 + std::exp(-x)); }

  gpaReal calcPressureGradient(gpaReal Q, const gpaMedium *medium) {
    gpaReal density = medium->getDensity();
    gpaReal viscosity = medium->getViscosity();
    gpaReal V = Q / (std::numbers::pi * std::numbers::pi * m_d / 4.0);
    gpaReal Re = density * std::abs(V) * m_d / viscosity;

    gpaReal F1 = 16 * Re;
    gpaReal F3 = 0.07716 * Re * Re /
                 std::pow(std::log10(6.9 / (Re + 1e-9) +
                                     vmPower(m_eps / 3.7 / m_d, 1.11)),
                          2);

    gpaReal F2 = F1 + (Re - 2300.0) / 1700.0 * (F3 - F1);

    gpaReal X1 = (Re - 2300.0) / 300.0;
    gpaReal X2 = (Re - 4000.0) / 300.0;

    gpaReal f =
        (F1 * (1 - sigmoid(X1)) + F2 * sigmoid(X1)) * (1 - sigmoid(X2)) +
        F3 * sigmoid(X2);

    gpaReal friction_dp =
        f * viscosity * viscosity * m_l / 2.0 / density / std::pow(m_d, 3);

    gpaReal dp = 9.81 * m_dh * density / GPA_KILOPASCAL_TO_PASCAL +
                 friction_dp * vmAbs(V);

    gpaReal dp_bends =
        V != .0 ? m_nBends * 0.02 * density * vmPower(V, 2) / 2 : 0;

    return dp + dp_bends;
  }
  gpaReal calcRmat() {
    m_A_in = std::numbers::pi * m_wall_diamet1;
    m_A_out = std::numbers::pi * m_wall_diamet3;
    gpaReal rMat = 0;
    rMat += std::log(m_wall_diamet2 / m_wall_diamet1) /
            (2 * std::numbers::pi * m_wall_conductive1);
    rMat += std::log(m_wall_diamet3 / m_wall_diamet2) /
            (2 * std::numbers::pi * m_wall_conductive2);
    return rMat;
  }

  virtual const gpaString &getTypeName() const override {
    return getDeviceTypeName();
  }
  virtual const gpaString &getDescription() const override {
    return getDeviceDescription();
  }

private:
  void calcThermalParams() {
    gpaReal d = m_d;
    gpaReal l = m_l;
    // PIPE (основная труба)
    m_R_pipe = 0;
    m_A_in_pipe = std::numbers::pi * d * l;
    gpaReal radius_inner = d / 2.0;
    for (const auto &layer : m_heatLayers) {
      gpaReal r1 = radius_inner;
      gpaReal r2 = r1 + layer.thickness;
      m_R_pipe += std::log(r2 / r1) / (2 * std::numbers::pi * layer.heatConductivity * l);
      radius_inner = r2;
    }
    m_A_out_pipe = std::numbers::pi * (2 * radius_inner) * l;

    // GAS (газовая сторона, пусть конструкция аналогична)
    m_R_gas = m_R_pipe;
    m_A_in_gas = m_A_in_pipe;
    m_A_out_gas = m_A_out_pipe;
  }

public:
  // Параметры геометрии:
  gpaReal m_d = 0.0;       // внутренний диаметр (м)
  gpaReal m_l = 0.0;       // длина аппарата (м)
  gpaReal m_dh = 0.0;      // гидростат. напор (м)
  gpaReal m_nBends = 0.0;  // число колен
  gpaReal m_eps = 0.0;     // шероховатость (м)
  gpaReal m_Tenv = 298.15; // температура окружающей среды (К)

  gpaHeatLayerVector m_heatLayers;
  gpaHeatCoeffPrm *m_heatCoef1;

  // PIPE (общая труба)
  gpaReal m_R_pipe = 1.0;
  gpaReal m_A_in = 0.0;
  gpaReal m_A_out = 0.0;
  gpaReal m_A_in_pipe = 0.0;
  gpaReal m_A_out_pipe = 0.0;
  gpaReal m_alpha_in_pipe = 0.0;
  gpaReal m_alpha_out_pipe = 0.0;

  // GAS (газовая)
  gpaReal m_R_gas = 1.0;
  gpaReal m_A_in_gas = 0.0;
  gpaReal m_A_out_gas = 0.0;
  gpaReal m_alpha_in_gas = 0.0;
  gpaReal m_alpha_out_gas = 0.0;
  gpaReal m_wall_diamet1;
  gpaReal m_wall_diamet2;
  gpaReal m_wall_diamet3;
  gpaReal m_hydro_coeff;
  gpaReal m_diametr;
  gpaReal m_wall_conductive1;
  gpaReal m_wall_conductive2;
  // gpaHeatCoeffPrm m_hydro_coeff;

  // Остальное
  gpaMedium *m_medium;
  gpaReal m_temperature = 0.0;
  gpaReal m_gasEnthalpy = 0.0;
  gpaReal m_liquidEnthalpy = 0.0;
  gpaReal m_liquidFlowRate = 0.0;
  gpaReal m_Qout = 0.0;
  gpaDataVector m_gasFractions;
  gpaDataVector m_liquidFractions;
  gpaReal getVelocity2() const {

    auto *circuit = getMixCircuit(GPA_ELEM_CIRCUIT_0);
    const gpaMixPort *inlet = circuit->getPort(0);
    gpaReal Q = inlet->getIncomingFlowRate();
    gpaReal V = Q / (std::numbers::pi * std::numbers::pi * m_d / 4.0);
    return V;
  }
  gpaReal getDeltaPres() const {

    auto *circuit = getMixCircuit(GPA_ELEM_CIRCUIT_0);
    const gpaMixPort *inlet = circuit->getPort(0);
    const gpaMixPort *out = circuit->getPort(1);
    return inlet->getStreamPressure() - out->getStreamPressure();
  }

public:
  static const gpaString &getDeviceTypeName() { return m_typeName; }
  static const gpaString &getDeviceDescription() { return m_description; }

private:
  static const gpaString m_typeName;
  static const gpaString m_description;
  static const gpaSensorInfoVector m_sensors;
};
#endif
