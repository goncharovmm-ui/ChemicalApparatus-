#include "gpaDynamicReservoirInfo.h"
#include "gpaDynamicReservoir.h"

gpaDynamicReservoirInfo::gpaDynamicReservoirInfo()
    : gpaDeviceInfo(gpaDynamicReservoir::getDeviceTypeName(),
                    gpaDynamicReservoir::getDeviceDescription()) {
  setParameters(gpaDynamicReservoir::getParametersInfo());
  setSensors(gpaDynamicReservoir::getSensorsInfo());
}

gpaUInt gpaDynamicReservoirInfo::getNumMixCircuits() const {
  return gpaDynamicReservoir::getDeviceNumMixCircuits();
}

gpaUInt gpaDynamicReservoirInfo::getMinNumMixPorts(gpaUInt index) const {
  return gpaDynamicReservoir::getDeviceMinNumMixPorts(index);
}

gpaUInt gpaDynamicReservoirInfo::getMaxNumMixPorts(gpaUInt index) const {
  return gpaDynamicReservoir::getDeviceMaxNumMixPorts(index);
}

const gpaString *
gpaDynamicReservoirInfo::getMixPortName(gpaUInt circIdx,
                                        gpaUInt portIdx) const {
  return gpaDynamicReservoir::getDeviceMixPortName(circIdx, portIdx);
}

const gpaString *
gpaDynamicReservoirInfo::getMixCircuitName(gpaUInt index) const {
  return gpaDynamicReservoir::getDeviceMixCircuitName(index);
}

gpaElement *
gpaDynamicReservoirInfo::createDevice(const gpaCoreInterfaces *interfaces,
                                      gpaCoreReference pairDevice,
                                      const gpaExtObjectModel *model) const {
  gpaDynamicReservoir *separator =
      new gpaDynamicReservoir(interfaces, pairDevice);
  gpaResult res = separator->specifyModel(model);
  if (res == GPA_RESULT_OK)
    return separator;
  delete separator;
  return NULL;
}
