/*!
 *  \file      gpaTankVolume.h
 *  \brief     Класс для описания однослойного объемного элемента
 *  \author    Фролов Алексей
 *  \date      2024
 */
#ifndef GPA_TANK_VOLUME_H
#define GPA_TANK_VOLUME_H

#include "gpaInclude.h"
#include "gpaMedium.h"
#include "gpaVolumeElement.h"

/*!
 * \class gpaTankVolume
 * \brief Класс, реализующий однослойный объемный элемента
 */
class gpaTankVolume : public gpaVolumeElement {
public:
  /*!
   * Конструктор по умолчанию
   * \param link ссылки на родительские контейнеры
   */
  gpaTankVolume(const gpaParentLink *link = NULL);
  /*!
   * Конструктор копирования
   * \param volume объемный элемент для копирования
   */
  gpaTankVolume(const gpaTankVolume &volume);
  /*!
   * Деструктор по умолчанию
   */
  virtual ~gpaTankVolume() override;
  /*!
   * Функция копирования объемного элемента
   * \return скопированный объемный элемент
   */
  virtual gpaTankVolume *copy() const override;
  /*!
   * Получить название типа элемента
   * \return название типа элемента
   */
  virtual const gpaString &getTypeName() const override {
    return getDeviceTypeName();
  }
  /*!
   * Получить описание элемента
   * \return описание элемента
   */
  virtual const gpaString &getDescription() const override {
    return getDeviceDescription();
  }
  /*!
   * Получить начальное значение давления
   * \return начальное значение давления
   */
  gpaReal getInitPressure() const { return m_initPressure; }
  /*!
   * Получить начальное значение температуры
   * \return начальное значение температуры
   */
  gpaReal getInitTemperature() const { return m_initTemperature; }
  /*!
   * Получить начальные значения мольных долей компонентов смеси
   * \return начальные значения мольных долей компонентов смеси
   */
  gpaConstVector getInitFraction() const { return m_initFractions; }

  const gpaMedium *getMedium() const override { return m_medium; }
  /*!
   * Задать начальное значение давления
   * \param initPressure начальное значение давления
   * \return флаг успеха назначения параметра
   */
  bool setInitPressure(gpaReal initPressure);
  /*!
   * Задать начальное значение температуры
   * \param initTemperature начальное значение температуры
   * \return флаг успеха назначения параметра
   */
  bool setInitTemperature(gpaReal initTemperature);
  /*!
   * Задать начальные значения мольных долей компонентов смеси
   * \param fractions начальные значения мольных долей компонентов смеси
   * \return флаг успеха назначения параметра
   */
  bool setInitFractions(const gpaConstVector &fractions);
  /*!
   * Задать значение коэффициента теплопередачи к стенке по газу [Вт/(м^2*K)]
   * \param liqHeatTransCoef значение коэффициента теплопередачи к стенке по
   * газу [Вт/(м^2*K)]
   * \return флаг успеха назначения параметра
   */
  bool setLiqHeatTransCoef(gpaReal liqHeatTransCoef);
  /*!
   * Задать значение коэффициента теплопередачи к стенке по жидкости
   * [Вт/(м^2*K)]
   * \param gasHeatTransCoef значение коэффициента теплопередачи к стенке по
   * жидкости [Вт/(м^2*K)]
   * \return флаг успеха назначения параметра
   */
  bool setGasHeatTransCoef(gpaReal gasHeatTransCoef);
  /*!
   * Получить значение давления на определенном уровне [кПа]
   * \param level уровень (высота)
   * \return значение давления на определенном уровне [кПа]
   */
  virtual gpaReal getPressureAt(gpaReal level) const override;
  /*!
   * Получить значение температуры на определенном уровне [К]
   * \param level уровень (высота)
   * \return значение температуры на определенном уровне [К]
   */
  virtual gpaReal getTemperatureAt(gpaReal level) const override;
  /*!
   * Получить значение молярной массы для линейной комбинации равновесных фаз
   * для заданной объемной доли газа [кг/кмоль]
   * \param gasVolumeFraction заданная объемная доля газа в среде
   * \return значение молярной массы для линейной комбинации равновесных фаз для
   * заданной объемной доли газа [кг/кмоль]
   */
  virtual gpaReal getMolarMassFor(gpaReal gasVolumeFraction) const override;
  /*!
   * Получить значение удельной мольной энтальпии для линейной комбинации
   * равновесных фаз для заданной объемной доли газа [кДж/кмоль]
   * \param gasVolumeFraction заданная объемная доля газа в среде
   * \return значение удельной мольной энтальпии для линейной комбинации
   * равновесных фаз для заданной объемной доли газа [кДж/кмоль]
   */
  virtual gpaReal getEnthalpyFor(gpaReal gasVolumeFraction) const override;
  /*!
   * Получить значение плотности для линейной комбинации равновесных фаз для
   * заданной объемной доли газа [кг/м3]
   * \param gasVolumeFraction заданная объемная доля газа в среде
   * \return значение плотности для линейной комбинации равновесных фаз для
   * заданной объемной доли газа [кг/м3]
   */
  virtual gpaReal getDensityFor(gpaReal gasVolumeFraction) const override;
  /*!
   * Получить значение вязкости для линейной комбинации равновесных фаз для
   * заданной объемной доли газа [Па*с]
   * \param gasVolumeFraction заданная объемная доля газа в среде
   * \return значение вязкости для линейной комбинации равновесных фаз для
   * заданной объемной доли газа [Па*с]
   */
  virtual gpaReal getViscosityFor(gpaReal gasVolumeFraction) const override;
  /*!
   * Получить значение коэффициента теплопередачи для жидкости [Вт/(м^2*K)]
   * \return значение коэффициента теплопередачи для жидкости [Вт/(м^2*K)]
   */
  virtual gpaReal getLiquidHeatTransferCoef() const override {
    return m_liqHeatTransCoef;
  }
  /*!
   * Получить значение коэффициента теплопередачи для газа [Вт/(м^2*K)]
   * \return значение коэффициента теплопередачи для газа [Вт/(м^2*K)]
   */
  virtual gpaReal getGasHeatTransferCoef() const override {
    return m_gasHeatTransCoef;
  }
  /*!
   * Получить значения мольных долей на выходе
   * \param fractions вектор мольных долей компонент для линейной комбинации
   * равновесных фаз для заданной объемной доли газа
   * \param gasVolumeFraction заданная объемная доля газа в среде
   */
  virtual void getFractionsFor(gpaDataVector &fractions,
                               gpaReal gasVolumeFraction) const override;
  /*!
   * Получить значение уровня жидкости
   * \return значение уровня жидкости
   */
  virtual gpaReal getLiquidLevel() const override { return m_liquidLevel; }

  virtual gpaReal getLiquidVolume() const override;

  virtual gpaReal getTransitionLevel(gpaReal level,
                                     gpaReal radius) const override;

  virtual gpaReal getTransitionRadius(gpaReal level,
                                      gpaReal radius) const override;
  /*!
   * Получить значение размерности
   * \return значение размерности
   */
  virtual gpaUInt getNumVariables() const override;
  /*!
   * Заполнить названия неизвестных
   * \param [out] varNames названия неизвестных
   */
  virtual void fillVarNames(gpaStringVector &varNames) const override;
  /*!
   * Инициализировать камеру и ее параметры для расчета
   * \return код операции
   */
  virtual gpaResult initialize() override;
  /*!
   * Заполнить матрицу масс камеры
   * \param refRow первая строка подматрицы
   * \param refCol первый столбец подматрицы
   * \return код ошибки
   */
  virtual gpaResult fillMassMatrix(gpaUInt refRow,
                                   gpaUInt refCol) const override;
  /*!
   * Инициализировать решение заданным вектором
   * \param [out] variables вектор неизвестных
   * \return код ошибки
   */
  virtual gpaResult initVariables(gpaVector &variables) const override;
  /*!
   * Рассчитать значения функций правых частей
   * \param [in] states вектор состояний
   * \param [in] variables вектор неизвестных
   * \param [out] values вектор значений функций правых частей
   * \return код операции
   */
  virtual gpaResult calcFuncValues(const gpaConstVector &states,
                                   const gpaConstVector &variables,
                                   gpaVector &values,
                                   const gpaSetOfEquations &eqIds) override;
  /*!
   * Получить невязку уравнения для удельной мольной энтальпии для заданного
   * порта материального потока
   * \param circIdx индекс материального контура
   * \param portIdx индекс порта материального потока
   * \param enthalpy текущее значение энтальпии (относительно которого требуется
   * невязка)
   * \param [out] funcValue значение невязки уравнения для удельной мольной
   * энтальпии для заданного порта материального потока
   * \param код операции
   */
  virtual gpaResult calcEnthalpyFuncValueAt(gpaUInt circIdx, gpaUInt portIdx,
                                            gpaReal enthalpy,
                                            gpaReal &funcValue) const override;
  /*!
   * Получить невязки уравнений для мольных долей компонентов смеси для
   * заданного порта материального потока
   * \param circIdx индекс материального контура
   * \param portIdx индекс порта материального потока
   * \param fractions текущие значения мольных долей компонентов (относительно
   * которых требуется невязка)
   * \param [out] funcValues вектор невязок уравнений для мольных долей
   * компонентов смеси для заданного порта материального потока
   * \param код операции
   */
  virtual gpaResult
  calcFractionsFuncValuesAt(gpaUInt circIdx, gpaUInt portIdx,
                            const gpaConstVector &fractions,
                            gpaVector &funcValues) const override;

protected:
  /*!
   * Освободить текущую среду
   */
  void finalizeMedium();
  /*!
   * Рассчитать внутренний параметры камеры
   */
  void updateLiquidLevel(gpaReal mixMoles);

  bool aboveLiquidSurface(gpaReal level) const;

private:
  //! Заданная среда
  gpaMedium *m_medium;
  //! Внутренняя энергия
  gpaReal m_mixEnergy;
  //! Количество вещества
  gpaReal m_mixMoles;
  //! Начальное давление
  gpaReal m_initPressure;
  //! Начальная температура
  gpaReal m_initTemperature;
  //! Начальные мольные доли
  gpaDataVector m_initFractions;
  //! Уровень жидкости
  gpaReal m_liquidLevel;
  //! Коэфициент теплопередачи к стенке по жидкости
  gpaReal m_liqHeatTransCoef;
  //! Коэфициент теплопередачи к стенке по газу
  gpaReal m_gasHeatTransCoef;
  //! Вектор сохраненных неизвестных
  gpaDataVector m_savedVariables;

public:
  /*!
   * Получить название типа элемента
   * \return название типа элемента
   */
  static const gpaString &getDeviceTypeName() { return m_typeName; }
  /*!
   * Получить описание элемента
   * \return описание элемента
   */
  static const gpaString &getDeviceDescription() { return m_description; }

private:
  //! Название элемента
  static const gpaString m_typeName;
  //! Описание элемента
  static const gpaString m_description;
};

#endif
