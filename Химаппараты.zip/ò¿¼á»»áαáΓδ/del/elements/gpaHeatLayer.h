#include "gpaInclude.h"
#include <numbers>
#ifndef GPA_HEAT_LAYER_H
#define GPA_HEAT_LAYER_H
struct gpaHeatLayer {
  gpaReal thickness;
  gpaReal density;
  gpaReal heatConductivity;
  gpaReal heatCapacity;

  gpaReal calcHeatCapacity(gpaReal innerDiameter, gpaReal length) const {
    return length * std::numbers::pi / 4 * heatCapacity * density *
           (vmPower(thickness + innerDiameter, 2) - vmPower(innerDiameter, 2));
  }
};

typedef std::vector<gpaHeatLayer> gpaHeatLayerVector;
#endif
