#include "gpaLogMeanTempDifference.h"
#include "gpaZeroRadiation.h"
#include "gpaThinWall.h"
#include "gpaFireOilHeater.h"
#include <iostream>

constexpr gpaUInt ID_CIRCUIT_INNER      = 0;
constexpr gpaUInt NUM_CIRCUITS          = 2;

constexpr gpaUInt ID_CIRCUIT = 0;
constexpr gpaUInt ID_CIRCUIT_2 = 1;

constexpr gpaUInt ID_PORT_GAS_INLET  = 0;
constexpr gpaUInt ID_PORT_GAS_OUTLET = 1;
constexpr gpaUInt ID_PORT_OIL_INLET  = 0;
constexpr gpaUInt ID_PORT_OIL_OUTLET = 1;

constexpr gpaUInt NUM_PORTS          = 2;


enum id_Param: gpaUInt {
    //Перечень параметров для расчета тепла
    //ID_PARAM_LHV_Fuel                     = 0,
    // ID_PARAM_kQCC                       = 0,
    // ID_PARAM_kQRC                       , 
    // ID_PARAM_k_LMTDRC                   ,
    ID_PARAM_temp_gas_star_zero         = 0,
    ID_PARAM_temp_gas_oil_zero          ,
    //ID_PARAM_flagMixBibl                ,

    //Перечень входных геометрических параметров КР (RC - radiation chamber) 7
    ID_PARAM_aRC                ,
    ID_PARAM_bRC                ,
    ID_PARAM_lPipeRC            ,
    ID_PARAM_dPipeRC            ,
    ID_PARAM_nPipeRC            ,
    ID_PARAM_deltaPipeRC        ,
    ID_PARAM_epsilonRC          ,

    //Перечень входных геометрических параметров КК (СC - convection chamber) 16
    ID_PARAM_lPipeCC            ,
    ID_PARAM_dPipeCC            ,
    ID_PARAM_aCC                ,
    ID_PARAM_bCC               ,
    ID_PARAM_hCC1               ,
    ID_PARAM_hCC2               ,
    ID_PARAM_nPipeSmСС         ,
    ID_PARAM_nPipeCorСС        ,
    ID_PARAM_deltaPipeCC        ,
    ID_PARAM_epsilonСС         ,
    ID_PARAM_kRib               ,
    ID_PARAM_deltaRib          ,
    ID_PARAM_hRib             ,
    ID_PARAM_s1                ,
    ID_PARAM_s2                 ,
    ID_PARAM_s3                 ,
    //ID_PARAM_setParsMethodFlag ,

};



// sensors 
constexpr gpaUInt ID_SENSOR_GAS_IN_TEMP         = 0;
constexpr gpaUInt ID_SENSOR_GAS_STAR_TEMP       = 1;
constexpr gpaUInt ID_SENSOR_GAS_OUT_TEMP        = 2;
constexpr gpaUInt ID_SENSOR_OIL_IN_TEMP         = 3;
constexpr gpaUInt ID_SENSOR_OIL_STAR_TEMP       = 4;
constexpr gpaUInt ID_SENSOR_OIL_OUT_TEMP        = 5;

constexpr gpaUInt ID_SENSOR_alphaRC      = 6;
constexpr gpaUInt ID_SENSOR_alphaCC      = 7;
constexpr gpaUInt ID_SENSOR_sSideRC      = 8;
constexpr gpaUInt ID_SENSOR_sSideCC      = 9;
constexpr gpaUInt ID_SENSOR_LMTDRC       = 10;
constexpr gpaUInt ID_SENSOR_LMTDCC       = 11;

constexpr gpaUInt ID_SENSOR_T_Burned_gas     = 12;

constexpr gpaUInt ID_SENSOR_GAS_IN_MHC      = 13;
constexpr gpaUInt ID_SENSOR_GAS_STAR_MHC    = 14;
constexpr gpaUInt ID_SENSOR_GAS_OUT_MHC     = 15;
constexpr gpaUInt ID_SENSOR_OIL_IN_MHC      = 16;
constexpr gpaUInt ID_SENSOR_OIL_STAR_MHC    = 17;
constexpr gpaUInt ID_SENSOR_OIL_OUT_MHC     = 18;

constexpr gpaUInt ID_SENSOR_Delta_H_Gas     = 19;
constexpr gpaUInt ID_SENSOR_Delta_H_Oil     = 20;

constexpr gpaUInt ID_SENSOR_Q               = 21;

constexpr gpaUInt ID_SENSOR_QAtmCC          = 22;
constexpr gpaUInt ID_SENSOR_QAtmRC          = 23;

constexpr gpaUInt ID_SENSOR_deltaP_oil      = 24;
constexpr gpaUInt ID_SENSOR_deltaP_gas      = 25;

constexpr gpaUInt ID_SENSOR_oilPipeCC_density        = 26;
constexpr gpaUInt ID_SENSOR_oilPipeCC_viscosity      = 27;
constexpr gpaUInt ID_SENSOR_oilPipeCC_mu             = 28;
constexpr gpaUInt ID_SENSOR_oilPipeCC_v              = 29;
constexpr gpaUInt ID_SENSOR_oilPipeCC_Re             = 30;
constexpr gpaUInt ID_SENSOR_oilPipeCC_deltaH         = 31;
constexpr gpaUInt ID_SENSOR_oilPipeCC_coefFrick      = 32;
constexpr gpaUInt ID_SENSOR_oilPipeCC_DP_Frick       = 33;
constexpr gpaUInt ID_SENSOR_oilPipeCC_DP_DH          = 34;
constexpr gpaUInt ID_SENSOR_oilPipeCC_DP             = 35;

constexpr gpaUInt ID_SENSOR_oilPipeRC_density        = 36;
constexpr gpaUInt ID_SENSOR_oilPipeRC_viscosity      = 37;
constexpr gpaUInt ID_SENSOR_oilPipeRC_mu             = 38;
constexpr gpaUInt ID_SENSOR_oilPipeRC_v              = 39;
constexpr gpaUInt ID_SENSOR_oilPipeRC_Re             = 40;
constexpr gpaUInt ID_SENSOR_oilPipeRC_deltaH         = 41;
constexpr gpaUInt ID_SENSOR_oilPipeRC_coefFrick      = 42;
constexpr gpaUInt ID_SENSOR_oilPipeRC_DP_Frick       = 43;
constexpr gpaUInt ID_SENSOR_oilPipeRC_DP_DH          = 44;
constexpr gpaUInt ID_SENSOR_oilPipeRC_DP             = 45;   

constexpr gpaUInt ID_SENSOR_gasPipeRC_density        = 46;
constexpr gpaUInt ID_SENSOR_gasPipeRC_viscosity      = 47;
constexpr gpaUInt ID_SENSOR_gasPipeRC_mu             = 48;
constexpr gpaUInt ID_SENSOR_gasPipeRC_v              = 49;
constexpr gpaUInt ID_SENSOR_gasPipeRC_Re             = 50;
constexpr gpaUInt ID_SENSOR_gasPipeRC_deltaH         = 51;
constexpr gpaUInt ID_SENSOR_gasPipeRC_coefFrick      = 52;
constexpr gpaUInt ID_SENSOR_gasPipeRC_DP_Frick       = 53;
constexpr gpaUInt ID_SENSOR_gasPipeRC_DP_DH          = 54;
constexpr gpaUInt ID_SENSOR_gasPipeRC_DP             = 55;   

const gpaString gpaFireOilHeater::m_typeName      = "fire-oilheater";
const gpaString gpaFireOilHeater::m_description   = "Огневой подогреватель горячего масла (ОПГМ)";

const gpaStringVector gpaFireOilHeater::m_circuitNames =
{
    "Контур ТГ + воздух -> ТС -> ДГ",
    "Контур ГМ",
};

const gpaStringVector gpaFireOilHeater::m_portNames =
{
    "Вход ТС",
    "Выход ДГ",
    "Вход ГМ",
    "Выход ГМ",
};



const gpaParameterInfoVector gpaFireOilHeater::m_parameters =
{
    // Перечень параметров для расчета тепла
    //realParam("LHV_Fuel",                      "Низшая теплотворная способность, кДж/кг",                                                GPA_DIMLESS_UNIT,      true, 50000),
    // realParam("kQCC",                       "Поправочный коэфф. для теплоотдачи в КК",                              GPA_DIMLESS_UNIT,     true, 1.0),
    // realParam("kQRC",                       "Поправочный коэфф. для теплоотдачи в КР",                              GPA_DIMLESS_UNIT,     true, 1.0),
    // realParam("k_LMTDRC",                    "Поправочный коэфф. для СЛРТ КР ",                                     GPA_DIMLESS_UNIT,     true, 1.0),
    //alphaAtmCC alphaAtmRC
    
    realParam("temp_gas_star_zero",         "Температура газа между зонами при иницализации",                       GPA_TEMPERATURE_UNIT, false, 500),
    realParam("temp_gas_oil_zero",          "Температура масла между зонами при иницализации",                      GPA_TEMPERATURE_UNIT, false, 200),
    // realParam("flagMixBibl",                "Переключатель библиотек (0 - табличные свойства, 1 - встроенная)",     GPA_DIMLESS_UNIT,     false, 1.0),

    //Перечень входных геометрических параметров КР (RC - radiation chamber)
    realParam("aRC",                      "Длина газового канала КР",                                                GPA_LENGTH_UNIT, false, 6),
    realParam("bRC",                      "Ширина газового канала КР",                                               GPA_LENGTH_UNIT, false, 4.2),
    realParam("lPipeRC",                  "Длина труб масляного канала внутри КР",                                   GPA_LENGTH_UNIT, false, 10),
    realParam("dPipeRC",                  "Внутренний диаметр труб масляного канала внутри КР",                      GPA_LENGTH_UNIT, false, 0.102),
    realParam("nPipeRC",                  "Количество труб масляного канала внутри одного змеевика КР",                          NAN, false, 40),
    realParam("deltaPipeRC",              "Толщина труб с маслом канала КР",                                         GPA_LENGTH_UNIT, false, 0.006),
    realParam("epsilonRC",                "Шероховатость трубопровода",                                              GPA_LENGTH_UNIT, false, 0.001),

    //Перечень входных геометрических параметров КК (СC - convection chamber)
    realParam("lPipeCC",                  "Длина труб масляного канала внутри КК",                                    GPA_LENGTH_UNIT, false, 6.7),
    realParam("dPipeCC",                  "Внутренний диаметр труб масляного канала внутри КК",                       GPA_LENGTH_UNIT, false, 0.102),
    realParam("aCC",                      "Длина газового канала КК",                                                 GPA_LENGTH_UNIT, false, 1),
    realParam("bCC",                      "Ширина газового канала КК",                                                GPA_LENGTH_UNIT, false, 6),
    realParam("hCC1",                     "Высота прямоугольного участка трубопровода КК",                            GPA_LENGTH_UNIT, false, 5),
    realParam("hCC2",                     "Эффективная высота участка общего дымохода КК",                            GPA_LENGTH_UNIT, false, 1.7),
    realParam("nPipeSmСС",                "Количество гладких труб масляного канала внутри одного змеевика КК",       NAN,             false, 5),
    realParam("nPipeCorСС",               "Количество оребренных труб масляного канала внутри одного змеевика КК",    NAN,             false, 18),
    realParam("deltaPipeCC",              "Толщина труб с маслом канала КР",                                          GPA_LENGTH_UNIT, false, 0.006),
    realParam("epsilonСС",                "Шероховатость трубопровода",                                               GPA_LENGTH_UNIT, false, 0.0002),
    realParam("kRib",                     "Шаг ребр, шт/м",                                                           NAN,             false, 167),
    realParam("deltaRib",                 "Толщина ребра",                                                            GPA_LENGTH_UNIT, false, 0.0012),
    realParam("hRib",                     "Высота ребра",                                                             GPA_LENGTH_UNIT, false, 0.015),
    realParam("s1",                       "Горизонтальный шаг",                                                       GPA_LENGTH_UNIT, false, 0.2),
    realParam("s2",                       "Вертикальный шаг",                                                         GPA_LENGTH_UNIT, false, 0.0865),
    realParam("s3",                       "Диагональный шаг",                                                         GPA_LENGTH_UNIT, false, 0.200),
    //realParam("setParsMethodFlag",                       "Переключатель метода расчета параметров регулировки",       NAN, false, 0),
};


const gpaSensorInfoVector gpaFireOilHeater::m_sensors =
{
    //6 
    scalarSensor("GAS_IN_TEMP",      "T1 Температура газа на входе в КР",                 GPA_TEMPERATURE_UNIT),
    scalarSensor("GAS_STAR_TEMP",    "T*Gas Температура газа на выходе из КР",            GPA_TEMPERATURE_UNIT),
    scalarSensor("GAS_OUT_TEMP",     "T2 Температура газа на выходе из КК",               GPA_TEMPERATURE_UNIT),
    scalarSensor("OIL_IN_TEMP",      "T3 Температура масла на входе  в КК",               GPA_TEMPERATURE_UNIT),
    scalarSensor("OIL_STAR_TEMP",    "T*Oil Температура масла на выходе из КК",           GPA_TEMPERATURE_UNIT),
    scalarSensor("OIL_OUT_TEMP",     "T4 Температура масла на выходе из КР",              GPA_TEMPERATURE_UNIT),
    //6
    scalarSensor("ID_SENSOR_alphaRC",     "Коэффициент теплоотдачи с поверхности змеевиков КР, КВт/м^2/K",            NAN),
    scalarSensor("ID_SENSOR_alphaCC",     "Коэффициент теплоотдачи с поверхности змеевиков КК, КВт/м^2/K",             NAN),
    scalarSensor("ID_SENSOR_sSideRC",     "Площадь поверхности теплоотдачи змеевиков КР, м^2",            GPA_AREA_UNIT),
    scalarSensor("ID_SENSOR_sSideCC",     "Площадь поверхности теплоотдачи змеевиков КК, м^2",             GPA_AREA_UNIT),
    scalarSensor("ID_SENSOR_LMTDRC",      "Средне-логарифмический перепад температур КР, K",               GPA_TEMPERATURE_UNIT),
    scalarSensor("ID_SENSOR_LMTDCC",      "Средне-логарифмический перепад температур КК, K",              GPA_TEMPERATURE_UNIT),
    //5
    scalarSensor("ID_SENSOR_T_Burned_gas",    "Эффективная температура дымовых газов после горелок",          GPA_TEMPERATURE_UNIT),
    //6
    scalarSensor("GAS_IN_MHC",      "1    Теплоемкость  газа на входе в КР, КДж/кмоль/К",            NAN),
    scalarSensor("GAS_STAR_MHC",    "*Gas Теплоемкость газа на выходе из КР, КДж/кмоль/К",           NAN),
    scalarSensor("GAS_OUT_MHC",     "2    Теплоемкость газа на выходе из КК, КДж/кмоль/К",           NAN),
    scalarSensor("OIL_IN_MHC",      "3    Теплоемкость масла на входе  в КК, КДж/кмоль/К",           NAN),
    scalarSensor("OIL_STAR_MHC",    "*Oil Теплоемкость масла на выходе из КК, КДж/кмоль/К",          NAN),
    scalarSensor("OIL_OUT_MHC",     "4    Теплоемкость масла на выходе из КР, КДж/кмоль/К",          NAN),
    //4
    scalarSensor("Delta_H_Gas",     "Изменение этальпии газа, кДж/кмоль",   NAN),
    scalarSensor("Delta_H_Oil",     "Изменение энтальпии масла, кДж/кмоль", NAN),
    scalarSensor("Q",               "Тепло от газа к маслу, кДж",           NAN),
    scalarSensor("QAtmCC",          "Тепло от CC в атм, кДж",               NAN),
    scalarSensor("QAtmRC",          "Тепло от RC в атм, кДж",               NAN),

    scalarSensor("deltaP_oil",      "Перепад давлений по маслу",            GPA_PRESSURE_UNIT),
    scalarSensor("deltaP_gas",      "Перепад давлений по газу",             GPA_PRESSURE_UNIT),

    
    scalarSensor("oilPipeCC_density",      "Плотность ГМ в КК, кг/(м^3)",                 GPA_DENSITY_UNIT),   
    scalarSensor("oilPipeCC_viscosity",    "Вязкость ГМ в КК, мкПа*с",                      GPA_DIMLESS_UNIT),  
    scalarSensor("oilPipeCC_mu",           "Молярная масса ГМ в КК, КГ/КМоль",            GPA_DIMLESS_UNIT),  
    scalarSensor("oilPipeCC_v",            "Скорость ГМ в КК_v, м/c",                     GPA_VELOCITY_UNIT), 
    scalarSensor("oilPipeCC_Re",           "Число Рейнольдса ГМ в КК",                    GPA_DIMLESS_UNIT), 
    scalarSensor("oilPipeCC_deltaH",       "Перепад высот канала ГМ в КК",                GPA_LENGTH_UNIT),  
    scalarSensor("oilPipeCC_coefFrick",    "Коэффициент трения ГМ в КК",                  GPA_DIMLESS_UNIT),  
    scalarSensor("oilPipeCC_DP_Frick",     "Гидравлические потери давления ГМ в КК",  GPA_PRESSURE_UNIT),  
    scalarSensor("oilPipeCC_DP_DH",        "Гидростатический напор ГМ в КК",         GPA_PRESSURE_UNIT),  
    scalarSensor("oilPipeCC_DP",           "Суммарные потери давления ГМ в КК",      GPA_PRESSURE_UNIT),  

    scalarSensor("oilPipeRC_density",      "Плотность ГМ в КР, кг/(м^3)",                 GPA_DENSITY_UNIT),   
    scalarSensor("oilPipeRC_viscosity",    "Вязкость ГМ в КР, мкПа*с",                      GPA_DIMLESS_UNIT),  
    scalarSensor("oilPipeRC_mu",           "Молярная масса ГМ в КР, КГ/КМоль",            GPA_DIMLESS_UNIT),  
    scalarSensor("oilPipeRC_v",            "Скорость ГМ в КР, м/c",                       GPA_VELOCITY_UNIT), 
    scalarSensor("oilPipeRC_Re",           "Число Рейнольдса ГМ в КР",                    GPA_DIMLESS_UNIT), 
    scalarSensor("oilPipeRC_deltaH",       "Перепад высот канала ГМ в КР",                GPA_LENGTH_UNIT),  
    scalarSensor("oilPipeRC_coefFrick",    "Коэффициент трения ГМ в КР",                  GPA_DIMLESS_UNIT),  
    scalarSensor("oilPipeRC_DP_Frick",     "Гидравлические потери давления ГМ в КР",  GPA_PRESSURE_UNIT),  
    scalarSensor("oilPipeRC_DP_DH",        "Гидростатический напор ГМ в КР",         GPA_PRESSURE_UNIT),  
    scalarSensor("oilPipeRC_DP",           "Суммарные потери давления ГМ в КР",      GPA_PRESSURE_UNIT),   

    scalarSensor("gasPipeRC_density",      "Плотность ДГ в КР, кг/(м^3)",                 GPA_DENSITY_UNIT),   
    scalarSensor("gasPipeRC_viscosity",    "Вязкость ДГ в КР, мкПа*с",                      GPA_DIMLESS_UNIT),  
    scalarSensor("gasPipeRC_mu",           "Молярная масса ДГ в КР, КГ/КМоль",            GPA_DIMLESS_UNIT),  
    scalarSensor("gasPipeRC_v",            "Скорость ДГ в КР, м/c",                       GPA_VELOCITY_UNIT), 
    scalarSensor("gasPipeRC_Re",           "Число Рейнольдса ДГ в КР",                    GPA_DIMLESS_UNIT), 
    scalarSensor("gasPipeRC_deltaH",       "Перепад высот канала ДГ в КР",                GPA_LENGTH_UNIT),  
    scalarSensor("gasPipeRC_coefFrick",    "Коэффициент трения ДГ в КР",                  GPA_DIMLESS_UNIT),  
    scalarSensor("gasPipeRC_DP_Frick",     "Гидравлические потери давления ДГ в КР",  GPA_PRESSURE_UNIT),  
    scalarSensor("gasPipeRC_DP_DH",        "Гидростатический напор ДГ в КР",         GPA_PRESSURE_UNIT),  
    scalarSensor("gasPipeRC_DP",           "Суммарные потери давления ДГ в КР",      GPA_PRESSURE_UNIT),   
};

gpaFireOilHeater::gpaFireOilHeater(const gpaCoreInterfaces* interfaces, gpaCoreReference importRef) :
    gpaExportSystem (interfaces, importRef),
    m_heatPipes      (asParent())
{
}

gpaResult gpaFireOilHeater::calcSensors(gpaVector& sensors) const
{

    // (QBurn-Q)/abs(G_in_gas)
    setSensorValue(sensors, ID_SENSOR_GAS_IN_TEMP,      m_heatPipes.T_in_gas   - 273.15); // m_heatPipes.T_in_gas   - 273.15
    setSensorValue(sensors, ID_SENSOR_GAS_STAR_TEMP,    m_heatPipes.T_star_gas - 273.15);// 
    setSensorValue(sensors, ID_SENSOR_GAS_OUT_TEMP,     m_heatPipes.T_out_gas  - 273.15);//  
    setSensorValue(sensors, ID_SENSOR_OIL_IN_TEMP,      m_heatPipes.T_in_oil   - 273.15);//T_in_oil - 273.15
    setSensorValue(sensors, ID_SENSOR_OIL_STAR_TEMP,    m_heatPipes.T_star_oil - 273.15);//T_star_oil - 273.15
    setSensorValue(sensors, ID_SENSOR_OIL_OUT_TEMP,     m_heatPipes.T_out_oil  - 273.15);//T_out_oil - 273.15

    setSensorValue(sensors, ID_SENSOR_alphaRC,     m_heatPipes.alphaRC);//m_heatPipes.alphaRC
    setSensorValue(sensors, ID_SENSOR_alphaCC,     m_heatPipes.alphaCC);//m_heatPipes.alphaCC
    setSensorValue(sensors, ID_SENSOR_sSideRC,     m_heatPipes.sSideRC);
    setSensorValue(sensors, ID_SENSOR_sSideCC,     m_heatPipes.sSideCC);
    setSensorValue(sensors, ID_SENSOR_LMTDRC,      m_heatPipes.LMTDRC);
    setSensorValue(sensors, ID_SENSOR_LMTDCC,      m_heatPipes.LMTDCC);

    setSensorValue(sensors, ID_SENSOR_T_Burned_gas,     m_heatPipes.burner.T_Burned_gas - 273.15);

    
    setSensorValue(sensors, ID_SENSOR_GAS_IN_MHC,     m_heatPipes.Cp_M_in_gas);
    setSensorValue(sensors, ID_SENSOR_GAS_STAR_MHC,   m_heatPipes.Cp_M_star_gas);
    setSensorValue(sensors, ID_SENSOR_GAS_OUT_MHC,    m_heatPipes.Cp_M_out_gas);
    setSensorValue(sensors, ID_SENSOR_OIL_IN_MHC,     m_heatPipes.Cp_M_in_oil);
    setSensorValue(sensors, ID_SENSOR_OIL_STAR_MHC,   m_heatPipes.Cp_M_star_oil);
    setSensorValue(sensors, ID_SENSOR_OIL_OUT_MHC,    m_heatPipes.Cp_M_out_oil);

    setSensorValue(sensors, ID_SENSOR_Delta_H_Gas,    m_heatPipes.Delta_H_Gas_Fixed);
    setSensorValue(sensors, ID_SENSOR_Delta_H_Oil,    m_heatPipes.Delta_H_Oil_Fixed);
    setSensorValue(sensors, ID_SENSOR_Q,              m_heatPipes.Q);
    setSensorValue(sensors, ID_SENSOR_QAtmCC,         m_heatPipes.QAtmCC);//
    setSensorValue(sensors, ID_SENSOR_QAtmRC,         m_heatPipes.QAtmRC);//

    setSensorValue(sensors, ID_SENSOR_deltaP_oil,         m_heatPipes.deltaP_oil);//
    setSensorValue(sensors, ID_SENSOR_deltaP_gas,         m_heatPipes.deltaP_gas);//


    setSensorValue(sensors, ID_SENSOR_oilPipeCC_density,       m_heatPipes.oilPipeCC.density);//
    setSensorValue(sensors, ID_SENSOR_oilPipeCC_viscosity,     1000000*m_heatPipes.oilPipeCC.viscosity);//
    setSensorValue(sensors, ID_SENSOR_oilPipeCC_mu,            m_heatPipes.oilPipeCC.mu);//
    setSensorValue(sensors, ID_SENSOR_oilPipeCC_v,             m_heatPipes.oilPipeCC.v);//
    setSensorValue(sensors, ID_SENSOR_oilPipeCC_Re,            m_heatPipes.oilPipeCC.Re);//
    setSensorValue(sensors, ID_SENSOR_oilPipeCC_deltaH,        m_heatPipes.oilPipeCC.deltaH);//
    setSensorValue(sensors, ID_SENSOR_oilPipeCC_coefFrick,     m_heatPipes.oilPipeCC.coefFrick/pow(m_heatPipes.oilPipeCC.Re, 2));//
    setSensorValue(sensors, ID_SENSOR_oilPipeCC_DP_Frick,      m_heatPipes.oilPipeCC.DP_Frick);//
    setSensorValue(sensors, ID_SENSOR_oilPipeCC_DP_DH,         m_heatPipes.oilPipeCC.DP_DH);//
    setSensorValue(sensors, ID_SENSOR_oilPipeCC_DP,            m_heatPipes.oilPipeCC.DP);//
    
    setSensorValue(sensors, ID_SENSOR_oilPipeRC_density,       m_heatPipes.oilPipeRC.density);//
    setSensorValue(sensors, ID_SENSOR_oilPipeRC_viscosity,     1000000*m_heatPipes.oilPipeRC.viscosity);//
    setSensorValue(sensors, ID_SENSOR_oilPipeRC_mu,            m_heatPipes.oilPipeRC.mu);//
    setSensorValue(sensors, ID_SENSOR_oilPipeRC_v,             m_heatPipes.oilPipeRC.v);//
    setSensorValue(sensors, ID_SENSOR_oilPipeRC_Re,            m_heatPipes.oilPipeRC.Re);//
    setSensorValue(sensors, ID_SENSOR_oilPipeRC_deltaH,        m_heatPipes.oilPipeRC.deltaH);//
    setSensorValue(sensors, ID_SENSOR_oilPipeRC_coefFrick,     m_heatPipes.oilPipeRC.coefFrick/pow(m_heatPipes.oilPipeRC.Re, 2));//
    setSensorValue(sensors, ID_SENSOR_oilPipeRC_DP_Frick,      m_heatPipes.oilPipeRC.DP_Frick);//
    setSensorValue(sensors, ID_SENSOR_oilPipeRC_DP_DH,         m_heatPipes.oilPipeRC.DP_DH);//
    setSensorValue(sensors, ID_SENSOR_oilPipeRC_DP,            m_heatPipes.oilPipeRC.DP);//
    
    setSensorValue(sensors, ID_SENSOR_gasPipeRC_density,       m_heatPipes.gasPipeRC.density);//
    setSensorValue(sensors, ID_SENSOR_gasPipeRC_viscosity,     1000000*m_heatPipes.gasPipeRC.viscosity);//
    setSensorValue(sensors, ID_SENSOR_gasPipeRC_mu,            m_heatPipes.gasPipeRC.mu);//
    setSensorValue(sensors, ID_SENSOR_gasPipeRC_v,             m_heatPipes.gasPipeRC.v);//
    setSensorValue(sensors, ID_SENSOR_gasPipeRC_Re,            m_heatPipes.gasPipeRC.Re);//
    setSensorValue(sensors, ID_SENSOR_gasPipeRC_deltaH,        m_heatPipes.gasPipeRC.deltaH);//
    setSensorValue(sensors, ID_SENSOR_gasPipeRC_coefFrick,     m_heatPipes.gasPipeRC.coefFrick/pow(m_heatPipes.gasPipeRC.Re, 2));//
    setSensorValue(sensors, ID_SENSOR_gasPipeRC_DP_Frick,      m_heatPipes.gasPipeRC.DP_Frick);//
    setSensorValue(sensors, ID_SENSOR_gasPipeRC_DP_DH,         m_heatPipes.gasPipeRC.DP_DH);//
    setSensorValue(sensors, ID_SENSOR_gasPipeRC_DP,            m_heatPipes.gasPipeRC.DP);//
    
    return GPA_RESULT_OK;
}
gpaResult gpaFireOilHeater::checkParamValues(const gpaExtParameter *values) const
{
    (void)values;
    return GPA_RESULT_OK;
}

void gpaFireOilHeater::setNames()
{
    m_heatPipes.setName("pipes");
}

gpaResult gpaFireOilHeater::initMixtureFlow(const gpaExtParameter *values)
{
    // Назначаем параметры проточных элементов
    bool good = true;
    return GPA_RESULT_OK;
}

gpaResult gpaFireOilHeater::setParamValues(const gpaExtParameter *values, bool checkNeeded)
{

    //набор параметров модели
    //m_heatPipes.LHV_Fuel             = values[ID_PARAM_LHV_Fuel].value.realValue;
    // m_heatPipes.kQCC                = values[ID_PARAM_kQCC].value.realValue;
    // m_heatPipes.kQRC                = values[ID_PARAM_kQRC].value.realValue;
    // m_heatPipes.k_LMTDRC            = values[ID_PARAM_k_LMTDRC].value.realValue;

    // набор значений еременных для их инициализации
    m_heatPipes.temp_gas_star_zero    = values[ID_PARAM_temp_gas_star_zero].value.realValue + 273;
    m_heatPipes.temp_gas_oil_zero     = values[ID_PARAM_temp_gas_oil_zero] .value.realValue + 273;
    // переключение между библ
    //m_heatPipes.flagMixBibl         = values[ID_PARAM_flagMixBibl].value.realValue;    


    //Параметры геометрии 
    //Перечень входных геометрических параметров КР (RC - radiation chamber) 7
    m_heatPipes.aRC         =values[ID_PARAM_aRC].value.realValue;
    m_heatPipes.bRC         =values[ID_PARAM_bRC].value.realValue;
    m_heatPipes.lPipeRC     =values[ID_PARAM_lPipeRC].value.realValue;
    m_heatPipes.dPipeRC     =values[ID_PARAM_dPipeRC].value.realValue;
    m_heatPipes.nPipeRC     =values[ID_PARAM_nPipeRC].value.realValue;
    m_heatPipes.deltaPipeRC =values[ID_PARAM_deltaPipeRC].value.realValue;
    m_heatPipes.epsilonRC   =values[ID_PARAM_epsilonRC].value.realValue;

    //Перечень входных геометрических параметров КК (СC - convection chamber) 16
    m_heatPipes.lPipeCC =   values[ID_PARAM_lPipeCC].value.realValue;
    m_heatPipes.dPipeCC =   values[ID_PARAM_dPipeCC].value.realValue;

    m_heatPipes.aCC =       values[ID_PARAM_aCC].value.realValue;
    m_heatPipes.bCC =       values[ID_PARAM_bCC].value.realValue;

    m_heatPipes.hCC1=       values[ID_PARAM_hCC1].value.realValue;
    m_heatPipes.hCC2=       values[ID_PARAM_hCC2].value.realValue;

    m_heatPipes.nPipeSmСС=  values[ID_PARAM_nPipeSmСС].value.realValue;
    m_heatPipes.nPipeCorСС= values[ID_PARAM_nPipeCorСС].value.realValue;
    m_heatPipes.deltaPipeCC=values[ID_PARAM_deltaPipeCC].value.realValue;
    m_heatPipes.epsilonСС=  values[ID_PARAM_epsilonСС].value.realValue;

    m_heatPipes.kRib=       values[ID_PARAM_kRib].value.realValue;
    m_heatPipes.deltaRib=   values[ID_PARAM_deltaRib].value.realValue;
    m_heatPipes.hRib=       values[ID_PARAM_hRib].value.realValue;

    m_heatPipes.s1=         values[ID_PARAM_s1].value.realValue;
    m_heatPipes.s2=         values[ID_PARAM_s2].value.realValue;
    m_heatPipes.s3=         values[ID_PARAM_s3].value.realValue;
    //Параметры геометрии
    //m_heatPipes.setParsMethodFlag=values[ID_PARAM_setParsMethodFlag].value.realValue;
    

    // Проверка параметров, если требуется
    if (checkNeeded)
    {
        gpaResult res = checkParamValues(values);
        if (res != GPA_RESULT_OK)
            return res;
    }
    // Даем названия элементам и потокам
    setNames();
    // Инициализируются элементы с потоком смеси
    gpaResult res = initMixtureFlow(values);
    if (res != GPA_RESULT_OK)
        return res;
    // Обновляем параметры воздуха на входе
    return res;
}

gpaResult gpaFireOilHeater::buildDevice()
{
    bool good = true;
    std::cout<<"buildDevice ------------------------------------------------"<<"\n";
    // Соединяем поток смеси по трубам с граничными потоками смеси системы
    good = good && m_heatPipes.connectMixStream(GPA_ELEM_CIRCUIT_0, ID_PORT_GAS_INLET,  getEdgeMixStream(ID_CIRCUIT,   ID_PORT_GAS_INLET),  GPA_STREAM_INLET);
    good = good && m_heatPipes.connectMixStream(GPA_ELEM_CIRCUIT_0, ID_PORT_GAS_OUTLET, getEdgeMixStream(ID_CIRCUIT,   ID_PORT_GAS_OUTLET), GPA_STREAM_OUTLET);
    good = good && m_heatPipes.connectMixStream(GPA_ELEM_CIRCUIT_Oil, ID_PORT_OIL_INLET,  getEdgeMixStream(ID_CIRCUIT_2, ID_PORT_OIL_INLET),  GPA_STREAM_INLET);
    good = good && m_heatPipes.connectMixStream(GPA_ELEM_CIRCUIT_Oil, ID_PORT_OIL_OUTLET, getEdgeMixStream(ID_CIRCUIT_2, ID_PORT_OIL_OUTLET), GPA_STREAM_OUTLET);
     std::cout<<"buildDevice goof"<<good <<"\n";
    if (!good)
        return GPA_ERROR_WRONG_ARGS;
    // Добавляем в систему все элементы и потоки
    setElements({&m_heatPipes});
    setStreams({});
     std::cout<<"buildDevice 2"<<"\n";
    return GPA_RESULT_OK;
}

gpaResult gpaFireOilHeater::initialize()
{
    // Подключить экспортируемый элемент к потокам в интеграторе
    std::cout<<"initialize ------------------------------------------------"<<"\n";
    gpaResult res = linkToCoreStreams();
    if (res != GPA_RESULT_OK)
        return res;
    // Соединяем все элементы друг с другом
    res = buildDevice();
    if (res != GPA_RESULT_OK)
        return res;
    // Создаем схемы течений (нужны соединенные элементы)
    if (!createSimStructures({}, {getOuterEntrance(ID_CIRCUIT, ID_PORT_GAS_INLET),
                                  getOuterEntrance(ID_CIRCUIT_2, ID_PORT_OIL_INLET)}))
        return GPA_ERROR_WRONG_ARGS;
    // Инициализируем систему
    return gpaExportSystem::initialize();
}

gpaResult gpaFireOilHeater::setSignals(const gpaConstVector &signals)
{

    gpaReal value;
    bool good = true;

    // if (getSignalValue(signals, ID_PARAM_kQCC, value))
    // m_heatPipes.kQCC               = value;
    // if (getSignalValue(signals, ID_PARAM_kQRC, value))
    // m_heatPipes.kQRC               = value;


    return GPA_RESULT_OK;
}
const gpaString* gpaFireOilHeater::getDeviceMixCircuitName(gpaUInt index)
{
    return index < NUM_CIRCUITS ? &m_circuitNames[index] : NULL;
}
const gpaString* gpaFireOilHeater::getDeviceMixPortName(gpaUInt circIdx, gpaUInt portIdx)
{
    return portIdx + circIdx*2 < 4 ? &m_portNames[portIdx + circIdx*2] : NULL;
}





