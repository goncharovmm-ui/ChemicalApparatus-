#include "gpaVolumeVaporatorElement.h"
#include "gpaInclude.h"
#include <cassert>
#include <iostream>
#include <numbers>
#include <numeric>

const gpaString initPresErrorStr = "Initial volume pressure must be positive";
const gpaString initTempErrorStr =
    "Initial volume temperature must be positive";
const gpaString initFractErrorStr =
    "Initial mole fractions must be in range [0,1] and their sum is less or "
    "equal to 1.0";
const gpaString liqHeatTransCoefErrorStr =
    "Gas-wall heat transfer coefficient must be non-negative";
const gpaString gasHeatTransCoefErrorStr =
    "Liquid-wall heat transfer coefficient must be non-negative";

const gpaString gpaVolumeVaporatorElement::m_typeName = "dynamic-volume";
const gpaString gpaVolumeVaporatorElement::m_description =
    "Однослойный объем с фазовым переходом";

// Конструктор по умолчанию
gpaVolumeVaporatorElement::gpaVolumeVaporatorElement(const gpaParentLink *link)
    : gpaVolumeElement(link), m_topHydroStatic(true), m_medium(NULL),
      m_medium2(NULL), m_useFlashPH(true), m_mixEnergy(0.0), m_mixMoles(0.0),
      m_initPressure(0.0), m_initTemperature(0.0), m_fractions(0),
      m_liquidLevel(0.0), m_savedVariables(0), m_initLiqVolumeFraction(0.01),
      m_eps_N_L(0.0) {
    for (gpaUInt i = 0; i < GPA_VOLUME_NUM_FACES; ++i)
        setHeatPortData(i, new gpaVolumeHeatData(this, i));
}

// Конструктор копирования
gpaVolumeVaporatorElement::gpaVolumeVaporatorElement(
    const gpaVolumeVaporatorElement &volume)
    : gpaVolumeElement(volume), m_topHydroStatic(volume.m_topHydroStatic),
      m_medium(volume.m_medium ? volume.m_medium->copyTo(asOwner()) : NULL),
      m_medium2(volume.m_medium2 ? volume.m_medium2->copyTo(asOwner()) : NULL),
      m_useFlashPH(volume.m_useFlashPH), m_mixEnergy(volume.m_mixEnergy),
      m_mixMoles(volume.m_mixMoles), m_initPressure(volume.m_initPressure),
      m_initTemperature(volume.m_initTemperature),
      m_fractions(volume.m_fractions), m_liquidLevel(volume.m_liquidLevel),
      m_tau_evap(volume.m_tau_evap), m_tau_vaporisate(volume.m_tau_vaporisate),
      m_eps_N_L(volume.m_eps_N_L), m_T_out(volume.m_T_out) {
    for (gpaUInt i = 0; i < GPA_VOLUME_NUM_FACES; ++i)
        setHeatPortData(i, new gpaVolumeHeatData(this, i));
}

gpaVolumeVaporatorElement::~gpaVolumeVaporatorElement() { finalizeMedium(); }

gpaVolumeVaporatorElement *gpaVolumeVaporatorElement::copy() const {
    return new gpaVolumeVaporatorElement(*this);
}

void gpaVolumeVaporatorElement::finalizeMedium() {
    if (m_medium)
        delete m_medium;
    m_medium = NULL;

    if (m_medium2)
        delete m_medium2;
    m_medium2 = NULL;
}

bool gpaVolumeVaporatorElement::setEvaporationTimeConstant(gpaReal tau_kip) {
    if (tau_kip <= 0.0)
        return false;
    m_tau_evap = tau_kip;
    return true;
}

bool gpaVolumeVaporatorElement::setVaporizationTimeConstant(
    gpaReal tau_vaporisate) {
    if (tau_vaporisate <= 0.0)
        return false;
    m_tau_vaporisate = tau_vaporisate;
    return true;
}

// Evaporation threshold
bool gpaVolumeVaporatorElement::setEvaporationThreshold(gpaReal eps_N_L) {
    if (eps_N_L < 0.0)
        return false;
    m_eps_N_L = eps_N_L;
    return true;
}

bool gpaVolumeVaporatorElement::setWallLayer(gpaHeatLayer layer) {
    m_wallLayer = layer;
    return true;
}

bool gpaVolumeVaporatorElement::addIsolationLayer(gpaHeatLayer layer) {
    m_isolationLayers.push_back(layer);
    return true;
}

bool gpaVolumeVaporatorElement::setGasHeatTransferCoeff(gpaReal alpha_in_gas) {
    if (alpha_in_gas <= 0.0)
        return false;
    m_alpha_in_gas = alpha_in_gas;
    return true;
}

bool gpaVolumeVaporatorElement::setLiquidHeatTransferCoeff(
    gpaReal alpha_in_liq) {
    if (alpha_in_liq <= 0.0)
        return false;
    m_alpha_in_liq = alpha_in_liq;
    return true;
}

bool gpaVolumeVaporatorElement::setMiddleLayerCoeff(gpaReal alpha_m) {
    if (alpha_m <= 0.0)
        return false;
    m_alpha_m = alpha_m;
    return true;
}

bool gpaVolumeVaporatorElement::setOuterLayerCoeff(gpaReal alpha_out) {
    if (alpha_out <= 0.0)
        return false;
    m_alpha_out = alpha_out;
    return true;
}

bool gpaVolumeVaporatorElement::setHeatTransferParams(gpaReal alpha_in_gas,
                                                      gpaReal alpha_in_liq) {
    if (!setGasHeatTransferCoeff(alpha_in_gas))
        return false;
    if (!setLiquidHeatTransferCoeff(alpha_in_liq))
        return false;
    return true;
}

// Ambient temperature
bool gpaVolumeVaporatorElement::setAmbientTemperature(gpaReal T_out) {
    if (T_out < 0)
        return false; // Absolute zero check
    m_T_out = T_out;
    return true;
}

bool gpaVolumeVaporatorElement::setInitFractions(
    const gpaConstVector &fractions) {
    bool good = true;
    good &= gpaMedium::checkInitFractions(fractions);
    if (!good)
        pushParameterError(initFractErrorStr, this);
    m_fractions.resize(fractions.size());
    m_fractions = fractions;
    good &= gpaMedium::prepareInitFractions(m_fractions);

    return good;
}

bool gpaVolumeVaporatorElement::setInitPressure(gpaReal initPressure) {
    if (initPressure < 0)
        return false;
    m_initPressure = initPressure;
    return true;
}

bool gpaVolumeVaporatorElement::setInitLiqVolumeFraction(
    gpaReal volumeFraction) {
    if ((volumeFraction < 0) || (volumeFraction > 1))
        return false;
    m_initLiqVolumeFraction = volumeFraction;
    return true;
}

bool gpaVolumeVaporatorElement::setInitTemperature(gpaReal initTemperature) {
    if (initTemperature < 0)
        return false;
    m_initTemperature = initTemperature;
    return true;
}

bool gpaVolumeVaporatorElement::aboveLiquidSurface(gpaReal level) const {
    return m_liquidLevel <= level;
}

gpaReal gpaVolumeVaporatorElement::getPressureAt(gpaReal level) const {
    gpaReal hydro = vmMax(0.0, m_liquidLevel - level);
    gpaReal gas = getShape()->getHeight() - vmMax(level, m_liquidLevel);
    gpaReal pressure = m_medium->getPressure() +
                       GPA_GRAVITY_ACCELERATION / GPA_KILOPASCAL_TO_PASCAL *
                           (hydro * m_medium->getLiquidDensity() +
                            gas * m_medium->getGasDensity());

    //  gpaReal pressure = m_medium->getPressure() +
    //                     (level < m_liquidLevel ? level : m_liquidLevel) *
    //                         GPA_GRAVITY_ACCELERATION *
    //                         m_medium->getLiquidDensity() /
    //                         GPA_KILOPASCAL_TO_PASCAL;
    //  if (level > m_liquidLevel)
    //    pressure += GPA_GRAVITY_ACCELERATION * (level - m_liquidLevel) *
    //                m_medium->getGasDensity() / GPA_KILOPASCAL_TO_PASCAL;
    return pressure;
}

gpaReal gpaVolumeVaporatorElement::getTemperatureAt(gpaReal) const {
    return m_medium->getTemperature();
}

gpaReal
gpaVolumeVaporatorElement::getMolarMassFor(gpaReal gasVolumeFraction) const {
    if (gasVolumeFraction == 1)
        return m_medium->getGasMolarMass();
    if (gasVolumeFraction == 0)
        return m_medium->getLiquidMolarMass();
    return vmAffine(m_medium->getGasMolarMass(), m_medium->getLiquidMolarMass(),
                    m_medium->calcGasMolarFraction(gasVolumeFraction));
}

gpaReal
gpaVolumeVaporatorElement::getEnthalpyFor(gpaReal gasVolumeFraction) const {
    if (gasVolumeFraction == 1)
        return m_medium->getGasEnthalpy();
    if (gasVolumeFraction == 0)
        return m_medium->getLiquidEnthalpy();
    return vmAffine(m_medium->getGasEnthalpy(), m_medium->getLiquidEnthalpy(),
                    m_medium->calcGasMolarFraction(gasVolumeFraction));
}

gpaReal
gpaVolumeVaporatorElement::getDensityFor(gpaReal gasVolumeFraction) const {
    if (gasVolumeFraction == 1)
        return m_medium->getGasDensity();
    if (gasVolumeFraction == 0)
        return m_medium->getLiquidDensity();
    return vmAffine(m_medium->getGasDensity(), m_medium->getLiquidDensity(),
                    gasVolumeFraction);
}

gpaReal
gpaVolumeVaporatorElement::getViscosityFor(gpaReal gasVolumeFraction) const {
    if (gasVolumeFraction == 1)
        return m_medium->getGasViscosity();
    if (gasVolumeFraction == 0)
        return m_medium->getLiquidViscosity();
    return vmAffine(m_medium->getGasViscosity(), m_medium->getLiquidViscosity(),
                    gasVolumeFraction);
}

void gpaVolumeVaporatorElement::getFractionsFor(
    gpaDataVector &fractions, gpaReal gasVolumeFraction) const {
    if (gasVolumeFraction == 1)
        fractions = m_medium->getGasFractions();
    else if (gasVolumeFraction == 0)
        fractions = m_medium->getLiquidFractions();
    else {
        gpaReal molarFraction =
            m_medium->calcGasMolarFraction(gasVolumeFraction);
        const gpaConstVector &gasFracs = m_medium->getGasFractions();
        const gpaConstVector &liqFracs = m_medium->getLiquidFractions();
        for (gpaUInt i = 0; i < fractions.size(); ++i)
            fractions[i] = vmAffine(gasFracs[i], liqFracs[i], molarFraction);
    }
}

gpaReal gpaVolumeVaporatorElement::getTransitionLevel(gpaReal level,
                                                      gpaReal radius) const {
    gpaReal transLevel = level;
    if (level == 0.0)
        transLevel = radius / 4.0;
    if (level == getShape()->getHeight())
        transLevel = getShape()->getHeight() - radius / 4.0;
    return transLevel;
}

gpaReal gpaVolumeVaporatorElement::getTransitionRadius(gpaReal level,
                                                       gpaReal radius) const {
    gpaReal transRadius = radius;
    if (level == 0.0 || level == getShape()->getHeight())
        transRadius = radius / 4.0;
    return transRadius;
}

gpaReal gpaVolumeVaporatorElement::getMixEnergy() const { return m_mixEnergy; }

gpaReal gpaVolumeVaporatorElement::getMixMoles() const { return m_mixMoles; }

gpaReal gpaVolumeVaporatorElement::getCondensationRate() const {
    return G_cond;
}

gpaReal gpaVolumeVaporatorElement::getEvaporationRate() const { return G_evap; }

gpaReal gpaVolumeVaporatorElement::getIncomingGasHeatRate() const {
    return Q_G;
}

gpaReal gpaVolumeVaporatorElement::getIncomingLiquidHeatRate() const {
    return Q_L;
}

void gpaVolumeVaporatorElement::updateLiquidLevel(gpaReal mixMoles) {
    gpaReal steamContent = m_medium->getSteamContent();
    m_liquidLevel = getShape()->getLevelFor((1.0 - steamContent) * mixMoles *
                                            m_medium->getLiquidMolarMass() /
                                            m_medium->getLiquidDensity());
}

gpaReal gpaVolumeVaporatorElement::getLiquidVolume() const {
    return getShape()->getVolumeAt(m_liquidLevel);
}

gpaUInt gpaVolumeVaporatorElement::getNumVariables() const {
    return m_medium->getNumComponents() + 2 + getNumMixPorts();
}

gpaResult gpaVolumeVaporatorElement::initialize() {
    const gpaMedium *medium = getCircuitMedium();

    if (!medium)
        return GPA_ERROR_WRONG_ARGS;
    if (!medium->supportsFlash(PH_FLASH) || !medium->supportsFlash(PT_FLASH))
        return GPA_ERROR_UNSUPPORTED;
    if (m_fractions.size() != medium->getNumComponents())
        return GPA_ERROR_WRONG_ARGS;
    finalizeMedium();

    m_medium = medium->copyTo(asOwner());
    m_medium2 = medium->copyTo(asOwner());
    m_savedVariables.resize(getNumVariables());
    m_savedVariables = -1;

    gpaResult res = gpaVolumeElement::initialize();
    if (res != GPA_RESULT_OK)
        return res;
    res = m_medium->calcFlashPT(m_initPressure, m_initTemperature, m_fractions);
    if (res != GPA_RESULT_OK)
        return res;

    const gpaReal V = getShape()->getVolume();
    const gpaReal molesLiq = V / m_medium->getMolarVolume();
    updateLiquidLevel(molesLiq);
    return GPA_RESULT_OK;
}

void gpaVolumeVaporatorElement::fillVarNames(gpaStringVector &varNames) const {
    size_t numComonents = m_medium->getNumComponents();

    for (size_t i = 0; i < numComonents; ++i)
        varNames[i] = "n" + gpaToString(i);

    varNames[numComonents] = "U";
    varNames[numComonents + 1] = "p";

    gpaElementMixCircuit *circuit = getMixCircuit(GPA_ELEM_CIRCUIT_0);
    for (auto iter = circuit->firstPortIter(); iter != circuit->lastPortIter();
         ++iter) {
        const gpaUInt portID = iter->first;
        varNames[numComonents + 2 + portID] =
            "virtual velocity" + gpaToString(portID);
    }
}
void gpaVolumeVaporatorElement::fillEquationNames(
    gpaStringVector &eqNames) const {
    const size_t numComonents = m_medium->getNumComponents();

    for (size_t i = 0; i < numComonents; ++i)
        eqNames[i] = "n" + gpaToString(i);

    eqNames[numComonents] = "U";
    eqNames[numComonents + 1] = "p";

    gpaElementMixCircuit *circuit = getMixCircuit(GPA_ELEM_CIRCUIT_0);
    gpaUInt numPorts = getNumMixPorts();
    for (auto iter = circuit->firstPortIter(); iter != circuit->lastPortIter();
         ++iter) {
        const gpaUInt portID = iter->first;
        eqNames[numComonents + 2 + portID] =
            "virtual velocity" + gpaToString(portID);
        eqNames[numComonents + 2 + portID + numPorts] =
            "pressure" + gpaToString(portID);
    }
}

gpaResult gpaVolumeVaporatorElement::initVariables(gpaVector &variables) const {
    const gpaReal V = getShape()->getVolume() + m_external_volume;
    const gpaReal molesLiq = V / m_medium->getMolarVolume();

    for (gpaUInt i = 0; i < m_fractions.size(); i++)
        variables[i] = m_fractions[i] * molesLiq;

    // set internal energy
    variables[m_fractions.size()] = molesLiq * m_medium->getEnergy();
    // set pressure
    variables[m_fractions.size() + 1] = m_initPressure;

    gpaElementMixCircuit *circuit = getMixCircuit(GPA_ELEM_CIRCUIT_0);

    for (auto iter = circuit->firstPortIter(); iter != circuit->lastPortIter();
         ++iter) {
        const gpaUInt portID = iter->first;
        variables[m_fractions.size() + 2 + portID] = 0;
    }

    return GPA_RESULT_OK;
}

gpaResult gpaVolumeVaporatorElement::fillMassMatrix(gpaUInt refRow,
                                                    gpaUInt refCol) const {
    const size_t numComponents = m_medium->getNumComponents();
    for (size_t i = 0; i <= numComponents; ++i)
        setMassMatrCoef(refRow + i, refCol + i, 1.0);

    gpaElementMixCircuit *circuit = getMixCircuit(GPA_ELEM_CIRCUIT_0);
    for (auto iter = circuit->firstPortIter(); iter != circuit->lastPortIter();
         ++iter) {
        const gpaUInt portID = iter->first;
        setMassMatrCoef(refRow + numComponents + 2 + portID,
                        refCol + numComponents + 2 + portID, 1.0);
    }

    return GPA_RESULT_OK;
}

gpaResult gpaVolumeVaporatorElement::calcFuncValues(
    const gpaConstVector &, const gpaConstVector &variables, gpaVector &values,
    const gpaSetOfEquations &eqIds) {
    gpaElementMixCircuit *circuit = getMixCircuit(GPA_ELEM_CIRCUIT_0);
    const size_t numComponents = m_medium->getNumComponents();
    std::fill_n(values.data(), values.size(), 0.0);

    m_mixMoles = std::accumulate(variables.data(),
                                 variables.data() + numComponents, 0.0);
    m_mixEnergy = variables[numComponents];
    m_vel_1 = variables[numComponents + 2 + 1];
    m_vel_2 = variables[numComponents + 2 + 2];

    for (size_t i = 0; i < numComponents; ++i)
        m_fractions[i] = variables[i] / m_mixMoles;

    gpaReal pv = getShape()->getVolume() * (variables[numComponents + 1]);
    gpaReal effectiv_volume = m_external_volume + getShape()->getVolume();
    gpaResult res = m_medium->calcFlashUv(
        (m_mixEnergy) / m_mixMoles, effectiv_volume / m_mixMoles, m_fractions);

    if (res != GPA_RESULT_OK)
        return res;

    updateLiquidLevel(m_mixMoles);

    for (auto iter = circuit->firstPortIter(); iter != circuit->lastPortIter();
         ++iter) {
        const gpaUInt portID = iter->first;
        const gpaMixPort *port = iter->second;
        const gpaVolumeFittingData *fitting = getFittingData(portID);
        const gpaReal flowRate = port->getIncomingFlowRate();
        const gpaDataVector inflowFractions = port->getStreamFractions();
        const gpaReal inflowEnergy = port->getStreamEnthalpy();

        // compute component flow rates
        for (size_t i = 0; i < numComponents; ++i) {
            values[i] += flowRate * inflowFractions[i];
        }

        // compute flow energy
        values[numComponents] += flowRate * inflowEnergy;

        const gpaReal rho = port->getStreamMedium()->getDensity();
        const gpaReal g =
            port->getIncomingVolRate() /
            (std::numbers::pi * fitting->getRadius() * fitting->getRadius());
        const gpaReal g2 = variables[numComponents + 2 + portID];

        const gpaReal v1 =
            port->getIncomingMassRate() /
            (std::numbers::pi * fitting->getRadius() * fitting->getRadius());
        const gpaReal deltaP = 0.5 * (v1 * v1 * vmSign(v1)) / rho / 2;

        values[numComponents + 2 + portID] = -10.0 / rho * (g2 - v1);
        gpaReal portPressure = fitting->getPressure();
        values[numComponents + 2 + portID + getNumMixPorts()] =
            (-v1 * v1 / 2 / rho * vmSign(v1) + port->getStreamPressure()) -
            (-g2 * g2 / 2 / rho * vmSign(g2) + portPressure) - deltaP;
    }

    values[numComponents] += m_q_heater;
    values[numComponents + 1] =
        m_medium->getPressure() - variables[numComponents + 1];

    m_ten_T = m_medium->getTemperature() + m_q_heater / m_alpha_in;
    return GPA_RESULT_OK;
}
