#include "gpaReboilerVolume.h"
#include "gpaReboilerShape.h"
#include <cassert>
#include <numbers>

namespace {
gpaReal sigmoid(gpaReal x) { return 1.0 / (1.0 + std::exp(-x)); }
} // namespace

const gpaString initPresErrorStr = "Initial volume pressure must be positive";
const gpaString initTempErrorStr =
    "Initial volume temperature must be positive";
const gpaString initFractErrorStr =
    "Initial mole fractions must be in range [0,1] and their sum is less or "
    "equal to 1.0";
const gpaString liqHeatTransCoefErrorStr =
    "Gas-wall heat transfer coefficient must be non-negative";
const gpaString gasHeatTransCoefErrorStr =
    "Liquid-wall heat transfer coefficient must be non-negative";

const gpaString gpaReboilerVolume::m_typeName = "reboiler-volume";
const gpaString gpaReboilerVolume::m_description =
    "Однослойный объем с фазовым переходом";

// Конструктор по умолчанию
gpaReboilerVolume::gpaReboilerVolume(const gpaParentLink *link)
    : gpaVolumeElement(link), m_topHydroStatic(true), m_firstMedium(NULL),
      m_secondMedium(NULL), m_firstEnthalpy(0.0), m_firstMoles(0.0),
      m_secondEnthalpy(0.0), m_secondMoles(0.0), m_initPressure(0.0),
      m_initTemperature(0.0), m_secondFractions(0), m_firstFractions(0),
      m_firstLiquidLevel(0.0), m_alpha_first_gas(0.0),
      m_initLiqVolumeFraction(0.01), m_savedVariables(0) {
  m_portLocation = 1 << 1 | 1 << 2;
  setMixCircuit(new gpaElementMixCircuit(this, 1));
  for (gpaUInt i = 0; i < GPA_VOLUME_NUM_FACES; ++i)
    setHeatPortData(i, new gpaVolumeHeatData(this, i));
}

// Конструктор копирования
gpaReboilerVolume::gpaReboilerVolume(const gpaReboilerVolume &volume)
    : gpaVolumeElement(volume), m_topHydroStatic(volume.m_topHydroStatic),
      m_firstMedium(volume.m_firstMedium
                        ? volume.m_firstMedium->copyTo(asOwner())
                        : NULL),
      m_secondMedium(volume.m_secondMedium
                         ? volume.m_secondMedium->copyTo(asOwner())
                         : NULL),
      m_firstEnthalpy(volume.m_firstEnthalpy),
      m_firstMoles(volume.m_firstMoles),
      m_secondEnthalpy(volume.m_secondEnthalpy),
      m_secondMoles(volume.m_secondMoles),
      m_initPressure(volume.m_initPressure),
      m_initTemperature(volume.m_initTemperature),
      m_secondFractions(volume.m_secondFractions),
      m_firstFractions(volume.m_firstFractions),
      m_firstLiquidLevel(volume.m_firstLiquidLevel),
      m_tauDiff(volume.m_tauDiff), m_wallLayer(volume.m_wallLayer),
      m_alpha_first_gas(volume.m_alpha_first_gas), m_T_env(volume.m_T_env) {
  for (gpaUInt i = 0; i < GPA_VOLUME_NUM_FACES; ++i)
    setHeatPortData(i, new gpaVolumeHeatData(this, i));
  for (auto &layer : volume.m_isolationLayers)
    m_isolationLayers.push_back(layer);
}

gpaReboilerVolume::~gpaReboilerVolume() { finalizeMedium(); }

gpaReboilerVolume *gpaReboilerVolume::copy() const {
  return new gpaReboilerVolume(*this);
}

gpaUInt gpaReboilerVolume::getMinNumMixPorts(gpaUInt index) const {
  switch (index) {
  case GPA_ELEM_CIRCUIT_0:
    return 4;
    break;
  case 1:
    return 2;
    break;

  default:
    return 0;
    break;
  }
}

gpaUInt gpaReboilerVolume::getMaxNumMixPorts(gpaUInt index) const {
  switch (index) {
  case GPA_ELEM_CIRCUIT_0:
    return 4;
    break;
  case 1:
    return 2;
    break;

  default:
    return 0;
    break;
  }
}

void gpaReboilerVolume::finalizeMedium() {
  if (m_firstMedium)
    delete m_firstMedium;
  m_firstMedium = NULL;
  if (m_secondMedium)
    delete m_secondMedium;
  m_secondMedium = NULL;
}

bool gpaReboilerVolume::setPartitionProperties(gpaReal partitionHeight,
                                                  gpaReal tauDiff,
                                                  gpaReal tauLiq,
                                                  gpaReal tauLiqDiff,
                                                  gpaReal liqDiffFlowrate) {
  m_partitionHeight = partitionHeight;
  m_tauDiff = tauDiff;
  m_tauLiq = tauLiq;
  m_tauLiqDiff = tauLiqDiff;
  m_liqDiffFlowrate = liqDiffFlowrate;
  return true;
}

bool gpaReboilerVolume::addIsolationLayer(gpaHeatLayer layer) {
  m_isolationLayers.push_back(layer);
  return true;
}

// Heat transfer coefficients
bool gpaReboilerVolume::setGasHeatTransferCoeff(gpaReal alpha_in_gas) {
  if (alpha_in_gas <= 0.0)
    return false;
  m_alpha_first_gas = alpha_in_gas;
  m_alpha_second_gas = alpha_in_gas;
  return true;
}

bool gpaReboilerVolume::setLiquidHeatTransferCoeff(gpaReal alpha_in_liq) {
  if (alpha_in_liq <= 0.0)
    return false;
  m_alpha_first_liq = alpha_in_liq;
  m_alpha_second_liq = alpha_in_liq;
  return true;
}

bool gpaReboilerVolume::setWallParameters(gpaReal heatCapacity,
                                             gpaReal density) {
  if (heatCapacity < 0.0)
    return false;
  m_heatCapacity = heatCapacity;
  m_density = density;
  return true;
}

// Ambient temperature
bool gpaReboilerVolume::setAmbientTemperature(gpaReal T_env) {
  if (T_env < 0)
    return false; // Absolute zero check
  m_T_env = T_env;
  return true;
}

// Combined setters for physical validation
bool gpaReboilerVolume::setMixHeatTransferParams(gpaReal alpha_in_gas,
                                                    gpaReal alpha_in_liq) {
  if (!setGasHeatTransferCoeff(alpha_in_gas))
    return false;
  if (!setLiquidHeatTransferCoeff(alpha_in_liq))
    return false;
  return true;
}

bool gpaReboilerVolume::setShellMixHeatTransferParams(
    gpaReal alpha_in_shell, gpaReal alpha_out_gas, gpaReal alpha_out_liq) {
  m_alpha_in_shell = alpha_in_shell;
  m_alpha_out_shell_gas = alpha_out_gas;
  m_alpha_out_shell_liq = alpha_out_liq;
  return true;
}

bool gpaReboilerVolume::setShellParameters(
    gpaReal roughness, gpaReal minHeight, gpaReal maxHeight, gpaReal diameter,
    gpaReal heightDiff, gpaReal thickness, gpaReal length, gpaUInt numPipes) {
  m_shellRoughness = roughness;
  m_shellMinHeight = minHeight;
  m_shellMaxHeight = maxHeight;
  m_shellDiameter = diameter;
  m_shellHeightDiff = heightDiff;
  m_shellThickness = thickness;
  m_shellLength = length;
  m_shellNumPipes = numPipes;
  return true;
}

bool gpaReboilerVolume::setGeometryParameters(gpaReal cylynderLength,
                                                 gpaReal cylynderHeight,
                                                 gpaReal minorCylynderLength,
                                                 gpaReal minorCylynderHeight,
                                                 gpaReal thickness) {
  m_cylynderHeight = cylynderHeight;
  m_cylynderLength = cylynderLength;
  m_minorCylynderHeight = minorCylynderHeight;
  m_minorCylynderLength = minorCylynderLength;
  m_thickness = thickness;
  return true;
}

bool
gpaReboilerVolume::setInitSecondFractions(const gpaConstVector &fractions) {
  bool good = true;
  good &= gpaMedium::checkInitFractions(fractions);
  if (!good)
    pushParameterError(initFractErrorStr, this);
  m_secondFractions.resize(fractions.size());
  m_secondFractions = fractions;
  good &= gpaMedium::prepareInitFractions(m_secondFractions);
  return good;
}

bool
gpaReboilerVolume::setInitFirstFractions(const gpaConstVector &fractions) {
  bool good = true;
  good &= gpaMedium::checkInitFractions(fractions);
  if (!good)
    pushParameterError(initFractErrorStr, this);
  m_firstFractions.resize(fractions.size());
  m_firstFractions = fractions;
  good &= gpaMedium::prepareInitFractions(m_firstFractions);
  return good;
}

bool gpaReboilerVolume::setInitPressure(gpaReal initPressure) {
  if (initPressure < 0)
    return false;
  m_initPressure = initPressure;
  return true;
}

bool gpaReboilerVolume::setInitLiqVolumeFraction(gpaReal volumeFraction) {
  if ((volumeFraction < 0) || (volumeFraction > 1))
    return false;
  m_initLiqVolumeFraction = volumeFraction;
  return true;
}

bool gpaReboilerVolume::setInitTemperature(gpaReal initTemperature) {
  if (initTemperature < 0)
    return false;
  m_initTemperature = initTemperature;
  return true;
}

bool gpaReboilerVolume::aboveLiquidSurface(gpaReal level) const {
  return m_firstLiquidLevel <= level;
}

gpaReal gpaReboilerVolume::getPressureAt(gpaReal level) const {
  gpaReal gasDensity = m_firstMedium->getGasDensity();
  gpaReal gasColumn =
      gasDensity * (getShape()->getHeight() - m_firstLiquidLevel);
  gpaReal upGasColumn = level > m_firstLiquidLevel
                            ? gasDensity * (getShape()->getHeight() - level)
                            : gasColumn;
  gpaReal liqColumn = m_firstMedium->getLiquidDensity() *
                      vmMax(0.0, m_firstLiquidLevel - level);
  gpaReal column = upGasColumn + liqColumn;
  if (!m_topHydroStatic)
    column -= gasColumn;
  return m_firstMedium->getPressure() +
         GPA_GRAVITY_ACCELERATION * column / GPA_KILOPASCAL_TO_PASCAL;
}

gpaReal gpaReboilerVolume::getTemperatureAt(gpaReal) const {
  return m_firstMedium->getTemperature();
}

gpaReal gpaReboilerVolume::getMolarMassFor(gpaReal gasVolumeFraction) const {
  if (gasVolumeFraction == 1)
    return m_secondMedium->getGasMolarMass();
  if (gasVolumeFraction == 0)
    return m_firstMedium->getLiquidMolarMass();
  return vmAffine(m_secondMedium->getGasMolarMass(),
                  m_firstMedium->getLiquidMolarMass(),
                  m_secondMedium->calcGasMolarFraction(gasVolumeFraction));
}

gpaReal gpaReboilerVolume::getEnthalpyFor(gpaReal gasVolumeFraction) const {
  if (gasVolumeFraction == 1)
    return m_secondMedium->getGasEnthalpy();
  if (gasVolumeFraction == 0)
    return m_firstMedium->getLiquidEnthalpy();
  return vmAffine(m_secondMedium->getGasEnthalpy(),
                  m_firstMedium->getLiquidEnthalpy(),
                  m_secondMedium->calcGasMolarFraction(gasVolumeFraction));
}

gpaReal gpaReboilerVolume::getDensityFor(gpaReal gasVolumeFraction) const {
  if (gasVolumeFraction == 1)
    return m_secondMedium->getGasDensity();
  if (gasVolumeFraction == 0)
    return m_firstMedium->getLiquidDensity();
  return vmAffine(m_secondMedium->getGasDensity(),
                  m_firstMedium->getLiquidDensity(), gasVolumeFraction);
}

gpaReal gpaReboilerVolume::getViscosityFor(gpaReal gasVolumeFraction) const {
  if (gasVolumeFraction == 1)
    return m_secondMedium->getGasViscosity();
  if (gasVolumeFraction == 0)
    return m_firstMedium->getLiquidViscosity();
  return vmAffine(m_secondMedium->getGasViscosity(),
                  m_firstMedium->getLiquidViscosity(), gasVolumeFraction);
}

void gpaReboilerVolume::getFractionsFor(gpaDataVector &fractions,
                                        gpaReal gasVolumeFraction) const {
  if (gasVolumeFraction == 1)
    fractions = m_secondMedium->getGasFractions();
  else if (gasVolumeFraction == 0)
    fractions = m_firstMedium->getLiquidFractions();
  else {
    gpaReal molarFraction =
        m_secondMedium->calcGasMolarFraction(gasVolumeFraction);
    const gpaConstVector &gasFracs = m_secondMedium->getGasFractions();
    const gpaConstVector &liqFracs = m_firstMedium->getLiquidFractions();
    for (gpaUInt i = 0; i < fractions.size(); ++i)
      fractions[i] = vmAffine(gasFracs[i], liqFracs[i], molarFraction);
  }
}

gpaReal gpaReboilerVolume::getTransitionLevel(gpaReal level,
                                              gpaReal radius) const {
  gpaReal transLevel = level;
  if (level == 0.0)
    transLevel = radius / 4.0;
  if (level == getShape()->getHeight())
    transLevel = getShape()->getHeight() - radius / 4.0;
  return transLevel;
}

gpaReal gpaReboilerVolume::getTransitionRadius(gpaReal level,
                                               gpaReal radius) const {
  gpaReal transRadius = radius;
  if (level == 0.0 || level == getShape()->getHeight())
    transRadius = radius / 4.0;
  return transRadius;
}

gpaReal gpaReboilerVolume::getEnthalpySum() const {
  return m_firstEnthalpy + m_secondEnthalpy;
}

gpaReal gpaReboilerVolume::getMolesSum() const {
  return m_firstMoles + m_secondMoles;
}

gpaReal gpaReboilerVolume::getPartitionFlowRate() const {
  return m_partitionFlowRate;
}

void gpaReboilerVolume::updateLiquidLevel(gpaReal mixMoles) {
  gpaReal steamContent = m_firstMedium->getSteamContent();
  m_firstLiquidLevel = getShape()->getLevelFor(
      (1.0 - steamContent) * mixMoles * m_firstMedium->getLiquidMolarVolume());
  m_firstLiquidLevel =
      vmMin(vmMax(m_firstLiquidLevel, 0.0), getShape()->getHeight());
}

gpaReal gpaReboilerVolume::getLiquidVolume() const {
  return getShape()->getVolumeAt(m_firstLiquidLevel);
}

gpaUInt gpaReboilerVolume::getNumVariables() const {
  return 6 + 2 * m_firstMedium->getNumComponents();
}

gpaResult gpaReboilerVolume::initialize() {
  const gpaMedium *medium = getCircuitMedium();
  if (!medium)
    return GPA_ERROR_WRONG_ARGS;
  if (!medium->supportsFlash(PH_FLASH) || !medium->supportsFlash(PT_FLASH))
    return GPA_ERROR_UNSUPPORTED;
  if (m_firstFractions.size() != medium->getNumComponents())
    return GPA_ERROR_WRONG_ARGS;
  finalizeMedium();
  m_firstMedium = medium->copyTo(asOwner());
  m_secondMedium = medium->copyTo(asOwner());
  m_savedVariables.resize(getNumVariables());
  m_savedVariables = -1;
  gpaResult res = gpaVolumeElement::initialize();
  if (res != GPA_RESULT_OK)
    return res;
  res = m_firstMedium->calcFlashPT(m_initPressure, m_initTemperature,
                                   m_firstFractions);
  res &= m_secondMedium->calcFlashPT(m_initPressure, m_initTemperature,
                                     m_secondFractions);
  if (res != GPA_RESULT_OK)
    return res;

  calcHeatTransferProperties();
  const gpaReboilerShape *shape = (gpaReboilerShape *)getShape();
  gpaReal V = shape->getFirstVolume();
  gpaReal VL = 1 - m_firstMedium->getSteamContent();
  gpaReal moles = V / m_firstMedium->getMolarVolume();
  m_firstLiquidLevel = shape->getFirstLevelFor(
      moles * VL * m_firstMedium->getLiquidMolarVolume());
  V = shape->getSecondVolume();
  VL = 1 - m_secondMedium->getSteamContent();
  moles = V * VL / m_secondMedium->getMolarVolume();
  m_secondLiquidLevel = shape->getSecondLevelFor(
      moles * VL * m_secondMedium->getLiquidMolarVolume());
  return GPA_RESULT_OK;
}

bool gpaReboilerVolume::calcHeatTransferProperties() {
  const gpaReboilerShape *shape = (gpaReboilerShape *)getShape();
  m_A_in_first = shape->getFirstArea();
  gpaReal r_priv = (m_minorCylynderLength * m_shellMinHeight / 2 +
                    m_cylynderLength * m_shellMaxHeight / 2) /
                   (m_cylynderLength + m_minorCylynderLength);
  m_A_out_first = m_A_in_first * (1 + m_thickness / r_priv);
  m_A_in_second = shape->getSecondArea();
  m_A_out_second = m_A_in_second * (1 + 2 * m_thickness / m_shellMaxHeight);
  gpaReal dOut = m_shellDiameter + 2 * m_shellThickness;
  m_A_out_shell = m_shellNumPipes *
                  (2 * std::numbers::pi * dOut * (m_shellLength - 0.5 * m_shellHeightDiff) +
                   std::numbers::pi * m_shellHeightDiff / 2 * std::numbers::pi * dOut);
  m_A_in_shell =
      m_shellNumPipes *
      (2 * std::numbers::pi * m_shellDiameter * (m_shellLength - 0.5 * m_shellHeightDiff) +
       std::numbers::pi * m_shellHeightDiff / 2 * std::numbers::pi * m_shellDiameter);
  m_Cm_shell =
      m_shellNumPipes *
      (std::numbers::pi * (vmPower(dOut, 2) - vmPower(m_shellDiameter, 2)) / 4 *
           (m_shellLength - 0.5 * m_shellHeightDiff) * 2 +
       std::numbers::pi * m_shellHeightDiff / 2 *
           (std::numbers::pi * (vmPower(dOut, 2) - vmPower(m_shellDiameter, 2)) / 4));
  m_Cm_wall =
      (m_A_in_first + m_A_in_second) * m_thickness * m_density * m_heatCapacity;
  return true;
}

void gpaReboilerVolume::fillVarNames(gpaStringVector &varNames) const {
  const Indices &idx = getIndices();
  varNames[idx.PRESSURE] = "p";
  varNames[idx.FIRST_ENTHALPY] = "H";
  for (gpaUInt i = 0; i < idx.n; i++)
    varNames[idx.FIRST_FRAC_START + i] = "N" + gpaToString(i);
  varNames[idx.SECOND_ENTHALPY] = "H";
  for (gpaUInt i = 0; i < idx.n; i++)
    varNames[idx.SECOND_FRAC_START + i] = "N" + gpaToString(i);
  varNames[idx.WALL_TEMP] = "T";
  varNames[idx.SHELL_TEMP] = "T";
  varNames[idx.DELTA_PRES] = "P";
}

gpaResult gpaReboilerVolume::initVariables(gpaVector &variables) const {

  const gpaReboilerShape *shape = (gpaReboilerShape *)getShape();
  const gpaReal molesFirst =
      shape->getFirstVolume() / m_firstMedium->getMolarVolume();
  const gpaReal molesSecond =
      shape->getSecondVolume() / m_secondMedium->getMolarVolume();
  const Indices &idx = getIndices();

  // Initialize variables
  variables(idx.PRESSURE) = m_initPressure;

  // Gas phase
  variables(idx.FIRST_ENTHALPY) = molesFirst * m_firstMedium->getEnthalpy();
  for (gpaUInt i = 0; i < idx.n; i++) {
    variables(idx.FIRST_FRAC_START + i) = m_firstFractions[i] * molesFirst;
  }

  // Liquid phase
  variables(idx.SECOND_ENTHALPY) = molesSecond * m_secondMedium->getEnthalpy();
  for (gpaUInt i = 0; i < idx.n; i++) {
    variables(idx.SECOND_FRAC_START + i) = m_firstFractions[i] * molesSecond;
  }

  // Temperatures
  variables(idx.WALL_TEMP) = m_initTemperature;
  variables(idx.SHELL_TEMP) = m_initTemperature;
  variables(idx.DELTA_PRES) = 1;

  return GPA_RESULT_OK;
}

gpaResult gpaReboilerVolume::fillMassMatrix(gpaUInt refRow,
                                            gpaUInt refCol) const {
  // Gas energy
  const Indices &idx = getIndices();
  setMassMatrCoef(refRow + idx.FIRST_ENTHALPY_EQ, refCol + idx.FIRST_ENTHALPY,
                  1.0);

  // Gas components
  for (gpaUInt i = 0; i < idx.n; i++) {
    setMassMatrCoef(refRow + idx.FIRST_COMP_START + i,
                    refCol + idx.FIRST_FRAC_START + i, 1.0);
  }

  // Liquid energy
  setMassMatrCoef(refRow + idx.SECOND_ENTHALPY_EQ, refCol + idx.SECOND_ENTHALPY,
                  1.0);

  // Liquid components
  for (gpaUInt i = 0; i < idx.n; i++) {
    setMassMatrCoef(refRow + idx.SECOND_COMP_START + i,
                    refCol + idx.SECOND_FRAC_START + i, 1.0);
  }

  // Wall temperatures
  setMassMatrCoef(refRow + idx.WALL_TEMP_EQ, refCol + idx.WALL_TEMP, 1.0);
  setMassMatrCoef(refRow + idx.SHELL_TEMP_EQ, refCol + idx.SHELL_TEMP, 1.0);

  return GPA_RESULT_OK;
}

gpaResult gpaReboilerVolume::calcFuncValues(const gpaConstVector &,
                                            const gpaConstVector &variables,
                                            gpaVector &values,
                                            const gpaSetOfEquations &eqIds) {
  values = 0.0;
  const Indices &idx = getIndices();
  // 1. Unpack variables -------------------------------------------------
  const gpaReal P = variables(idx.PRESSURE); // [Pa]

  // Gas phase - calculate total moles from fractions
  m_firstEnthalpy = variables(idx.FIRST_ENTHALPY);

  // Liquid phase - calculate total moles from fractions
  m_secondEnthalpy = variables(idx.SECOND_ENTHALPY);

  // Wall temperatures and evaporation rate
  const gpaReal T_wall = variables(idx.WALL_TEMP);
  const gpaReal T_shell = variables(idx.SHELL_TEMP);
  const gpaReal dP = variables(idx.DELTA_PRES);

  gpaReal v_1 = m_firstMedium->getMolarVolume();
  gpaReal v_2 = m_secondMedium->getMolarVolume();
  gpaReal totalVolume = getShape()->getVolume();
  gpaReal totalHeight = getShape()->getHeight();
  const gpaReboilerShape *shape = (gpaReboilerShape *)getShape();

  if (m_savedVariables != variables) {
    // 2. Calculate molar fractions -----------------------------------------
    gpaResult res = m_firstMedium->prepareMolesTol(
        m_firstFractions,
        variables(idx.FIRST_FRAC_START, idx.FIRST_FRAC_START + idx.n),
        &m_firstMoles);
    res |= m_secondMedium->prepareMolesTol(
        m_secondFractions,
        variables(idx.SECOND_FRAC_START, idx.SECOND_FRAC_START + idx.n),
        &m_secondMoles);
    if (res != GPA_RESULT_OK)
      return res;

    // 3. Flash calculations -----------------------------------------------
    res = m_secondMedium->calcFlashPH(P, m_secondEnthalpy / m_secondMoles,
                                      m_secondFractions);
    res |= m_firstMedium->calcFlashPH(P, m_firstEnthalpy / m_firstMoles,
                                      m_firstFractions);
    if (res != GPA_RESULT_OK)
      return res;
    v_1 = m_firstMedium->getMolarVolume();
    v_2 = m_secondMedium->getMolarVolume();

    m_firstLiquidLevel = shape->getFirstLevelFor(
        (1 - m_firstMedium->getSteamContent()) * m_firstMoles *
        m_firstMedium->getLiquidMolarVolume());
    m_secondLiquidLevel = shape->getSecondLevelFor(
        (1 - m_secondMedium->getSteamContent()) * m_secondMoles *
        m_secondMedium->getLiquidMolarVolume());
    m_savedVariables = variables;
  }

  // 6. Process all ports ------------------------------------------------
  gpaElementMixCircuit *circuit = getMixCircuit(GPA_ELEM_CIRCUIT_0);
  gpaDataVector fractions(idx.n + 1);

  for (auto iter = circuit->firstPortIter(); iter != circuit->lastPortIter();
       ++iter) {
    const gpaUInt portID = iter->first;
    const gpaMixPort *port = iter->second;
    const gpaVolumeFittingData *fitting = getFittingData(portID);
    const gpaReal flowRate = port->getIncomingFlowRate();
    const gpaReal fittingHeight = fitting->getLevel();
    fractions = port->getStreamFractions();

    // 6.1 Calculate pressure at fitting height
    gpaReal P_fitting;
    if (isFirstSectionPort(portID))
      P_fitting =
          P + (m_firstMedium->getGasDensity() * GPA_GRAVITY_ACCELERATION *
                   (totalHeight - vmMax(fittingHeight, m_firstLiquidLevel)) +
               m_firstMedium->getLiquidDensity() * GPA_GRAVITY_ACCELERATION *
                   vmMax(m_firstLiquidLevel - fittingHeight, 0.)) /
                  GPA_KILOPASCAL_TO_PASCAL;
    else
      P_fitting =
          P + (m_secondMedium->getGasDensity() * GPA_GRAVITY_ACCELERATION *
                   (totalHeight - vmMax(fittingHeight, m_secondLiquidLevel)) +
               m_secondMedium->getLiquidDensity() * GPA_GRAVITY_ACCELERATION *
                   vmMax(m_secondLiquidLevel - fittingHeight, 0.)) /
                  GPA_KILOPASCAL_TO_PASCAL;

    // Pressure residual
    values(idx.NUM_EQNS + portID) = port->getStreamPressure() - P_fitting;

    gpaReal &H = isFirstSectionPort(portID) ? values(idx.FIRST_ENTHALPY_EQ)
                                            : values(idx.SECOND_ENTHALPY_EQ);
    gpaUInt fracs_start = isFirstSectionPort(portID) ? idx.FIRST_FRAC_START
                                                     : idx.SECOND_FRAC_START;
    H += port->getStreamEnthalpy() * flowRate;
    for (gpaUInt j = 0; j < idx.n; j++) {
      values(fracs_start + j) += flowRate * fractions(j);
    }
  }

  circuit = getMixCircuit(1);

  gpaMixPort *shellInlet = circuit->getPort(0);
  gpaMixPort *shellOutlet = circuit->getPort(1);
  gpaMedium *pipeMedium = circuit->getMedium()->copyTo(asOwner());

  gpaResult res = pipeMedium->calcFlashMiddle(shellInlet->getStreamMedium(),
                                              shellOutlet->getStreamMedium());
  if (res != GPA_RESULT_OK)
    return res;

  gpaReal dp_cacl =
      calcPressureGradient(shellInlet->getIncomingFlowRate(), pipeMedium) /
      GPA_KILOPASCAL_TO_PASCAL;
  values(idx.DELTA_PRES_EQ) = dP - dp_cacl;
  values(idx.FLOWRATE_EQ) =
      shellInlet->getIncomingFlowRate() + shellOutlet->getIncomingFlowRate();
  values(idx.PRESSURE_EQ) =
      shellInlet->getStreamPressure() - (shellOutlet->getStreamPressure() + dP);
  gpaReal Q_shell_in = m_A_in_shell * m_alpha_in_shell *
                       (pipeMedium->getTemperature() - T_shell);

  gpaReal Q_shell_out;
  if (m_firstLiquidLevel < m_shellMinHeight)
    Q_shell_out = m_A_out_shell * m_alpha_out_shell_gas *
                  (T_shell - m_firstMedium->getTemperature());
  else if (m_firstLiquidLevel > m_shellMinHeight &&
           m_firstLiquidLevel < m_shellMaxHeight) {
    gpaReal H_L_frac = (m_firstLiquidLevel - m_shellMinHeight) /
                       (m_shellMaxHeight - m_shellMinHeight);
    Q_shell_out = m_A_out_shell * m_alpha_out_shell_gas * H_L_frac *
                      (T_shell - m_firstMedium->getTemperature()) +
                  m_A_out_shell * m_alpha_out_shell_liq * (1 - H_L_frac) *
                      (m_firstMedium->getTemperature());
  } else {
    Q_shell_out = m_A_out_shell * m_alpha_out_shell_liq *
                  (T_shell - m_firstMedium->getTemperature());
  }

  // 7. Add phase transition effects -------------------------------------
  // Gas phase
  const gpaReal Q_G_first = m_A_in_first * m_alpha_first_gas *
                            m_firstMedium->getSteamContent() *
                            (m_firstMedium->getTemperature() - T_wall);
  const gpaReal Q_L_first = m_A_in_first * m_alpha_first_liq *
                            (1 - m_firstMedium->getSteamContent()) *
                            (m_firstMedium->getTemperature() - T_wall);
  const gpaReal Q_G_second = m_A_in_second * m_alpha_second_gas *
                             m_secondMedium->getSteamContent() *
                             (m_secondMedium->getTemperature() - T_wall);
  const gpaReal Q_L_second = m_A_in_second * m_alpha_second_liq *
                             (1 - m_secondMedium->getSteamContent()) *
                             (m_secondMedium->getTemperature() - T_wall);

  const gpaReal Q_out = (m_A_out_first + m_A_out_second) * (T_wall - m_T_env);

  auto [w_total, h_total] = calcFlowsInterphase(m_firstMoles, m_secondMoles);

  m_partitionFlowRate = w_total.sum();

  values(idx.FIRST_ENTHALPY_EQ) +=
      -Q_G_first - Q_L_first - h_total + Q_shell_out;

  for (gpaUInt j = 0; j < idx.n; j++) {
    values(idx.FIRST_COMP_START + j) -= w_total[j];
  }

  // Liquid phase
  values(idx.SECOND_ENTHALPY_EQ) += -Q_G_second - Q_L_second + h_total;

  for (gpaUInt j = 0; j < idx.n; j++) {
    values(idx.SECOND_COMP_START + j) += w_total[j];
  }

  // 8. Volume balance ---------------------------------------------------
  values(idx.VOLUME_BALANCE) =
      (totalVolume - v_1 * m_firstMoles - v_2 * m_secondMoles);

  // 9. Heat transfer equations ------------------------------------------

  // Wall temperature equations
  values(idx.WALL_TEMP_EQ) =
      (Q_G_first + Q_L_first + Q_G_second + Q_L_second - Q_out) / m_Cm_wall;
  values(idx.SHELL_TEMP_EQ) = (Q_shell_in + Q_shell_out) / m_Cm_shell;

  return GPA_RESULT_OK;
}

bool gpaReboilerVolume::isFirstSectionPort(gpaUInt portID) const {
  return ((m_portLocation >> portID) & 0x01) == 0;
}

gpaReal gpaReboilerVolume::calcPressureGradient(gpaReal Q, gpaMedium *medium) {
  gpaReal density = medium->getDensity();
  gpaReal viscosity = medium->getViscosity();
  gpaReal V = Q / (std::numbers::pi * std::numbers::pi * m_shellDiameter / 4.0);
  gpaReal Re = density * std::abs(V) * m_shellDiameter / viscosity;

  gpaReal F1 = 16 * Re;
  gpaReal F3 =
      0.07716 * Re * Re /
      std::pow(
          std::log10(6.9 / (Re + 1e-9) +
                     vmPower(m_shellRoughness / 3.7 / m_shellDiameter, 1.11)),
          2);

  gpaReal F2 = F1 + (Re - 2300.0) / 1700.0 * (F3 - F1);

  gpaReal X1 = (Re - 2300.0) / 300.0;
  gpaReal X2 = (Re - 4000.0) / 300.0;

  gpaReal f = (F1 * (1 - sigmoid(X1)) + F2 * sigmoid(X1)) * (1 - sigmoid(X2)) +
              F3 * sigmoid(X2);

  gpaReal length =
      2 * (m_shellLength - m_shellHeightDiff) + std::numbers::pi * m_shellHeightDiff / 2;

  gpaReal friction_dp = f * viscosity * viscosity * length / 2.0 / density /
                        std::pow(m_shellDiameter, 3);

  gpaReal dp = GPA_GRAVITY_ACCELERATION * m_minorCylynderHeight * density +
               friction_dp * ((V > 0) ? 1 : ((V < 0) ? -1 : 0));

  gpaReal dp_bends = 1 * 0.04 * density * vmPower(V, 2) / 2;

  return dp + dp_bends;
}

std::pair<gpaDataVector, gpaReal>
gpaReboilerVolume::calcFlowsInterphase(gpaReal firstMoles,
                                       gpaReal secondMoles) {
  gpaUInt n = m_firstMedium->getNumComponents();

  gpaReal Ng_1 =
      firstMoles *
      m_firstMedium->getSteamContent(); // Количество молей газа в первом объеме
  gpaReal Ng_2 =
      secondMoles *
      m_secondMedium
          ->getSteamContent(); // Количество молей газа во втором объеме
  gpaReal Nl_1 =
      firstMoles *
      (1 -
       m_firstMedium
           ->getSteamContent()); // Количество молей жидкости в первом объеме
  gpaReal Nl_2 =
      secondMoles *
      (1 -
       m_secondMedium
           ->getSteamContent()); // Количество молей жидкости во втором объеме

  gpaReal G_1_2 = vmMin(Ng_1, Ng_2) /
                  m_tauDiff; // Молярный расход газа из первого объема во второй

  gpaDataVector w_1 = m_firstMedium->getGasFractions();
  gpaDataVector w_2 = m_secondMedium->getGasFractions();

  gpaReal G_2_1 =
      G_1_2 * m_secondMedium->getGasDensity() / m_firstMedium->getGasDensity() *
      m_firstMedium->getGasMolarMass() / m_secondMedium->getGasMolarMass();

  gpaDataVector w_G(n);
  for (gpaUInt i = 0; i < n; i++)
    w_G[i] = G_1_2 * w_1[i] - G_2_1 * w_2[i];
  gpaReal h_G = G_1_2 * m_firstMedium->getGasEnthalpy() -
                G_2_1 * m_secondMedium->getGasEnthalpy();

  gpaReal v_l_1 =
      Nl_1 *
      m_firstMedium
          ->getLiquidMolarVolume(); // Физический объем жидкости в объеме 1
  gpaReal v_l_2 =
      Nl_2 *
      m_secondMedium
          ->getLiquidMolarVolume(); // Физический объем жидкости в объеме 2

  const gpaReboilerShape *shape = (gpaReboilerShape *)getShape();

  gpaReal G_L = 0;
  gpaReal h_L = 0;
  gpaDataVector w_L(n);
  w_1 = m_firstMedium->getLiquidFractions();
  w_2 = m_secondMedium->getLiquidFractions();
  if (m_firstLiquidLevel < m_partitionHeight &&
      m_secondLiquidLevel < m_partitionHeight) {
    G_L = 0;
    h_L = 0;
    w_L = 0.;
  } else if (m_firstLiquidLevel > m_partitionHeight &&
             m_secondLiquidLevel < m_partitionHeight) {
    gpaReal N_overflow =
        (v_l_1 - shape->getFirstVolumeAt(m_partitionHeight)) /
        m_firstMedium->getLiquidMolarMass(); // Количечство молей жидкости над
                                             // перегородкой
    G_L = N_overflow /
          m_tauLiq; // Молярный расход жидкости из первого объема во второй
    for (gpaUInt i = 0; i < n; i++)
      w_L[i] = G_L * w_1[i]; // Поток концентраций компонентов в первом объеме
    h_L = G_L *
          m_firstMedium->getLiquidEnthalpy(); // Поток энтальпии в первом объеме
  } else if (m_firstLiquidLevel < m_partitionHeight &&
             m_secondLiquidLevel > m_partitionHeight) {
    gpaReal N_overflow = (v_l_2 - shape->getSecondVolumeAt(m_partitionHeight)) /
                         m_secondMedium->getLiquidMolarMass();
    G_L = -N_overflow / m_tauLiq;
    for (gpaUInt i = 0; i < n; i++)
      w_L[i] = G_L * w_2[i];
    h_L = G_L * m_secondMedium->getLiquidEnthalpy();
  } else if (m_firstLiquidLevel > m_partitionHeight &&
             m_secondLiquidLevel > m_partitionHeight) {
    gpaReal G_L_diff_2_1 = m_liqDiffFlowrate *
                           m_secondMedium->getLiquidDensity() /
                           m_firstMedium->getLiquidDensity() *
                           m_firstMedium->getLiquidMolarMass() /
                           m_secondMedium->getLiquidMolarMass();
    gpaDataVector liq_flow_diff_j(n);
    for (gpaUInt i = 0; i < n; i++)
      liq_flow_diff_j[i] = m_liqDiffFlowrate * w_1[i] - G_L_diff_2_1 * w_2[i];
    gpaReal liq_H_flow_diff =
        m_liqDiffFlowrate * m_firstMedium->getLiquidEnthalpy() -
        G_L_diff_2_1 * m_secondMedium->getLiquidEnthalpy();
    gpaReal x = (m_firstLiquidLevel - m_secondLiquidLevel) / 1e-9;
    gpaReal Y = 1 / (1 + exp(x));
    gpaReal N_L_1 = (shape->getFirstVolumeAt(m_firstLiquidLevel) -
                     shape->getFirstVolumeAt(m_secondLiquidLevel)) /
                    m_firstMedium->getLiquidMolarMass();
    gpaReal N_L_2 = (shape->getSecondVolumeAt(m_secondLiquidLevel) -
                     shape->getSecondVolumeAt(m_firstLiquidLevel)) /
                    m_secondMedium->getLiquidMolarMass();
    gpaReal G_L_grav =
        N_L_1 / m_tauLiq * Y -
        N_L_2 / m_tauLiq * (1 - Y); // Знакопеременный расход, т.к. инвариантен
    gpaDataVector w_flow_L_grav(n);
    for (gpaUInt i = 0; i < n; i++)
      w_flow_L_grav[i] = G_L_grav * (w_1[i] * Y + w_2[i] * (1 - Y));
    gpaReal h_flow_L_grav =
        G_L_grav * (m_firstMedium->getLiquidEnthalpy() * Y +
                    m_secondMedium->getLiquidEnthalpy() * (1 - Y));
    G_L = G_L_diff_2_1 + G_L_grav;
    w_L = liq_flow_diff_j + w_flow_L_grav;
    h_L = liq_H_flow_diff + h_flow_L_grav;
  }

  gpaDataVector w_total = w_G + w_L;
  gpaReal h_total = h_G + h_L;
  if (std::isnan(h_total))
    printf("qwjdnkqjwd");
  return {w_total, h_total};
}

gpaResult gpaReboilerVolume::calcEnthalpyFuncValueAt(gpaUInt circIdx,
                                                     gpaUInt portIdx,
                                                     gpaReal enthalpy,
                                                     gpaReal &funcValue) const {
  if (circIdx != GPA_ELEM_CIRCUIT_0) {
    gpaMixPort *oppPort = getMixCircuit(circIdx)->getPort(1 - portIdx);
    gpaReal portEnthalpy = oppPort->getStreamEnthalpy();
    funcValue = enthalpy - portEnthalpy;
    printf("Enthalpy for circuit 1 port %d: %f\n", portIdx, funcValue);
    return GPA_RESULT_OK;
  }
  const gpaVolumeFittingData *data = getFittingData(portIdx);
  if (!data)
    return GPA_ERROR_WRONG_ARGS;

  gpaReal level =
      isFirstSectionPort(portIdx) ? m_firstLiquidLevel : m_secondLiquidLevel;
  gpaMedium *medium =
      isFirstSectionPort(portIdx) ? m_firstMedium : m_secondMedium;
  gpaReal x = (data->getLevel() - level) / 1e-3;
  gpaReal Y = 1 / (1 + exp(-x));
  funcValue = enthalpy - medium->getGasEnthalpy() * Y -
              m_firstMedium->getLiquidEnthalpy() * (1 - Y);
  printf("Enthalpy for %d: %f\n", portIdx, funcValue);
  return GPA_RESULT_OK;
}

gpaResult
gpaReboilerVolume::calcFractionsFuncValuesAt(gpaUInt circIdx, gpaUInt portIdx,
                                             const gpaConstVector &fractions,
                                             gpaVector &funcValues) const {
  if (circIdx != GPA_ELEM_CIRCUIT_0) {
    gpaMixPort *oppPort = getMixCircuit(circIdx)->getPort(1 - portIdx);
    gpaDataVector portFractions = oppPort->getStreamFractions();
    for (gpaUInt i = 0; i < funcValues.size(); i++) {
      funcValues[i] = fractions[i] - portFractions[i];
    }
    return GPA_RESULT_OK;
  }
  const gpaVolumeFittingData *data = getFittingData(portIdx);
  if (!data)
    return GPA_ERROR_WRONG_ARGS;

  gpaReal level =
      isFirstSectionPort(portIdx) ? m_firstLiquidLevel : m_secondLiquidLevel;
  gpaMedium *medium =
      isFirstSectionPort(portIdx) ? m_firstMedium : m_secondMedium;
  gpaReal x = (data->getLevel() - level) / 1e-3;
  gpaReal Y = 1 / (1 + exp(-x));

  gpaConstVector gasFractions = medium->getGasFractions();
  gpaConstVector liquidFractions = medium->getLiquidFractions();
  printf("Fractions are: ");
  for (gpaUInt i = 0; i < funcValues.size(); i++) {
    funcValues[i] =
        fractions[i] - gasFractions[i] * Y - liquidFractions[i] * (1 - Y);
    printf("%f\t", funcValues[i]);
  }
  printf("\n");
  return GPA_RESULT_OK;
}
