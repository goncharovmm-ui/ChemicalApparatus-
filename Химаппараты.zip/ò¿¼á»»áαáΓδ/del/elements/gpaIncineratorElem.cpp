#include "gpaIncineratorElem.h"
#include "gpaMixType.h"
#include <cassert>
#include <gpaMixture.h>
#include <memory>
#include <numbers>

constexpr gpaUInt ID_PORT_INLET = 0;
constexpr gpaUInt ID_PORT_OUTLET = 1;

const gpaString initPresErrorStr = "Initial volume pressure must be positive";
const gpaString initTempErrorStr =
    "Initial volume temperature must be positive";
const gpaString initFractErrorStr =
    "Initial mole fractions must be in range [0,1] and their sum is less or "
    "equal to 1.0";
const gpaString liqHeatTransCoefErrorStr =
    "Gas-wall heat transfer coefficient must be non-negative";
const gpaString gasHeatTransCoefErrorStr =
    "Liquid-wall heat transfer coefficient must be non-negative";

const gpaString gpaIncineratorElem::m_typeName = "incinerator";
const gpaString gpaIncineratorElem::m_description = "";

enum class gpaIncVars : std::uint8_t {
    outOxygenFraction, // Err: Переназвать переменную

    COUNT
};

enum class gpaIncFuncs : std::uint8_t {
    rate,
    excessOxygen,
    deltaPressure,

    COUNT
};

gpaIncineratorElem::gpaIncineratorElem(const gpaParentLink *link)
    : gpaLongFlow(link), m_enthalpy(0.0) {}

gpaIncineratorElem::gpaIncineratorElem(const gpaIncineratorElem &expander) {
    // Err: implement this method
}

gpaIncineratorElem::~gpaIncineratorElem() {
    if (m_medium != 0) {
        delete m_medium;
        delete m_medium_mixin;
    }
}

gpaIncineratorElem *gpaIncineratorElem::copy() const {
    return new gpaIncineratorElem(*this);
}

gpaUInt gpaIncineratorElem::getMinNumMixPorts(gpaUInt index) const {
    switch (index) {
    case GPA_ELEM_CIRCUIT_0:
        return 2;
        break;
    default:
        return 0;
        break;
    }
}

gpaUInt gpaIncineratorElem::getMaxNumMixPorts(gpaUInt index) const {
    switch (index) {
    case GPA_ELEM_CIRCUIT_0:
        return 2;
        break;
    default:
        return 0;
        break;
    }
}

gpaUInt gpaIncineratorElem::getNumVariables() const {
    return _u(gpaIncVars::COUNT);
}

gpaResult gpaIncineratorElem::initialize() {
    const gpaMedium *medium = getCircuitMediumAt(GPA_ELEM_CIRCUIT_0);
    if (!medium)
        return GPA_ERROR_WRONG_ARGS;
    if (!medium->supportsFlash(PS_FLASH) || !medium->supportsFlash(PH_FLASH))
        return GPA_ERROR_UNSUPPORTED;
    // if (!m_burn_model->isMediumValid(medium))
    //     return GPA_ERROR_UNSUPPORTED;
    m_medium = medium->copyTo(asOwner());
    m_medium_mixin = medium->copyTo(asOwner());
    m_fractions.assign(m_medium->getFractions());

    if (m_oxygen_id = m_medium->getMixType()->getComponentIndexByName("O2");
        m_oxygen_id == GPA_BAD_NUMBER)
        return GPA_ERROR_WRONG_ARGS;

    if (m_NO_id = m_medium->getMixType()->getComponentIndexByName("NO");
        m_NO_id == GPA_BAD_NUMBER)
        return GPA_ERROR_WRONG_ARGS;

    if (m_NO2_id = m_medium->getMixType()->getComponentIndexByName("NO2");
        m_NO2_id == GPA_BAD_NUMBER)
        return GPA_ERROR_WRONG_ARGS;

    if (m_nitro_id = m_medium->getMixType()->getComponentIndexByName("N2");
        m_nitro_id == GPA_BAD_NUMBER)
        return GPA_ERROR_WRONG_ARGS;

    return GPA_RESULT_OK;
}

void gpaIncineratorElem::fillVarNames(gpaStringVector &varNames) const {
    varNames[_u(gpaIncVars::outOxygenFraction)] = "outOxygenFraction";
}

gpaResult gpaIncineratorElem::initVariables(gpaVector &variables) const {
    // Err: init from user-required value
    variables[_u(gpaIncVars::outOxygenFraction)] = 1.0;

    return GPA_RESULT_OK;
}

void gpaIncineratorElem::fillEquationNames(gpaStringVector &eqNames) const {
    eqNames[_u(gpaIncFuncs::rate)] = "rate";
    eqNames[_u(gpaIncFuncs::excessOxygen)] = "excessOxygen";
    eqNames[_u(gpaIncFuncs::deltaPressure)] = "deltaPressure";
}

gpaResult gpaIncineratorElem::calcFuncValues(const gpaConstVector &,
                                             const gpaConstVector &variables,
                                             gpaVector &values,
                                             const gpaSetOfEquations &) {
    // init variables
    const auto inletPort = getMixPort(GPA_ELEM_CIRCUIT_0, ID_PORT_INLET);
    const gpaReal G = inletPort->getIncomingFlowRate();
    const gpaConstVector inputFractions = inletPort->getStreamFractions();
    const gpaReal pressure = inletPort->getStreamPressure();
    const gpaReal in_temperature = inletPort->getStreamTemperature();

    ////////////////////////////////
    gpaReal number_active_burn = m_burner1_switch + m_burner2_switch +
                                 m_burner3_switch + m_burner4_switch +
                                 m_burner5_switch;
    if (vmAbs(G) > 1e-6 && number_active_burn > .5) {
        if (auto res =
                calcReaction(variables[_u(gpaIncVars::outOxygenFraction)]);
            res != GPA_RESULT_OK)
            return res;
    } else {
        // Err: Почему необходимо обнулять заданную пользователем константу?
        // Если солвер на итерациях выйдет в область малых расходов, а затем
        // обратно, то расчет испортится m_excess_oxygen = 0;
        m_enthalpy = inletPort->getStreamEnthalpy();
        std::copy_n(inputFractions.data(), inputFractions.size(),
                    m_fractions.data());
    }

    m_burner1_temp =
        m_burner1_switch > 0 ? m_medium->getTemperature() : in_temperature;
    m_burner2_temp = (m_burner2_switch > 0 && m_num_burner > 1)
                         ? m_medium->getTemperature()
                         : in_temperature;
    m_burner3_temp = (m_burner3_switch > 0 && m_num_burner > 2)
                         ? m_medium->getTemperature()
                         : in_temperature;
    m_burner4_temp = (m_burner4_switch > 0 && m_num_burner > 3)
                         ? m_medium->getTemperature()
                         : in_temperature;
    m_burner5_temp = (m_burner5_switch > 0 && m_num_burner > 4)
                         ? m_medium->getTemperature()
                         : in_temperature;

    m_oxygen_last = m_fractions[m_oxygen_id];
    m_NO2_out = m_fractions[m_NO2_id];
    m_NO_out = m_fractions[m_NO_id];

    if (auto res = m_medium->calcFlashPH(pressure, m_enthalpy, m_fractions);
        res != GPA_RESULT_OK)
        return res;

    gpaElementMixCircuit *circuit = getMixCircuit(GPA_ELEM_CIRCUIT_0);
    values[_u(gpaIncFuncs::rate)] =
        circuit->getPort(ID_PORT_OUTLET)->getIncomingFlowRate() +
        (1.0 + m_oxygen_needed) *
            circuit->getPort(ID_PORT_INLET)->getIncomingFlowRate();

    if (vmAbs(G) > 1e-6 && number_active_burn > .5)
        values[_u(gpaIncFuncs::excessOxygen)] =
            m_excess_oxygen - m_fractions[m_oxygen_id];
    else
        // Err: почему доля кислорода в выходном потоке должна стать равной 1?
        values[_u(gpaIncFuncs::excessOxygen)] =
            variables[_u(gpaIncVars::outOxygenFraction)] - 1;

    values[_u(gpaIncFuncs::deltaPressure)] =
        circuit->getPort(ID_PORT_OUTLET)->getStreamPressure() -
        circuit->getPort(ID_PORT_INLET)->getStreamPressure() +
        m_pressure_model->calcDeltaPressure(G, m_medium);
    return GPA_RESULT_OK;
}

gpaResult
gpaIncineratorElem::calcEnthalpyFuncValueAt(gpaUInt, gpaUInt, gpaReal enthalpy,
                                            gpaReal &funcValue) const {
    funcValue = enthalpy - m_enthalpy;
    return GPA_RESULT_OK;
}

gpaResult
gpaIncineratorElem::calcFractionsFuncValuesAt(gpaUInt, gpaUInt,
                                              const gpaConstVector &fractions,
                                              gpaVector &funcValues) const {
    for (gpaUInt i = 0; i < funcValues.size(); i++)
        // Err: не учитывается изменение общего числа молей смеси
        funcValues[i] = fractions[i] - m_fractions[i];
    return GPA_RESULT_OK;
}

bool gpaIncineratorElem::setPressureModel(
    std::unique_ptr<PressureGradientModel> model) {
    m_pressure_model = std::move(model);
    return true;
}

bool gpaIncineratorElem::setGeometry(gpaReal diameter, gpaReal length) {
    m_diameter = diameter;
    m_length = length;
    return true;
}

bool gpaIncineratorElem::setHeatTransferCoef(gpaReal coef) {
    m_alpha = coef;
    return true;
}

bool gpaIncineratorElem::setOxidationCoef(gpaReal k_CO_2, gpaReal k_NO_2) {
    m_k_CO_2 = k_CO_2;
    m_k_NO_2 = k_NO_2;
    return true;
}

bool gpaIncineratorElem::setRadiationLossCoef(gpaReal coef) {
    m_radLossCoef = coef;
    return true;
}

gpaReal gpaIncineratorElem::getHeatArea() const {
    return std::numbers::pi * m_diameter * m_length;
}

gpaReal gpaIncineratorElem::getCrossArea() const {
    return std::numbers::pi * m_diameter * m_diameter * 0.25;
}

gpaReal gpaIncineratorElem::getHeatTransferCoef() const { return m_alpha; }

gpaReal gpaIncineratorElem::calcFrictionFunc(gpaReal, gpaReal) const {
    return 0.0;
}

gpaResult gpaIncineratorElem::calcReaction(gpaReal outOxygenFraction) {
    const auto inletPort = getMixPort(GPA_ELEM_CIRCUIT_0, ID_PORT_INLET);
    const gpaReal inPressure = inletPort->getStreamPressure();
    const gpaConstVector inputFractions = inletPort->getStreamFractions();

    const gpaMixture *mixture = dynamic_cast<gpaMixture *>(m_medium);
    m_oxygen_needed =
        outOxygenFraction * mixture->calcOxygenConsumptionForCombustion(
                                m_k_CO_2, m_k_NO_2, inputFractions);
    const gpaReal incoming_flow = inletPort->getIncomingFlowRate();
    const gpaUInt n = m_medium->getNumComponents();
    gpaDataVector mixidFractions(new vmReal[n], n);

    std::fill_n(mixidFractions.data(), mixidFractions.size(), 0.0);
    mixidFractions(m_oxygen_id) += vmMax(0.0, m_oxygen_needed);
    mixidFractions(m_nitro_id) += vmMax(0.0, 3.9 * m_oxygen_needed);
    gpaMedium::prepareMolesTol(mixidFractions, mixidFractions);

    if (auto res =
            m_medium_mixin->calcFlashPT(inPressure, m_ari_temp, mixidFractions);
        res != GPA_RESULT_OK)
        return res;

    gpaReal enthalpy = inletPort->getStreamEnthalpy();
    enthalpy = (enthalpy + m_oxygen_needed * m_medium_mixin->getEnthalpy()) /
               (1 + m_oxygen_needed);
    std::copy_n(inputFractions.data(), n, mixidFractions.data());

    mixidFractions(m_oxygen_id) += vmMax(0.0, m_oxygen_needed);
    mixidFractions(m_nitro_id) += vmMax(0.0, 3.9 * m_oxygen_needed);
    gpaMedium::prepareMolesTol(mixidFractions, mixidFractions);

    if (auto res =
            m_medium_mixin->calcFlashPH(inPressure, enthalpy, mixidFractions);
        res != GPA_RESULT_OK)
        return res;

    gpaVector outFractions(new vmReal[n], n);
    if (auto res = mixture->calcCombustionProducts(
            m_k_CO_2, m_k_NO_2, mixidFractions, outFractions);
        res != GPA_RESULT_OK)
        return res;

    m_fractions = outFractions;
    gpaMedium::prepareInitFractions(m_fractions);

    m_Q_reaction = 0;
    if (auto res = mixture->calcMixCombustionHigherHeatingValue(
            inPressure, m_medium_mixin->getTemperature(), m_k_CO_2, m_k_NO_2,
            mixidFractions, m_Q_reaction);
        res != GPA_RESULT_OK)
        return res;

    gpaReal enthalpy_reaction = (1 - m_radLossCoef) * m_Q_reaction;
    m_q_stream = m_Q_reaction * incoming_flow;

    m_enthalpy = enthalpy + enthalpy_reaction;
    if (auto res = m_medium->calcFlashPH(inPressure, m_enthalpy, m_fractions);
        res != GPA_RESULT_OK)
        return res;

    return GPA_RESULT_OK;
}
