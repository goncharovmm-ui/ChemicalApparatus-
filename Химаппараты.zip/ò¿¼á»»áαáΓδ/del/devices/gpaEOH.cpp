#include "gpaEOH.h"
#include <iostream>

constexpr gpaUInt NUM_CIRCUITS          = 1;

constexpr gpaUInt ID_CIRCUIT = 0;

constexpr gpaUInt ID_PORT_GAS_INLET = 0;
constexpr gpaUInt ID_PORT_GAS_OUTLET = 1;

constexpr gpaUInt NUM_PORTS          = 2;

// Перечень параметров для расчета 

enum id_Param: gpaUInt {
    //Перечень входных геометрических параметров КР (RC - radiation chamber) 7
    ID_PARAM_TEMP_TEH_bundle_INIT               =0,
    ID_PARAM_TEH_bundle_Power,
    ID_PARAM_TEH_amount,
    ID_PARAM_len_HE_zone,
    ID_PARAM_d_TEH,
    ID_PARAM_TEH_Row, 
    ID_PARAM_s1, 
    ID_PARAM_s2,     
    ID_PARAM_d_inner_oil_ch,
    ID_PARAM_amount_of_sections,
    ID_PARAM_cp_TEH_bundle,
    ID_PARAM_mass_TEH,
    ID_PARAM_coef_deltaP_Valve,
    ID_PARAM_k_delta_H,
    ID_PARAM_k_delta_DP,
};

// sensors
constexpr gpaUInt ID_SENSOR_T_in_oil                 = 0;
constexpr gpaUInt ID_SENSOR_T_out_oil                = 1;
constexpr gpaUInt ID_SENSOR_temp_TEH_bundle          = 2;
constexpr gpaUInt ID_SENSOR_HE_area                  = 3;
constexpr gpaUInt ID_SENSOR_alpha_oil                = 4;
constexpr gpaUInt ID_SENSOR_Q_from_TEH_bundle_to_oil = 5;
constexpr gpaUInt ID_SENSOR_Delta_H_oil              = 6;
constexpr gpaUInt ID_SENSOR_delta_P_oil              = 7;
constexpr gpaUInt ID_SENSOR_m_dot_oil                = 8;
constexpr gpaUInt ID_SENSOR_len_of_section           = 9;

const gpaString gpaEOH::m_typeName      = "EOH";
const gpaString gpaEOH::m_description   = "Электрический подогреватель масла";

const gpaStringVector gpaEOH::m_circuitNames =
{
    "Маслянной контур",
};

const gpaStringVector gpaEOH::m_portNames =
{
    "Вход",
    "Выход",
};



const gpaParameterInfoVector gpaEOH::m_parameters =
{
    realParam("TEMP_TEH_bundle_INIT",  "Начальная средняя температура пучка ТЭНов",   GPA_DIMLESS_UNIT,     false, 20),
    realParam("TEH_bundle_Power",   "Электрическая мощность пучка ТЭНов, кВт",       GPA_DIMLESS_UNIT,     true, 180),
    realParam("TEH_amount",   "Количество ТЭН ",       GPA_DIMLESS_UNIT,     false, 45),
    realParam("len_HE_zone",   "Длина зоны теплоотдачи",       GPA_LENGTH_UNIT,     false, 2.7), 
   
    realParam("d_TEH",   "Внешний диаметр ТЭН",       GPA_LENGTH_UNIT,     false, 0.012),
    realParam("TEH_Row",   "Кол-во рядов труб",       GPA_DIMLESS_UNIT,     false, 10),
    realParam("s1",   "Продольное расстояние между трубами",       GPA_LENGTH_UNIT,     false, 0.023),
    realParam("s2",   "Поперечное расстояние между трубами",       GPA_LENGTH_UNIT,     false, 0.020),   
    
    realParam("d_inner_oil_ch",   "Внутренний диаметр трубы с маслом и трубным пучком",       GPA_LENGTH_UNIT,     false, 0.18),
    realParam("amount_of_sections",   "Кол-во секций пучка труб",       GPA_DIMLESS_UNIT,     false, 5),
    realParam("cp_TEH_bundle",   "Средняя теплоемкость материала ТЭН, кДж/(кг * К)",       GPA_DIMLESS_UNIT,     false, 0.75),
    realParam("mass_TEH",   "Масса ТЭН, кг",       GPA_MASS_UNIT,     false, 2.4),
    
    realParam("coef_deltaP_Valve",   "Коэффициент открытия клапана",       GPA_DIMLESS_UNIT,     false, 0.001),
    realParam("k_delta_H",   "Коэффициент коррекции теплообмена",       GPA_DIMLESS_UNIT,     false, 1),
    realParam("k_delta_DP",   "Коэффициент коррекции перепала давления",       GPA_DIMLESS_UNIT,     false, 1),
    
  
};

const gpaSensorInfoVector gpaEOH::m_sensors =
{
    //6 
    scalarSensor("T_in_oil", "Температура масла на входе", GPA_TEMPERATURE_UNIT),
    scalarSensor("T_out_oil", "Температура масла на выходе", GPA_TEMPERATURE_UNIT),
    scalarSensor("temp_TEH_bundle", "Средняя температура пучка ТЭНов", GPA_TEMPERATURE_UNIT),
    scalarSensor("HE_area", "Площадь теплообмена", GPA_AREA_UNIT),
    scalarSensor("alpha_oil", "Удельный коэффициент теплоотдачи, кВт/(м^2*К) ", GPA_DIMLESS_UNIT),
    scalarSensor("Q_from_TEH_bundle_to_oil", "Тепловая мощность снимаемая маслом с поверхности пучка ТЭНов, кВт", GPA_DIMLESS_UNIT),
    scalarSensor("Delta_H_oil", "Изменение энтальпии масла, Дж/моль", GPA_DIMLESS_UNIT),
    scalarSensor("delta_P_oil", "Перепад давлений по маслу", GPA_PRESSURE_UNIT),
    scalarSensor("m_dot_oil", "Массовый расход входящего масла", GPA_MASS_RATE_UNIT),
    scalarSensor("len_of_section", "Длина секции пучка труб", GPA_LENGTH_UNIT),
};

gpaEOH::gpaEOH(const gpaCoreInterfaces* interfaces, gpaCoreReference importRef) :
    gpaExportSystem (interfaces, importRef),
    m_heatPipes      (asParent())
{
}

gpaResult gpaEOH::calcSensors(gpaVector& sensors) const
{

    setSensorValue(sensors, ID_SENSOR_T_in_oil,      m_heatPipes.T_in_oil - 273.15); //
    setSensorValue(sensors, ID_SENSOR_T_out_oil,      m_heatPipes.T_out_oil - 273.15);//T_in_oil - 273.15
    setSensorValue(sensors, ID_SENSOR_temp_TEH_bundle,     m_heatPipes.temp_TEH_bundle - 273.15);//T_out_oil - 273.15

    setSensorValue(sensors, ID_SENSOR_HE_area,    m_heatPipes.HE_area);
    setSensorValue(sensors, ID_SENSOR_alpha_oil,         m_heatPipes.alpha_oil);//

    setSensorValue(sensors, ID_SENSOR_Q_from_TEH_bundle_to_oil,         m_heatPipes.Q_from_TEH_bundle_to_oil);//

    setSensorValue(sensors, ID_SENSOR_Delta_H_oil,         m_heatPipes.Delta_H_oil);//
    setSensorValue(sensors, ID_SENSOR_delta_P_oil,         m_heatPipes.delta_P_oil);//

    setSensorValue(sensors, ID_SENSOR_m_dot_oil,         m_heatPipes.m_dot_oil);//

    setSensorValue(sensors, ID_SENSOR_len_of_section,         m_heatPipes.len_of_section);//

    return GPA_RESULT_OK;
}
gpaResult gpaEOH::checkParamValues(const gpaExtParameter *values) const
{
    (void)values;
    return GPA_RESULT_OK;
}

void gpaEOH::setNames()
{
    m_heatPipes.setName("pipes");
}

gpaResult gpaEOH::initMixtureFlow(const gpaExtParameter *values)
{
    // Назначаем параметры проточных элементов
    bool good = true;
    return GPA_RESULT_OK;
}

gpaResult gpaEOH::setParamValues(const gpaExtParameter *values, bool checkNeeded)
{


    //Передача введенных параметров
    m_heatPipes.TEMP_TEH_bundle_INIT = values[ID_PARAM_TEMP_TEH_bundle_INIT].value.realValue;
    m_heatPipes.TEH_bundle_Power = values[ID_PARAM_TEH_bundle_Power].value.realValue;
    m_heatPipes.TEH_amount = values[ID_PARAM_TEH_amount].value.realValue;
    m_heatPipes.len_HE_zone  = values[ID_PARAM_len_HE_zone]  .value.realValue;
    
    m_heatPipes.d_TEH    = values[ID_PARAM_d_TEH]  .value.realValue;
    m_heatPipes.TEH_Row    = values[ID_PARAM_TEH_Row]  .value.realValue;
    m_heatPipes.s1    = values[ID_PARAM_s1]  .value.realValue;
    m_heatPipes.s2    = values[ID_PARAM_s2]  .value.realValue;
   
    m_heatPipes.d_inner_oil_ch    = values[ID_PARAM_d_inner_oil_ch]  .value.realValue;
    m_heatPipes.amount_of_sections    = values[ID_PARAM_amount_of_sections]  .value.realValue;
    m_heatPipes.cp_TEH_bundle =   values[ID_PARAM_cp_TEH_bundle]  .value.realValue;
    m_heatPipes.mass_TEH = values[ID_PARAM_mass_TEH].value.realValue;
   
    m_heatPipes.coef_deltaP_Valve = values[ID_PARAM_coef_deltaP_Valve].value.realValue;
    m_heatPipes.k_delta_H = values[ID_PARAM_k_delta_H].value.realValue;
    m_heatPipes.k_delta_DP = values[ID_PARAM_k_delta_DP].value.realValue;
    



    // Проверка параметров, если требуется
    if (checkNeeded)
    {
        gpaResult res = checkParamValues(values);
        if (res != GPA_RESULT_OK)
            return res;
    }
    // Даем названия элементам и потокам
    setNames();
    // Инициализируются элементы с потоком смеси
    gpaResult res = initMixtureFlow(values);
    if (res != GPA_RESULT_OK)
        return res;
    // Обновляем параметры воздуха на входе
    return res;
}

gpaResult gpaEOH::buildDevice()
{
    bool good = true;
    std::cout<<"buildDevice ------------------------------------------------"<<"\n";
    // Соединяем поток смеси по трубам с граничными потоками смеси системы
    good = good && m_heatPipes.connectMixStream(GPA_ELEM_CIRCUIT_0, ID_PORT_GAS_INLET,  getEdgeMixStream(ID_CIRCUIT,   ID_PORT_GAS_INLET),  GPA_STREAM_INLET);
    good = good && m_heatPipes.connectMixStream(GPA_ELEM_CIRCUIT_0, ID_PORT_GAS_OUTLET, getEdgeMixStream(ID_CIRCUIT,   ID_PORT_GAS_OUTLET), GPA_STREAM_OUTLET);
     std::cout<<"buildDevice goof"<<good <<"\n";
    if (!good)
        return GPA_ERROR_WRONG_ARGS;
    // Добавляем в систему все элементы и потоки
    setElements({&m_heatPipes});
    setStreams({});
    std::cout<<"buildDevice 2"<<"\n";
    return GPA_RESULT_OK;
}

gpaResult gpaEOH::initialize()
{
    // Подключить экспортируемый элемент к потокам в интеграторе
    std::cout<<"initialize ------------------------------------------------"<<"\n";
    gpaResult res = linkToCoreStreams();
    if (res != GPA_RESULT_OK)
        return res;
    // Соединяем все элементы друг с другом
    res = buildDevice();
    if (res != GPA_RESULT_OK)
        return res;
    // Создаем схемы течений (нужны соединенные элементы)
    if (!createSimStructures({}, {getOuterEntrance(ID_CIRCUIT, ID_PORT_GAS_INLET)}))
        return GPA_ERROR_WRONG_ARGS;
    // Инициализируем систему
    return gpaExportSystem::initialize();
}

gpaResult gpaEOH::setSignals(const gpaConstVector &signals)
{

    gpaReal value;
    bool good = true;

    if (getSignalValue(signals, ID_PARAM_TEH_bundle_Power, value))
    m_heatPipes.TEH_bundle_Power               = value;

    // if (getSignalValue(signals, ID_PARAM_coef_deltaP_Valve, value))
    // m_heatPipes.coef_deltaP_Valve =   value;

    return GPA_RESULT_OK;
}
const gpaString* gpaEOH::getDeviceMixCircuitName(gpaUInt index)
{
    return index < NUM_CIRCUITS ? &m_circuitNames[index] : NULL;
}
const gpaString* gpaEOH::getDeviceMixPortName(gpaUInt circIdx, gpaUInt portIdx)
{
    if (circIdx == ID_CIRCUIT)
         return portIdx < NUM_PORTS ? &m_portNames[portIdx] : NULL;
    return NULL;
}





