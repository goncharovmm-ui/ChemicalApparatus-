#include "gpaTDBaseVerSimpleInfo.h"
#include "gpaTDBaseVerSimple.h"



gpaTDBaseVerSimpleInfo::gpaTDBaseVerSimpleInfo() :
    gpaDeviceInfo  (gpaTDBaseVerSimple::getDeviceTypeName(),
                    gpaTDBaseVerSimple::getDeviceDescription())
{
    setParameters(gpaTDBaseVerSimple::getParametersInfo());
    setSensors(gpaTDBaseVerSimple::getSensorsInfo());
}

gpaUInt gpaTDBaseVerSimpleInfo::getNumMixCircuits() const
{
    return gpaTDBaseVerSimple::getDeviceNumMixCircuits();
}

gpaUInt gpaTDBaseVerSimpleInfo::getMinNumMixPorts(gpaUInt index) const
{
    return gpaTDBaseVerSimple::getDeviceMinNumMixPorts(index);
}

gpaUInt gpaTDBaseVerSimpleInfo::getMaxNumMixPorts(gpaUInt index) const
{
    return gpaTDBaseVerSimple::getDeviceMaxNumMixPorts(index);
}
const gpaString *gpaTDBaseVerSimpleInfo::getMixPortName(gpaUInt circIdx, gpaUInt portIdx) const
{
    return gpaTDBaseVerSimple::getDeviceMixPortName(circIdx, portIdx);
}

const gpaString *gpaTDBaseVerSimpleInfo::getMixCircuitName(gpaUInt index) const
{
    return gpaTDBaseVerSimple::getDeviceMixCircuitName(index);
}



gpaElement* gpaTDBaseVerSimpleInfo::createDevice(const gpaCoreInterfaces* interfaces, gpaCoreReference pairDevice,
                                             const gpaExtObjectModel* model) const
{
    gpaTDBaseVerSimple* cooler = new gpaTDBaseVerSimple(interfaces, pairDevice);
    gpaResult res = cooler->specifyModel(model);
    if (res == GPA_RESULT_OK)
        return cooler;
    delete cooler;
    return NULL;
}
